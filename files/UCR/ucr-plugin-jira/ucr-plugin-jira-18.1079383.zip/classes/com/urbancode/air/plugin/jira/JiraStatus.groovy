/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Release
* (c) Copyright IBM Corporation 2011, 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.jira;

import org.codehaus.jettison.json.JSONObject;
import com.urbancode.commons.webext.util.JSONUtilities;
import org.codehaus.jettison.json.JSONTokener;
import org.codehaus.jettison.json.JSONException;
public class JiraStatus {

    //**********************************************************************************************
    // CLASS
    //**********************************************************************************************

    //**********************************************************************************************
    // INSTANCE
    //**********************************************************************************************
    final private String name;
    final private String id;
    //----------------------------------------------------------------------------------------------
    public JiraStatus(JSONObject json,def jiraStatusestypes)  throws JSONException {
        if(!jiraStatusestypes){
            name = JSONUtilities.getStringFromJsonObject(json, "name");
            id = JSONUtilities.getStringFromJsonObject(json, "id");
        }
        else{
           String jsonCategory=JSONUtilities.getStringFromJsonObject(json, "statusCategory");
           JSONObject cJson = new JSONObject(new JSONTokener(jsonCategory));
           name = JSONUtilities.getStringFromJsonObject(cJson, "name");
           id = JSONUtilities.getStringFromJsonObject(cJson, "id");
        }
        
    }

    //----------------------------------------------------------------------------------------------
    public String getName() {
        return name;
    }

    //----------------------------------------------------------------------------------------------
    public String getId() {
        return id;
    }
}
