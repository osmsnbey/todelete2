/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import java.text.SimpleDateFormat

import org.codehaus.jettison.json.JSONException

import com.urbancode.release.rest.framework.Clients
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider

class UCRClient {
    def integrationProviderId   // id of the integration provider that is running the script
    def integrationProvider
    def lastExecutionDate  // the last date the integration was run
    def ucrServerUrl    // used to call ucr rest endpoint from the script
    def ucrToken        // token used to authenticate with the ucr server

    public UCRClient(def integrationProviderId, def ucrServerUrl, def ucrToken) {
        // default ucr properties
        this.integrationProviderId = integrationProviderId
        this.ucrServerUrl = ucrServerUrl
        this.ucrToken = ucrToken
    }

    // authenticate with uRelease server
    private def releaseAuthentication(def timeout) {
        try {
            Clients.loginWithToken(ucrServerUrl, ucrToken, timeout)
        }
        catch (JSONException ex) {
            println('Could not login with token.')
            throw new RuntimeException("JSONException: ${ex.getMessage()}")
        }
    }

    // initialize the plugin integration provider
    private void init() {
        releaseAuthentication()

        integrationProvider = new PluginIntegrationProvider().id(integrationProviderId).get()

        // We need to make sure that all changes or initiatives imported from that integration won't be editable
        integrationProvider.disabledFields("change", "type", "name", "status", "release", "application",
            "description", "severity", "initiative", "description", "name")
        integrationProvider.save()

        // last date that the integration was run
        def lastExecution = integrationProvider.getProperty("lastExecution")

        if (lastExecution) {
            lastExecutionDate = new SimpleDateFormat("MM/dd/yyyy").parse(lastExecution)
            println("Last Execution Date: ${lastExecutionDate}")
        }

    }
}