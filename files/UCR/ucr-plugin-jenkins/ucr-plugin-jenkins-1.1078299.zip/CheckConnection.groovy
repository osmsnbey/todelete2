
class CheckConnection {

}
