#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */



import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import com.urbancode.release.rest.models.Application;

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

import com.urbancode.release.rest.framework.Clients;

import com.urbancode.air.plugin.automation.JenkinsRestHelper;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def _props = apTool.getStepProperties();
def _jenkinsUser = _props['jenkinsUser'];
def _jenkinsPassword = _props['jenkinsPassword'];
def _jenkinsHostame = _props['jenkinsHostame'];

def _jenkinsHelper = new JenkinsRestHelper(_jenkinsHostame, _jenkinsUser, _jenkinsPassword)


//We launch the integration here
def integration = new TaskExecutor (_props, _jenkinsHelper)

def totalStart = System.currentTimeMillis()
integration.executeTask()
def totalEnd = System.currentTimeMillis()

/*
Here the Task Execution step must return a list of ProcessRequest :
{String processRequestId; String link; String applicationTargetId}
That contains the unique ID of the process from the External tool, a link to the execution page where 
the user can see the trace of its execution and the Application target unique id for which the process was run.
All 3 values are required!
*/		
public class TaskExecutor {
    
    def releaseToken;
    def serverUrl;
    def jenkinsUser;
    def jenkinsPassword;
    def jenkinsHostame;
    def jenkinsJobName;
    def props;

    def taskId;
    def versionId;
    def versionChildren;
    def appTargIds = [];
    def appTargIdToName = [:];
    def releaseEnvName;

    def pluginProps;
    
    def jenkinsHelper

    //Main constructor
    TaskExecutor (props, jenkinsHelper) {

        def slurper = new JsonSlurper();
        def jsonBuilder = new groovy.json.JsonBuilder()
        def extraProperties = slurper.parseText(props['extraProperties'])

        if (extraProperties.task && extraProperties.task.version && !(extraProperties.task.version instanceof Number) && !(extraProperties.task.version instanceof String) && extraProperties.task.version.id) {
            this.versionId = extraProperties.task.version.id
            this.versionChildren = extraProperties.task.version.children
        }

        if (extraProperties.task.targets && extraProperties.task.application) {
            extraProperties.task.targets.each{ targ ->
                if (targ.application.id == extraProperties.task.application.id) {
                    this.appTargIds << targ.id
                    this.appTargIdToName[targ.id] = targ.name
                }
            }
        }

        this.pluginProps = extraProperties.task['properties/PluginProperties']

	    this.props = props;
        this.releaseToken = props['releaseToken'];
        this.serverUrl = props['releaseServerUrl'];

        this.jenkinsUser = props['jenkinsUser'];
        this.jenkinsPassword = props['jenkinsPassword'];
        this.jenkinsHostame = props['jenkinsHostame'];

        this.jenkinsHelper = jenkinsHelper;

        this.jenkinsJobName = extraProperties.task.name;
        this.taskId = extraProperties.task.id;

        def ucrServerUrl = props['releaseServerUrl']
        def ucrToken = props['releaseToken']
        
        def sdId = extraProperties.task.scheduledDeploymentId;
        
        Clients.loginWithToken(ucrServerUrl, ucrToken, 0);

        ScheduledDeployment sd = new ScheduledDeployment().id(sdId)
        sd.format("list")
        sd=sd.get();

        this.releaseEnvName = sd.environment.name
    }
    
    //--------------------------------------------------------------
    def executeTask () {
        println "Triggering Remote Build: " + this.jenkinsJobName
        println "-------------------------------"
        def additionalParams = [:]
        additionalParams["UCR_TASK_ID"] = this.taskId;
        // additionalParams["UCR_APP_TARG_ID"] = this.appTargId;
        additionalParams["UCR_APP_VERSION_ID"] = this.versionId;

        if(this.pluginProps) {
            def pluginPropLines = this.pluginProps.split("\n")

            pluginPropLines.each{ line ->
                def keyValue = line.split("=", 2);
                if (keyValue.size() > 1) {
                    def key = keyValue[0]
                    def value = keyValue[1]

                    if(key != null && !key.equals("") && value != null && !value.equals("")) {
                        additionalParams[key] = value;
                    }
                }
            }
        }

        if(this.versionChildren != null) {
            this.versionChildren.each{ child ->
                def key = child.application.name
                def value = child.name
                if(key != null && !key.equals("") && value != null && !value.equals("")) {
                    additionalParams[key] = value;
                }
            }
        } 

        String procsProp = "processRequestIdList"

        String value = ""

        TaskExecution task = new TaskExecution().id(this.taskId)
        task = task.get()

        String jobAuthToken = task.getProperty("jobAuthToken")
        additionalParams["token"] = jobAuthToken

        this.appTargIds.each{ appTargId -> 
            //println task
            String newValue = getProcIdHash(this.taskId, appTargId)
            if(value == null || value.isEmpty()) {
                value = newValue
            } else {
                value = value + "," + newValue
            }
            task.addProperty(procsProp, value)
        }

        task = task.save()

        
        this.appTargIds.each{ appTargId -> 
            additionalParams["UCR_APP_TARG_ID"] = appTargId;
            additionalParams["Host"] = this.appTargIdToName[appTargId]
            additionalParams["Env"] = this.releaseEnvName;
            jenkinsHelper.createJenkinsJob(this.jenkinsJobName, additionalParams)
            println "=============================================="
        }
    }
    
    //--------------------------------------------------------------
    def setOutput(apTool, value) {
        apTool.setOutputProperty("Output", value);
        apTool.storeOutputProperties();
    }

    def getProcIdHash(taskId, appTargId) {
        String preHash = taskId + appTargId
        return Integer.toString(preHash.hashCode());
    }
}