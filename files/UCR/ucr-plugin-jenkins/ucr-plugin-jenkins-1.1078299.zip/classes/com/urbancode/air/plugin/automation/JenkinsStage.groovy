package com.urbancode.air.plugin.automation

/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.commons.webext.util.JSONUtilities;
import org.codehaus.jettison.json.JSONObject

class JenkinsStage {
    final private String name
    final private String id

    public JenkinsStage(JSONObject stageJson) {
        this.name = JSONUtilities.getStringFromJsonObject(stageJson, "name")
        this.id = JSONUtilities.getStringFromJsonObject(stageJson, "id")
    }
}
