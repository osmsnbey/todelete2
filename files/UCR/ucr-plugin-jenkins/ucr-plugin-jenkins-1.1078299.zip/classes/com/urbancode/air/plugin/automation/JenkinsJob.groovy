package com.urbancode.air.plugin.automation

/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.commons.webext.util.JSONUtilities;
import org.codehaus.jettison.json.JSONObject

class JenkinsJob {
    final private String name
    final private String description
    final private String url
    final private String id

    // fields that will be modified at runtime
    private JenkinsBuild latestBuild // the latest successful build
    private List<JenkinsBuild> builds

    public JenkinsJob(JSONObject jobJson) {
        this.name = JSONUtilities.getStringFromJsonObject(jobJson, "name")
        this.description = JSONUtilities.getStringFromJsonObject(jobJson, "description")
        this.url = JSONUtilities.getStringFromJsonObject(jobJson, "url")

        builds = new ArrayList<JenkinsBuild>()
        commitIds = new ArrayList<String>()
    }

    public void addBuild(JSONObject buildJson, boolean isLatest) {
        JenkinsBuild newBuild = new JenkinsBuild(buildJson)
        builds.add(newBuild)

        if (isLatest) {
            latestBuild = newBuild
        }
    }

    public JenkinsBuild getLatestBuild() {
        return latestBuild
    }
}
