package com.urbancode.air.plugin.automation

import com.urbancode.commons.webext.util.JSONUtilities;

import java.util.List

import org.codehaus.jettison.json.JSONObject

class JenkinsBuild {
    final private String id
    final private String url
    final private String timestamp
    final private String duration

    // fields that will be modified at runtime
    private List<String> commitIds

    public JenkinsBuild(JSONObject buildJson) {
        this.id = JSONUtilities.getStringFromJsonObject(buildJson, "id")
        this.url = JSONUtilities.getStringFromJsonObject(buildJson, "url")
        this.url = JSONUtilities.getStringFromJsonObject(buildJson, "timestamp")
        this.duration = JSONUtilities.getStringFromJsonObject(buildJson, "duration")


    }

    public void addCommits(List commitIds) {
        this.commitIds = commitIds
    }
}
