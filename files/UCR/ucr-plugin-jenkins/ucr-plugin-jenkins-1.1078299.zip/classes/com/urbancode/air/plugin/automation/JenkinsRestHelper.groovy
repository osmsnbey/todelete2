package com.urbancode.air.plugin.automation

/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.httpcomponentsutil.PreemptiveAuthHttpClient

import org.apache.http.client.methods.HttpUriRequest
import org.apache.http.auth.Credentials
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.impl.client.BasicCredentialsProvider
import org.apache.http.util.EntityUtils
import org.apache.http.HttpResponse
import org.apache.http.ParseException
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPut
import org.apache.http.client.methods.HttpPost
import org.codehaus.jettison.json.JSONObject
import org.codehaus.jettison.json.JSONArray
import org.xml.sax.SAXParseException
import org.apache.http.Header

import java.net.URLEncoder
import java.net.URI

import groovy.json.JsonSlurper
import groovy.json.JsonException
import groovy.json.JsonBuilder
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.httpcomponentsutil.PreemptiveAuthHttpClient

public class JenkinsRestHelper {
    private HttpClientBuilder clientBuilder
    private DefaultHttpClient client
    String serverUrl
    String username
    String password

    public JenkinsRestHelper(def serverUrl, def username, def password) {
        this.serverUrl = serverUrl
        this.username = username
        this.password = password
        clientBuilder = new HttpClientBuilder()

        clientBuilder.setUsername(username)
        clientBuilder.setPassword(password)
        // clientBuilder.setPreemtiveAuthentication(true)

        client = clientBuilder.buildClient()

        if (serverUrl) {
            if (!serverUrl.substring(0, 7).equalsIgnoreCase("http://") && !serverUrl.substring(0, 8).equalsIgnoreCase("https://")){
                println("An HTTP protocol (http:// or https://) must be prepended to server URL: ${serverUrl}")
                throw new RuntimeException("Missing HTTP protocol in server URL: ${serverUrl}")
            }

            if (serverUrl.endsWith("/")) {
                this.serverUrl = serverUrl.substring(0, serverUrl.length() - 1)
            }
        }
        else {
            println("No server URL was specified, a connection cannot be created.")
            throw new RuntimeException("Missing server URL")
        }
    }

    /*
     * class to be overridden to extract specific item types from a JSONArray
     */
    public abstract class JenkinsExtractor<T> {
        String url

        public JenkinsExtractor(String url) {
            this.url = url
        }

        public List<T> extractList(String key) {
            List<T> extracted
            HttpGet getRequest = new HttpGet(url)
            HttpResponse response = doGetRequest(getRequest)
            JSONObject jsonObj = parseResponse(response)
            JSONArray jsonArr = jsonObj.get(key)

            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject currObj = jsonArr.get(i)
                extracted.add(extractItem(currObj))
            }
        }

        public abstract T extractItem(JSONObject item)
    }

    // get all jobs and build per job
    public List<JenkinsJob> getJobs() {
        String buildArrQuery = "[id,url,result,timestamp,duration,changeSets[commitId]]"
        String jobArrQuery = "[name,description,url,lastSuccessfulBuild[id],allBuilds${buildArrQuery}]"
        String url = serverUrl + "/api/json?tree=jobs${jobArrQuery}"

        // construct anonymous inner class, which requires an instance of outer class
        return new JenkinsExtractor<JenkinsJob>(this, url) {
            @Override
            public JenkinsJob extractItem(JSONObject item) {
                JenkinsJob newJob = new JenkinsJob(item)
                String lastBuildId = item.get("lastSuccessfulBuild").get("id")
                JSONArray buildArr = item.get("allBuilds")

                for (int i = 0; i < buildArr.length(); i++) {
                    JSONObject build = buildArr.get(i)
                    boolean isLastBuild = (newJob.id == lastBuildId) // is this the latest successful build
                    newJob.addBuild(build, isLastBuild)

                    JSONArray commitArr = build.get("changeSets")
                    for (int j = 0; j < commitArr.length(); j++) {
                        JSONObject change = commitArr.get(j)
                        String commitId = change.getString("commitId")

                    }
                }
            }
        }.extractList("jobs")
    }

    // POST a new Jenkins job
    public def createJenkinsJob(jobName, additionalParams) {
        String url = serverUrl + "/job/" + URLEncoder.encode(jobName).replace("+", "%20") + "/buildWithParameters?delay=0sec" + generateQueryParams(additionalParams)

        HttpPost postRequest = new HttpPost(url)
        HttpResponse response = doPostRequest(postRequest, null)

        String buildUrl = getBuildUrlFromResponse(response)
        String buildId = getBuildIdFromUrl(buildUrl)

        String link = "<a href='" + buildUrl + "' target='_blank'>" + "View Jenkins Execution" + "</a>";

        println "A Jenkins build has started: Build #" + buildId
        println ("The build can be viewed here: " + link)
    }

    private def generateQueryParams(additionalParams) {
        def result = ""
        println "Send the following properties:"
        additionalParams.each{ key, value -> 
            if (value != null) {
                println key + ": " + value
                def param = URLEncoder.encode(key).replace("+", "%20") + "=" + URLEncoder.encode(value).replace("+", "%20")
                result = result + "&" + param
            }
            
        }
        return result
    }

    private def getBuildUrlFromResponse (HttpResponse response) {
        Header locationHeader = response.getFirstHeader("location")
        String location = locationHeader.getValue()

        println location

        HttpGet httpGet = new HttpGet(new URI(location + "/api/json"));

        sleep(5000)

        HttpResponse responseQueue = doGetRequest(httpGet, true)

        JSONObject jsonObj = parseResponse(responseQueue)

        def url = jsonObj.get("executable").get("url")

        URI uri = new URI(location);
        String[] segments = uri.getPath().split("/");
        String id = segments[segments.length-1];

        return url
    }

    private def getBuildIdFromUrl (String url) {
        URI uri = new URI(url);
        String[] segments = uri.getPath().split("/");
        String id = segments[segments.length-1];

        return id
    }

    // get all stages for a given pipeline job's latest build
    public List<JenkinsStage> getStages(def buildId) {

    }

    //return an unparsed map of JSON properties from an http response
    public def parseResponse(HttpResponse response) {
        String json = EntityUtils.toString(response.getEntity())

        JsonSlurper slurper = new JsonSlurper()

        return slurper.parseText(json)
    }

    //execute http put request
    private void doPutRequest(HttpPut request, String jsonString) {
        HttpResponse response = doRequest(request, jsonString)
        def statusLine = response.getStatusLine()
        def statusCode = statusLine.getStatusCode()

        if (statusCode != 200) {
            println("Http Put request failed with an Http response code of ${statusCode}: ${statusLine.getReasonPhrase()}")
            throw new Exception(response.entity?.content?.text)
        }
    }

    //execute http post request
    private HttpResponse doPostRequest(HttpPost request, String jsonString) {
        HttpResponse response = doRequest(request, jsonString)
        def statusLine = response.getStatusLine()
        def statusCode = statusLine.getStatusCode()

        if (statusCode != 201) {
            println("Http Post request failed with an Http response code of ${statusCode}: ${statusLine.getReasonPhrase()}")
            throw new Exception(response.entity?.content?.text)
        }

        return response
    }

    //return http response from an http get request. Will throw an exception if http return code isn't 200
    private HttpResponse doGetRequest(HttpGet request) {
        return doGetRequest(request, false);
    }

    //return http response from an http get request. Will throw an exception if http return code isn't 200
    private HttpResponse doGetRequest(HttpGet request, Boolean isCrumbRequest) {
        HttpResponse response = doRequest(request, null, isCrumbRequest)
        def statusLine = response.getStatusLine()
        def statusCode = statusLine.getStatusCode()

        if (isCrumbRequest && statusCode == 404) {
            // CSRF in not enabled on this server
            return null
        } else if (statusCode != 200) {
            println("Http Get request failed with an Http response code of ${statusCode}: ${statusLine.getReasonPhrase()}")
            throw new Exception(response.entity?.content?.text)
        }

        return response
    }

    //execute a general http request
    private HttpResponse doRequest(HttpUriRequest request) {
        return doRequest(request, null)
    }

    //execute a general http request
    private HttpResponse doRequest(HttpUriRequest request, String contentString) {
        return doRequest(request, null, false)
    }

    //specify a json string to provide a string entity to the http request
    private HttpResponse doRequest(HttpUriRequest request, String contentString, Boolean isCrumbRequest) {
        request.addHeader("Content-Type", "application/json")
        request.addHeader("Accept", "application/json,application/xml")
        if(!isCrumbRequest) {
            attachCrumb(request)
        }

        if (contentString) {
            StringEntity input

            try {
                input = new StringEntity(contentString)
            }
            catch(UnsupportedEncodingException ex) {
                println("Unsupported characters in http request content: ${contentString}")
                throw new Exception(ex)
            }

            request.setEntity(input)
        }

        HttpResponse response = client.execute(request)

        return response
    }

    private attachCrumb(request) {
        HttpGet httpGet = new HttpGet(serverUrl + "/crumbIssuer/api/json");

        HttpResponse response = doGetRequest(httpGet, true)
        if(response == null) {
            // Skip attaching the crumb
            return
        }

        JSONObject jsonObj = parseResponse(response)

        def headerKey = jsonObj.getString("crumbRequestField")
        def headerValue = jsonObj.getString("crumb")

        request.addHeader(headerKey, headerValue)
    }
}
