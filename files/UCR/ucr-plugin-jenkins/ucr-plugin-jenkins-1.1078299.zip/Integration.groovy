/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2017. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.AirPluginTool
import com.urbancode.release.rest.models.Application
import com.urbancode.release.rest.models.Version
import com.urbancode.air.plugin.automation.JenkinsRestHelper
import com.urbancode.air.plugin.automation.JenkinsJob
import java.text.SimpleDateFormat

final def workDir = new File('.').canonicalFile
AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

def jenkinsHostname = props['jenkinsHostname']
def jenkinsUser = props['jenkinsUser']
def jenkinsPassword = props['jenkinsPassword']
def jenkinsHelperImpl = new JenkinsRestHelper(jenkinsHostname, jenkinsUser, jenkinsPassword)

def integrationProviderId = props['integrationProviderId']
def ucrServerUrl = props['releaseServerUrl']
def ucrToken = props['releaseToken']
def ucrClientImpl = new UCRClient(integrationProviderId, ucrServerUrl, ucrToken)

JenkinsIntegration integration = new JenkinsIntegration(props, ucrClientImpl, jenkinsHelperImpl)
integration.runIntegration()

public class JenkinsIntegration {
    final def MAX_QUERY = 500 // maximum number of arguments per sync query
    UCRClient ucrClient
    JenkinsRestHelper jenkinsHelper
    def fullIntegration
    def currentServerTime
    def lastExecutionTime
    def timeout

    public JenkinsIntegration(def props, def ucrClientImpl, def jenkinsHelperImpl) {
        this.jenkinsHelper = jenkinsHelperImpl

        this.ucrClient = ucrClientImpl

        this.fullIntegration = props['fullIntegration']
        this.timeout = props['timeout']

        //If no value is set for the timeout then we set it to 0
        if (timeout == null || timeout == "") {
            timeout = 0;
        }
        else {
            try {
                timeout = Integer.parseInt(defaultTimeout);
                println("Timeout for http requests is set to "+timeout+"s ")
                //We convert it into milliseconds
                timeout = timeout * 1000;
            }
            catch (Exception ex) {
                printLog("WARNING", "The default timeout provided ("+timeout+") is not a number and no timeout will be set")
                timeout = 0;
            }
        }
    }

    /*
     * Import all jobs, builds, and nodes in Jenkins as new applications, versions, and environments in UCR respectively
     */
    def runIntegration() {
        ucrClient.init()
        def integrationProvider = ucrClient.getIntegrationProvider()
        ucrClient.releaseAuthentication(timeout)

        /* Import jobs and corresponding builds */
        List<Application> ucrApplications = importJobs()

        /* Import stages per each pipeline job as application environments in UCR */
        importStages(ucrApplications)

        integrationProvider.property("lastExecution", new SimpleDateFormat("MM/dd/yyy").format(new Date())).save()
    }

    /*
     * Import jobs from Jenkins as new Applications in UCR
     */
    List<Application> importJobs() {
        println("<u><b>Importing Jobs</b></u>")
        List<Application> bulkAppList = new ArrayList<Application>()
        long startImport = System.currentTimeMillis()
        List<JenkinsJob> jobs = jenkinsHelper.getJobs()
        long endImport = System.currentTimeMillis()
        println("Imported ${jobs.size()} Jenkins jobs in ${(endImport - startImport)/1000} seconds.")

        /* create each imported job as an application in UCR */
        jobs.each {
            item ->
            def application = new Application()
                .name(item.name)
                .automated(true)
                .property("objectType", "APPLICATION")
                .description(item.description)
                .integrationProvider(ucrClient.getIntegrationProvider())
                .externalId(item.name)

            // import builds from the Jenkins job as Application Versions
            List<Version> versions = new ArrayList<Version>()
            item.builds.each {
                build ->
                Version ucrVersion = new Version().externalId(build.id.toString())
                versions.add(ucrVersion)
            }

            // add versions to application
            application.versions(versions.toArray(new Version[versions.size()]))
            bulkAppList.add(application)

            // maximum sync query size reached, list must be emptied
            if (bulkAppList.size() >= MAX_QUERY) {
                def startUpdate = System.currentTimeMillis()
                def updateApplications = new Application().sync(bulkAppList)
                def endUpdate = System.currentTimeMillis()
                println("Updated ${updateApplications.size()} Applications in UCR in"
                    + " ${(endUpdate - startUpdate)/1000} seconds")
                bulkAppList = new ArrayList<Application>()
            }
        }

        if (bulkAppList.size() > 0) {
            def startUpdate = System.currentTimeMillis()
            def updateApplications = new Application().sync(bulkAppList)
            def endUpdate = System.currentTimeMillis()
            println("Updated ${updateApplications.size()} Applications in UCR in"
                + " ${(endUpdate - startUpdate)/1000} seconds")
        }

        return bulkAppList
    }

    /*
     * Import all stages in Jenkins Pipeline jobs as new application environments in UCR
     */
    def importStages(List<Application> ucrApplications) {
        ucrApplications.each {

        }
    }

    /*
     * Print logs
     */
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}
