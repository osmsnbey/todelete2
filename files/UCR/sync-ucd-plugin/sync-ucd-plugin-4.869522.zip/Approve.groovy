#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
 
import com.urbancode.air.*
import com.urbancode.plugin.*;
import com.urbancode.plugin.models.*;

import static com.jayway.restassured.RestAssured.*;

import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;
import com.urbancode.release.rest.models.AuthenticationToken;
import com.urbancode.release.rest.models.internal.ApprovalItem;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

println props;

def uri = props['uri'];
def token = props['token'];
def user = props['user'];
def approvalId = props['approvalId'];
def comments = props['comments'];
def action = props['action'];

println "Approving ${approvalId} as user ${user}";

println "Logging in to ${uri} as admin"
//def adminTokenJson = '{ "token": "' + token + '" }';

def deployHelper = new UCDeployClient(uri, token);

println "Logged in"

if (user) {
    // approve as a specific user, requires the token given to be and admin token
    def userId;
    try {
        userId = UUID.fromString(user);
    }
    catch (IllegalArgumentException e) {
        if (user.indexOf("@") > 0) {
            println "Looking up user by email... " + user;
            def userObj = deployHelper.getUserByEmail(user);
            if (!userObj) {
                throw new Exception("User not found: ${user}");
            }
            userId = userObj.id;
            println "Found ${userId} for email ${user}"
        }
        else {
            println "Looking up user by username..."
            def filteredUsers = Clients.user().filter("name", FilterClass.STRING, FilterType.EQUALS, user).when().getAll();
            if (!filteredUsers || filteredUsers.length == 0) {
                throw new Exception("User not found: ${user}");
            }
            userId = filteredUsers[0].id;
            println "Found ${userId} for username ${user}"
        }
    }

    println "Creating temporary token for user id ${userId}"
    def userTokenExpiration = System.currentTimeMillis() + 60000L;
    def userToken = new UcdAuthToken (
            userId : userId,
            expiration : userTokenExpiration,
            description : "DevOps Connect Approval Token - Delete Me",
            host : ""
        )
    userToken = deployHelper.saveAuthToken(userToken);
    try {
        println "Created temporary token for user id ${userId}";
        def userTokenJson = '{ "token": "' + userToken.token + '" }';
        deployHelper = new UCDeployClient(uri, userToken.token);

        println "Action - " + action.toLowerCase();
        if(action.toLowerCase() == "accepted" || action.toLowerCase() == "approved") {
            deployHelper.approveTask(approvalId, new ApprovalRequest(passFail : "passed", comment : comments));
            println "Approval ${approvalId} approved";
        }
        else if(action.toLowerCase() == "rejected") {
            deployHelper.approveTask(approvalId, new ApprovalRequest(passFail : "failed", comment : comments));
            println "Approval ${approvalId} rejected";
        }
    }
    finally {
        //userToken.delete();
        println "Temporary token deleted";
    }
}
else {
    // approve with the token we already have
    given().put(new ApprovalItem().path(approvalId) + "/approve");
    println "Approval ${approvalId} approved";
}
