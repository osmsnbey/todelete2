#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder;
import com.urbancode.commons.util.IO;
import com.urbancode.plugin.*;

import org.apache.http.*;
import org.apache.http.auth.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.protocol.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.*;
import org.apache.http.impl.auth.*;
import org.apache.http.impl.client.*;
import org.apache.http.util.*;

import org.codehaus.jettison.json.JSONObject;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def uri = props['uri'];
def token = props['token'];
def application = props['application'];
def applicationProcess = props['process'];
def environment = props['environment'];
def snapshot = props['snapshot'];
def onlyChanged = props['onlyChanged'];
def callbackUrl = props['callbackUrl'];
def callbackContent = props['callbackContent'];
def date = props['date'];

// coerce onlyChanged to Boolean and default to true
onlyChanged = onlyChanged == null ? true : Boolean.valueOf(onlyChanged);
while (uri.endsWith('/')) {
    uri = uri.substring(0, uri.length() - 1)
}

CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder();
builder.setPreemptiveAuthentication(true);
builder.setUsername("PasswordIsAuthToken");
builder.setPassword(token);
builder.setTrustAllCerts(true);

CloseableHttpClient httpclient = builder.buildClient();

try {
    /*
    REQUEST_JSON_TEMPLATE = new JSONObject()
        .put("application", "Application name or ID")
        .put("description", "Description (Optional)")
        .put("applicationProcess", "Application process name or ID")
        .put("environment", "Environment name or ID")
        .put("snapshot", "Snapshot name or ID (Optional)")
        .put("onlyChanged", "Specify false to force deployment of versions that are already in the "+
                "inventory (Optional)")
        .put("description", "Description for the request (Optional)")
        .put("date", "Date and time to schedule the process for. (Optional) Supports unix timecodes or the format yyyy-mm-dd HH:mm")
        .put("recurrencePattern", "To make a scheduled process recur, specify 'D' (daily), 'W' (weekly), or 'M' (monthly). (Optional)")
        .put("properties", new JSONObject().put("Property name", "Property value (Optional)"))
        .put("versions", new JSONArray().put(new JSONObject()
            .put("version", "Version name or ID (Repeat as necessary. Not used with "+
                    "snapshots)")
            .put("component", "Component name or ID for the version, if you are using version name "+
                    "instead of ID.")))
        .put(ServerConstants.APP_POST_DEPLOY_PUT_URL, "The URL that the post-deploy-message is PUT to. (Optional)")
        .put(ServerConstants.APP_POST_DEPLOY_MESSAGE, "The body of the PUT message." +
              " You can use the variable ${p:finalStatus}, which holds the value 'success' or 'failure' " +
              " depending on whether the process succeeded or failed. (Optional)");
     */
    JSONObject json = new JSONObject();
    json.put("application", application);
    json.put("applicationProcess", applicationProcess);
    json.put("environment", environment);
    json.put("snapshot", snapshot);
    json.put("onlyChanged", onlyChanged);
    json.put("post-deploy-put-url", callbackUrl);
    json.put("post-deploy-message", callbackContent);
    println "Requesting to execute process ${applicationProcess} of application ${application} using snapshot ${snapshot} targeting environment ${environment}"
    if (date) {
        json.put("date", date);
        println "Scheduling execution for ${date}"
    }

    def requestUrl = uri.toString() + "/cli/applicationProcessRequest/request";
    println "Request URL: ${requestUrl}"
    //println "JSON:\n${json}"
    HttpPut httpPut = new HttpPut(requestUrl);
    httpPut.setEntity(new StringEntity(json.toString(), ContentType.APPLICATION_JSON));
    CloseableHttpResponse response = httpclient.execute(httpPut);

    try {
        System.out.println(response.getStatusLine());
        HttpEntity entity = response.getEntity();
        try {
            def content = IO.readText(entity.getContent());

            if (response.getStatusLine().getStatusCode() == 200) {
                JSONObject responseJson = new JSONObject(content);
                def requestId = responseJson.getString("requestId");
                println "Request ${requestId} created"
            }
            else {
                println content;
            }
        }
        finally {
            EntityUtils.consume(entity);
        }
    }
    finally {
        response.close();
    }
}
finally {
    httpclient.close();
}