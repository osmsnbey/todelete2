package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the deployment json doc
public class ApprovalRequest {
    def comment;
    def passFail;
}
