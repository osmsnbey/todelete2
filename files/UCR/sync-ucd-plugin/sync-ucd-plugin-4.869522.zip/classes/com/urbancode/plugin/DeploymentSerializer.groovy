package com.urbancode.plugin

import com.urbancode.air.*
import com.urbancode.plugin.models.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.Team;
import com.urbancode.release.rest.models.User;

public class DeploymentSerializer {

    def sd;
    def numIntervals = 50;

    def teams = [];
    def teamIds = [];
    def userIds = [];

    public DeploymentSerializer(scheduledDeployment) {
        sd = scheduledDeployment;
    }

    public DeploymentSerializer() {
    }

    def serializeToObject() {

        if(sd.relatedDeployment != null) {
            return serializeRelatedDeployment();
        }

        def startTime;
        if(sd.deploymentExecution.status == "NOTSTARTED") {
            startTime = sd.scheduledDate;
        }
        else {
            startTime = sd.deploymentExecution.startTimeActual;
        }

        def lateCount = 0;
        def waitingCount = 0;
        def errorCount = 0;

        def env = new NameIdPair(name: sd.environment.name, id: sd.environment.id);
        def rel = new NameIdPair(name: sd.release.name, id: sd.release.id);
        def phase = new NameIdPair(name: sd.phase.name, id: sd.phase.id);
        def detail = generateDetailData(sd);

        teams[0] = new NameIdPair(name: sd.release.teamName, id: SeedHandler.handle(sd.release.teamId));

        // UCR Values: EMPTY, NOTSTARTED, INPROGRESS, SOFTFAILED, FAILED, COMPLETE, ABORTED
        // Cloud Values: NOTSTARTED, INPROGRESS, FAILED, COMPLETE
        def deploymentStatus = sd.deploymentExecution.status;

        if(deploymentStatus == "EMPTY") {
            deploymentStatus = "NOTSTARTED";
        }
        else if(deploymentStatus == "SOFTFAILED"){
            deploymentStatus = "INPROGRESS";
        }
        else if(deploymentStatus == "ABORTED") {
            deploymentStatus = "FAILED"
        }

        def userDetails;
        def userMap = [:];
        if(userIds.size() > 0) {
            userDetails = (new TeamSerializer()).generateUserList((new User()).filter("id", FilterClass.STRING, FilterType.IN, (String[])userIds).when().getAll())
        }

        userDetails.each { item ->
            userMap.putAt(item.id, item);
        }

        def result = new Deployment(
            updatedTime: System.currentTimeMillis(),
            id: sd.id,
            name: generateName(sd),
            level: "DEPLOYMENT",
            status: deploymentStatus,
            environment: env,
            release: rel,
            phase: phase,
            startTime: startTime,
            plannedEndTime: sd.deploymentExecution.endTimePlanned,
            estimatedEndTime: ((sd.status != "NOTSTARTED") ? sd.deploymentExecution.endTimeEstimated : sd.deploymentExecution.endTimePlanned),
            lineGraph: detail.lineGraph,
            teams: teams,
            taskStatus: detail.taskStatus,
            taskCount: detail.taskCount,
            taskProgress: detail.taskProgress,
            progress: detail.progress,
            tasksByTags: detail.tasksByTags,
            users: userMap);

        return result;
    }

    def serializeRelatedDeployment() {

        def rd = sd.relatedDeployment;
        rd.format("details");
        rd = rd.get();
        def rdTimeRemainingObj = sd.relatedDeployment.getTimeRemaining();

        def lateCount = 0;
        def waitingCount = 0;
        def errorCount = 0;

        def detail = null;

        def deploymentStatus = null;

        def bucketsObj;

        def timeRemainingObj = sd.relatedDeployment.getTimeRemaining();

        if(timeRemainingObj.estimatedEndTime == null && timeRemainingObj.endTimePlanned == null){
            printLog("WARNING", "Skipped related deployment as timing metrics could not be calculated.  Is there an empty deployment participating in the related deployment?")
            return null;
        }

        def startTime = getRDStartTime(sd.relatedDeployment.id);
        def endTime = (timeRemainingObj.endTimeOverride == null || timeRemainingObj.endTimeOverride == 0) ? Math.max(timeRemainingObj.estimatedEndTime, timeRemainingObj.endTimePlanned) : timeRemainingObj.endTimeOverride;

        for(int i = 0; i < rd.scheduledDeployments.length; i++) {

            ScheduledDeployment dep =  rd.scheduledDeployments[i];
            def fullDeployment = dep.get();

            bucketsObj = combineBuckets(bucketsObj, generateBuckets(fullDeployment, startTime, endTime));

            if(!teamIds.contains(SeedHandler.handle(fullDeployment.release.teamId))) {
                teams << new NameIdPair(name: fullDeployment.release.teamName, id: SeedHandler.handle(fullDeployment.release.teamId));
                teamIds << SeedHandler.handle(fullDeployment.release.teamId)
            }


            // UCR Values: EMPTY, NOTSTARTED, INPROGRESS, SOFTFAILED, FAILED, COMPLETE, ABORTED
            // Cloud Values: NOTSTARTED, INPROGRESS, FAILED, COMPLETE
            def sdStatus = sd.deploymentExecution.status;

            if(deploymentStatus == null) {
                deploymentStatus = sdStatus;
                if(sdStatus == "EMPTY") {
                    deploymentStatus = "NOTSTARTED";
                }
                else if(sdStatus == "SOFTFAILED"){
                    deploymentStatus = "INPROGRESS";
                }
                else if(sdStatus == "ABORTED") {
                    deploymentStatus = "FAILED"
                }
            }
            else {
                if(sdStatus == "EMPTY") {
                    // No Op don't change anything
                }
                else if(sdStatus == "SOFTFAILED"){
                    deploymentStatus = "INPROGRESS";
                }
                else if(sdStatus == "ABORTED") {
                    deploymentStatus = "FAILED";
                }
                else if(sdStatus == "FAILED") {
                    deploymentStatus = "FAILED";
                }
                else if(sdStatus == "INPROGRESS" && deploymentStatus != "FAILED") {
                    deploymentStatus = "INPROGRESS";
                }
                else if(sdStatus == "COMPLETE" && deploymentStatus != "FAILED" && deploymentStatus == "NOTSTARTED") {
                    deploymentStatus = "INPROGRESS";
                }
            }
        }

        detail = generateDetailDataFromBuckets(bucketsObj);


        def userDetails;
        def userMap = [:];
        if(userIds.size() > 0) {
            userDetails = (new TeamSerializer()).generateUserList((new User()).filter("id", FilterClass.STRING, FilterType.IN, (String[])userIds).when().getAll())
        }

        userDetails.each { item ->
            userMap.putAt(item.id, item);
        }

        def result = new Deployment(
            updatedTime: System.currentTimeMillis(),
            id: rd.id,
            name: rd.event.name,
            level: "EVENT",
            status: deploymentStatus,
            environment: "event env",
            release: "event release",
            phase: "event phase",
            startTime: rdTimeRemainingObj.estimatedStartTime,
            plannedEndTime: rdTimeRemainingObj.endTimePlanned,
            estimatedEndTime: ((sd.status != "NOTSTARTED") ? rdTimeRemainingObj.estimatedEndTime : rdTimeRemainingObj.endTimePlanned),
            lineGraph: detail.lineGraph,
            teams: teams,
            taskStatus: detail.taskStatus,
            taskCount: detail.taskCount,
            taskProgress: detail.taskProgress,
            progress: detail.progress,
            tasksByTags: detail.tasksByTags,
            users: userMap);

        return result;
    }

    def generateBulkDeployment(sdArray) {
        return new BulkDeployment(deployments: sdArray);
    }

    def generateDetailData(sd) {
        def minTime;
        def progress = 0;

        if(sd.deploymentExecution.status == "NOTSTARTED") {
            minTime = sd.scheduledDate;
        }
        else {
            minTime = Math.min(sd.scheduledDate, sd.deploymentExecution.startTimeActual);
        }

        def maxTime;
        if(sd.deploymentExecution.endTimeEstimated != null) {
            maxTime = Math.max(sd.deploymentExecution.endTimePlanned, sd.deploymentExecution.endTimeEstimated);
        }
        else {
            maxTime = sd.deploymentExecution.endTimePlanned;
        }

        // Necessary for empty SDs
        if(maxTime == null) {
            // Trivial addition is necessary so as to not divide by zero later.
            maxTime = minTime + numIntervals;
        }

        def bucketsObj = generateBuckets (sd, minTime, maxTime);

        return generateDetailDataFromBuckets(bucketsObj);

    }

    def generateBuckets (sd, minTime, maxTime) {
        def progress = 0;

        def intervalSize = (Long)((maxTime - minTime) / numIntervals);

        def actualCount = new Integer[numIntervals];
        def estimatedCount = new Integer[numIntervals];
        def plannedCount = new Integer[numIntervals];

        for(int i = 0; i < numIntervals; i++) {
            actualCount[i] = 0;
            estimatedCount[i] = 0;
            plannedCount[i] = 0;
        }

        def lateBucket = [:];
        def errorBucket = [:];
        def waitingBucket = [:];

        def lateCount = 0;
        def errorCount = 0;
        def waitingCount = 0;

        def completeCount = 0;
        def inprogressCount = 0;
        def taskCount = 0;

        def tasksByTags = [:];

        def sdOffset = 0;

        if(sd.status == "NOTSTARTED") {
            sdOffset = System.currentTimeMillis() - sd.scheduledDate;

            if(sdOffset < 0) {
                sdOffset = 0;
            }
        }

        def teamId =  SeedHandler.handle(sd.release.teamId);
        def teamName =  sd.release.teamName;
        if(sd.deploymentExecution.segments != null) {
            sd.deploymentExecution.segments.each { segment ->
                if(segment.tasks != null) {
                    segment.tasks.each { task ->
                        if(task.isApplicable) {
                            taskCount++;

                            // Update task buckets

                            if(task.status == "OPEN") {
                                if(!waitingBucket.containsKey(sd.id)) {
                                    waitingBucket.put(sd.id, generateTaskBucketByDeployment(sd, teamName));
                                }
                                waitingBucket.get(sd.id).tasks << serializeTask(task);
                                waitingCount++;
                            }
                            else if(task.status == "EXECUTING") {
                                if(task.startTimeActual > task.startTimePlanned || System.currentTimeMillis() > (task.startTimePlanned + (task.duration * 60L * 1000L))) {
                                    if(!lateBucket.containsKey(sd.id)) {
                                        lateBucket.put(sd.id, generateTaskBucketByDeployment(sd, teamName));
                                    }
                                    lateBucket.get(sd.id).tasks << serializeTask(task);
                                    lateCount++;
                                }

                                inprogressCount++;
                            }
                            else if(task.status == "CLOSED" && task.result == "FAILURE") {
                                if(!errorBucket.containsKey(sd.id)) {
                                    errorBucket.put(sd.id, generateTaskBucketByDeployment(sd, teamName));
                                }
                                errorBucket.get(sd.id).tasks << serializeTask(task);
                                errorCount++;
                            }
                            else if(task.status == "CLOSED" && (task.result == "SUCCESS" || task.result == "SKIPPED")) {
                                completeCount++;
                            }

                            // update graph data

                            def plannedEnd = (task.startTimePlanned + (int)(task.duration * 60 * 1000));

                            def iPlanned = (int)((plannedEnd - minTime) / intervalSize);

                            if(iPlanned == numIntervals) {
                                iPlanned--;
                            }

                            plannedCount[iPlanned]++;

                            def startTimeEst;
                            if(sd.status == "NOTSTARTED") {
                                if(sdOffset > 0 ) {
                                    startTimeEst = sdOffset + task.startTimePlanned;
                                }
                                else {
                                    startTimeEst = task.startTimePlanned;
                                }
                            }
                            else if(task.startTimeEstimated != null){
                                startTimeEst = task.startTimeEstimated; // UCR will say the start time est is the same as the start time actual if it is started
                            }

                            if(task.endTimeActual != null) {
                                def actualEnd = task.endTimeActual;
                                def iActual = (int)((actualEnd - minTime) / intervalSize);

                                if(iActual == numIntervals) {
                                    iActual--;
                                }

                                actualCount[iActual]++;
                            }
                            else if(startTimeEst != null) {
                                def estimatedEnd;
                                if(task.status == "EXECUTING") {
                                    estimatedEnd = Math.max(startTimeEst + (task.duration * 60 * 1000), System.currentTimeMillis());
                                }
                                else {
                                    estimatedEnd = startTimeEst + (task.duration * 60 * 1000)
                                }

                                def iEstimated = (int)((estimatedEnd - minTime) / intervalSize);

                                if(iEstimated == numIntervals) {
                                    iEstimated--;
                                }
                                else if(iEstimated > numIntervals) {
                                    iEstimated = numIntervals - 1;
                                }

                                estimatedCount[iEstimated]++;
                            }

                            // Update Task Tags

                            for(int i = 0; i < task.taskTags.length; i++) {
                                def tagId = task.taskTags[i].id
                                if(!tasksByTags.containsKey(tagId)) {

                                    def inprogCount = 0;
                                    def compCount = 0;
                                    def failCount = 0;

                                    def users = [];

                                    if(task.status == "EXECUTING") {
                                        inprogCount++;
                                    }
                                    else if(task.status == "CLOSED") {
                                        if(task.result == "SUCCESS" || task.result == "SKIPPED") {
                                            compCount++;
                                        }
                                        else if(task.result == "FAILURE") {
                                            failCount++;
                                        }
                                    }

                                    if(task.userId != null) {
                                        if(!users.contains(task.userId)) {
                                            users << task.userId;
                                        }
                                    }

                                    tasksByTags.put(tagId, new TaskTagObject(
                                        name: task.taskTags[i].name,
                                        color: task.taskTags[i].color,
                                        totalTasks: 1,
                                        completeTasks: compCount,
                                        inProgressTasks : inprogCount,
                                        failedTasks : failCount,
                                        users : users,
                                        startTimeActual : task.startTimeActual,
                                        startTimePlanned : task.startTimePlanned,
                                        startTimeEstimated : task.startTimeEstimated,
                                        endTimeActual : task.endTimeActual,
                                        endTimePlanned : task.startTimePlanned + (((Long)task.duration) * 60L * 1000L),
                                        endTimeEstimated : (task.startTimeEstimated != null) ? task.startTimeEstimated + (((Long)task.duration) * 60L * 1000L) : null
                                        ));
                                }
                                else {

                                    def tagObj = tasksByTags.get(tagId);

                                    tagObj.totalTasks = tagObj.totalTasks + 1;

                                    if(task.status == "EXECUTING") {
                                        tagObj.inProgressTasks = tagObj.inProgressTasks + 1;
                                    }
                                    else if(task.status == "CLOSED") {
                                        if(task.result == "SUCCESS" || task.result == "SKIPPED") {
                                            tagObj.completeTasks = tagObj.completeTasks + 1;
                                        }
                                        else if(task.result == "FAILURE") {
                                            tagObj.failedTasks = tagObj.failedTasks + 1;
                                        }
                                    }

                                    // update planned start and end times
                                    tagObj.startTimePlanned = Math.min(tagObj.startTimePlanned, task.startTimePlanned);
                                    tagObj.endTimePlanned = Math.max(tagObj.endTimePlanned, task.startTimePlanned + (((Long)task.duration) * 60L * 1000L));

                                    // update actual start and end times
                                    if(task.startTimeActual != null) {
                                        if(tagObj.startTimeActual == null) {
                                            tagObj.startTimeActual = task.startTimeActual;
                                        }
                                        else {
                                            tagObj.startTimeActual = Math.min(tagObj.startTimeActual, task.startTimeActual);
                                        }
                                    }
                                    if(task.endTimeActual != null && tagObj.endTimeActual != null) {
                                        if(tagObj.endTimeActual != null) {
                                            // only update if there is an end time actual
                                            tagObj.endTimeActual = Math.max(tagObj.endTimeActual, task.endTimeActual);
                                        }
                                    }
                                    else {
                                        tagObj.endTimeActual = null;
                                    }

                                    // update estimated start and end times
                                    tagObj.startTimeEstimated = task.startTimeEstimated != null ? Math.min(tagObj.startTimeEstimated, task.startTimeEstimated) : tagObj.startTimeEstimated;
                                    tagObj.endTimeEstimated = task.startTimeEstimated != null ? Math.max(tagObj.endTimeEstimated, task.startTimeEstimated + (((Long)task.duration) * 60L * 1000L)) : tagObj.endTimeEstimated;

                                    if(task.userId != null && !tagObj.users.contains(task.userId)) {
                                        tagObj.users << task.userId;
                                    }

                                    tasksByTags.put(tagId, tagObj);
                                }
                            }
                        }
                    }
                }
            }
        }

        return new TaskBucketObject(
            lateBucket : lateBucket,
            errorBucket : errorBucket,
            waitingBucket : waitingBucket,
            lateCount : lateCount,
            errorCount : errorCount,
            waitingCount : waitingCount,
            completeCount : completeCount,
            inprogressCount : inprogressCount,
            totalCount : taskCount,
            actualCount : actualCount,
            estimatedCount : estimatedCount,
            plannedCount : plannedCount,
            minTime : minTime,
            maxTime : maxTime,
            tasksByTags : tasksByTags
        );
    }

    def generateDetailDataFromBuckets(buckets) {

        def lateBucket = buckets.lateBucket;
        def errorBucket = buckets.errorBucket;
        def waitingBucket = buckets.waitingBucket;

        def lateCount = buckets.lateCount;
        def errorCount = buckets.errorCount;
        def waitingCount = buckets.waitingCount;


        def inprogressCount = buckets.inprogressCount;
        def completeCount = buckets.completeCount;
        def totalCount = buckets.totalCount;

        def actualCount = buckets.actualCount;
        def estimatedCount = buckets.estimatedCount;
        def plannedCount = buckets.plannedCount;

        def isActualInterval = true;

        def progress = 0;

        def lastPlanned = 0;
        def lastActual = 0;
        def lastEstimated = 0;

        def minTime = buckets.minTime;
        def maxTime = buckets.maxTime;

        def intervalSize = (Long)((maxTime - minTime) / numIntervals);

        GraphDataPoint[] dataPoints = new GraphDataPoint[numIntervals];

        for(int i = 0; i < numIntervals; i++) {

            if(sd.status == "NOTSTARTED") {
                dataPoints[i] = new GraphDataPoint(
                    timestamp: (minTime + (int)(i * intervalSize)),
                    plannedCount: plannedCount[i] + lastPlanned,
                    estimatedCount: plannedCount[i] + lastPlanned); // same as planned if not started
            }
            else if(isActualInterval) {
                dataPoints[i] = new GraphDataPoint(
                    timestamp: (minTime + (int)(i * intervalSize)),
                    plannedCount: plannedCount[i] + lastPlanned,
                    actualCount: actualCount[i] + lastActual);

                lastActual = actualCount[i] + lastActual;

                if(estimatedCount[i] > 0) {
                    lastEstimated = estimatedCount[i] + lastActual;
                    isActualInterval = false;
                }
            }
            else {
                dataPoints[i] = new GraphDataPoint(
                    timestamp: (minTime + (int)(i * intervalSize)),
                    plannedCount: plannedCount[i] + lastPlanned,
                    estimatedCount: estimatedCount[i] + lastEstimated);

                lastEstimated = estimatedCount[i] + lastEstimated;
            }

            lastPlanned = plannedCount[i] + lastPlanned;
        }

        return new DeploymentDetail(
            lineGraph:(new LineGraphObject(
                taskCount: 0,
                minTime: minTime,
                maxTime: maxTime,
                dataPoints: dataPoints)),
            taskStatus: new TaskStatusCount(
                late: lateBucket,
                waiting: waitingBucket,
                error: errorBucket),
            taskProgress: new TaskProgressCount(
                inprogress: inprogressCount,
                complete: completeCount,
                total: totalCount),
            taskCount: new TaskStatusCount(
                late: lateCount,
                waiting: waitingCount,
                error: errorCount),
            progress: progress,
            tasksByTags: buckets.tasksByTags);

    }

    def serializeTask(task) {
        def statusString = task.status;
        if(task.status == "CLOSED") {
            if(task.result == "FAILURE") {
                statusString = "FAILURE";
            }
            else {
                statusString = "COMPLETE";
            }
        }

        def roleText;

        if(task.executorRole != null) {
            roleText = task.executorRole.name;
        }
        else if(task.executorGroup != null) {
            roleText = task.executorGroup.name;
        }

        if(!userIds.contains(task.userId) && task.userId != null) {
            userIds << task.userId;
        }

        return new TaskDetail(
            id: task.id,
            name: task.name,
            startTime: (task.startTimeActual != null ? task.startTimeActual : task.startTimeEstimated),
            startTimePlanned: task.startTimePlanned,
            duration: task.duration,
            endTime: task.endTimeActual,
            userId: task.userId,
            userName: task.userName,
            userPhone: null,
            status:statusString,
            role: roleText);
    }

    def generateName(sd) {
        // Classic UCR verbose name
        //return sd.release.name + ": " + sd.environment.name + " at " + (new Date(sd.scheduledDate));

        // UCCloud Name
        return "Deployment to " + sd.environment.name + " for " + sd.release.name;
    }

    def getRDStartTime(rdId) {
        def sd = (new ScheduledDeployment());
        sd.format("deploymentstab");
        def resultList = sd.filter("relatedDeployment.id", FilterClass.UUID, FilterType.EQUALS, rdId).when().getAll();

        def startTime;
        for(ScheduledDeployment dep : resultList) {
            def depStart = dep.scheduledDate;

            if(dep.deploymentExecution.startTimeActual != null) {
                depStart = Math.min(dep.deploymentExecution.startTimeActual, dep.scheduledDate);
            }

            if(startTime == null) {
                startTime = depStart;
            }
            else {
                startTime = Math.min(startTime, depStart);
            }
        }
        return startTime;
    }

    def combineBuckets(objA, objB) {
        if(objA == null) {
            return objB;
        }

        for(int i = 0; i < objB.actualCount.length; i++) {
            objA.actualCount[i] += objB.actualCount[i];
            objA.estimatedCount[i] += objB.estimatedCount[i];
            objA.plannedCount[i] += objB.plannedCount[i];
        }

        objA.lateCount += objB.lateCount;
        objA.errorCount += objB.errorCount;
        objA.waitingCount += objB.waitingCount;

        objA.completeCount += objB.completeCount;
        objA.inprogressCount += objB.inprogressCount;
        objA.totalCount += objB.totalCount;

        // Combine Lates
        objB.lateBucket.each { key, value ->
            objA.lateBucket.put(key, value);
        }

        // Combine Errors
        objB.errorBucket.each { key, value ->
            objA.errorBucket.put(key, value);
        }

        // Combine Waiting
        objB.waitingBucket.each { key, value ->
            objA.waitingBucket.put(key, value);
        }

        objB.tasksByTags.each { key, value ->
            if(!objA.tasksByTags.containsKey(key)) {
                objA.tasksByTags.put(key, value);
            }
            else {
                def tagObj = objA.tasksByTags.get(key);

                tagObj.totalTasks = tagObj.totalTasks + value.totalTasks;
                tagObj.completeTasks = tagObj.completeTasks + value.completeTasks;
                tagObj.inProgressTasks = tagObj.inProgressTasks + value.inProgressTasks;
                tagObj.failedTasks = tagObj.failedTasks + value.failedTasks;

                if(tagObj.startTimeActual != null && value.startTimeActual != null) {
                    tagObj.startTimeActual = Math.min(tagObj.startTimeActual, value.startTimeActual);
                }
                else {
                    if(value.startTimeActual != null) {
                        tagObj.startTimeActual = value.startTimeActual;
                    }
                }
                if(tagObj.endTimeActual != null && value.endTimeActual != null) {
                    tagObj.endTimeActual = Math.max(tagObj.endTimeActual, value.endTimeActual);
                }
                else {
                    tagObj.endTimeActual = null;
                }

                tagObj.startTimePlanned = Math.min(tagObj.startTimePlanned, value.startTimePlanned);
                if(value.startTimeEstimated != null && tagObj.startTimeEstimated != null) {
                    tagObj.startTimeEstimated = Math.min(tagObj.startTimeEstimated, value.startTimeEstimated);
                }
                else if(value.startTimeEstimated != null) {
                    tagObj.startTimeEstimated = value.startTimeEstimated;
                }

                tagObj.endTimePlanned = Math.max(tagObj.endTimePlanned, value.endTimePlanned);
                if(value.endTimeEstimated != null && tagObj.endTimeEstimated != null) {
                    tagObj.endTimeEstimated = Math.min(tagObj.endTimeEstimated, value.endTimeEstimated);
                }
                else if(value.endTimeEstimated != null) {
                    tagObj.endTimeEstimated = value.endTimeEstimated;
                }
            }

            objB.tasksByTags.users.each { u ->
                if(!objA.tasksByTags.users.contains(u)) {
                    objA.tasksByTags.users << u;
                }
            }
        }

        return objA;
    }

    def generateTaskBucketByDeployment(sd, teamName) {
        return new TaskBucketByDeployment(
            message : sd.statusText,
            userId : null, //TODO NEEDS IMPLEMENTED
            timestamp : null, //TODO NEEDS IMPLEMENTED
            statusColor : sd.statusState,
            teamName : teamName,
            tasks : []);
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}

def class TaskBucketObject {
    def lateBucket;
    def errorBucket;
    def waitingBucket;

    def lateCount;
    def errorCount;
    def waitingCount;

    def completeCount;
    def inprogressCount;
    def totalCount;

    def actualCount;
    def estimatedCount;
    def plannedCount;

    def minTime;
    def maxTime;
    def progress;

    def tasksByTags;
}

def class TaskBucketByDeployment {
    def message;
    def userId;
    def timestamp;
    def statusColor;
    def teamName;
    def tasks;
}