package com.urbancode.plugin

import com.urbancode.air.*
import com.urbancode.plugin.models.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;

public class ApprovalSerializer {

    def approvalJsonArray;
    def syncId;
    def integrationId;

    def teams = [];
    def teamIds = [];
    def userIds = [];

    public ApprovalSerializer(approvalJsonArray, syncId, integrationId) {
        this.approvalJsonArray = approvalJsonArray;
        this.syncId = syncId;
        this.integrationId = integrationId;
    }

    def serializeApprovals() {

        def result = [] as List;

        for (je in approvalJsonArray) {
            def reqObj = je.getAsJsonObject().get("requestor").getAsJsonObject();

            def teamsJsonArr = je.getAsJsonObject().get("teams").getAsJsonArray();
            def teams = [];
            
            for (teamJe in teamsJsonArr) {
                teams.add(new NameIdPair(id: teamJe.getAsJsonObject().get("id").getAsString(), name: teamJe.getAsJsonObject().get("name").getAsString()))
            }
            
            def envName = je.getAsJsonObject().get("environmentName") == null ? null : je.getAsJsonObject().get("environmentName").getAsString();
            def appName = je.getAsJsonObject().get("applicationName") == null ? null : je.getAsJsonObject().get("applicationName").getAsString();
            def procName = je.getAsJsonObject().get("processName") == null ? null : je.getAsJsonObject().get("processName").getAsString();
            
            def role = null;
            
            if(je.getAsJsonObject().get("role") != null) {
                def roleObj = je.getAsJsonObject().get("role").getAsJsonObject();
                def roleId = roleObj.get("id").getAsString();
                def roleName = roleObj.get("name").getAsString();
                role = new NameIdPair(id: roleId, name: roleName)
            }
            
            def userName = reqObj.get("name") == null ? null : reqObj.get("name").getAsString();
            def userEmail = reqObj.get("email") == null ? null : reqObj.get("email").getAsString();
            def userDisplayName = reqObj.get("displayName") == null ? null : reqObj.get("displayName").getAsString();
            
            def commentPrompt = ""
            if(je.getAsJsonObject().has("commentPrompt")) {
                commentPrompt = je.getAsJsonObject().get("commentPrompt").getAsString()
            }

            def approval = new Approval(
                id: je.getAsJsonObject().get("id").getAsString(),
                type: "Approval",
                subtype: "Deploy",
                context: (new ApprovalContext(
                    name: je.getAsJsonObject().get("name").getAsString(),
                    environment: envName,
                    application: appName,
                    process: procName,
                    )),
                requestor: new User(name: userName, email: userEmail, displayName: userDisplayName),
                commentEnabled: true,
                commentRequired: je.getAsJsonObject().get("commentRequired").getAsBoolean(),
                commentPrompt: commentPrompt,
                requestedDate: je.getAsJsonObject().get("requestedDate") != null ? je.getAsJsonObject().get("requestedDate").getAsLong() : null,
                scheduledDate: je.getAsJsonObject().get("scheduledDate") != null ? je.getAsJsonObject().get("scheduledDate").getAsLong() : null,
                status: je.getAsJsonObject().get("status").getAsString(),
                teams: teams,
                role: role,
                syncId: syncId,
                integrationId: integrationId
            )

            result.add(approval);
        }

        return result;
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}

