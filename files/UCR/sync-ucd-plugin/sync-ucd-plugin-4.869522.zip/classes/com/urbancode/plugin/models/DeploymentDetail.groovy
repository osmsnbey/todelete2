package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for details of deployment dashboard
public class DeploymentDetail {
    def progress;
    def taskStatus;
    def taskCount;
    def taskProgress;
    def lineGraph;
    def tasksByTags;
}