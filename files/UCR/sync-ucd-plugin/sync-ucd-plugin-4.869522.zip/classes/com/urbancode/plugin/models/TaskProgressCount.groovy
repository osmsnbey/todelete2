package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for basic task counts
public class TaskProgressCount {
    def inprogress;
    def complete;
    def total;
}