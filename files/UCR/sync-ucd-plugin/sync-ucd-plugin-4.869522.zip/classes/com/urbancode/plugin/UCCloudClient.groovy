package com.urbancode.plugin

import com.urbancode.air.*
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

import groovy.json.JsonBuilder;

public class UCCloudClient {

    private boolean debug = false;

    private final String DEPLOYMENT_OVERVIEW_ORIGINAL = "api/v1/deployments/overview";
    private final String DEPLOYMENT_OVERVIEW = "api/v1/deployments/{id}/overview";
    private final String DEPLOYMENT_OVERVIEW_BULK = "api/v1/deployments/overview";
    private final String REGISTER_UCR = "api/v1/ucr";
    private final String REGISTER_TEAMS = "api/v2/teams"
    private final String APPROVALS_BULK = "api/v2/actionitem"
    
    private String syncId;
    private String syncToken;
    private String instanceId;

    def cloudUrl;
    HttpClient client;

    //Main constructor
    UCCloudClient (url, syncId, syncToken, integrationId) {
        client = HttpClientBuilder.create().build();
        cloudUrl = addSlash(url);
        this.syncId = syncId;
        this.syncToken = syncToken;
        this.instanceId = integrationId
    }

    //Main constructor
    UCCloudClient (url) {
        client = HttpClientBuilder.create().build();
        cloudUrl = addSlash(url);
    }

    //--------------------------------------------------------------
    //Authentication with Release
    private postJson (url, json) {
    
        trace("Now executing a POST\n" + url);

        HttpPost post = new HttpPost(url);
        if(this.syncId != null) {
            post.setHeader("sync_id", this.syncId);
            post.setHeader("sync_token", this.syncToken);
            post.setHeader("instance_id", this.instanceId);
            post.setHeader("instance_type", "UCD");
        }

        def body = new JsonBuilder(json).toString();
        
        HttpEntity entity = new StringEntity(body);
        post.setHeader("Content-Type", "application/json");
        post.setEntity(entity);
        HttpResponse response = client.execute(post);

        return response;
    }

    //--------------------------------------------------------------
    //Authentication with Release
    def getJson () {
        HttpGet request = new HttpGet(cloudUrl);

        trace("Now executing a GET");

        HttpResponse response = client.execute(request);

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        trace(result);
    }

    //--------------------------------------------------------------
    //Authentication with Release
    public postBulkDeployments (json) {
        def response = postJson(
            cloudUrl + DEPLOYMENT_OVERVIEW_BULK,
            json);

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer result = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        trace(result);
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Posting deployments failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to POST deployments");
        }
    }

    //--------------------------------------------------------------
    //Authentication with Release
    public postBulkApprovals (json) {

        def response = postJson(
            cloudUrl + APPROVALS_BULK,
            json);

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer result = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        trace(result);
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Posting approvals failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to POST approvals");
        }
    }


    //--------------------------------------------------------------
    //
    public postTeams (json) {

        def response = postJson(
            cloudUrl + REGISTER_TEAMS,
            json);

                trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer result = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            result.append(line);
        }
        
        if(response.getStatusLine().getStatusCode() != 200) {
            if(response.getStatusLine().getStatusCode() == 400) {
                printLog("WARNING", "Posting one of the teams was skipped.  Are there any users in that team who aren't admin, releaser, or user?");
                printLog("WARNING", result);
            }
            else {
                printLog("WARNING", "Posting teams failed");
                printLog("WARNING", result);
                throw new RuntimeException("Failed to POST teams");
            }
        }
        else {
            trace(result);
        }
    }

    //--------------------------------------------------------------
    // If provided URL does not end with a slash, the slash will be added
    private addSlash(String baseUrl) {
        String url = baseUrl.trim();
        if(baseUrl.charAt(url.length()-1) == '/') {
            return url;
        }
        return url + '/';
    }

    //--------------------------------------------------------------
    // Print message with UCR specific type (like logging level)
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    def trace(message) {
        if(debug == true) {
            printLog("TRACE", message);
        }
    }
}