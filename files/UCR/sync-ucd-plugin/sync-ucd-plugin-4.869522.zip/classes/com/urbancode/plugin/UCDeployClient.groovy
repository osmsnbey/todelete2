package com.urbancode.plugin

import com.urbancode.air.*
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;
import org.apache.http.params.HttpParams;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.client.utils.URIBuilder;

import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import java.security.cert.X509Certificate;

import groovy.json.JsonOutput;

import com.urbancode.plugin.models.Approval;
import com.urbancode.plugin.models.Team;
import com.urbancode.plugin.models.User;
import com.urbancode.plugin.models.UCDUser;
import com.urbancode.plugin.models.NameIdPair;
import com.urbancode.plugin.models.UcdAuthToken;

public class UCDeployClient {

    private boolean debug = false;
    
    private final String APPROVALS_ENDPOINT = "cli/approval/task?modifiedAfter={modifiedAfter}"
    private final String USERS_IN_ROLE_ON_TEAM = "cli/user/inRoleOnTeam"
    private final String GET_TEAMS_ENDPOINT = "/security/team"
    private final String GET_ROLES_ENDPOINT = "/security/role"
    private final String USER_EMAIL_ENDPOINT = "cli/user/byEmail?email={email}"
    private final String USER_DETAIL_ENDPOINT = "cli/user/info?user={userId}"
    private final String USER_AUTH_ENDPOINT = "security/authtoken/table?rowsPerPage=1&pageNumber=1&filterFields=user.id&filterValue_user.id={userId}&filterType_user.in=eq&filterClass_user.id=UUID"
    private final String AUTH_TOKEN_ENDPOINT = "security/authtoken";
    private final String APPROVE_ENDPOINT = "cli/approval/task/{taskId}/close"
    
    private String ucr_token
    private cloudUrl;
    HttpClient client;
    
    private gson;

    //Main constructor
    UCDeployClient (url, token) {
        CredentialsProvider credentials = new BasicCredentialsProvider();
        credentials.setCredentials(
                AuthScope.ANY,
                new UsernamePasswordCredentials("PasswordIsAuthToken", token));
            
        //SSL Strategy
        def sslFactory;

        try {
            //We need to allow self signed certificates
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };

            sslFactory = new SSLSocketFactory(acceptingTrustStrategy,
                //allow all host names since the installer creates a certificat for localhost but for sure the
                //customer will use his own domain name with that certificate
                SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

        } catch (Exception ex) {
            printLog("ERROR", "Can not apply SSL strategy "+ ex);
        }
            
            
        client = HttpClientBuilder.create().setSSLSocketFactory(sslFactory).setDefaultCredentialsProvider(credentials).build();
        
        cloudUrl = addSlash(url);
        ucr_token = null;
        
        gson = new Gson();
    }

    //--------------------------------------------------------------
    //Authentication with Release
    private postJson (url, json) {
        trace("Now executing a POST\n" + url);

        HttpPost post = new HttpPost(url);
        if(ucr_token != null) {
            json.ucr_token = this.ucr_token;
            post.setHeader("ucr_token", this.ucr_token);
        }

        def body = JsonOutput.toJson(json);

        HttpEntity entity = new StringEntity(body);
        post.setHeader("Content-Type", "application/json");
        post.setEntity(entity);
        HttpResponse response = client.execute(post);

        return response;
    }
    
    private putJson (url, json) {
        trace("Now executing a PUT\n" + url);

        HttpPut put = new HttpPut(url);
        if(ucr_token != null) {
            json.ucr_token = this.ucr_token;
            put.setHeader("ucr_token", this.ucr_token);
        }

        def body = JsonOutput.toJson(json);

        HttpEntity entity = new StringEntity(body);
        put.setHeader("Content-Type", "application/json");
        put.setEntity(entity);
        HttpResponse response = client.execute(put);

        return response;
    }

    //--------------------------------------------------------------
    //Authentication with Release
    private getJson (url) {
        return getJson(url, null);
    }
    
    //--------------------------------------------------------------
    //Authentication with Release
    private getJson (url, paramsMap) {
        def builder = new URIBuilder(url);
        
        if(paramsMap != null) {
            paramsMap.each{ k, v -> builder.setParameter(k, v); }
        }
        
        HttpGet request = new HttpGet(builder.build());
        request.setHeader("Content-Type", "application/json");
        
        trace("Now executing a GET");

        HttpResponse response = client.execute(request);
        
        return response;
    }
    
    //--------------------------------------------------------------
    //Authentication with Release
    public getApprovals (modifiedAfter) {
        def response = getJson(
            cloudUrl + APPROVALS_ENDPOINT.replace("{modifiedAfter}", modifiedAfter.toString()));

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer result = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        trace(result);
        
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Getting UCD approvals failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to GET approvals");
        }
        
        JsonParser parser = new JsonParser();
        
        JsonElement jsonElement = parser.parse(result.toString());
        
        Gson gson = new Gson();
        
        return jsonElement.getAsJsonArray();
    }

    //--------------------------------------------------------------
    //Authentication with Release
    public getTeams (modifiedAfter) {
        def response = getJson(
            cloudUrl + GET_TEAMS_ENDPOINT);

        def temp = getJsonElementFromResponse(response);
        
        return gson.fromJson(temp, Team[].class);
    }

    public getRoles (modifiedAfter) {
        def response = getJson(
            cloudUrl + GET_ROLES_ENDPOINT);

        return gson.fromJson(getJsonElementFromResponse(response), NameIdPair[].class);
    }
    
    public getUsersInRoleOnTeam (teamId, roleId) {
        def params = [:];
        params.put("role", roleId);
        params.put("team", teamId);
        
        def response = getJson(cloudUrl + USERS_IN_ROLE_ON_TEAM, params);
        
        return gson.fromJson(getJsonElementFromResponse(response), UCDUser[].class);
    }
    
    private getJsonElementFromResponse(response) {
    
        try {
        trace("Response Code : "
            + response.getStatusLine().getStatusCode());
        
        HttpEntity entity = response.getEntity();
        
        StringBuffer result;
        
        try {
            BufferedReader rd = new BufferedReader(
                new InputStreamReader(entity.getContent()));
                    
            
            String line = "";
            result = new StringBuffer();
            
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }
        }
        finally {
            EntityUtils.consume(entity);
        }        
        trace(result);
        
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Getting response body failed")
            printLog("WARNING", response.getStatusLine().getStatusCode());
            printLog("WARNING", result)
            
            throw new RuntimeException("Failed to GET response body");
        }
        
        JsonParser parser = new JsonParser();
        
        JsonElement jsonElement = parser.parse(result.toString());
        
        return jsonElement;
        }
        catch (all) {
            throw all;
        }
    }
    
    public approveTask(taskId, approvalRequest) {
        def response = putJson(
            cloudUrl + APPROVE_ENDPOINT.replace("{taskId}", taskId), approvalRequest);
        
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Approving task failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to approve task");
        }
    }
    
    public getUserByEmail (email) {
        def response = getJson(
            cloudUrl + USER_EMAIL_ENDPOINT.replace("{email}", email));

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        def temp = getJsonElementFromResponse(response);
        
        def user = gson.fromJson(temp, User.class);
        
        return user;
    }
    
    public getUserDetail (userId) {
        def response = getJson(
            cloudUrl + USER_DETAIL_ENDPOINT.replace("{userId}", userId));

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        def temp = getJsonElementFromResponse(response);
        
        def user = gson.fromJson(temp, User.class);
        user.displayName = temp.actualName;

        return user;
    }
    
    public saveAuthToken(authToken) {
        
        def url = cloudUrl + AUTH_TOKEN_ENDPOINT;
        
        def response = putJson(url, authToken);
        
        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer responseBody = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            responseBody.append(line);
        }
        
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Creating Auth Token failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to PUT auth token");
        }
        
        JsonParser parser = new JsonParser();
        
        JsonElement jsonElement = parser.parse(responseBody.toString());
        
        Gson gson = new Gson();
        
        def token = gson.fromJson(jsonElement, UcdAuthToken.class);
        
        return token;
    }
    
    public getAuthTokenForUser (user) {
        def response = getJson(
            cloudUrl + USER_AUTH_ENDPOINT.replace("{userId}", user.id));

        trace("Response Code : "
                    + response.getStatusLine().getStatusCode());

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = "";
        StringBuffer result = new StringBuffer();

        while ((line = rd.readLine()) != null) {
            result.append(line);
        }

        trace(result);
        
        if(response.getStatusLine().getStatusCode() != 200) {
            printLog("WARNING", "Getting UCD user failed")
            printLog("WARNING", result)
            throw new RuntimeException("Failed to GET user");
        }
        
        JsonParser parser = new JsonParser();
        
        JsonElement jsonElement = parser.parse(result.toString());
        
        JsonArray records = jsonElement.getAsJsonObject().get("records").getAsJsonArray();
        
        return records.get(0).getAsJsonObject().get("token");
    }
    
    //--------------------------------------------------------------
    // If provided URL does not end with a slash, the slash will be added
    private addSlash(String baseUrl) {
        String url = baseUrl.trim();
        if(baseUrl.charAt(url.length()-1) == '/') {
            return url;
        }
        return url + '/';
    }

    //--------------------------------------------------------------
    // Print message with UCR specific type (like logging level)
    private printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    private trace(message) {
        if(debug == true) {
            printLog("TRACE", message);
        }
    }
}