package com.urbancode.plugin

import com.urbancode.air.*

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.urbancode.release.rest.models.Role;
import com.urbancode.plugin.models.Team;
import com.urbancode.plugin.models.User;

public class TeamRoleSerializer {

    def teamId;
    def teamName;
    def roleUserMap;

    public TeamRoleSerializer(id, name, role_user_map) {
        //SeedHandler.handle(id);
        teamId = id;
        teamName = name;
        roleUserMap = role_user_map;
    }

    def serializeToObject() {
        def rolesMap = [:];

        def temp;
        roleUserMap.each { entry ->
            temp = entry.key.id;
            rolesMap.put(entry.key.id, new RoleObj(id: entry.key.id, name: entry.key.name, users:generateUserList(entry.value)));
        }
        
        return new Team(id: teamId, name:teamName, roles: rolesMap);
    }

    def generateUserList(userList) {
        def users = [];
        userList.each { user ->
            if(user instanceof User) {
                users << new User(id: user.id.toString(), name: user.name.toString(), email: user.email.toString(), displayName: user.displayName.toString());
            }
            else {
                users << new User(id: user.id, name: user.name, email: user.email, displayName: user.actualName);
            }
        }
        return users;
    }
}

public class RoleObj {
    def id;
    def name;
    def users;
}

