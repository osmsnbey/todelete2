package com.urbancode.plugin.models

public class Team {
    def id;
    def name;
    def roles;
    def users;
}