#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
 
import com.urbancode.air.*
import com.urbancode.plugin.*;

import static com.jayway.restassured.RestAssured.*;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def uri = props['uri'];
def token = props['token'];
def taskId = props['taskId'];
def status = props['status'];

//Clients.loginWithToken(uri, token);
Clients.loginAs(uri, "admin", "admin");

given().put(InternalClients.taskExecution().path(taskId) + "/${status}");
