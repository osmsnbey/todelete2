/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.automation.ALMHelper
import com.urbancode.air.plugin.hp.alm.rest.ALMRestException


def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

ALMHelper helper = new ALMHelper(props)
int exitVal = 0

try {
    helper.authenticate()
    def releases = helper.getReleases()
    println(releases)
    apTool.setOutputProperty("Output", releases)
    apTool.storeOutputProperties()
}
catch (ALMRestException ex) {
    println("Error while retrieving ALM releases:\n" + ex)
    exitVal = 1
}
finally {
    helper.logout()
}

System.exit(exitVal)