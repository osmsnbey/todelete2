/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
package com.urbancode.urelease

import java.io.File;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.urbancode.release.rest.models.internal.RelatedDeployment;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.ScheduledDeploymentVersion;
import com.urbancode.release.rest.models.internal.Milestone;
import com.urbancode.release.rest.models.Release;
import com.urbancode.release.rest.models.Application;
import com.urbancode.release.rest.models.Version;
import com.urbancode.release.rest.models.internal.ScheduledDeploymentVersion;
import com.urbancode.release.rest.models.internal.VersionStatus;
import com.urbancode.release.rest.models.internal.Gate;
import com.urbancode.release.rest.models.internal.ApprovalSet;
import com.urbancode.release.rest.models.internal.ApprovalItem;
import com.urbancode.urelease.UrlHelper;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;
import com.urbancode.release.rest.models.Release.ChangeCount;
import com.urbancode.release.rest.models.internal.DeploymentExecutionUpdate;
import groovy.time.TimeDuration;
import groovy.time.TimeCategory;
import com.urbancode.urelease.ScheduledDeploymentWithTiming;

/**
 * Utilities to assist with email sending in tests and plugins.
 * @author pcentgraf
 */
public class DeploymentTrendContextGenerator {
    protected static Logger log = Logger.getLogger(ReleaseEventContextGenerator.class);

    RelatedDeployment rd;
    String releaseServerUrl;
    def releaseIds;
    def planNameToSDMap;

    public DeploymentTrendContextGenerator(planNameToSDMap, releaseServerUrl) {
        this.releaseServerUrl = releaseServerUrl
        this.planNameToSDMap = planNameToSDMap
    }

    public static def queryForDeployments() {
        def oneWeek = 7L * 24L * 60L * 60L * 1000L;
        ScheduledDeployment query = new ScheduledDeployment();
        query.filter("phase.phaseModel.name", FilterClass.STRING, FilterType.EQUALS, "PROD");
        query.filter("scheduledDate", FilterClass.LONG, FilterType.LESS_THAN, System.currentTimeMillis());
        query.filter("scheduledDate", FilterClass.LONG, FilterType.GREATER_OR_EQUAL, System.currentTimeMillis() - oneWeek);
        query.format("list");

        ScheduledDeployment[] sds = query.getAll()

        def deploymentPlanNames = []

        for(def sd : sds) {
            def deploymentPlanName = sd.deploymentExecution.deploymentPlan.name
            if(!deploymentPlanNames.contains(deploymentPlanName)) {
                deploymentPlanNames << deploymentPlanName
            }
        }

        def result = [:]

        for(def depName : deploymentPlanNames) {
            result[depName] = DeploymentTrendContextGenerator.retrieveLastFiveDeploymentsOfPlanName(depName)
        }

        return result;
    }

    private static def retrieveLastFiveDeploymentsOfPlanName(planName) {
        ScheduledDeployment query = new ScheduledDeployment();
        query.filter("deploymentExecution.deploymentPlan.name", FilterClass.STRING, FilterType.EQUALS, planName);
        query.filter("scheduledDate", FilterClass.LONG, FilterType.LESS_THAN, System.currentTimeMillis());
        query.orderBy("scheduledDate")
        def result = query.getPage(0,4);

        return result
    }

    public def generateContext() {
        def result = [:]

        addDeploymentPlanContext(result)

        addStyleContext(result)

        return result
    }

    private addDeploymentPlanContext(context) {

        def planNameKeySet = planNameToSDMap.keySet()

        def deploymentPlans = []

        for(def planName : planNameKeySet) {
            def deploymentPlanObj = [:]
            def sdList = planNameToSDMap[planName]

            def deployments = []
            for(def sd : sdList) {
                def sdObj = [:]
                sd.format("detail")
                sd = sd.get()

                sdObj["release"] = sd.release.name
                sdObj["env"] = sd.environment.name
                sdObj["date"] = new SimpleDateFormat("MM/dd/YYYY HH:MM").format(sd.scheduledDate)
                sdObj["url"] = UrlHelper.concatPaths(releaseServerUrl, "scheduledDeployment", sd.id)
                if(sd.deploymentExecution.status != null) {
                    sdObj["status"] = sd.deploymentExecution.status
                }

                def endTimePlanned = getPlannedEndTime(sd)

                if (endTimePlanned != null) {
                    sdObj["plannedDuration"] = getDurationString(new Date(endTimePlanned), new Date(sd.scheduledDate))
                } else {
                    sdObj["plannedDuration"] = ""
                }

                if (sd.deploymentExecution.endTimeActual != null) {
                    sdObj["actualDuration"] = getDurationString(new Date(sd.deploymentExecution.endTimeActual), new Date(sd.deploymentExecution.startTimeActual))
                } else {
                    sdObj["actualDuration"] = ""
                }

                if(sd.versions != null) {
                    sdObj["versionCount"] = sd.versions.length
                } else {
                    sdObj["versionCount"] = 0
                }

                sdObj["manAuto"] = getManAutoCount(sd)
                deployments << sdObj
            }

            deploymentPlanObj["deployments"] = deployments
            deploymentPlanObj["name"] = planName
            deploymentPlans << deploymentPlanObj
        }

        context["deploymentPlans"] = deploymentPlans
    }

    private def getManAutoCount(sd) {
        def totalCount = 0
        def automatedCount = 0
        def result = [:]
        for(def se : sd.deploymentExecution.segments) {
            for(def te: se.tasks) {
                totalCount++
                if(te.automated) {
                    automatedCount++
                }
            }
        }

        def percent = 0
        if(totalCount > 0) {
            percent = Math.round(automatedCount / totalCount * 100)
        }

        result["total"] = totalCount
        result["automated"] = automatedCount
        result["percent"] = percent

        return result
    }

    private def getPlannedEndTime(sd) {
        if(sd.deploymentExecution.endTimePlanned != null) {
            return sd.deploymentExecution.endTimePlanned
        }

        ScheduledDeploymentWithTiming sdwt = new ScheduledDeploymentWithTiming();

        ScheduledDeployment newSD = sdwt.getSDWithTiming(sd.id);

        return newSD.deploymentExecution.endTimePlanned
        //return result
    }

    // Normalize method to return a new TimeDuration
    private TimeDuration normalize( TimeDuration tc ) {
        return new TimeDuration( ( tc.days != 0 ? tc.days * 24 : 0 ) + tc.hours,
                        tc.minutes, tc.seconds, tc.millis )
    }

    private def getDurationString (end, start) {
        def tc = TimeCategory.minus(end, start)

        return (normalizeDigit(tc.hours) + ":" + normalizeDigit(tc.minutes) + ":" + normalizeDigit(tc.seconds))
    }

    private def normalizeDigit(digit) {
        if (digit < 10) {
            return "0" + digit
        } else {
            return digit
        }
    }

    private def addStyleContext(context) {
        context["spacerStyle"] = "height: 35px; width: 100%;"
        context["subHeadingStyle"] = "font-weight: bold;font-size: 20px;font-family: sans-serif; margin-top: 10px;"
        context["subSectionStyle"] = "margin-left: 25px; margin-top: 10px;"
        context["indentStyle"] = "margin-left: 15px;"
        context["smallHeadingStyle"] = "font-weight: bolder;font-size: 15px;font-family: sans-serif;"

        context["tableStyle"] = "border-collapse: collapse; text-align: left; width: 100%;"
        context["thStyle"] = "background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #006699), color-stop(1, #00557F) );background:-moz-linear-gradient( center top, #006699 5%, #00557F 100% );filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#006699', endColorstr='#00557F');background-color:#006699; color:#FFFFFF; font-size: 12px; font-weight: bolder; border-left: 1px solid #0070A8; width: 125px;"
        context["trStyle"] = "padding: 3px 10px;"
        context["tdStyle"] = "padding: 3px 10px; background: #FFFFFF; color: #00496B; border-left: 1px solid #E1EEF4;font-size: 12px;font-weight: normal;"
        context["td-altStyle"] = "padding: 3px 10px; background: #E1EEF4; color: #00496B; border-left: 1px solid #E1EEF4;font-size: 12px;font-weight: normal;"
        context["redTdStyle"] = "padding: 3px 10px; background: #ff8080; color: #00496B; border-left: 1px solid #E1EEF4;font-size: 12px;font-weight: normal;"
        context["lateOutstandingStyle"] = "clear:left; font-weight: bolder; color: #cc3300; margin-top: 5px; margin-bottom: 15px;"
    }
}
