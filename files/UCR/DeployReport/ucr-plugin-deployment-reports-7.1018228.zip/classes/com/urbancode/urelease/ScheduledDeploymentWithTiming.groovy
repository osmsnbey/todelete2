/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
package com.urbancode.urelease

import java.io.File;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.urbancode.release.rest.models.internal.ScheduledDeployment;

/**
* This is a hack to ensure timing will be on the SD
*/
public class ScheduledDeploymentWithTiming {

    public def getSDWithTiming(id) {
        ScheduledDeployment sd = new ScheduledDeployment()
        sd.id(id + "/deploymentWithTiming")
        sd = sd.get()
        return sd
    }

}
