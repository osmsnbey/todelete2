package com.urbancode.air

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.release.rest.models.Team
import com.urbancode.release.rest.models.User
import com.urbancode.release.rest.models.internal.ScheduledDeployment
import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPost
import org.apache.http.util.EntityUtils
import org.apache.log4j.*
import org.codehaus.jettison.json.JSONArray
import org.codehaus.jettison.json.JSONObject

import java.text.SimpleDateFormat

public class CreateChannelAndInvite {
    def authToken;
    Logger log = Logger.getInstance(getClass())
    public CreateChannelAndInvite(def authToken) {
        this.authToken = authToken;
    }

    /**
     * This method will return all users in a slack team using RESTAPI: https://slack.com/api/users.list?token=xxxx
     * The token is configured on the Integration page of Slack on UCR,
     * This method will parse the JSON response containing details of the slack users to create a new JSON Object with the following properties:
     *      {
     *          "property-name" : "slack_member_id",
     *          users:[
     *              {
     *              "email" : < SlackUser - Email_Value >
     *               "propValue" : < SlackUser - Member - ID_Value >
     *              }
     *          ]
     *      }
     * This method calls sync() of the User class once the JSON Object is framed.
     * @param token
     * @throws Exception
     */
    public void syncSlackUsers(String token) throws Exception {
        log.info("Syncing Slack Users");
        if (token != null && !token.isEmpty()) {
            HttpClientBuilder builder = new HttpClientBuilder();
            builder.setTrustAllCerts(true);
            HttpClient client = builder.buildClient();
            String slackUserURL = "https://slack.com/api/users.list?token=" + token;
            HttpGet request = new HttpGet(slackUserURL);
            HttpResponse response = client.execute(request);
            JSONObject mainObj = new JSONObject(EntityUtils.toString(response.getEntity()));
            boolean isValidToken = mainObj.getString("ok").equalsIgnoreCase("true")
            log.info("Is the token used valid: "+isValidToken);
            if(isValidToken){
                JSONArray memberArray = mainObj.getJSONArray("members");
                int userCount = memberArray.length();
                JSONObject slackData = new JSONObject();
                slackData.put("property-name", "slack_member_id");
                JSONArray slackMembers = new JSONArray();
                for (int i = 0; i < memberArray.length(); i++) {
                    JSONObject obj = memberArray.getJSONObject(i);
                    String memberID = obj.getString("id");
                    boolean is_email_confirmed = obj.getBoolean("is_email_confirmed");
                    JSONObject profile = obj.getJSONObject("profile");
                    if (is_email_confirmed) {
                        String emailID = profile.getString("email");
                        JSONObject slackUser = new JSONObject();
                        slackUser.put("email", emailID);
                        slackUser.put("propValue", memberID);
                        slackMembers.put(slackUser);
                    }
                }
                slackData.put("users", slackMembers);
                if (userCount > 0) {
                    User user = new User();
                    log.info("Sync Slack users with ucr database users");
                    user.sync(slackData);
                }
            } else {
                throw new ExitCodeException("Host Authentication Token used is not valid!")
            }
        }
    }

	/**
	 * This method will fetch the Deployment Name currently under execution and create
	 * a slack channel with the same name as the Deployment Name in UCRelease by using
	 * the REST API https://slack.com/api/conversations.create?name=xxxx. Once the
	 * channel is successfully created in Slack, then this method will query all the
	 * slack member is' with property value configured as "slack_member_id" from the
	 * sec_user_property table and invite these members to the channel created using,
	 * the Slack REST API
	 * https://slack.com/api/conversations.invite?channel="+channel_id+"&users=<memberId's>
	 *
	 * @param deployment
	 * @param phase_name
	 * @param release_name
	 */
    public void createChannel(ScheduledDeployment deployment, String phase_name, String release_name) {
        log.info("Creating channel for the current deployment");
        def propsParser = new PropsParser();
        HttpClientBuilder builder = new HttpClientBuilder();
        builder.setTrustAllCerts(true);

        long date = Long.valueOf(deployment.scheduledDate);
        SimpleDateFormat format = new SimpleDateFormat("MMM_dd_YYYY_hh_mm_aa");
        String channelName = release_name.toLowerCase().replace(" ", "_") + "_" + phase_name.toLowerCase().replace(" ", "_") + "_" + format.format(date).toLowerCase();
        log.info("Deployment channel name created : "+channelName);
        String postURL = "https://slack.com/api/conversations.create?name=" + channelName + "&pretty=1";
        def client = builder.buildClient();
        HttpPost methodPost = new HttpPost(postURL);
        methodPost.addHeader("Authorization", "Bearer " + authToken)

        HttpResponse responsePost = client.execute(methodPost);
        def entity = responsePost.getEntity();
        if (entity != null) {
            String result = EntityUtils.toString(entity, "UTF-8");
            JSONObject job_created = new JSONObject(result);
            JSONObject channel = job_created.getJSONObject("channel");
            String channel_id = channel.getString("id");
            String teamId = deployment.release.teamId;
			invitePeople(channel_id, teamId);
        }
    }

    /**
     * This method will be used to pull slack users who are synced with ucr users and send them invite
     * @param channel_id
     * @param releaseTeamID
     */
    public void invitePeople(String channel_id, String releaseTeamID) {
        log.info("Inviting People to Deployment channel created");
        HttpClientBuilder builder = new HttpClientBuilder();
        builder.setTrustAllCerts(true);

        // Retrieve all-ready synced in users from ucr database.
        Team team = new Team();
        JsonArray memberArray = team.getTeamUserProps(releaseTeamID, "slack_member_id");
        String slackUsers = "";
        int len = memberArray.size();
        if (len > 0) {
            for (int i = 0; i < len; i++) {
                JsonObject obj = memberArray.get(i).getAsJsonObject();
                if (i < len - 1) {
                    slackUsers = slackUsers + obj.get("value").getAsString() + ",";
                } else {
                    slackUsers = slackUsers + obj.get("value").getAsString();
                }
            }
            log.info("The invite to be sent to users : " + slackUsers)
            String postURL = "https://slack.com/api/conversations.invite?channel=" + channel_id + "&users=" + slackUsers + "&pretty=1";
            def client = builder.buildClient();
            HttpPost methodPost = new HttpPost(postURL);
            methodPost.addHeader("Authorization", "Bearer " + authToken)

            HttpResponse responsePost = client.execute(methodPost);
            def entity = responsePost.getEntity();
            if (entity != null) {
                String result = EntityUtils.toString(entity, "UTF-8");
                JSONObject job_created1 = new JSONObject(result);
                JSONObject channel1 = job_created1.getJSONObject("channel");
            }
        } else {
            log.warn("There are no slack users in-sync with ucr");
        }
    }
}