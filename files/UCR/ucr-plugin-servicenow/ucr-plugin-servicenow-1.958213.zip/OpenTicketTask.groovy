#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1
import com.urbancode.air.*
import com.urbancode.plugin.*;

import com.urbancode.plugin.*;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.PhaseModel;
import com.urbancode.release.rest.models.internal.Lifecycle;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.TaskComment;
import com.urbancode.air.PropsParser;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;


/**
 * Script for obtaining the phases in UCR. Primarily used for the integration's checked multi-
 * select for selecting phases.
 *
 * @author aberk
 */

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

// UCR auth variables
def token = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];

def slurper1 = new groovy.json.JsonSlurper()
def tokenJson = slurper1.parseText(token)

def extraProperties = props['extraProperties']

Date date = new Date();
String requestedDate = date.format( 'yyyy-MM-dd HH:mm:ss' )

def group = props['serviceNowAssignedGroup']
def workflow = props['workflow']
def tableName = "change_request"
def approval='requested'
def requested_by_date=requestedDate
def start_date=requestedDate
def description="This ticket was created by an UrbanCode Release task..."
def shortDescription="This is the short description"
def statusCreated = props['deploymentCreatedState']

def pluginProps = [:]
def propsParser = new PropsParser();

// Establish the client connection
Clients.loginWithToken(serverUrl, tokenJson.token, 0);

HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)

def task;

if (extraProperties != null) {
    def slurper = new groovy.json.JsonSlurper()
    def currentTaskExtra = slurper.parseText(extraProperties)

    if (currentTaskExtra != null) {
        //We need the ucr task if so we can handle that UCR object later
        def urcTaskId = currentTaskExtra.task.id

        task = new TaskExecution()
        task.id(urcTaskId)

        task = task.get()

        def taskDescription = task.getProperty("description")
        def taskShortDescription = task.getProperty("shortDescription")
        def taskWorkflow = task.getProperty("workflow")
        def taskGroup = task.getProperty("serviceNowAssignedGroup")
        def taskTable = task.getProperty("table")
        def taskState = task.getProperty("deploymentCreatedState")

        tableName = taskTable ? taskTable : tableName
        description = taskDescription ? taskDescription : description
        shortDescription = taskShortDescription ? taskShortDescription : shortDescription
        workflow = taskWorkflow ? taskWorkflow : workflow
        group = taskGroup ? taskGroup : group
        statusCreated = taskState ? taskState : statusCreated

        println "shortDescription - " + shortDescription

        pluginProps = propsParser.parse(currentTaskExtra.task['properties/PluginProperties'])
    }
}

println pluginProps;

def fieldMap = [:]
//fieldMap["description"] = description
fieldMap["short_description"] = shortDescription
fieldMap["workflow"] = workflow
fieldMap["requested_by_date"] = requested_by_date
fieldMap["approval"] = "requested"
fieldMap["assignment_group"] = group

for(entry in pluginProps) {
    fieldMap[entry.key] = pluginProps[entry.key]
}

def fields = ""
for(entry in fieldMap) {
    if (fieldMap.containsKey(entry.key)) {
        def temp = ("" + entry.key + "=" + entry.value + "\n")
        fields+= temp
    }
}

// // //We create the work item

def crId = helper.insertRow(fields, description)

def recordURL = helper.getURI(tableName, helper.getCRSysId(crId))
def commentText = "The ServiceNow record has been created.<br><br>Table: " + tableName + "<br>ID: " + crId + "<br><a target='_blank' href='" + recordURL + "'>Link to Record</a>"

TaskComment comment = new TaskComment();
comment.task(task);
comment.comment(commentText);
comment.save()

println "========================"
println crId
println "========================"

task.setProperty("record_id", crId);
task.save();

task.complete();