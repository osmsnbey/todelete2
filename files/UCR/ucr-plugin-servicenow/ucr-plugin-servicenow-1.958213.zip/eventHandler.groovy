/*
* Li/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
/* This is an example step groovy to show the proper use of APTool
 * In order to use import these utilities, you have to use the "pluginutilscripts" jar
 * that comes bundled with this plugin example.
 */
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.air.XTrustProvider;
import java.net.URI;
import java.nio.charset.Charset;
import org.apache.log4j.*
import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder;
import com.urbancode.air.XTrustProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.*
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;

//Service Now Client
import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1
//UCR Client
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.ScheduledDeployment.StatusState;

final def workDir = new File('.').canonicalFile

def fetchStepName = "Fetch SNOW Records and Create Deployments"

//Setup log4j
def currentDirectory = new File(getClass().protectionDomain.codeSource.location.path).parent
def config = new ConfigSlurper().parse(new File(currentDirectory+'/log4jSetup.groovy').toURL())
PropertyConfigurator.configure(config.toProperties())
Logger log = Logger.getInstance(getClass())

//Required imports
def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

//Required to access Release endpoints
def releaseToken = props['releaseToken'];
def extraProperties = props['extraProperties'];
//Useful for some operations
//it gets the ID of the integration provider running that step
def integrationProviderId = props['releaseIntegrationProvider'];

//All fields saved from the UI
//to be added automatically by the server
def serverUrl = props['releaseServerUrl'];
if (!serverUrl.endsWith("/")) {
    serverUrl = serverUrl+"/";
}

def group = props['serviceNowAssignedGroup'];
def serviceNowUrl = props['serverUrl']
def phasesSelected = props['phasesSelected']
def releaseName = props['releaseName']
def releasePhase = props['releasePhase']

def statusCreated = props['deploymentCreatedState'];
def statusStarted = props['deploymentStartedState'];
def statusEnded = props['deploymentEndedState'];

//Authenticate with UCR
Clients.loginWithToken(serverUrl, releaseToken);

def provider = new PluginIntegrationProvider().id(integrationProviderId).get()
def isFetchStep = false;

if(provider.defaultStep.equals(fetchStepName)) {
    isFetchStep = true;
}

if (extraProperties != null) {
    def slurper = new groovy.json.JsonSlurper()
    def currentTaskExtra = slurper.parseText(extraProperties)

    //-------------------------------------------------
    def event = currentTaskExtra.event;
    def scheduledDeployment = currentTaskExtra.scheduledDeployment;

    //To get the phase name we need to load the report format
    def sd = new ScheduledDeployment ()
    sd.format("report");
    sd = sd.id(scheduledDeployment.id).get()

    def sdPhase = sd.phase.phaseModel.name;
    def sdPhaseModelId = sd.phase.phaseModel.id;

    log.debug("-------------------------------");
    log.debug(event);
    log.debug(scheduledDeployment.id);
    log.debug(sdPhase);
    log.debug(scheduledDeployment.release.name);
    log.debug(scheduledDeployment.deploymentExecution.status);
    log.debug("-------------------------------");

    //Service Now Client
    HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)

    def handleRelease = false;
    log.debug("Selected phases: " + phasesSelected);
    log.debug("SD Phase Model ID: " + sdPhaseModelId);

    if (!isFetchStep && phasesSelected.contains(sdPhaseModelId)) {
        handleRelease = true
    }

    if (handleRelease || isFetchStep) {
        // When SD is created
        //If status NONE then it means it is not handled
        if (event == "AtDeploymentCreated" && statusCreated != null && statusCreated != "NONE" && !isFetchStep) {
             log.debug("Event AtDeploymentCreated");

             //Scheduled Date
             Date date = new Date(scheduledDeployment.scheduledDate);
             String requestedDate = date.format( 'yyyy-MM-dd HH:mm:ss' )

             //DESCRIPTION
             //List of applications
             def applicationList="";
             log.debug("BaseApp=>"+scheduledDeployment.release)
             scheduledDeployment.release.baseApplication.children.each {
                 app-> applicationList+="     " +app.name+"\r\n";
             }
             //SD Link
             def sdLink = serverUrl+"scheduledDeployment/"+scheduledDeployment.id+"#execution ";

             def multiLineDescription = "Applications:\r\n"+applicationList+"\r\n\r\nUCR Link: "+sdLink

             def fields ="short_description=UCR "+sdPhase+" Scheduled Deployment for release "+scheduledDeployment.release.name+"\n";
             fields+="type=normal\n";
             fields+="approval=requested\n";
             fields+="requested_by_date="+requestedDate+"\n";
             fields+="start_date="+requestedDate+"\n";

             if (group != null) {
                 fields+="assignment_group="+group
             }

             log.debug("Fields=>"+fields);

             //We create the work item
             def crId = helper.insertRow(fields, multiLineDescription)
             log.debug("StatusCreated=>"+statusCreated)
             //We check what status should be set
             helper.setStatus(crId, statusCreated)

             log.debug("CR ID "+crId);

             //We update the records saved on the IP
             def existingMap = provider.getProperty("crMapping");

             def mappingStore = []
             if (existingMap != null) {
                 mappingStore = slurper.parseText(existingMap);
             }

             //We add one record to it
             def mappingRecord = [id: scheduledDeployment.id,cr: crId];
             mappingStore.add(mappingRecord);
             provider.property("crMapping", new groovy.json.JsonBuilder(mappingStore).toString()).put()

             //Lets add the SN record # in the status of the SD
             def freshSd = new ScheduledDeployment ().id(scheduledDeployment.id);
             while (serviceNowUrl.endsWith("/")) {
                serviceNowUrl = serviceNowUrl.substring(0, serviceNowUrl.length() - 1);
             }
            log.debug(helper.getCRSysId(crId));

             def link = serviceNowUrl+"/nav_to.do?uri=change_request.do?sys_id="+helper.getCRSysId(crId)
             log.debug(link);
             freshSd.notes("<a href='"+link+"' target='_blank' >Service Now Ticket# "+crId+"</a>").save();
             log.debug("<a href='"+link+"' target='_blank' >Service Now Ticket# "+crId+"</a>");
             //Lets update the name of the Service Now approval if any
             sd = new ScheduledDeployment ()
             sd.format("report");
             sd = sd.id(scheduledDeployment.id).get()

             if (sd.approval != null) {
                sd.approval.tasks.each {
                   approval ->
                   if (approval.name == props['approvalName'] && approval.status == "OPEN") {
                       approval.name (approval.name+" - # "+crId).save()
                   }
                }
             }
         }
         else if (event == "AtDeploymentStart" && statusStarted != null && statusStarted != "NONE") {
             log.debug("HANDLE AtDeploymentStart");
             log.debug("SD=>"+scheduledDeployment);

             def existingMap = provider.getProperty("crMapping");
             def mappingStore = []
             if (existingMap != null) {
                 mappingStore = slurper.parseText(existingMap);
             }

             mappingStore.each {
                 item ->
                 //Lets update the versions of the app that should have been selected at that time
                 if (item.id == scheduledDeployment.id) {
                   Date date = new Date(scheduledDeployment.deploymentExecution.startTimeActual);
                   String actualStart = date.format( 'yyyy-MM-dd HH:mm:ss' )
                   def sdLink = serverUrl+"scheduledDeployment/"+scheduledDeployment.id+"#execution ";
                   def applicationList="";
                   log.debug("BaseApp=>"+scheduledDeployment.release)
                   scheduledDeployment.versions.each {
                      app-> applicationList+="     " + app.application.name+" - "+app.appVersion.name + "\r\n";
                   }

                  def fields = "work_start="+actualStart
                  def multiLineDescription = "Applications:\r\n"+applicationList+"\r\n\r\nUCR Link:"+sdLink+"\n";
                  helper.updateRecordFields(item.cr,fields, multiLineDescription)
                  log.debug("Service Now CR found and will be updated to Implement")
                  helper.setStatus(item.cr, statusStarted)
                 }
             }
         }
         else if (event == "AtDeploymentEnd" && statusEnded != null && statusEnded != "NONE") {
             log.debug("HANDLE AtDeploymentEnd");
             log.debug("SD=>"+scheduledDeployment);
             def existingMap = provider.getProperty("crMapping");
             def mappingStore = []
             if (existingMap != null) {
                 mappingStore = slurper.parseText(existingMap);
             }
             mappingStore.each {
                 item ->
                     log.debug(item.id +" "+scheduledDeployment.id)
                     if (item.id == scheduledDeployment.id) {
                         def fields = "close_code=successful\n";
                         fields += "close_notes=Deployment was executed successfully\n";
                         log.debug("Fields=>"+fields);
                         helper.updateRecordFields(item.cr,fields, null)
                         log.debug("Service Now CR found and will be review")
                         helper.setStatus(item.cr, statusEnded)
                 }
             }
         }
    }
}

