#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2014, 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.AirPluginTool

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import org.apache.log4j.*

//Service Now Client
import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1


final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

//Setup log4j
def currentDirectory = new File(getClass().protectionDomain.codeSource.location.path).parent
def config = new ConfigSlurper().parse(new File(currentDirectory+'/log4jSetup.groovy').toURL())
PropertyConfigurator.configure(config.toProperties())
def log = Logger.getInstance(getClass())

HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)

def jsonSlurper = new groovy.json.JsonSlurper()

def result = helper.getGroups().result

class Item { String label; String value }

if (result != null) {
log.debug(result.size()); 
    if (result.size() > 0) {
        items = [] as List
        result.each{
            key ->
                log.debug(key.name+" "+key.sys_id); 
                def item = new Item(label:key.name, value:key.sys_id)
                items.add(item)
        }

        def jsonBuilder = new groovy.json.JsonBuilder(items)
        //Old versions of UCR will look for the output printed
        print(jsonBuilder.toString())
        //New Version of UCR will look for the property "Output"
        setOutput(apTool, jsonBuilder.toString())
    }
}

//--------------------------------------------------------------    53
def setOutput(AirPluginTool apTool, String value) {
    apTool.setOutputProperty("Output", value);
    apTool.storeOutputProperties();
}