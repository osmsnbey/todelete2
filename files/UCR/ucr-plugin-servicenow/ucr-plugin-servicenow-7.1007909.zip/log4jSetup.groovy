log4j {    
  appender.scrlog = "org.apache.log4j.FileAppender"    
  appender."scrlog.layout"="org.apache.log4j.PatternLayout"
  appender."scrlog.layout.ConversionPattern"="%d %5p %c{1}:%L - %m%n"         
  appender."scrlog.file"="service-now-plugin.log" 
  rootLogger = "debug,scrlog"
}