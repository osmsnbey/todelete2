#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.urbancode.air.plugin.servicenow.HelperRestClientJsonV1
import com.urbancode.air.*
import com.urbancode.plugin.*;

import com.urbancode.plugin.*;
import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.PhaseModel;
import com.urbancode.release.rest.models.internal.Lifecycle;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.TaskComment;
import com.urbancode.air.PropsParser;

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;


/**
 *
 * @author aberk
 */

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

// UCR auth variables
def token = props['releaseToken'];
def serverUrl = props['releaseServerUrl'];

def slurper1 = new groovy.json.JsonSlurper()
def tokenJson = slurper1.parseText(token)

def extraProperties = props['extraProperties']

Date date = new Date();
String requestedDate = date.format( 'yyyy-MM-dd HH:mm:ss' )

def group = props['serviceNowAssignedGroup']
def workflow = props['workflow']
def releaseIntegrationProvider = props['releaseIntegrationProvider']
def approval='requested'
def tableName= props['table'] != null ? props['table'] : "change_request"


// Establish the client connection
Clients.loginWithToken(serverUrl, tokenJson.token, 0);

HelperRestClientJsonV1 helper = new HelperRestClientJsonV1(apTool)

def task;
def sdId;
def record_id;
def expectedFieldName = "";
def expectedFieldValue = "approved";
def expectedFieldValueFailed = "rejected";
def pluginProps;
def propsParser = new PropsParser();
def prereqTasks = []

if (extraProperties != null) {
    def slurper = new groovy.json.JsonSlurper()
    def currentTaskExtra = slurper.parseText(extraProperties)

    if (currentTaskExtra != null) {
        sdId = currentTaskExtra.task.scheduledDeploymentId

        //We need the ucr task if so we can handle that UCR object later
        def urcTaskId = currentTaskExtra.task.id

        task = new TaskExecution()
        task.id(urcTaskId)
        task.format("chart")

        task = task.get()

        prereqTasks = task.prerequisites

        task.format("detail")
        task = task.get()

        pluginProps = propsParser.parse(currentTaskExtra.task['properties/PluginProperties'])
        if (pluginProps["expectedFieldName"] != null) {
            expectedFieldName = pluginProps["expectedFieldName"]
            pluginProps.remove["expectedFieldName"]
        }
        if (pluginProps["expectedFieldValue"] != null) {
            expectedFieldValue = pluginProps["expectedFieldValue"]
            pluginProps.remove["expectedFieldValue"]
        }
        if (pluginProps["expectedFieldValueFailed"] != null) {
            expectedFieldValueFailed = pluginProps["expectedFieldValueFailed"]
            pluginProps.remove["expectedFieldValueFailed"]
        }
        if (pluginProps["table"] != null) {
            tableName = pluginProps["table"]
            pluginProps.remove["table"]
        }
        if (pluginProps["record_id"] != null) {
            record_id = pluginProps["record_id"]
            pluginProps.remove["record_id"]
        } else if (task.getProperty("record_id") != null && task.getProperty("record_id") != "" ) {
            record_id = task.getProperty("record_id")
        }
    }
}

ScheduledDeployment sd = new ScheduledDeployment();
sd = sd.id(sdId);
sd = sd.get();

def segments = sd.deploymentExecution.segments

// Must find work item that this should listen to
// 1. Does this have any direct prereqs that would have created a work item
// 2. Find any task that may have created the work item

if(!record_id) {
    prereqTasks.each { t ->
        t.format("detail")
        t = t.get()

        if(t.integrationProvider != null ) {
            
            def taskIntegrationId = t.integrationProvider
            if(!(taskIntegrationId instanceof String)) {
                taskIntegrationId = t.integrationProvider.id
            }

            if (taskIntegrationId == releaseIntegrationProvider && t.executionStep == "Open Service Now Ticket" && t.result != "NOT_APPLICABLE") {
                record_id = t.getProperty("record_id")
            }
        }
    }
}

if(!record_id) {
    segments.each { s ->
        def tasks = s.tasks

        if (record_id == null || record_id == "") {
            tasks.each { t ->
            
                if(t.integrationProvider != null ) {
                    
                    def taskIntegrationId = t.integrationProvider
                    if(!(taskIntegrationId instanceof String)) {
                        taskIntegrationId = t.integrationProvider.id
                    }

                    if (taskIntegrationId == releaseIntegrationProvider && t.executionStep == "Open Service Now Ticket" && t.result != "NOT_APPLICABLE") {
                        record_id = t.getProperty("record_id")
                    }
                }
            }
        }
    }
}

println record_id

def approvalResult = helper.getApproval(record_id, tableName)

def shouldContinue = true;
def commentPosted = false;

def counter = 0;

while (shouldContinue && counter < 8640) {
    approvalResult = helper.getApproval(record_id, tableName)

    println "HEYY APPROVAL RESULT === " + approvalResult

    if (approvalResult == "approved") {
        task.complete()
        shouldContinue = false;

        def recordURL = helper.getURI(tableName, helper.getSysId(record_id, tableName))
        def commentText = "<b>The ServiceNow record has been approved.</b> <br><br>Table: " + tableName + "<br>ID: " + record_id + "<br><a target='_blank' href='" + recordURL + "'>Link to Record</a>"

        TaskComment comment = new TaskComment();
        comment.task(task);
        comment.comment(commentText);
        comment.save()

    } else if (approvalResult == "rejected"){
        def recordURL = helper.getURI(tableName, helper.getSysId(record_id, tableName))
        def commentText = "<b>The ServiceNow record has been rejected.</b> <br><br>Table: " + tableName + "<br>ID: " + record_id + "<br><a target='_blank' href='" + recordURL + "'>Link to Record</a>"

        TaskComment comment = new TaskComment();
        comment.task(task);
        comment.comment(commentText);
        comment.save()

        task.fail()
        shouldContinue = false;
    } else if (approvalResult == "not requested"){
        def recordURL = helper.getURI(tableName, helper.getSysId(record_id, tableName))
        def commentText = "<b>The ServiceNow record does not require approval.  Task should skip/</b> <br><br>Table: " + tableName + "<br>ID: " + record_id + "<br><a target='_blank' href='" + recordURL + "'>Link to Record</a>"

        TaskComment comment = new TaskComment();
        comment.task(task);
        comment.comment(commentText);
        comment.save()

        task.skip()
        shouldContinue = false;
    } else if (!commentPosted) {
        commentPosted = true

        def recordURL = helper.getURI(tableName, helper.getSysId(record_id, tableName))
        def commentText = "<b>The ServiceNow record has yet to be accepted.  Please alert the necessary parties.</b> <br><br>Table: " + tableName + "<br>ID: " + record_id + "<br><a target='_blank' href='" + recordURL + "'>Link to Record</a>"

        TaskComment comment = new TaskComment();
        comment.task(task);
        comment.comment(commentText);
        comment.save()
    }
    sleep(10000)
    counter++
}

if (pluginProps["newStatus"] != null) {
    def newStatus = pluginProps["newStatus"]

    helper.setStatus(record_id, newStatus)

    pluginProps.remove["newStatus"]
} else if (task.getProperty("newStatus") != null && task.getProperty("newStatus") != "") {
    def newStatus = task.getProperty("newStatus")

    helper.setStatus(record_id, newStatus)
}

def fields = ""
for(key in pluginProps) {
    def temp = ("" + key + "=" + pluginProps[key] + "\n")
    fields+= temp
}

if(pluginProps.size() > 0) {
    helper.updateRecordFields(record_id, fields, null)
}