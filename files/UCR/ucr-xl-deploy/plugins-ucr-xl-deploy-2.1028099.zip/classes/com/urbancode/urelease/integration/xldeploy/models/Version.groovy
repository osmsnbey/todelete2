/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
package com.urbancode.urelease.integration.xldeploy.models

/**
 * JSON data pertaining to a UCR version will be deserialzied into this class object.
 */
class Version {
    String name
    String externalId
    String externalUrl
}
