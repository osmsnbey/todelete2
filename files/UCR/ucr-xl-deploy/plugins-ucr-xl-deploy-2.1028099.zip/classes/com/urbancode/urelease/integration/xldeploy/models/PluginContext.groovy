/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
package com.urbancode.urelease.integration.xldeploy.models

/**
 * JSON data from the UCR plugin context will be deserialized into this class object.
 */
class PluginContext {
    Task task
    String userId
}
