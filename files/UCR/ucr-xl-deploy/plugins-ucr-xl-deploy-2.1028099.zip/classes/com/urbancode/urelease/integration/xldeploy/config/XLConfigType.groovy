/*
 * Licensed Materials - Property of HCL
 * UrbanCode Deploy
 * (c) Copyright HCL Technologies Ltd. 2019. All Rights Reserved.
 */
package com.urbancode.urelease.integration.xldeploy.config

public enum XLConfigType {
    APPLICATION("udm.Application"),
    ENVIRONMENT("udm.Environment"),
    VERSION("udm.DeploymentPackage"),
    DEPLOYEDAPP("udm.DeployedApplication")

    private String value

    public XLConfigType(String value) {
        this.value = value
    }

    @Override
    public String toString() {
        return this.value
    }

}
