package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the collection of deployments in a request
public class BulkTeam {
    def ucr_token;
    def teams;
}
