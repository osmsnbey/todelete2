package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for UCR Instance Registration
public class NameIdPair {
	String name;
	String id;
}