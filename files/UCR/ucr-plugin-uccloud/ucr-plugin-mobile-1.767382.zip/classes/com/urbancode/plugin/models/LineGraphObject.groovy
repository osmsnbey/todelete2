package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the line graph on the dashboard
public class LineGraphObject {
	def taskCount;
	def minTime;
	def maxTime;
	def dataPoints;
}
