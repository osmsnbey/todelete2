package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for the deployment json doc
public class Deployment {
    def ucr_token;
    def environment;
    def release;
    def phase;
    def id;
    def level;
    def startTime;
    def plannedEndTime;
    def estimatedEndTime;
    def name;
    def updatedTime;
    def lineGraph;
    def teams;
    def taskStatus;
    def taskCount;
    def taskProgress;
    def status;
    def progress;
    def tasksByTags;
    def users;
    def hidden;
}
