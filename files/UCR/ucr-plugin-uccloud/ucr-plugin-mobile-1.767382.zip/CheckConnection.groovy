#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;

import com.urbancode.plugin.*;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();
def ucr_token = props['ucr_token'];

def cloudUrl = props['cloudHostName']
def payloadString = props['jsonPayload']

def jsonSlurper = new JsonSlurper();
def json = jsonSlurper.parseText(payloadString);

println cloudUrl;
println "--------------------------\n";

def integration = new UCCloudClient(cloudUrl, ucr_token)
integration.postDeployment(json);
