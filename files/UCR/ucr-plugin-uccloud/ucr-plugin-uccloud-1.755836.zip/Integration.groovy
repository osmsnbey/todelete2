#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import com.urbancode.plugin.*;
import com.urbancode.plugin.models.*;

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import com.urbancode.release.rest.framework.QueryParams.FilterClass;
import com.urbancode.release.rest.models.Team;
import com.urbancode.release.rest.models.User;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def integration = new CloudIntegration (props)

def totalStart = System.currentTimeMillis()

//We launch the full Integration
integration.runIntegration ()

public class CloudIntegration {

    def releaseToken;
    def serverUrl;
    def currentDeployServerTime;
    def lastloudHostNameExecutionTime;
    def cloudHelper;
    def phaseList;
    def slurper;
    def deploymentNameMap = [:];
    def deploymentTeamMap = [:];
    def deploymentUserMap = [:];
    def teamUserMap = [:];
    def integrationProviderId;
    def provider;
    def lastExecutionTime;
    def ucr_token;
    def importRange;
    def testUsersString;

    Set<String> userBlackList = new HashSet<String>();

    // We paginate the updating of entities to UCR.  We limit it to this number
    // for all entities
    def limitPerQuery = 500;

    public CloudIntegration (props) {
        slurper = new groovy.json.JsonSlurper();

        ucr_token = props['ucr_token'];
        def cloudUrl = "https://uccloud.mybluemix.net";

        if(ucr_token == null) {
            printLog("bold", "--------------------")
            printLog("bold", "Please register this instance of UCR before running integration.")
            printLog("bold", "--------------------")
            throw new RuntimeException("UCR instance is not registered.  Please register before running integration.");
        }

        releaseToken = props['releaseToken'];
        serverUrl = props['releaseServerUrl'];
        phaseList = slurper.parseText(props['phasesSelected']);
        testUsersString = props['testUsers'];

        if(phaseList.size == 0) {
            printLog("bold", "--------------------")
            printLog("bold", "Please select the phase(s) for which you want to sync deployments.")
            printLog("bold", "--------------------")
            throw new RuntimeException("No phases selected.  A phase must be specified to indicate which deployments must be synced.");
        }

        importRange = props['importRange'];

        if(importRange == null || importRange == "") {
            importRange = 14;
        }
        else {
            importRange = Long.valueOf(importRange);
        }

        cloudHelper = new UCCloudClient(cloudUrl, ucr_token);

        userBlackList.add(User.ADMIN);
        userBlackList.add(User.RELEASER);
        userBlackList.add(User.USER);

        // Authenticate plugin with UCR
        Clients.loginWithToken(serverUrl, releaseToken);

        integrationProviderId = props['releaseIntegrationProvider'];
        //We load the Integration Provider Info
        provider = new PluginIntegrationProvider().id(integrationProviderId).get()

        lastExecutionTime = provider.getProperty("lastExecutionTime");
        if(lastExecutionTime == null) {
            lastExecutionTime = 0;
        }
    }

    //--------------------------------------------------------------
    def runIntegration () {
        def integrationStartTime = System.currentTimeMillis();

        println "------------------------------------------------------------------------------------------------------------------------------"
        syncTeams();
        syncDeployments();

        provider = provider.property("lastExecutionTime", integrationStartTime.toString()).save()
    }

    def syncDeployments() {
        def startTime = System.currentTimeMillis();
        def pageSize = 100;
        def deploymentsList = queryDeployments();
        def sdObjArray = [];
        def numItems = 0;
        def numRequests = 0;

        Set<String> rdIDs = new HashSet<String>();

        for(deployment in deploymentsList) {
            numItems++;

            def sdObj = null;
            def deploymentSerializer;

            if(deployment.relatedDeployment == null) {
                deployment = deployment.get();
                if(deployment.deploymentExecution.status == "EMPTY") {
                    continue;
                }
                deploymentSerializer = new DeploymentSerializer(deployment);
                sdObj = deploymentSerializer.serializeToObject();

            }
            else {
                if(!rdIDs.contains(deployment.relatedDeployment.id)) {
                    deploymentSerializer = new DeploymentSerializer(deployment);
                    sdObj = deploymentSerializer.serializeToObject();
                    rdIDs.add(deployment.relatedDeployment.id)
                }
                sdObjArray << generateChildSDObj(deployment);
            }

            if(sdObj != null) {
                sdObj.ucr_token = ucr_token;
                sdObjArray << sdObj;


                if(sdObjArray.size() >= pageSize) {
                    cloudHelper.postBulkDeployments(deploymentSerializer.generateBulkDeployment(sdObjArray));
                    sdObjArray = [];
                    numRequests++;
                }
                // Knowing the teams for the deployment may not be necessary now that we track teams in
                // the cloud
                deploymentNameMap[sdObj.id] = sdObj.name;
                if(deploymentTeamMap[deployment.id] == null) {
                    deploymentTeamMap[deployment.id] = new HashSet<String>();
                }
                deploymentTeamMap[deployment.id].add(deployment.release.teamId);
            }
        }

        if(sdObjArray.size() >= 0) {
            cloudHelper.postBulkDeployments(new DeploymentSerializer().generateBulkDeployment(sdObjArray));
            sdObjArray = [];
            numRequests++;
        }

        def messages = ["No. of Deployments: " + numItems, "No. of Requests: " + numRequests] as String[];
        printStepInfo(startTime, "Sync Deployments", messages);
    }

    /**
     * Syncs all the teams in UCR.  It takes all of the users in the team and hashes the set of
     * users.  It saves the vaue of that hash in the Integration Prop Sheet (the key being the team
     * id).  If the hash is different than the last run, we send the serialized team to the cloud
     * service.
     *
     * @return
     */
    def syncTeams() {
        def startTime = System.currentTimeMillis();
        def numItems = 0;
        def tempTeam = new Team();
        tempTeam.format("name");
        def teams = tempTeam.getAll();

        def previousTestUsersString = provider.getProperty("prevTestUsersString");


        def testUsers = null;
        if(testUsersString != null && testUsersString != "") {
            if(testUsersString == previousTestUsersString) {
                printLog("bold", "Test users unchanged, will not sync teams")
                return;
            }

            testUsers = getTestUsers();
            printLog("bold", "Using test users")
            printLog("bold", testUsers.size() + " test users found")
        }

        for (t in teams) {

            def teamId = t.id;

            def users;
            if(testUsers == null) {
                users = (new Team()).id(teamId).getAllUsersInTeam();
            }
            else {
                users = testUsers;
            }

            if(users == []) {
                continue;
            }
            def userSet = new HashSet<User>();

            users.each{ user ->
                if(!userBlackList.contains(user)) {
                    userSet.add(user);
                }
            };

            def userHash = userSet.hashCode().toString();
            def oldUsersHash = provider.getProperty(teamId).toString();
            if(oldUsersHash != null) {
                if(userHash.equals(oldUsersHash)) {
                    // Next team, don't send this one
                    continue;
                }
            }

            // Serialize the team and pass it to the cloud client to send to the service
            def team = new TeamSerializer(t.id, t.name, userSet).serializeToObject();
            cloudHelper.postTeam(team);

            numItems++;
            // Save the new hash
            provider = provider.property(teamId, userHash).save();

        }

        def messages = ["No. of Teams: " + numItems] as String[];
        printStepInfo(startTime, "Sync Teams", messages);

        provider = provider.property("prevTestUsersString", testUsersString).save();
    }

    /**
     *
     * Using three different search criteria, find the set of Deployments that we need to integrate
     *
     * 1) SDs that have changed or been edited since the last integration
     * 2) SDs that have been added or removed from an event since the last integration
     * 3) In Progress deployments that have been scheduled to run in the last 24 hours
     *          - This is to assure lateness is updated in real-time, but does not overwhelm the
     *              system with abandoned in progress SDs
     *
     *  *) If integration has never been run, sync all SDs that have been scheduled in the last
     *      14 days, unless otherwise specified in the UI
     *
     * @return List of Scheduled Deployment object using deployments tab format
     */
    def queryDeployments() {

        def resultList = [];
        def sd = (new ScheduledDeployment());
        sd.format("deploymentstab");

        if(Long.valueOf(lastExecutionTime) > 0) {

            // Grab SDs that have been edited

            AuditAction query = new AuditAction();
            query.filter("phase.phaseModel.id", FilterClass.UUID, FilterType.IN, (String[])phaseList);
            query.filter("parentClass", FilterClass.STRING, FilterType.EQUALS, "com.urbancode.urelease.domain.release.ScheduledDeployment");
            query.filter("dateCreated", FilterClass.LONG, FilterType.GREATER_THAN, lastExecutionTime);

            query.format("byUniqueParent");

            AuditAction[] result = query.getAll();

            def sdIds = [] as List;

            if(result.size() > 0) {

                for(int i = 0; i < result.size(); i++) {
                    sdIds.add(result[i].parentId);
                }
            }

            // Grab SDs recently added or removed from an event
            query = new AuditAction();
            query.filter("phase.phaseModel.id", FilterClass.UUID, FilterType.IN, (String[])phaseList);
            query.filter("parentClass", FilterClass.STRING, FilterType.EQUALS, "com.urbancode.urelease.domain.release.RelatedDeployment");
            query.filter("primaryClass", FilterClass.STRING, FilterType.EQUALS, "com.urbancode.urelease.domain.release.ScheduledDeployment");
            query.filter("dateCreated", FilterClass.LONG, FilterType.GREATER_THAN, lastExecutionTime);

            result = query.getAll();

            if(result.size() > 0) {

                for(int i = 0; i < result.size(); i++) {
                    if(!sdIds.contains(result[i].primaryId)) {
                        sdIds.add(result[i].primaryId);
                    }
                }
            }

            // Grab SDs of interest --> Late SDs that are getting later in real time, but are relevant
            sd.filter("deploymentExecution.status", FilterClass.ENUM, FilterType.EQUALS, "INPROGRESS");
            sd.filter("phase.phaseModel.id", FilterClass.UUID, FilterType.IN, (String[])phaseList);
            sd.filter("scheduledDate", FilterClass.LONG, FilterType.GREATER_THAN, (System.currentTimeMillis()) - (24 * 60 * 60 * 1000));

            def staleSDs = sd.getAll();

            for(int i = 0; i < staleSDs.size(); i++) {
                resultList.add(staleSDs[i]);
                sdIds.remove(staleSDs[i].id);
            }

            if(sdIds.size() > 0) {
                sd = (new ScheduledDeployment());
                sd.format("deploymentstab");
                resultList.addAll(sd.filter("id", FilterClass.UUID, FilterType.IN, (String[])sdIds).when().getAll());
            }
        }
        else {

            // First Integration Run
            def dateAfter = (System.currentTimeMillis()) - ((Long)importRange * 24 * 60 * 60 * 1000);
            sd.filter("phase.phaseModel.id", FilterClass.UUID, FilterType.IN, (String[])phaseList);
            resultList = sd.filter("scheduledDate", FilterClass.LONG, FilterType.GREATER_THAN, dateAfter).when().getAll();
        }

        return resultList;
    }

    def generateChildSDObj(sd) {
        new Deployment(
            updatedTime: System.currentTimeMillis(),
            id: sd.id,
            level: "DEPLOYMENT",
            hidden: true);
    }

    def getTestUsers() {
        def testEmails = [] as List;
        String[] testEmailArr = testUsersString.split(",");
        for(int i = 0; i < testEmailArr.length; i++) {
            testEmails.add(testEmailArr[i].trim());
        }

        def query = new User();
        query.filter("email", FilterClass.STRING, FilterType.IN, (String[])testEmails);

        def result = query.getAll();

        return result;
    }

    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    //--------------------------------------------------------------
    //Print step info
    def printStepInfo(startTime, stepDisplayName, messages) {
        printLog("TRACE", "--- "+ stepDisplayName +" ---");
        if(messages !=  null) {
            messages.each{ message -> printLog("TRACE", message) };
        }
        println "Step completed in " + (int)((System.currentTimeMillis() - startTime) / 1000) + " sec";
    }
}
