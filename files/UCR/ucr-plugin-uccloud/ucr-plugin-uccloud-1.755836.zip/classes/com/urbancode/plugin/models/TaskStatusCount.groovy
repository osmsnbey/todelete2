package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for basic task counts
public class TaskStatusCount {
    def late;
    def waiting;
    def error;
}