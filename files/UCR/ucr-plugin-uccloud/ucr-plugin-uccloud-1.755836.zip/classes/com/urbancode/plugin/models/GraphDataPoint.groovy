package com.urbancode.plugin.models

//--------------------------------------------------------------
// POGO for specific data point on line graph
public class GraphDataPoint {
	def timestamp;
	def plannedCount;
	def actualCount;
	def estimatedCount;
}
