#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import com.urbancode.urelease.rest.Rester;
import com.urbancode.urelease.integration.deploy.DeployFactory;
import com.urbancode.release.rest.models.Application;
import com.urbancode.release.rest.models.Component;
import com.urbancode.release.rest.models.ComponentVersion;
import com.urbancode.release.rest.models.internal.ApplicationEnvironment;
import com.urbancode.release.rest.models.Version;
import com.urbancode.release.rest.models.Inventory;

import com.urbancode.release.rest.models.internal.Comment;
import com.urbancode.release.rest.models.internal.TaskExecutionUpdate;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.Status;
import com.urbancode.release.rest.models.internal.VersionStatus
import com.urbancode.release.rest.models.internal.TaskPlan;

import com.urbancode.release.rest.framework.Clients;
import java.net.SocketTimeoutException;
final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

//We launch the integration here
def integration = new DeployIntegration (props)

def totalStart = System.currentTimeMillis()
//We authenticate with IBM UrbanCode Release
integration.releaseAuthentication ()
//We launch the full Integration
integration.runIntegration ()
def totalEnd = System.currentTimeMillis()

public class DeployIntegration {
    
    def releaseToken;
    def fullIntegration;
    def serverUrl;
    def deployHostName;
    def deployToken;
    def integrationProviderVersion
    def integrationProviderId;
    def factory;
    def provider;
    def currentDeployServerTime;
    def lastExecutionTime;
    
    // We paginate the updating of entities to UCR.  We limit it to this number
    // for all entities 
    def limitPerQuery = 500;
    
    //Main constructor
    DeployIntegration (props) {
        //Release Token used for Authentication
        this.releaseToken = props['releaseToken'];
        //Delta Sync or Full Sync
        this.fullIntegration = props['fullIntegration'];
        //Release Server URL
        this.serverUrl = props['releaseServerUrl'];
        //Deploy info
        this.deployHostName = props['deployHostName']
        this.deployToken = props['deployToken']
        //Integration Provider currently running that Integration
        this.integrationProviderId = props['releaseIntegrationProvider'];
    }
    
    //--------------------------------------------------------------
    //Authentication with Release
    def releaseAuthentication () {
        Clients.loginWithToken(serverUrl, releaseToken);
    } 
    
    //--------------------------------------------------------------
    def runIntegration () {
        println "------------------------------------------------------------------------------------------------------------------------------"
        //We load the Integration Provider Info
        provider = new PluginIntegrationProvider().id(integrationProviderId).get()
        
        //We get the last execution date (UCD time)
        def lastExecutionDeployDate = null;
        def lastExecutionDeployTime = provider.getProperty("lastExecutionDeployTime");

        if(this.fullIntegration == "true") {
            lastExecutionDeployTime = null;
            println "Running full integration - imports all data regardless of modified date"
        }
        
        //We check the last execution date, if none the full sync will be started
        if (lastExecutionDeployTime != null) {
            lastExecutionDeployDate = new Date(lastExecutionDeployTime.toLong());
            println "Last Execution Deploy Date: "+lastExecutionDeployDate
        }
        else {
            lastExecutionDeployTime = 0;
        }
        //We init the factory so it would use the lastExecutionTime in each call to Deploy
        this.factory = new DeployFactory(deployHostName, deployToken, lastExecutionDeployTime.toLong());
       
        //We display the current Deploy integration protocol and get the current UCD time as well
        this.integrationProviderVersion = factory.getIntegrationVersion();
        println "Integration Provider Version: "+integrationProviderVersion;
        currentDeployServerTime = factory.getServerCurrentTime();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Statuses from UCD
        importStatuses ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Components
        importComponents ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Applications
        importApplications ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Environments
        importEnvironments ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Automated Processes
        importProcesses ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Component Versions
        importComponentVersions ();

        println "---------------------------------------------------------------------------------------------------------------"
        //Import Snapshots
        importSnapshots ();
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Import Inventory
        importInventories ()
        
        println "---------------------------------------------------------------------------------------------------------------"
        //Update Executing Tasks
        updateExecutingTasks()
        
        //We reset the last execution date if everything went well
        //We also reset the fullsync option to false
        provider.property("fullIntegration", "false").property("lastExecutionDeployTime", currentDeployServerTime.toString()).put()
    }
    
    //--------------------------------------------------------------
    def importStatuses () {
       println "<b><u>>>>> Import Statuses</u></b>"
       def snapshotStatuses = factory.getAvailableSnapshotStatuses();
       def versionStatuses = factory.getAvailableVersionStatuses();
       
       def bulkStatusList = [] as List
       
       println "# Snapshot Statuses imported: "+snapshotStatuses.size()
       println "# Version Statuses imported: "+versionStatuses.size()
       
       snapshotStatuses.each {
           item -> 
           def status = new Status()
               .name(item.name)
               .description(item.description)
               .color(item.color)
               .type(item.type)
               .externalId(item.externalId.toString())
               .integrationProvider(provider)
               
           bulkStatusList.add(status)
       }
       
       versionStatuses.each {
           item -> 
               def status = new Status()
               .name(item.name)
               .description(item.description)
               .color(item.color)
               .type(item.type)
               .externalId(item.externalId.toString())
               .integrationProvider(provider)
           
               bulkStatusList.add(status)
       }
       
       //We sync the statuses
       def statusesUpdated = new Status().sync(bulkStatusList)
    }
    
    //--------------------------------------------------------------
    def importApplications () {
       println "<b><u>>>>> Import Applications</u></b>"
       //List of all applications from UCD that will be turned into UCR Applications
       def bulkApplicationList = [] as List
       //We get all UCD application
       long startImportApplication = System.currentTimeMillis()
       def ucdApplications = factory.getApplications();
       long endImportApplication = System.currentTimeMillis()
       println "# UCD Applications imported: "+ucdApplications.size()+" in "+((endImportApplication-startImportApplication)/1000)+"s"
       
       ucdApplications.each {
           item ->  
           def application = new Application()
               .name(item.name)
               .automated(true)
               .property("objectType", "APPLICATION")
               .description(item.description)
               .integrationProvider(provider)
               .externalId(item.externalId.toString());
           
           //lets build the list of components
           def childrenComponentList = [] as List
           item.components.each {
               comp -> 
               def ucrComponent = new Component().externalId(comp.externalId.toString())
               childrenComponentList.add(ucrComponent)
           }
           //We add the children
           application.children(childrenComponentList.toArray(new Component[childrenComponentList.size()]))
           
           //Is the item supposed to be deleted
           if (item.deleted) {
              application.toBeDeleted(true)
           }
           
           bulkApplicationList.add(application);
           
           if (bulkApplicationList.size() >= limitPerQuery) {
                long startImportIntoUCR = System.currentTimeMillis()    
                def applicationsUpdated = new Application().sync(bulkApplicationList)
                long endImportIntoUCR = System.currentTimeMillis()
                println "# UCR Applications updated: "+applicationsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"
                bulkApplicationList = [] as List
           }
       }
       
       if (bulkApplicationList.size() > 0) {
           //We sync the applications and display some timing
           long startImportIntoUCR = System.currentTimeMillis()    
           def applicationsUpdated = new Application().sync(bulkApplicationList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# UCR Applications updated: "+applicationsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"
       }

    }
    
    //--------------------------------------------------------------
    def importComponents () {
       println "<b><u>>>>> Import Components</u></b>"
       //List of all components from UCD that will be turned into UCR Components
       def bulkComponentList = [] as List
       //We get all UCD component
       long startImportComponent = System.currentTimeMillis()
       def ucdComponents = factory.getComponents();
       long endImportComponent = System.currentTimeMillis()
       println "# UCD Components imported: "+ucdComponents.size()+" in "+((endImportComponent-startImportComponent)/1000)+"s"
       
       ucdComponents.each {
           item ->  
           def component = new Component()
               .name(item.name)
               .automated(true)
               .property("objectType", "COMPONENT")
               .description(item.description)
               .integrationProvider(provider)
               .externalId(item.externalId.toString());
               
           if (item.deleted) {
              component.toBeDeleted(true)
           }
           
           bulkComponentList.add(component);
           
           if (bulkComponentList.size() >= limitPerQuery) {
                long startImportIntoUCR = System.currentTimeMillis()    
                def componentsUpdated = new Component().sync(bulkComponentList)
                long endImportIntoUCR = System.currentTimeMillis()
                println "# UCR Components updated: "+componentsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s" 
                bulkComponentList = [] as List
           }
       }
       
       if (bulkComponentList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
           def componentsUpdated = new Component().sync(bulkComponentList)
           
           long endImportIntoUCR = System.currentTimeMillis()
           println "# UCR Components updated: "+componentsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
       } 
       else {
           println "No Components to sync"   
       }       
    }
    
    //--------------------------------------------------------------
    def importComponentVersions () {
       println "<b><u>>>>> Import Component Versions</u></b>"
       //List of all component versions that will be turned into UCR versions
       def bulkComponentVersionList = [] as List
       //We get all UCD component versions
       long startImportComponentVersion = System.currentTimeMillis()
       def ucdComponentVersions = factory.getComponentVersions();
       long endImportComponentVersion = System.currentTimeMillis()
       println "# UCD Component Versions imported: "+ucdComponentVersions.size()+" in "+((endImportComponentVersion-startImportComponentVersion)/1000)+"s"


       ucdComponentVersions.each {
           item ->  
 
           def componentVersion = new ComponentVersion()
               .name(handleTrailingWhiteSpace(item.name))
               .automated(true)
               .description(item.description)
               .integrationProvider(provider)
               .createdDate(item.created)
               .externalId(item.externalId.toString());
           
           //We set the Component for that version
           if (item.componentId != null) {
               def parent = new Component().externalId(item.componentId.toString())
               componentVersion.component(parent)
           }
           
           //We add all Version Statuses for that Component Version
           if (item.statuses != null) {
               def versionStatusesList = [] as List
                   item.statuses.each {
                       itemVersionStatus ->
                       def status = new Status().externalId(itemVersionStatus.externalId).name(itemVersionStatus.statusName)
                       def versionStatus = new VersionStatus ().status(status)
                       versionStatusesList.add(versionStatus)
                   }
                   
               componentVersion.versionStatuses(versionStatusesList.toArray(new VersionStatus[versionStatusesList.size()]))
           }
           
           //We set the deleted flag to let know Release that that item has been deleted
           if (item.deleted) {
              componentVersion.toBeDeleted(true)
           }
           
           bulkComponentVersionList.add(componentVersion);
           
           if (bulkComponentVersionList.size() >= limitPerQuery) {
                long startImportIntoUCR = System.currentTimeMillis()    
                def componentVersionUpdated = new ComponentVersion().sync(bulkComponentVersionList)
                long endImportIntoUCR = System.currentTimeMillis()
                println "# UCR Components updated: "+componentVersionUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
                bulkComponentVersionList = [] as List
           }
       }

       if (bulkComponentVersionList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
    
           def componentVersionUpdated = new ComponentVersion().sync(bulkComponentVersionList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# UCR Components updated: "+componentVersionUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
       } 
       else {
           println "No Component Versions to sync"   
       }    
    }
    
    //--------------------------------------------------------------
    def importSnapshots () {
       println "<b><u>>>>> Import Snapshots</u></b>"
       //List of all snapshots that will be turned into UCR versions
       def bulkSnapshotList = [] as List
       //We get all UCD snapshots
       long startImport = System.currentTimeMillis()
       def ucdSnapshots = factory.getSnapshots();
       long endImport = System.currentTimeMillis()
       println "# UCD Snapshots imported: "+ucdSnapshots.size()+" in "+((endImport-startImport)/1000)+"s"
       def externalIdToSnapshot = [:]
       
       //We need to put the snapshots into a map to ensure there are no duplicates
       ucdSnapshots.each {
       item ->  
           externalIdToSnapshot[item.externalId.toString()] = item;
       }
       
       println "New List Size:"+externalIdToSnapshot.size()
       
       for (snap in externalIdToSnapshot) {
           def item = snap.value
        
           def snapshot = new Version()
               .name(handleTrailingWhiteSpace(item.name))
               .automated(true)
               .description(item.description)
               .integrationProvider(provider)
               .createdDate(item.created)
               .externalId(item.externalId.toString());
           
           //Here we build the list of version statuses
           if (item.statuses != null) {
               def versionStatusesList = [] as List
                   item.statuses.each {
                       itemVersionStatus ->
                       def status = new Status()
                           .externalId(itemVersionStatus.externalId)
                           .name(itemVersionStatus.statusName)
                           
                       def versionStatus = new VersionStatus ().status(status)
                       versionStatusesList.add(versionStatus)
               }
               
               snapshot.versionStatuses(versionStatusesList.toArray(new VersionStatus[versionStatusesList.size()]))
           }
           
           //The snapshot should reference the application parent
           if (item.applicationId != null) {
               def parent = new Application().externalId(item.applicationId.toString())
               snapshot.application(parent)
           }
           
           //lets build the list of children versions
           def childrenList = [] as List
           
           item.versions.each {
               child -> 
               def ucrComponentVersion = new ComponentVersion().externalId(child.externalId.toString())
               childrenList.add(ucrComponentVersion)
           }
           
           snapshot.children(childrenList.toArray(new ComponentVersion[childrenList.size()]))
           
           //If the snapshot has been inactivated we mark it as to be deleted
           if (!item.isActive) {
              snapshot.toBeDeleted(true)
           }
           
           bulkSnapshotList.add(snapshot);
           
           if (bulkSnapshotList.size() >= limitPerQuery) {
               long startImportIntoUCR = System.currentTimeMillis()    
               def snapshotsUpdated = new ComponentVersion().sync(bulkSnapshotList)
               long endImportIntoUCR = System.currentTimeMillis()
               println "# UCR Snapshots updated: "+snapshotsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"    
               bulkSnapshotList = [] as List
           }
       }
       
       if (bulkSnapshotList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
    
           def snapshotsUpdated = new ComponentVersion().sync(bulkSnapshotList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# UCR Snapshots updated: "+snapshotsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
       } 
       else {
           println "No Snapshots to sync"   
       }    
    }
    
    //--------------------------------------------------------------
    def importEnvironments () {
       println "<b><u>>>>> Import Environments</u></b>"
       //List of all environments from UCD that will be turned into UCR Application Targets
       def bulkEnvironmentList = [] as List
       //We get all UCD environments
       long startImport = System.currentTimeMillis()
       def ucdEnvironments = factory.getEnvironments();
       long endImport = System.currentTimeMillis()
       println "# UCD Environments imported: "+ucdEnvironments.size()+" in "+((endImport-startImport)/1000)+"s"
       
       for (item in ucdEnvironments) {
           def environment = new ApplicationEnvironment()
               .name(item.name)
               .description(item.description)
               .integrationProvider(provider)
               .externalId(item.externalId.toString());
           
           if (item.applicationId != null) {
               def parent = new Application().externalId(item.applicationId.toString())
               environment.application(parent)
           }
           //We set the deleted flag to let know Release that that item has been deleted
           if (item.deleted) {
              environment.toBeDeleted(item.deleted)
           }
           
           bulkEnvironmentList.add(environment);
        
            if (bulkEnvironmentList.size() >= limitPerQuery) {
               long startImportIntoUCR = System.currentTimeMillis()    
               def environmentsUpdated = new ApplicationEnvironment().sync(bulkEnvironmentList)
               long endImportIntoUCR = System.currentTimeMillis()
               println "# UCR Environments updated: "+environmentsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"    
               bulkEnvironmentList = [] as List
           }
        }
         
        if (bulkEnvironmentList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
    
           def environmentsUpdated = new ApplicationEnvironment().sync(bulkEnvironmentList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# UCR Environments updated: "+environmentsUpdated.size()+" in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
       } 
       else {
           println "No Environments to sync"   
       }   
    }
    
     //--------------------------------------------------------------
    def importInventories () {
       println "<b><u>>>>> Import Inventories</u></b>"
       //List of all environments inventories from UCD
       def bulkInventoriesList = [] as List
       //We get all UCD environments
       long startImport = System.currentTimeMillis()
       def ucdInventories = factory.getInventories();
       long endImport = System.currentTimeMillis()
       println "# UCD Inventories imported: "+ucdInventories.size()+" in "+((endImport-startImport)/1000)+"s"
       
        for (item in ucdInventories) {

           def inventory = new Inventory();

           if (item.environmentId != null) {
               inventory.applicationTarget(new ApplicationEnvironment().externalId(item.environmentId))

               if (item.componentId != null) {
                   inventory.component(new Component().externalId(item.componentId))
               }
               
               if (item.snapshotId != null) {
                   inventory.version(new Version().externalId(item.snapshotId))
               }
               
               if (item.componentVersionId != null) {
                   inventory.componentVersion(new ComponentVersion().externalId(item.componentVersionId))
               }
               bulkInventoriesList.add(inventory);
            }
            
            if (bulkInventoriesList.size() >= limitPerQuery) {
               long startImportIntoUCR = System.currentTimeMillis()    
               def inventoryUpdated = new Inventory().sync(bulkInventoriesList)
               long endImportIntoUCR = System.currentTimeMillis()
               println "# Inventory updated in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s" 
               bulkInventoriesList = [] as List
           }
        }
        
        if (bulkInventoriesList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
    
           new Inventory().sync(bulkInventoriesList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# Inventory updated in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"
       } 
       else {
           println "No Inventory to sync"   
       }   
       
    }
    
    //--------------------------------------------------------------
    def importProcesses () {
       println "<b><u>>>>> Import Processes</u></b>"
       //List of all processes from UCD that will be turned into UCR Automated Tasks
       def bulkProcessesList = [] as List
       
       //We want to be more cautious about how many items we are updating at once.
       //That rest end point is slow and if anything is touching a task in UCR while
       //it is updating them during the integration it could cause a stale object exception
       //By paginating the queries we lower that risk a lot
       def limitPerQuery = 100;
       
       //We get all UCD processes
       long startImportProcesses = System.currentTimeMillis()
       def ucdProcesses = factory.getApplicationProcesses();
       long endImportProcesses = System.currentTimeMillis()
       println "# UCD Processes imported: "+ucdProcesses.size()+" in "+((endImportProcesses-startImportProcesses)/1000)+"s"
       
       ucdProcesses.each {
           item ->  
           
           //Parent Application
           def application;
           if (item.applicationId) {
               application = new Application().externalId(item.applicationId.toString())
           }
           //Should the task be active in UCR ?
           def active = true;
           if (item.deleted || !item.active) {
              active = false;
           }
           
           def process = new TaskPlan()
                  .name(item.name)
                  .description(item.description)
                  .integrationProvider(provider)
                  .externalId(item.externalId.toString())
                  .property("processId",item.externalId.toString())
                  .active(active)
                  .automated(true);
                      
           if (item.applicationId) {
               process.application(new Application().externalId(item.applicationId.toString()))
           }

           bulkProcessesList.add(process);
           
           if (bulkProcessesList.size() > limitPerQuery) {
               long startImportIntoUCR = System.currentTimeMillis()
        
               new TaskPlan().sync(bulkProcessesList)
               long endImportIntoUCR = System.currentTimeMillis()
               println "# Tasks updated in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"
               bulkProcessesList = [] as List
           }
        }
       
        if (bulkProcessesList.size() > 0) {
           long startImportIntoUCR = System.currentTimeMillis()    
    
           new TaskPlan().sync(bulkProcessesList)
           long endImportIntoUCR = System.currentTimeMillis()
           println "# Tasks updated in "+((endImportIntoUCR-startImportIntoUCR)/1000)+"s"   
        } 
        else {
            println "No Tasks to sync"   
        }   
    }
    
    //--------------------------------------------------------------
    def updateExecutingTasks () {
       println "<b><u>>>>> Update Executing Tasks</u></b>"
       //List of all processes from UCD that will be turned into UCR Automated Tasks
       def executingTask = new TaskExecution().getAllExecutingForProvider(provider.id.toString())
        println "# UCR Tasks to update: "+executingTask.size()
        def waitingOnApprovalString = provider.getProperty("tasksWaitingOnApproval");
        def tasksWaitingOnApproval = [] as Set
        if(waitingOnApprovalString != null) {
            tasksWaitingOnApproval = waitingOnApprovalString.tokenize(',').toSet()
            //Only keep the tasks that are still executing. We need to do this to remove any tasks that had an approved approval from this set
            tasksWaitingOnApproval.retainAll(executingTask)
        }
        def bulkTaskExecutionList = [] as List
        
        if (executingTask.size() > 0) {
            executingTask.each {
               item ->  
              def task = item
              def executionUpdateList = [] as List
               if (item.propertyValues.processRequestIdList != null) {
                   def processIdArray = item.propertyValues.processRequestIdList.split(',')
                    processIdArray.each {
                          processId ->
                          
                          try {
                              def processUpdate = factory.getApplicationProcessRequestForId(processId)
                              def taskUpdate = new TaskExecutionUpdate();
                              if(processUpdate.approval != null 
                                && !processUpdate.approval.failed 
                                && !processUpdate.approval.finished 
                                && !processUpdate.approval.cancelled &&
                                !tasksWaitingOnApproval.contains(item.id.toString())) {
                                   //This is the first time we encountered this task since it has been started and it is waiting on an approval
                                   def waitingApproval = new Comment()
                                   waitingApproval.task(item)
                                   waitingApproval.comment("Waiting on approval").save()
                                   
                                   tasksWaitingOnApproval.add(item.id.toString())
                              }
                              else if(processUpdate.approval != null && processUpdate.approval.failed) {
                                  //The approval for this task was failed so we should fail the task and add a comment saying why
                                  tasksWaitingOnApproval.remove(item.id.toString())
                                  taskUpdate.result(TaskExecutionUpdate.Result.FAULTED)
                                  taskUpdate.status(TaskExecutionUpdate.Status.CLOSED)
                                  taskUpdate.applicationProcessRequestId(processId)
                                  taskUpdate.applicationTargetId(processUpdate.appEnvironment.externalId.toString())
                                  executionUpdateList.add(taskUpdate)
                                  
                                  def approvalRejected = new Comment()
                                  approvalRejected.task(item)
                                  approvalRejected.comment("The approval for this process was rejected").save()
                              }
                              //In some rare cases some tasks with status 'waiting for' something in UCD return state = null and result = null
                              //We just skip them anyway since they are still in progress for what release cares about 
                              else if (processUpdate != null && processUpdate.state != null && processUpdate.result != null) {
                                  tasksWaitingOnApproval.remove(item.id.toString())
                                  //Here we need to map the statuses External Tool / Release
                                  //On purpose we go explicitly through all of them to show all possible states
                                  
                                  if (processUpdate.state == "EXECUTING") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.EXECUTING)
                                  }
                                  
                                  if (processUpdate.state == "OPEN") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.OPEN)
                                  }
                                  
                                  if (processUpdate.state == "CLOSED") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.CLOSED)
                                  }
                                  
                                  if (processUpdate.state == "PLANNED") {
                                      taskUpdate.status(TaskExecutionUpdate.Status.PLANNED)
                                  }
      
                                  if (processUpdate.result == "NONE") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.NONE)
                                  }
                                  
                                  if (processUpdate.result == "SUCCEEDED") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.SUCCEEDED)
                                  }
                                  
                                  if (processUpdate.result == "CANCELED") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.CANCELED)
                                  }
                                  
                                  if (processUpdate.result == "FAULTED") {
                                      taskUpdate.result(TaskExecutionUpdate.Result.FAULTED)
                                  }

                                  if (taskUpdate.result == null) {
                                      println "UCD Application Process ID "+processId+" did not return a valid result"
                                      println "Result not handled: "+processUpdate.result
                                  }
                                  
                                  if (taskUpdate.status  == null) {
                                      println "UCD Application Process ID "+processId+" did not return a valid state"
                                      println "State not handled: "+processUpdate.state
                                  }

                                  taskUpdate.applicationProcessRequestId(processId)
                                  taskUpdate.applicationTargetId(processUpdate.appEnvironment.externalId.toString())
                                  executionUpdateList.add(taskUpdate)
                              }
                              //If the state can not be handled we mark the task as failed
                              else {
                                  taskUpdate.status(TaskExecutionUpdate.Status.CLOSED)
                                  taskUpdate.result(TaskExecutionUpdate.Result.FAULTED)
                                  taskUpdate.applicationProcessRequestId(processId)
                                  taskUpdate.applicationTargetId(processUpdate.appEnvironment.externalId.toString())
                                  executionUpdateList.add(taskUpdate)
                              }
                          }
                          //Here if for any reason the request hangs in Deploy we want to log it and keep going
                          //That task will be updated during the next run
                          //Timeout is set to 1 minute
                          catch (SocketTimeoutException ex) {
                              printLog("WARNING", ex)
                              printLog("WARNING", "Timeout occured while updating UCD Application Process ID: ")
                              printLog("WARNING", processId)
                          }
                    }
                    if (executionUpdateList.size() > 0) {
                        item.taskUpdates(executionUpdateList.toArray(new TaskExecutionUpdate[executionUpdateList.size()]))
                        bulkTaskExecutionList.add(item)
                    }
               }
            }

            if (bulkTaskExecutionList.size() > 0) {
                //We sync the Task Updates
                new TaskExecution().saveExecutingTasks(bulkTaskExecutionList.toArray(new TaskExecution[bulkTaskExecutionList.size()]))
            }
            else {
                println "No tasks to update"
            }
        }
        else {
           println "No Executing tasks to update"    
        }
        
        //Update the set of tasks waiting on approval
        provider = provider.property("tasksWaitingOnApproval",tasksWaitingOnApproval.join(',')).save()
    }
    
    //--------------------------------------------------------------
    //Method that replaces the white spaces on versions name with an underscore
    def handleTrailingWhiteSpace(s) {
        if(s.endsWith(" ") || s.endsWith("_")) {
            println "Trailing whitespace in name: " + s;
            s = s + "_"
        }
        return s;
    }
    
    //--------------------------------------------------------------
    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }
}
