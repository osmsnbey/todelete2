#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.urbancode.urelease.rest.Rester;
import com.urbancode.urelease.integration.deploy.DeployFactory;
import com.urbancode.release.rest.models.Application;
import com.urbancode.release.rest.models.Component;
import com.urbancode.release.rest.models.ComponentVersion;
import com.urbancode.release.rest.models.ApplicationTarget;
import com.urbancode.release.rest.models.Version;
import com.urbancode.release.rest.models.Inventory;
import com.urbancode.release.rest.models.Task;
import com.urbancode.release.rest.models.TaskExecutionUpdate;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.Status;
import com.urbancode.release.rest.models.internal.VersionStatus

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

import com.urbancode.release.rest.framework.Clients;

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);

//We launch the integration here
def integration = new StatusFactory (apTool)

def totalStart = System.currentTimeMillis()
integration.removeStatus ()
def totalEnd = System.currentTimeMillis()

public class StatusFactory {
    
    def releaseToken;
    def serverUrl;
    def deployHostName;
    def deployToken;
    def integrationProviderVersion
    def integrationProviderId;
    def factory;
    def extraProperties;
	def apTool;
    
    //Main constructor
    StatusFactory (apTool) {
	    this.apTool = apTool;
	    def props = apTool.getStepProperties();
        this.releaseToken = props['releaseToken'];
        this.serverUrl = props['releaseServerUrl'];
        this.deployHostName = props['deployHostName']
        this.deployToken = props['deployToken']
        this.integrationProviderId = props['releaseIntegrationProvider'];
        this.extraProperties = props['extraProperties']
    }
    
    //--------------------------------------------------------------
    //Authentication with Release
    def releaseAuthentication () {
        Clients.loginWithToken(serverUrl, releaseToken);
    }
    
    //--------------------------------------------------------------
    def removeStatus () {
        def slurper = new JsonSlurper();
        this.factory = new DeployFactory(deployHostName, deployToken, 0);
        
        def extraProperties = slurper.parseText(extraProperties)
        
        if (extraProperties.taskProperties != null) {
            def taskProperties = extraProperties.taskProperties;
            
            def statusId = taskProperties.status.id;
            def statusExternalId = taskProperties.status.externalId;
            def statusName = taskProperties.status.name;
            def statusDescription = taskProperties.status.description;
            def statusColor = taskProperties.status.color;
            def versionId = taskProperties.versionId;
            def statusType = taskProperties.statusType;
            println("External ID"+statusExternalId)
            //---------------------IBM URBANCODE LOGIC START-----------------------
            //We create that status in UCD if it does not exist
            if (statusExternalId == null) {
                def newStatusExternalId = factory.createStatus(statusName, statusDescription, statusColor, statusType);
                def updatedStatus = new Status ().id(statusId).property("externalId_"+statusType+"_"+integrationProviderId, newStatusExternalId)
                updatedStatus.save()
            }
            
            if (statusType == "SNAPSHOT") {
                factory.removeStatusFromSnapshot(statusName, versionId)
            }
            else if (statusType == "VERSION") {
                factory.removeStatusFromVersion(statusName, versionId)
            }
            //---------------------IBM URBANCODE LOGIC END-----------------------
            
        }
    }
}
    
