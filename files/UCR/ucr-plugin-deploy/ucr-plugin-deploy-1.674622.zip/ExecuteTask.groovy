#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.urbancode.urelease.rest.Rester;
import com.urbancode.urelease.integration.deploy.DeployFactory;
import com.urbancode.release.rest.models.Application;
import com.urbancode.release.rest.models.Component;
import com.urbancode.release.rest.models.ComponentVersion;
import com.urbancode.release.rest.models.ApplicationTarget;
import com.urbancode.release.rest.models.Version;
import com.urbancode.release.rest.models.Inventory;
import com.urbancode.release.rest.models.Task;
import com.urbancode.release.rest.models.TaskExecutionUpdate;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.release.rest.models.internal.TaskExecution;
import com.urbancode.release.rest.models.internal.Status;
import com.urbancode.release.rest.models.internal.VersionStatus

import groovy.json.JsonSlurper;
import groovy.json.JsonBuilder;

import com.urbancode.release.rest.framework.Clients;

final def workDir = new File('.').canonicalFile

def apTool = new AirPluginTool(this.args[0], this.args[1]);

//We launch the integration here
def integration = new TaskExecution (apTool)

def totalStart = System.currentTimeMillis()
integration.executeTask ()
def totalEnd = System.currentTimeMillis()

public class ProcessRequest {String processRequestId; String link; String applicationTargetId}
		
/*
Here the Task Execution step must return a list of ProcessRequest :
{String processRequestId; String link; String applicationTargetId}
That contains the unique ID of the process from the External tool, a link to the execution page where 
the user can see the trace of its execution and the Application target unique id for which the process was run.
All 3 values are required!
*/		
public class TaskExecution {
    
    def releaseToken;
    def serverUrl;
    def deployHostName;
    def deployToken;
    def integrationProviderVersion
    def integrationProviderId;
    def factory;
    def provider;
    def currentDeployServerTime;
    def lastExecutionTime;
    def extraProperties;
	def apTool;
    
    //Main constructor
    TaskExecution (apTool) {
	    this.apTool = apTool;
	    def props = apTool.getStepProperties();
        this.releaseToken = props['releaseToken'];
        this.serverUrl = props['releaseServerUrl'];
        this.deployHostName = props['deployHostName']
        this.deployToken = props['deployToken']
        this.integrationProviderId = props['releaseIntegrationProvider'];
        this.extraProperties = props['extraProperties']
    }
    
    //--------------------------------------------------------------
    def executeTask () {
        this.factory = new DeployFactory(deployHostName, deployToken, 0);
        
        def slurper = new JsonSlurper();
        def jsonBuilder = new groovy.json.JsonBuilder()
        
        def extraProperties = slurper.parseText(extraProperties)
        
        
        def processRequests = [] as List
         
        if (extraProperties.taskExecution != null) {
            def taskProperties = extraProperties.taskExecution;
            if (extraProperties.taskExecution.targets != null) {
                if (extraProperties.taskExecution.targets.size() != 0) {
                    
                    def applicationId = taskProperties.application;
                    def versionId = taskProperties.version;
                    def processId = taskProperties.process;
                    def taskId = taskProperties.task;
                    def onlyChangedVersions = taskProperties.onlyChangedVersions;
                    def updateUrl = taskProperties.updateUrl;
                    def sdLink = taskProperties.sdLinkUrl;

                    println extraProperties.taskExecution.targets      

                    def targets = slurper.parseText(extraProperties.taskExecution.targets)

                    targets.each {
                        target ->
                        println "target is "+target
                        def targetId = target.id;

                        //---------------------IBM URBANCODE LOGIC START-----------------------
                        def appRequest = factory.createApplicationProcessRequest (
                            applicationId, versionId, processId, targetId, onlyChangedVersions, updateUrl, sdLink,taskId);

                            //We submit the Process to UCD
                            def requestId =  factory.submitApplicationProcessRequest(appRequest);
                            //We build the URL that will be displayed later in the UI to redirect to the trace execution of that Process
                            def processlink = factory.getProcessUrl(requestId);
                            //We build our process request
                            def appProcess = new ProcessRequest(processRequestId:requestId, link:processlink,applicationTargetId: targetId)
                            
                            processRequests.add(appProcess)
                            //Add a link to Application Process Request so UCD users could be redirected to the
                            //automated task in a Scheduled Deployment that started it
                            try {
                                factory.addLinkToApplicationProcessRequest(requestId, "View in IBM UrbanCode Release", sdLink);
                            } catch (Exception e) {
                                throw new RuntimeException("Failed to add a link to the Application Process Request", e);
                            }
                        //---------------------IBM URBANCODE LOGIC END-----------------------
                }
                    

                jsonBuilder(processRequests)

                //We save the list of process request to an output property
                setOutput(apTool, jsonBuilder.toString());
                }
                else {
                    println "No targets specified"
                }
            }
        }
    }
    
    //--------------------------------------------------------------
    def setOutput(apTool, value) {
        apTool.setOutputProperty("Output", value);
        apTool.storeOutputProperties();
    }
}
    
