#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2015. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import com.urbancode.plugin.*;
import com.urbancode.plugin.models.*;

import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import static java.util.Calendar.*
import java.text.SimpleDateFormat;

import com.urbancode.sync.*;

import com.urbancode.release.rest.framework.Clients;
import com.urbancode.release.rest.framework.Clients.*;
import com.urbancode.release.rest.models.internal.InternalClients.*;
import com.urbancode.release.rest.models.internal.ScheduledDeployment;
import com.urbancode.release.rest.models.internal.AuditAction;
import com.urbancode.release.rest.models.internal.PluginIntegrationProvider;
import com.urbancode.commons.util.query.QueryFilter.FilterType;
import static com.jayway.restassured.RestAssured.expect;
import static com.jayway.restassured.RestAssured.given;
import static com.jayway.restassured.RestAssured.requestSpecification;
import static com.jayway.restassured.RestAssured.responseSpecification;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import java.security.cert.X509Certificate;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;

import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonNull;

import com.google.gson.Gson;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

def integration = new CloudIntegration (props)

def totalStart = System.currentTimeMillis()

//We launch the full Integration
integration.runIntegration ()

public class CloudIntegration {

    def logFile; // = new File("/tmp/reporting-ucd-plugin.txt");
    int timeoutValue = 30000;
    int batchSize = 100;
    def token;
    String serverUrl;
    String cloudUrl;
    UCCloudClient cloudHelper;
    UCDeployClient deployHelper;
    TeamSerializer teamHelper;
    ApplicationProcessRequestSerializer aprHelper;
    ComponentProcessRequestSerializer cprHelper;
    def integrationProviderId;
    def syncId;
    def syncToken;
    String syncUrl;
    String syncName;
    String adminUser;
    def isComponentProcessRequestEnabled;
    def provider;
    long lastExecutionTime;
    // long lastInventoryExecutionTime;
    // long lastVersionExecutionTime;
    boolean firstTime = false;
    boolean inventoryFirstTime = false;
    boolean versionFirstTime = false;
    String mesg = "";
    boolean retDel = false;
    def compMap = [:];
    def envAppMap = [:];

    public CloudIntegration (props) {

        // Setting up the default log directory and file based off the user's home directory
        // which is the default location where the cloud-sync directory is located
        def userHomeDir = System.getProperty("user.home");
        def logDir = new File(userHomeDir + "/.ibm/cloud-sync/plugins/logs");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }

        def date = new Date();
        def logName = "reporting-ucd-plugin_" + date[DATE] + "_" + (date[MONTH].toInteger() + 1).toString() + "_" + date[YEAR] + ".log";
        logFile = new File(System.getProperty("user.home") + "/.ibm/cloud-sync/plugins/logs/" + logName);

        date = date - 7;
        def oldLogName = "reporting-ucd-plugin_" + date[DATE] + "_" + date[MONTH] + "_" + date[YEAR] + ".log";
        def oldLogFile = new File(System.getProperty("user.home") + "/.ibm/cloud-sync/plugins/logs/" + oldLogName);

        if (oldLogFile.exists()) {
            oldLogFile.delete();
        }

        // Are we in Dev?
        def syncEnv = props['sync.environment']

        // Checking for the plugin settings file exists and creating it if it doesn't
        def pluginSettingsDir = new File(userHomeDir + "/.ibm/cloud-sync/plugins/settings");
        if (!pluginSettingsDir.exists()) {
            printToLogFile("settings dir did not exist, creating it now!");
            pluginSettingsDir.mkdirs();
        } else {
            printToLogFile("settings dir exists already!");
        }

        // Checking if the settings directory for this specific plugin exists and creating it if it doesn't
        def repPlugDir = new File(userHomeDir + "/.ibm/cloud-sync/plugins/settings" + "/reporting-ucd-plugin");
        if (!repPlugDir.exists()) {
            printToLogFile("reporting-ucd-plugin dir did not exist, creating it now!");
            repPlugDir.mkdirs();
        } else {
            printToLogFile("reporting-ucd-plugin dir exists already!");
        }


        def settingsFileName = userHomeDir + "/.ibm/cloud-sync/plugins/settings" + "/reporting-ucd-plugin" + "/plugin.properties";
        def settingsFile = new File(settingsFileName);
        def logFileName = userHomeDir + "/.ibm/cloud-sync/plugins/logs/" + logName;
        def numDaysToRetrieve = -1L;
        cloudUrl = "https://ucreporting-sync-api.mybluemix.net/";

        if(syncEnv == "dev") {
            cloudUrl = "https://ucreporting-sync-api-dev.mybluemix.net/";
        }
        else if (syncEnv == "ys1dev") {
            cloudUrl = "https://ucreporting-sync-api-stage1.stage1.mybluemix.net/";
        }

        if (!settingsFile.exists()) {

            printToLogFile("plugin.properties file did not exist, creating it now!");
            settingsFile.write("#logfile=" + userHomeDir + "/.ibm/cloud-sync/plugins/logs/reporting-ucd-plugin.log\n");
            settingsFile << "\n# Number of retries before REST call is considered a failure and moves on to next data set.\n";
            settingsFile << "numRetries=3\n";
            settingsFile << "\n# Timeout value for socket connections (in milliseconds). Useful for slow networks or servers with large data sets.\n";
            settingsFile << "timeout=30000\n";
            settingsFile << "\n# Batch size for how many items at once to retrieve. If you are running out of heap space, decrease this value.\n";
            settingsFile << "batchSize=100\n";
            settingsFile << "\n# Number of days from current time to grab, by default ~3 months worth of information.\n";
            settingsFile << "#numDaysToRetrieve=90\n";
            settingsFile << "\n# Flag to indicate whether to retrieve deleted applications and environments.\n";
            settingsFile << "retrieveDeleted=false\n";
            settingsFile << "\n# URL to send data from UCD server to.\n"
            settingsFile << "#cloudUrl=https://ucreporting-sync-api.mybluemix.net/\n";

        } else {

            printToLogFile("plugin.properties file exists already!");
            def lines = settingsFile.readLines();

            for (line in lines) {
                // Check if the current line is for the logfile, numDays or the cloud URL
                if (line.contains("logfile=")) {
                    if (line.substring(0,1) == '#') {
                        printToLogFile("There was a #, so I'm ignoring the logfile setting!");
                    } else {
                        logFileName = line.substring(line.indexOf('=') + 1);
                        printToLogFile("Log File should be: " + logFileName);
                        logFile = new File(logFileName);
                    }
                } else if (line.contains("numDaysToRetrieve=")) {
                    if (line.substring(0,1) == '#') {
                        printToLogFile("There was a #, so I'm ignoring the numDaysToRetrieve setting!");
                    } else {
                        numDaysToRetrieve = line.substring(line.indexOf('=') + 1).toLong();
                        printToLogFile("Number of Days to Retrieve: " + numDaysToRetrieve.toString());
                        settingsFile.text = settingsFile.text.replace("numDaysToRetrieve=", "#numDaysToRetrieve=");
                    }
                } else if (line.contains("cloudUrl=")) {
                    if (line.substring(0,1) == '#') {
                        printToLogFile("There was a #, I'm ignoring the cloudURL setting");
                    } else {
                        cloudUrl = line.substring(line.indexOf('=') + 1);
                        printToLogFile("Cloud URL: " + cloudUrl);
                    }
                } else if (line.contains("batchSize=")) {
                    batchSize = (line.substring(line.indexOf('=') + 1).toInteger());
                    printToLogFile("Line contained batch size and that value was: " + batchSize.toString());
                } else if (line.contains("timeout=")) {
                    timeoutValue = (line.substring(line.indexOf('=') + 1).toInteger());
                    printToLogFile("Line contained timeout value and that value was: " + timeoutValue.toString());
                } else if (line.contains("retrieveDeleted=")) {
                    retDel = (line.substring(line.indexOf('=') + 1).toBoolean());
                    printToLogFile("Line contained retrieve deleted value and that value was: " + retDel);
                }
            }
        }

        // grab the identifying values for your username and cloud-sync
        integrationProviderId = props['releaseIntegrationProvider'];
        syncId = props['sync.id'];
        syncUrl = props['sync.url'];
        syncToken = props['sync.token'];
        syncName = props['sync.name'];
        token = props['token'];
        serverUrl = props['server_uri'];
        adminUser = props['admin_user'];
        isComponentProcessRequestEnabled = props['sync_cprs'];
        cloudHelper = new UCCloudClient(serverUrl, cloudUrl, syncId, syncToken, syncName, adminUser, integrationProviderId, logFileName, settingsFileName, timeoutValue)
        deployHelper = new UCDeployClient(serverUrl, token, syncId, logFileName, settingsFileName, timeoutValue);
        teamHelper = new TeamSerializer();
        aprHelper = new ApplicationProcessRequestSerializer();
        cprHelper = new ComponentProcessRequestSerializer();

        // This is a Groovy class that extend the UCR client IntegrationProvider and overrides the
        // endpoints used.  Otherwise it behaves exactly the same
        provider = new SyncIntegration().setSyncAuth(syncUrl, syncToken).id(integrationProviderId);
        configureSSL(syncUrl);
        provider = provider.get();

        long curTime = System.currentTimeMillis();
        // Attempt to grab the lastExecutionTime, if it's null, grab current time and subtract
        // the number of days to retrieve in millis.

        if (provider.getProperty("lastExecutionTime") == null) {
            long ninetyDaysInMillis = 90L * 24L * 60L * 60L * 1000L;
            long ninetyDaysAgo = curTime - ninetyDaysInMillis;
            lastExecutionTime = ninetyDaysAgo;
            provider.setProperty("lastExecutionTime", ninetyDaysAgo.toString());
            firstTime = true;
        } else {
            lastExecutionTime = provider.getProperty("lastExecutionTime").toLong();
        }

        // if (provider.getProperty("lastVersionExecutionTime") == null) {
        //     long ninetyDaysInMillis = 90L * 24L * 60L * 60L * 1000L;
        //     long ninetyDaysAgo = curTime - ninetyDaysInMillis;
        //     lastVersionExecutionTime = ninetyDaysAgo;
        //     provider.setProperty("lastVersionExecutionTime", ninetyDaysAgo.toString());
        //     versionFirstTime = true;
        // } else {
        //     lastVersionExecutionTime = provider.getProperty("lastVersionExecutionTime").toLong();
        // }

        // if (provider.getProperty("lastInventoryExecutionTime") == null) {
        //     long ninetyDaysInMillis = 90L * 24L * 60L * 60L * 1000L;
        //     long ninetyDaysAgo = curTime - ninetyDaysInMillis;
        //     lastInventoryExecutionTime = ninetyDaysAgo;
        //     provider.setProperty("lastInventoryExecutionTime", ninetyDaysAgo.toString());
        //     inventoryFirstTime = true;
        // } else {
        //     lastInventoryExecutionTime = provider.getProperty("lastInventoryExecutionTime").toLong();
        // }

        if (numDaysToRetrieve != -1L) {
            long numDaysToRetrieveInMillis = numDaysToRetrieve * 24L * 60L * 60L * 1000L;
            lastExecutionTime = curTime - numDaysToRetrieveInMillis;
            // lastInventoryExecutionTime = curTime - numDaysToRetrieveInMillis;
            // lastVersionExecutionTime = curTime - numDaysToRetrieveInMillis;
        }

        //REMOVE THIS WHEN YOU HAVE A BIGGER UCD DB.
        //lastExecutionTime = 1478803904065;
        //lastExecutionTime = 0;
        //lastExecutionTime = 1487003563211;
        printToLogFile("lastExecutionTime: " + lastExecutionTime.toString());

    }

    def runIntegration(){

        def integrationStartTime = System.currentTimeMillis();
        println "------------------------------------------------------------------------------------------------------------------------------"

        getTeams();
        getApplications();
        getEnvironments();
        getSnapshots();
        getApplicationProcesses();
        retryApplicationProcessRequests();
        getApplicationProcessRequests(lastExecutionTime, batchSize);
        getMissedAppDeployments();

        // If this is the first time, then we must run the security model again to connect apps and teams
        if (firstTime) {
            getTeams();
        }

        if (isComponentProcessRequestEnabled == "true") {
            retryComponentProcessRequests();
            getComponents();
            getMissedCompDeployments();
            // version call requires that components have already been retrieved so it should only run if getComponents was successful
            // getVersions();
        }

        // getInventory();

        println "------------------------------------------------------------------------------------------------------------------------------"

        provider.setSyncAuth(syncUrl, syncToken);
        provider.property("lastExecutionTime", integrationStartTime.toString()).save();
        // provider.property("lastVersionExecutionTime", integrationStartTime.toString()).save();
        // provider.property("lastInventoryExecutionTime", integrationStartTime.toString()).save();

        printToLogFile("Finished Integration\n\n\n");
    }

    /*
    * Method to query for APR IDs that were in the middle of running when integration ran.
    * Then take that list of IDs and individually try to retrieve their run info and send that
    * to our database.
    */

    def apprJson;
    boolean success;
    def getMissedAppDeployments() {

        printToLogFile("Starting getMissedAppDeployments");
        def startTime = System.currentTimeMillis();
        def missedAppDeps = cloudHelper.getMissedAppDeployments();
        String id = "";
        String approvalId = "";
        def mdJson;

        for (md in missedAppDeps) {

            JsonArray appProcReqs = new JsonArray();
            JsonObject appProcReq = new JsonObject();
            id = md.id;
            id = id.replaceAll("\"", "");
            mdJson = deployHelper.getMissedAppDeployment(id);

            appProcReq.add("application", aprHelper.processApplication(mdJson));
            appProcReq.add("environment", aprHelper.processEnvironment(mdJson));
            appProcReq.add("application_process", aprHelper.processApplicationProcess(mdJson));

            if (mdJson.has("approval")) {
                approvalId = mdJson.get("approval").id;
                approvalId = (approvalId == null) ? "" : approvalId.replaceAll("\"", "");
                apprJson = deployHelper.getApprovalTrace(approvalId);
                if (apprJson != null) {
                    appProcReq.add("approval", aprHelper.processApproval(apprJson));
                }
            }

            appProcReq = aprHelper.processAPR(mdJson, appProcReq);
            appProcReqs.add(appProcReq);

            success = cloudHelper.sendMissedApplicationProcessRequests(appProcReqs.toString());
            if (!success) {
                mesg = "ERROR: Unable to send Missed Application Process Request: " + id;
                printToLogFile(mesg);
            } else {
                mesg = "Sent Missed Application Process Requests: " + id ;
                printToLogFile(mesg);
            }
        }

        def messages = ["Number of App Deployments: " + missedAppDeps.size()] as String[];
        printStepInfo(startTime, "Get Remaining App Deployments", messages);
    }

    /*
    * Method to query for CPR ids that were in the middle of running when integration ran.
    * Then take that list of IDs and individually try to retrieve their run info and send that
    * to our database.
    */

    def getMissedCompDeployments() {

        printToLogFile("Starting getMissedCompDeployments");
        def startTime = System.currentTimeMillis();
        def missedCompDeps = cloudHelper.getMissedCompDeployments();
        JsonArray compProcReqs;
        JsonObject compProcReq;
        String id = "";
        def mdJson;
        boolean success = false;

        for (md in missedCompDeps) {

            compProcReqs = new JsonArray();
            compProcReq = new JsonObject();
            id = md.id;
            id = id.replaceAll("\"", "");
            mdJson = deployHelper.getMissedCompDeployment(id);

            compProcReq.add("application", cprHelper.processApplication(mdJson));
            compProcReq.add("environment", cprHelper.processEnvironment(mdJson));
            compProcReq.add("component", cprHelper.processComponent(mdJson));
            compProcReq.add("componetProcess", cprHelper.processComponentProcess(mdJson));

            if (mdJson.has("rootTrace")){
                rootTrace = mdJson.get("rootTrace");
                if (rootTrace instanceof JsonPrimitive){
                } else {
                    compProcReq.add("workflow", cprHelper.processWorkflow(rootTrace));
                    if (rootTrace.has("children")) {
                        children = rootTrace.get("children");
                        compProcReq.add("commands", cprHelper.processCommands(children));
                    }
                }
            }

            compProcReq = cprHelper.processCPR(mdJson, compProcReq);
            compProcReqs.add(compProcReq);

            success = cloudHelper.sendMissedComponentProcessRequests(compProcReqs.toString());
            if (!success) {
                mesg = "ERROR: Unable to send Missed Component Process Request: " + id;
                printToLogFile(mesg);
            } else {
                mesg = "Sent Missed Component Process Requests: " + id ;
                printToLogFile(mesg);
            }
        }

        def messages = ["Number of Deployments: " + missedCompDeps.size()] as String[];
        printStepInfo(startTime, "Get Remaining Comp Deployments", messages);
    }

    /*
    * Method to retry grabbing batches of the APRs that for some reason weren't retrieved during integration.
    */

    def retryApplicationProcessRequests() {

        printToLogFile("Starting retryApplicationProcessRequests");
        JsonArray failedInfo = cloudHelper.getFailedAPRInfo();
        long submittedTime;
        int bSize;

        for (fi in failedInfo) {

            submittedTime = fi.get("submitted_time").getAsLong();
            bSize = fi.get("batch_size").getAsInt();
            getAPRSubset(submittedTime, bSize);

        }

    }

    /*
    * Method to retry grabbing batches of the CPRs that for some reason weren't retrieved during integration.
    */

    def retryComponentProcessRequests() {

        printToLogFile("Starting retryComponentProcessRequests");
        JsonArray failedInfo = cloudHelper.getFailedCPRInfo();
        long submittedTime;
        int bSize;
        String compId;

        for (fi in failedInfo) {

            submittedTime = fi.get("submitted_time").getAsLong();
            bSize = fi.get("batch_size").getAsInt();
            compId = fi.get("comp_id").replaceAll("\"", "");
            getCPRSubset(compId, submittedTime, bSize);

        }

    }

    /*
    * Method to send info to a UCD REST endpoint with a URL and ID to send back to our database
    * once the APR is finished running.
    */

    def sendCallbackProps(aprId){

        JsonArray urlArray = new JsonArray();
        JsonObject urlProps = new JsonObject();
        urlProps.addProperty("name", "insights-post-deploy-put-url");
        urlProps.addProperty("value", cloudUrl + "api/v1/ucd/deploymentdone");
        urlProps.addProperty("secure", "false");

        urlArray.add(urlProps);
        deployHelper.saveProps(aprId, urlArray.toString());

        JsonObject mesg = new JsonObject();
        mesg.addProperty("id", aprId);
        mesg.addProperty("sync_id", syncId);

        JsonArray messageArray = new JsonArray();
        JsonObject messageProps = new JsonObject();
        messageProps.addProperty("name", "insights-post-deploy-message");
        messageProps.add("value", mesg);
        messageProps.addProperty("secure", "false");

        messageArray.add(messageProps);
        deployHelper.saveProps(aprId, messageArray.toString());

    }

    /*
    * Method to send info to a UCD REST endpoint with a URL and ID to send back to our database
    * once the APR is finished running.
    */

    def sendCPRCallbackProps(cprId){

        JsonArray urlArray = new JsonArray();
        JsonObject urlProps = new JsonObject();
        urlProps.addProperty("name", "insights-post-deploy-put-url");
        urlProps.addProperty("value", cloudUrl + "api/v1/ucd/cprdone");
        urlProps.addProperty("secure", "false");

        urlArray.add(urlProps);
        deployHelper.saveCPRProps(cprId, urlArray.toString());

        JsonObject mesg = new JsonObject();
        mesg.addProperty("id", cprId);
        mesg.addProperty("sync_id", syncId);

        JsonArray messageArray = new JsonArray();
        JsonObject messageProps = new JsonObject();
        messageProps.addProperty("name", "insights-post-deploy-message");
        messageProps.add("value", mesg);
        messageProps.addProperty("secure", "false");

        messageArray.add(messageProps);
        deployHelper.saveCPRProps(cprId, messageArray.toString());

    }

    def numItems = 0;
    def curIndex = 0;
    def method = "";
    def startedAfter = 0;

    // Get the json of all applications and then send them on
    def getApplications() {

        def startTime = System.currentTimeMillis();
        printToLogFile("Starting getApplications");
        numItems = 0;

        if (firstTime){
            startedAfter = 0;
        } else {
            startedAfter = lastExecutionTime;
        }

        def numApps = deployHelper.getAppCount(startedAfter, retDel);
        def applications = [];
        def applicationJsonArray;
        def appObj;
        def application;
        curIndex = 0;

        while (curIndex < numApps){

            applications = [];
            applicationJsonArray = deployHelper.getApplications(startedAfter, curIndex, batchSize, retDel);
            Gson gson = new Gson();

            //Iterate through applications
            for(je in applicationJsonArray) {

                // Get the application object
                appObj = je.getAsJsonObject();
                application = gson.fromJson(appObj, Application.class);
                application.type = "UCD"

                String sec_res_id = appObj.securityResourceId;
                if (sec_res_id != null)
                    application.sec_res_id = sec_res_id.replaceAll("\"", "");

                applications.add(application);
                numItems++;

            }

            if (applications.size() != 0) {

                def success = cloudHelper.sendApplications(applications);

                if (!success) {
                    mesg = "ERROR: Unable to send Applications " + curIndex + " through " + (curIndex + batchSize);
                    printToLogFile(mesg);
                    printToLogFile("Failing out of current sync run!");
                    throw new RuntimeException("Failed to send applications");

                } else {
                    mesg = "Sent Applications " + curIndex + " through " + (curIndex + batchSize);
                    printToLogFile(mesg);
                }

            } else {
                mesg = "ERROR: Unable to grab Applications " + curIndex + " through " + (curIndex + batchSize);
                printToLogFile(mesg);
                printToLogFile("Failing out of current sync run!");
                throw new RuntimeException("Failed to retrieve applications");
            }

            curIndex += batchSize;

        }

        def messages = ["Number of Applications: " + numItems] as String[];
        printStepInfo(startTime, "Sync Applications", messages);
    }

    // Get the json of all environments and then send them on
    def getEnvironments() {
        def startTime = System.currentTimeMillis();

        method = "getEnvironments";
        printToLogFile("Starting getEnvironments");
        mesg = "Starting" + method;

        numItems = 0;

        if (firstTime){
            startedAfter = 0;
        } else {
            startedAfter = lastExecutionTime;
        }

        def numEnvs = deployHelper.getEnvCount(startedAfter, retDel);
        def envs;
        def envJsonArray;
        def envObj;
        def env;
        curIndex = 0;

        String app_id;
        String req_approval;
        String calendar_id;
        String enable_proc;
        String no_self_approvals;
        String cleanup_count_to_keep;
        String cleanup_days_to_keep;
        String lock_snapshots;
        String security_resource_id;
        String use_system_default_days;
        String history_cleanup_days_to_keep;

        while (curIndex < numEnvs){

            envs = [];
            envJsonArray = deployHelper.getEnvironments(startedAfter, curIndex, batchSize, retDel);

            Gson gson = new Gson();
            //Iterate through environments
            for(je in envJsonArray) {

                // Get the environment object
                envObj = je.getAsJsonObject();
                env = gson.fromJson(envObj, Environment.class);

                app_id = je.applicationId;
                req_approval = je.requireApprovals;
                calendar_id = je.calendarId;
                enable_proc = je.enableProcessHistoryCleanup;
                no_self_approvals = je.noSelfApprovals;
                cleanup_count_to_keep = je.cleanupCountToKeep;
                cleanup_days_to_keep = je.cleanupDaysToKeep;
                lock_snapshots = je.lockSnapshots;
                security_resource_id = je.securityResourceId;
                use_system_default_days = je.useSystemDefaultDays;
                history_cleanup_days_to_keep = je.historyCleanupDaysToKeep;

                if (app_id != null)
                    env.application_id = app_id.replaceAll("\"", "");
                if (req_approval != null)
                    env.require_approvals = req_approval.replaceAll("\"", "");
                if (calendar_id != null)
                    env.calendar_id = calendar_id.replaceAll("\"", "");
                if (enable_proc != null)
                    env.enable_process_history_cleanup = enable_proc.replaceAll("\"", "");
                if (no_self_approvals != null)
                    env.no_self_approvals = no_self_approvals.replaceAll("\"", "");
                if (cleanup_count_to_keep != null)
                    env.cleanup_count_to_keep = cleanup_count_to_keep.replaceAll("\"", "");
                if (cleanup_days_to_keep != null)
                    env.cleanup_days_to_keep = cleanup_days_to_keep.replaceAll("\"", "");
                if (lock_snapshots != null)
                    env.lock_snapshots = lock_snapshots.replaceAll("\"", "");
                if (security_resource_id != null)
                    env.sec_res_id = security_resource_id.replaceAll("\"", "");
                if (use_system_default_days != null)
                    env.use_system_default_days = use_system_default_days.replaceAll("\"", "");
                if (history_cleanup_days_to_keep != null)
                    env.history_cleanup_days_to_keep = history_cleanup_days_to_keep.replaceAll("\"", "");

                envs.add(env);
                numItems++;
            }

            if (envs.size() != 0) {

                def success = cloudHelper.sendEnvironments(envs);
                if (!success) {
                    mesg = "ERROR: Failed to send Environments " + curIndex + " through " + (curIndex + batchSize);
                    printToLogFile(mesg);
                    printToLogFile("Failing out of current sync run!");
                    throw new RuntimeException("Failed to retrieve environments");
                } else {

                    mesg = "Sent Environments " + curIndex + " through " + (curIndex + batchSize);
                    printToLogFile(mesg);
                }

            } else {
                mesg = "ERROR: Unable to grab Environments " + curIndex + " through " + (curIndex + batchSize);
                printToLogFile(mesg);
                printToLogFile("Failing out of current sync run!");
                throw new RuntimeException("Failed to retrieve environments");
            }

            curIndex += batchSize;

        }

        def messages = ["Number of Environments: " + numItems] as String[];
        printStepInfo(startTime, "Get Environments", messages);

    }

    // get the JSON representation of each App Process and send it to our services.
    def getApplicationProcesses() {
        def startTime = System.currentTimeMillis();

        method = "getApplicationProcesses";
        printToLogFile("Starting getApplicationProcesses");

        def numAppProcs = deployHelper.getAppProcCount(lastExecutionTime);
        curIndex = 0;
        printToLogFile("Number of Application Processes: " + numAppProcs);

        def applicationProcessArray;
        def totalAP = 0;

        while (curIndex < numAppProcs) {

            def applicationProcsJsonArray = deployHelper.getApplicationProcesses(lastExecutionTime, curIndex, batchSize * 10);
            Gson gson = new Gson();
            applicationProcessArray = gson.fromJson(applicationProcsJsonArray, ApplicationProcess[].class);
            cloudHelper.sendApplicationProcesses(applicationProcessArray);
            totalAP += applicationProcessArray.size();
            curIndex += batchSize * 10;

        }

        def numAppTempProcs = deployHelper.getAppProcTempCount(lastExecutionTime);
        curIndex = 0;
        printToLogFile("Number of Application Process Templates: " + numAppTempProcs);
        def appProcTempArray;
        totalAP = 0;

        while (curIndex < numAppTempProcs) {

            def appProcTempJsonArray = deployHelper.getApplicationProcessTemplates(lastExecutionTime, curIndex, batchSize * 10);
            Gson gson = new Gson();
            appProcTempArray = gson.fromJson(appProcTempJsonArray, ApplicationProcess[].class);
            cloudHelper.sendApplicationProcesses(appProcTempArray);

            totalAP += appProcTempArray.size();
            curIndex += batchSize * 10;

        }

        def messages = ["Number of Application Processes: " + numAppProcs, "Number of Application Template Processes: " + numAppTempProcs] as String[];
        printStepInfo(startTime, "Get Application Processes Start", messages);

    }

    // Get the JSON representation of snapshots and send them on to our service.
    def getSnapshots() {
        def startTime = System.currentTimeMillis();

        method = "getSnapshots"
        printToLogFile("Starting getSnapshots");
        numItems = 0;

        def numSnapshots = deployHelper.getSnapshotCount(lastExecutionTime);
        def snapshotArray;
        def totalSS = 0;
        curIndex = 0;

        while (curIndex < numSnapshots) {

            def snapshotsJsonArray = deployHelper.getSnapshots(lastExecutionTime, curIndex, batchSize);
            Gson gson = new Gson();
            snapshotArray = gson.fromJson(snapshotsJsonArray, Snapshot[].class);
            cloudHelper.sendSnapshots(snapshotArray);
            totalSS += snapshotArray.size();

            curIndex += batchSize;

        }

        def messages = ["Number of Snapshots: " + totalSS] as String[];
        printStepInfo(startTime, "Get Snapshots", messages);

    }

    def getVersions() {
        method = "getVersions"
        printToLogFile("Starting " + method);
        numItems = 0;
        def startTime = System.currentTimeMillis();

        printStepInfo(startTime, "Get Versions Start", null);

        def versionJsonArray = deployHelper.getVersions(lastVersionExecutionTime);

        for (version in versionJsonArray) {
            String compId = version.get("componentId");
            compId = compId.replaceAll("\"", "");
            def comp = compMap.get(compId)
            version.add("component_name", comp.name);
            version.add("component_active", comp.active);
            version.add("component_deleted", comp.deleted);
        }

        Gson gson = new Gson();

        def versionArray = gson.fromJson(versionJsonArray, Version[].class);

        if (versionArray.size() > 0) {
            cloudHelper.sendVersions(versionArray);
        }

        println "Number of Versions: " + versionArray.size();
    }

    def getInventory() {
        method = "getInventory"
        printToLogFile("Starting " + method);
        numItems = 0;
        def startTime = System.currentTimeMillis();

        printStepInfo(startTime, "Get Inventory Start", null);

        def inventoryJsonArray = deployHelper.getInventory(lastInventoryExecutionTime);

        Gson gson = new Gson();

        def inventoryArray = gson.fromJson(inventoryJsonArray, Inventory[].class);
        if (inventoryArray.size() > 0) {
            def environmentJsonArray = deployHelper.getAllEnvironments();
            for (environment in environmentJsonArray) {
                String envId = environment.get("id");
                envId = envId.replaceAll("\"", "");
                String appId = environment.get("applicationId");
                appId = appId.replaceAll("\"", "");
                envAppMap.put(envId, appId);
            }

            for (inventory in inventoryArray) {
                String envId = inventory.environment_id;
                envId = envId.replaceAll("\"", "");
                def appId = envAppMap.get(envId);
                inventory.application_id = appId;
            }

            cloudHelper.sendInventory(inventoryArray);
        }

        println "Number of Inventory entries: " + inventoryArray.size()
    }

    // get info about all the teams on the UCD server and send it on
    def getTeams(){

        def startTime = System.currentTimeMillis();
        method = "getTeams";
        printToLogFile("Starting getTeams");

        def responseArray = deployHelper.getTeams();
        def roleIds = [];
        JsonArray teamArray = new JsonArray();
        String team_id;
        String team_name;
        JsonArray roleMappings;
        JsonObject roleMapping;
        JsonObject team;
        JsonArray applications;
        JsonArray environments;
        JsonArray processes;

        for (jo in responseArray) {

            team = new JsonObject();
            team_id = jo.id;
            team_name = jo.name;
            team.addProperty("team_id", team_id.replaceAll("\"", ""));
            team.addProperty("team_name", team_name.replaceAll("\"", ""));

            roleMappings = new JsonArray();
            for (role in jo.get("roleMappings")) {

                roleMapping = new JsonObject();
                if (role.has("user")) {
                    roleMapping = teamHelper.processUser(roleMapping, role);
                } else if (role.has("group")) {
                    roleMapping = teamHelper.processGroup(roleMapping, role, deployHelper);
                }

                if (role.has("role")) {
                    roleMapping = teamHelper.processRole(roleMapping, role);
                    roleIds.add(roleMapping.get("role_id").getAsString());
                }
                roleMappings.add(roleMapping);
            }

            applications = new JsonArray();
            for (app in jo.get("applications")) {
                applications.add(teamHelper.processApp(app));
            }

            environments = new JsonArray();
            for (env in jo.get("environments")) {
                environments.add(teamHelper.processEnv(env));
            }

            processes = new JsonArray();
            for (proc in jo.get("processes")) {
                processes.add(teamHelper.processProc(proc));
            }

            team.add("role_mappings", roleMappings);
            team.add("applications", applications);
            team.add("environments", environments);
            team.add("processes", processes);
            teamArray.add(team);
        }

        roleIds = roleIds.unique();

        getActionMappings(roleIds);
        mesg = "Successfully sent action mappings";
        cloudHelper.sendTeams(teamArray.toString());

        mesg = "Successfully sent team mappings";
        def messages = ["Number of Teams: " + teamArray.size()] as String[];
        printStepInfo(startTime, "Get Teams", messages);

    }

    // given a set of role IDs from getTeams(), grab each role's permissions (action mappings) and send it on.
    def getActionMappings(roleIds) {

        JsonObject acmap;
        JsonArray amArray;
        def actionMapping;

        for(roleId in roleIds){

            acmap = new JsonObject();
            acmap.addProperty("role_id", roleId);
            amArray = new JsonArray();
            actionMapping = deployHelper.getActionMappings(roleId);

            for(am in actionMapping) {
                if(am["action"].name.toString().contains("View")) {
                    if(am["action"].name.toString().contains("View Applications"))
                        amArray.add(am);
                    if(am["action"].name.toString().contains("View Environments"))
                        amArray.add(am);
                    if(am["action"].name.toString().contains("View Processes"))
                        amArray.add(am);
                }
            }

            acmap.add("action_mappings", amArray);
            cloudHelper.sendActionMappings(acmap.toString());

        }

    }

    def appProcReqs;
    def appProcReqsJsonArray;
    def rootTrace;
    JsonObject appProcReq;

    // Given a specific time and a batch size, retry to grab the batch of APRs that failed last time
    def getAPRSubset(time, bSize) {

        printToLogFile("Starting getAPRSubset");

        String status = "";
        String state = "";
        String missedId = "";
        String approvalId = "";

        appProcReqs = [];
        appProcReqsJsonArray = deployHelper.getApplicationProcessRequests(time, bSize);

        for(je in appProcReqsJsonArray) {

            appProcReq = new JsonObject();

            status = je.get("status");
            state = je.get("state");
            if (status != null) {
                status = status.replaceAll("\"", "");
            }
            if (state != null) {
                state = state.replaceAll("\"", "");
            }

            if (state != "CLOSED") {

                if (status != "CANCELLED") {
                    missedId = je.get("id");
                    missedId = missedId.replaceAll("\"", "");
                    sendCallbackProps(missedId);
                }

            }

            // Create the application process request and application JSON objects
            appProcReq.add("application", aprHelper.processApplication(je));
            appProcReq.add("environment", aprHelper.processEnvironment(je));
            appProcReq.add("application_process", aprHelper.processApplicationProcess(je));

            if (je.has("approval")) {
                approvalId = je.get("approval").id;
                approvalId = (approvalId == null) ? "" : approvalId.replaceAll("\"", "");
                apprJson = deployHelper.getApprovalTrace(approvalId);
                if (apprJson != null) {
                    appProcReq.add("approval", aprHelper.processApproval(apprJson));
                }
            }

            appProcReq = aprHelper.processAPR(je, appProcReq);
            appProcReqs.add(appProcReq);

        }

        if (appProcReqs.size() != 0) {

            // Update the "floor" time for the next DB query
            def success = cloudHelper.sendApplicationProcessRequests(appProcReqs.toString());
            if (!success) {
                mesg = "ERROR: Unable to send Application Process Requests for the second time";
                printToLogFile(mesg);
            } else {
                mesg = "Sent Application Process Requests on the second try.";
                printToLogFile(mesg);
            }

        } else {
            mesg = "ERROR: Unable to grab Application Process Requests on the second try";
            printToLogFile(mesg);
        }

    }


    long latestAPRSubTime = 0L;
    // Get the json of all application processes requests and then send them on
    def getApplicationProcessRequests(time, bSize) {
        def startTime = System.currentTimeMillis();

        method = "getApplicationProcessRequests";
        printToLogFile("Starting getApplicationProcessRequests");
        numItems = 0;
        curIndex = 0;
        int numAppProcReqs = deployHelper.getAppProcReqCount(time);
        latestAPRSubTime = time;
        String status = "";
        String state = "";
        String missedId = "";
        String approvalId = "";
        JsonObject failedAPR;

        while (curIndex < numAppProcReqs){

            appProcReqs = [];
            appProcReqsJsonArray = deployHelper.getApplicationProcessRequests(latestAPRSubTime, bSize);

            if (appProcReqsJsonArray.size() == 0) {

                printToLogFile("Failed to get back a proper set of APRs, sending info to try again at a later run.");

                failedAPR = new JsonObject();
                failedAPR.addProperty("submitted_time", latestAPRSubTime.toString());
                failedAPR.addProperty("batch_size", bSize.toString());
                cloudHelper.sendFailedAPRInfo(failedAPR.toString());

            }

            //Iterate through application process requests
            for(je in appProcReqsJsonArray) {

                appProcReq = new JsonObject();

                status = je.get("status");
                state = je.get("state");
                if (status != null) {
                    status = status.replaceAll("\"", "");
                }
                if (state != null) {
                    state = state.replaceAll("\"", "");
                }

                if (state != "CLOSED") {

                    if (status != "CANCELLED") {
                        missedId = je.get("id");
                        missedId = missedId.replaceAll("\"", "");
                        sendCallbackProps(missedId);
                    }

                }

                // Create the application process request and application JSON objects
                appProcReq.add("application", aprHelper.processApplication(je));
                appProcReq.add("environment", aprHelper.processEnvironment(je));
                appProcReq.add("application_process", aprHelper.processApplicationProcess(je));

                if (je.has("approval")) {
                    approvalId = je.get("approval").id;
                    approvalId = (approvalId == null) ? "" : approvalId.replaceAll("\"", "");
                    apprJson = deployHelper.getApprovalTrace(approvalId);
                    if (apprJson != null) {
                        appProcReq.add("approval", aprHelper.processApproval(apprJson));
                    }
                }

                appProcReq = aprHelper.processAPR(je, appProcReq);
                appProcReqs.add(appProcReq);
                numItems++;

            }

            if (appProcReqs.size() != 0) {

                // Update the "floor" time for the next DB query
                if (appProcReq.get("submitted_time") != null) {
                    latestAPRSubTime = appProcReq.get("submitted_time").toString().replaceAll("\"", "").toLong();
                }
                def success = cloudHelper.sendApplicationProcessRequests(appProcReqs.toString());
                if (!success) {
                    mesg = "ERROR: Unable to send Application Process Requests " + curIndex + " through " + (curIndex + bSize);
                    printToLogFile(mesg);
                } else {
                    mesg = "Sent Application Process Requests " + curIndex + " through " + (curIndex + bSize);
                    printToLogFile(mesg);
                }

            } else {
                mesg = "ERROR: Unable to grab Application Process Requests " + curIndex + " through " + (curIndex + bSize);
                printToLogFile(mesg);
                latestAPRSubTime += 3600000; //increase time by one hour so we don't query same batch over and over
            }
            curIndex += bSize;
        }

        def messages = ["No. of Applications Process Requests: " + numAppProcReqs] as String[];
        printStepInfo(startTime, "Get Application Process Requests Start", messages);

    }

    int numCPR = 0;
    long startTime;

    // get a list of all components and then one by one check if they have recent CPRs associated with them.
    def getComponents() {

        printToLogFile("Starting getComponents");
        numItems = 0;
        def compList = deployHelper.getComponents();
        for (comp in compList){
            String comp_id = comp.id;
            comp_id = comp_id.replaceAll("\"", "");
            compMap.put(comp_id, comp) // used to add component info to versions
            getComponentProcessRequests(comp_id, lastExecutionTime, batchSize);
            numItems++;
        }

        def messages = ["No. of Components: " + numItems] as String[];
        printStepInfo(startTime, "Get Components", messages);

    }

    def compProcReqsJsonArray;
    def compProcReqs;
    def children;
    long latestCPRSubTime;
    int numCompProcReqs;
    JsonObject compProcReq;

    // given a component ID, a time and a batchsize, retry retrieving a batch of CPRs that failed previously
    def getCPRSubset(compId, time, bSize) {

        String status = "";
        String state = "";
        String missedId = "";

        compProcReqsJsonArray = deployHelper.getComponentProcessRequests(time, compId, bSize);
        compProcReqs = [];

        for (je in compProcReqsJsonArray) {

            status = je.get("status");
            state = je.get("state");
            if (status != null) {
                status = status.replaceAll("\"", "");
            }
            if (state != null) {
                state = state.replaceAll("\"", "");
            }

            if (state != "CLOSED"){
                if (status != "CANCELLED") {
                    missedId = je.get("id");
                    missedId = missedId.replaceAll("\"", "");
                    sendCPRCallbackProps(missedId);
                }
            }

            // Create the component process requests json object
            compProcReq = new JsonObject();
            compProcReq.add("application", cprHelper.processApplication(je));
            compProcReq.add("environment", cprHelper.processEnvironment(je));
            compProcReq.add("component", cprHelper.processComponent(je));
            compProcReq.add("componetProcess", cprHelper.processComponentProcess(je));

            if (je.has("rootTrace")){
                rootTrace = je.get("rootTrace");
                if (rootTrace instanceof JsonPrimitive){
                    // Do nothing!
                } else {
                    compProcReq.add("workflow", cprHelper.processWorkflow(rootTrace));
                    if (rootTrace.has("children")) {
                        children = rootTrace.get("children");
                        compProcReq.add("commands", cprHelper.processCommands(children));
                    }
                }
            }

            compProcReq = cprHelper.processCPR(je, compProcReq);
            compProcReqs.add(compProcReq);

        }

        if (compProcReqs.size() != 0) {

            //printToLogFile(compProcReqs.get(0).toString());
            def success = cloudHelper.sendComponentProcessRequests(compProcReqs.toString());
            if (!success) {
                mesg = "ERROR: Unable to send Component Process Requests for Component " + compId + " for the second time!";
                    printToLogFile(mesg);
                } else {
                    mesg = "Sent Component Process Requests for Component " + compId + " on the second attempt.";
                    printToLogFile(mesg);
                }
            } else {
                mesg = "ERROR: Unable to retrieve new Component Process Requests for Component: " + compId + " for the second time!";
                printToLogFile(mesg);
            }

    }

    //Get the json of all the component process requests and send them on
    def getComponentProcessRequests(compId, time, bSize) {

        startTime = System.currentTimeMillis();
        method = "getComponentProcessRequests";
        printToLogFile("Starting getComponentProcessRequests");

        numCompProcReqs = deployHelper.getComponentProcessRequestsCount(time, compId);
        latestCPRSubTime = time;
        curIndex = 0;
        numCPR += numCompProcReqs;

        JsonObject failedCPR;
        String status = "";
        String state = "";
        String missedId = "";

        while (curIndex < numCompProcReqs){

            compProcReqsJsonArray = deployHelper.getComponentProcessRequests(latestCPRSubTime, compId, bSize);
            compProcReqs = [];

            if (compProcReqsJsonArray.size() == 0) {

                printToLogFile("Failed to get back a proper set of CPRs, sending info to try again at a later run.");

                failedCPR = new JsonObject();
                failedCPR.addProperty("comp_id", compId.toString());
                failedCPR.addProperty("submitted_time", latestCPRSubTime.toString());
                failedCPR.addProperty("batch_size", bSize.toString());

                printToLogFile(failedCPR.toString());

                cloudHelper.sendFailedCPRInfo(failedCPR.toString());

            }

            // Iterate through the component process requests
            for (je in compProcReqsJsonArray) {

                status = je.get("status");
                state = je.get("state");
                if (status != null) {
                    status = status.replaceAll("\"", "");
                }
                if (state != null) {
                    state = state.replaceAll("\"", "");
                }

                if (state != "CLOSED"){
                    if (status != "CANCELLED") {
                        missedId = je.get("id");
                        missedId = missedId.replaceAll("\"", "");
                        sendCPRCallbackProps(missedId);
                    }
                }

                // Create the component process requests json object
                compProcReq = new JsonObject();
                compProcReq.add("application", cprHelper.processApplication(je));
                compProcReq.add("environment", cprHelper.processEnvironment(je));
                compProcReq.add("component", cprHelper.processComponent(je));
                compProcReq.add("componetProcess", cprHelper.processComponentProcess(je));

                if (je.has("rootTrace")){
                    rootTrace = je.get("rootTrace");
                    if (rootTrace instanceof JsonPrimitive){
                        // Do nothing!
                    } else {
                        compProcReq.add("workflow", cprHelper.processWorkflow(rootTrace));
                        if (rootTrace.has("children")) {
                            children = rootTrace.get("children");
                            compProcReq.add("commands", cprHelper.processCommands(children));
                        }
                    }
                }

                compProcReq = cprHelper.processCPR(je, compProcReq);
                compProcReqs.add(compProcReq);

            }

            if (compProcReqs.size() != 0) {
                // Updating the "floor" for the latest submitted time
                latestCPRSubTime = compProcReq.get("submitted_time").toString().replaceAll("\"", "").toLong();

                //printToLogFile(compProcReqs.get(0).toString());
                def success = cloudHelper.sendComponentProcessRequests(compProcReqs.toString());
                if (!success) {
                    mesg = "ERROR: Unable to send Component Process Requests for Component " + compId + " numbers " +
                        curIndex + " through " + (curIndex + bSize);
                    printToLogFile(mesg);
                } else {
                    mesg = "Sent Component Process Requests for Component " + compId + " numbers " +
                        curIndex + " through " + (curIndex + bSize);
                    printToLogFile(mesg);
                }
            } else {
                mesg = "ERROR: Unable to retrieve new Component Process Requests for Component: " + compId + " numbers " +
                     curIndex + " through " + (curIndex + bSize);
                printToLogFile(mesg);
            }
            curIndex += bSize;
        }
    }

    //Print logs
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    // Helper function to print out statements to a log file. If no log file exists, just print to std out.
    def printToLogFile(statement) {
        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        if (logFile != null) {
            logFile << "[" + timestamp.format(now) + "]: " + statement + "\n";
        } else {
            println "[" + timestamp.format(now) + "]: " + statement;
        }
    }

    def configureSSL(baseUrl) {
        //SSL Strategy
        def sslFactory;
        def url = baseUrl;

        try {
            //We need to allow self signed certificates
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };

            sslFactory = new SSLSocketFactory(acceptingTrustStrategy,
                //allow all host names since the installer creates a certificat for localhost but for sure the
                //customer will use his own domain name with that certificate
                SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

            requestSpecification = given().config(RestAssured.config().sslConfig(SSLConfig.sslConfig().sslSocketFactory(sslFactory)));

            URL serverUrl = new URL(url);

            //If the protocol is https and no port is provided explicitly we need to default to 443
            if (serverUrl.getProtocol().equals("https")) {
                if (serverUrl.getPort() == -1) {
                    requestSpecification = given().port(443);
                }
            }

        } catch (Exception ex) {
            printLog("ERROR", "Can not apply SSL strategy "+ ex);
        }
    }

    //--------------------------------------------------------------
    //Print step info
    def printStepInfo(startTime, stepDisplayName, messages) {
        printLog("TRACE", "--- " + stepDisplayName +" ---");
        if(messages !=  null) {
            messages.each{ message -> printLog("INFO", message) };
        }

        def duration = (int)((System.currentTimeMillis() - startTime) / 1000); //

        if(duration < 1) {
            duration = "<1"
        }

        printLog("INFO", "Step completed in " + duration + " sec");
    }

}
