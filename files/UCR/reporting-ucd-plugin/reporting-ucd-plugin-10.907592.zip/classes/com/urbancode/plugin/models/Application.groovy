package com.urbancode.plugin.models

public class Application {
    def id;
    def sec_res_id;
    def name;
    def description;
    def created;
    def enforce_complete_snapshots;
    def active;
    def tags;
    def deleted;
    def user;
    def type;
}
