package com.urbancode.plugin.models

import com.google.gson.annotations.SerializedName;

public class Inventory{
    @SerializedName("environmentId")
    def environment_id;
    @SerializedName("componentId")
    def component_id;
    @SerializedName("versionId")
    def version_id;
    @SerializedName("snapshotId")
    def snapshot_id;
    def application_id;
}
