package com.urbancode.plugin;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;

import java.text.SimpleDateFormat;

public class ComponentProcessRequestSerializer {

    public ComponentProcessRequestSerializer(){}

    public processApplication(cpr) {

        JsonObject application = new JsonObject();

        String app_id = cpr["application"].id;
        String app_sec_id = cpr["application"].securityResourceId;
        String app_name = cpr["application"].name;
        String app_desc = cpr["application"].description;
        String app_active = cpr["application"].active;

        app_id = removeQuotes(app_id);
        app_sec_id = removeQuotes(app_sec_id);
        app_name = removeQuotes(app_name);
        app_desc = removeQuotes(app_desc);
        app_active = removeQuotes(app_active);

        application.addProperty("app_id", app_id);
        application.addProperty("app_sec_id", app_sec_id);
        application.addProperty("app_name", app_name);
        application.addProperty("app_desc", app_desc);
        application.addProperty("app_active", app_active);

        return application;

    }

    public processEnvironment(cpr) {

        JsonObject environment = new JsonObject();

        String env_id = cpr["environment"].id;
        String env_name = cpr["environment"].name;
        String env_sec_id = cpr["environment"].securityResourceId;
        String env_desc = cpr["environment"].description;
        String env_active = cpr["environment"].active;
        String env_deleted = cpr["environment"].deleted;

        env_id = removeQuotes(env_id);
        env_name = removeQuotes(env_name);
        env_sec_id = removeQuotes(env_sec_id);
        env_desc = removeQuotes(env_desc);
        env_active = removeQuotes(env_active);
        env_deleted = removeQuotes(env_deleted);

        environment.addProperty("env_id", env_id);
        environment.addProperty("env_name", env_name);
        environment.addProperty("env_sec_id", env_sec_id);
        environment.addProperty("env_desc", env_desc);
        environment.addProperty("env_active", env_active);
        environment.addProperty("env_deleted", env_deleted);

        return environment;

    }

    public processComponent(cpr) {

        JsonObject comp = new JsonObject();

        String comp_id = cpr["component"].id;
        String comp_sec_res_id = cpr["component"].securityResourceId;
        String comp_name = cpr["component"].name;
        String comp_desc = cpr["component"].description;
        String comp_created = cpr["component"].created;

        comp_id = removeQuotes(comp_id);
        comp_sec_res_id = removeQuotes(comp_sec_res_id);
        comp_name = removeQuotes(comp_name);
        comp_desc = removeQuotes(comp_desc);
        comp_created = removeQuotes(comp_created);

        comp.addProperty("comp_id", comp_id);
        comp.addProperty("comp_sec_res_id", comp_sec_res_id);
        comp.addProperty("comp_name", comp_name);
        comp.addProperty("comp_desc", comp_desc);
        comp.addProperty("comp_created", comp_created);

        return comp;

    }

    public processComponentProcess(cpr) {

        JsonObject compProc = new JsonObject();

        String comp_proc_id = cpr["componentProcess"].id;
        String comp_proc_name = cpr["componentProcess"].name;
        String comp_proc_desc = cpr["componentProcess"].description;
        String comp_proc_active = cpr["componentProcess"].active;
        String comp_proc_version = cpr["componentProcess"].version;
        String comp_proc_version_count = cpr["componentProcess"].versionCount;
        String comp_proc_path = cpr["componentProcess"].path;

        comp_proc_id = removeQuotes(comp_proc_id);
        comp_proc_name = removeQuotes(comp_proc_name);
        comp_proc_desc = removeQuotes(comp_proc_desc);
        comp_proc_active = removeQuotes(comp_proc_active);
        comp_proc_version = removeQuotes(comp_proc_version);
        comp_proc_version_count = removeQuotes(comp_proc_version_count);
        comp_proc_path = removeQuotes(comp_proc_path);

        compProc.addProperty("comp_proc_id", comp_proc_id);
        compProc.addProperty("comp_proc_name", comp_proc_name);
        compProc.addProperty("comp_proc_desc", comp_proc_desc);
        compProc.addProperty("comp_proc_active", comp_proc_active);
        compProc.addProperty("comp_proc_version", comp_proc_version);
        compProc.addProperty("comp_proc_version_count", comp_proc_version_count);
        compProc.addProperty("comp_proc_path", comp_proc_path);

        return compProc;

    }

    public processWorkflow(wf) {

        JsonObject workflow = new JsonObject();

        String wf_id = wf.id;
        String wf_name = wf.name;
        String wf_state = wf.state;
        String wf_result = wf.result;
        String wf_start_date = wf.startDate;
        String wf_end_date = wf.endDate;
        String wf_duration = wf.duration;
        String wf_trace_id = wf.workflowTraceId;

        wf_id = removeQuotes(wf_id);
        wf_name = removeQuotes(wf_name);
        wf_state = removeQuotes(wf_state);
        wf_result = removeQuotes(wf_result);
        wf_start_date = removeQuotes(wf_start_date);
        wf_end_date = removeQuotes(wf_end_date);
        wf_duration = removeQuotes(wf_duration);
        wf_trace_id = removeQuotes(wf_trace_id);

        workflow.addProperty("wf_id", wf_id);
        workflow.addProperty("wf_name", wf_name);
        workflow.addProperty("wf_state", wf_state);
        workflow.addProperty("wf_result", wf_result);
        workflow.addProperty("wf_start_date", wf_start_date);
        workflow.addProperty("wf_end_date", wf_end_date);
        workflow.addProperty("wf_duration", wf_duration);
        workflow.addProperty("wf_trace_id", wf_trace_id);

        return workflow;

    }

    public processCommands(commands){

        JsonArray array = new JsonArray();

        for (command in commands) {

            JsonObject cmd = new JsonObject();

            String cmd_id = command.id;
            String cmd_name = command.name;
            String cmd_state = command.state;
            String cmd_result = command.result;
            String cmd_start_date = command.startDate;
            String cmd_end_date = command.endDate;
            String cmd_duration = command.duration;

            cmd_id = removeQuotes(cmd_id);
            cmd_name = removeQuotes(cmd_name);
            cmd_state = removeQuotes(cmd_state);
            cmd_result = removeQuotes(cmd_result);
            cmd_start_date = removeQuotes(cmd_start_date);
            cmd_end_date = removeQuotes(cmd_end_date);
            cmd_duration = removeQuotes(cmd_duration);

            cmd.addProperty("cmd_id", cmd_id);
            cmd.addProperty("cmd_name", cmd_name);
            cmd.addProperty("cmd_state", cmd_state);
            cmd.addProperty("cmd_result", cmd_result);
            cmd.addProperty("cmd_start_date", cmd_start_date);
            cmd.addProperty("cmd_end_date", cmd_end_date);
            cmd.addProperty("cmd_duration", cmd_duration);

            if (command.has("command")) {

                def com = command["command"];
                if (com.has("plugin")) {

                    String plugin_id = com["plugin"].id;
                    String plugin_name = com["plugin"].name;
                    String plugin_version = com["plugin"].version;

                    plugin_id = removeQuotes(plugin_id);
                    plugin_name = removeQuotes(plugin_name);
                    plugin_version = removeQuotes(plugin_version);

                    cmd.addProperty("plugin_id", plugin_id);
                    cmd.addProperty("plugin_name", plugin_name);
                    cmd.addProperty("plugin_version", plugin_version);

                }

            }

            if (command.has("fault")) {

                String error = command.error;
                String message = command.get("fault").message;
                String type = command.get("fault").type;
                String trace = command.get("fault").trace;

                error = removeQuotes(error);
                message = removeQuotes(message);
                type = removeQuotes(type);
                trace = removeQuotes(trace);

                cmd.addProperty("error", error);
                cmd.addProperty("message", message);
                cmd.addProperty("type", type);
                cmd.addProperty("trace", trace);

            }

            array.add(cmd);

        }

        return array;

    }

    public processCPR(je, compProcReq){

        String process_id = je.id;
        String user_name = je.userName;
        String submitted_time = je.submittedTime;
        String paused = je.paused;
        String trace_id = je.traceId;
        String parent_req_id = je.parentRequestId;
        String dep_req_id = je.deploymentRequestId;

        process_id = removeQuotes(process_id);
        user_name = removeQuotes(user_name);
        submitted_time = removeQuotes(submitted_time);
        paused = removeQuotes(paused);
        trace_id = removeQuotes(trace_id);
        parent_req_id = removeQuotes(parent_req_id);
        dep_req_id = removeQuotes(dep_req_id);

        compProcReq.addProperty("process_id", process_id);
        compProcReq.addProperty("user_name", user_name);
        compProcReq.addProperty("submitted_time", submitted_time);
        compProcReq.addProperty("paused", paused);
        compProcReq.addProperty("trace_id", trace_id);
        compProcReq.addProperty("parent_req_id", parent_req_id);
        compProcReq.addProperty("dep_req_id", dep_req_id);

        if (je.has("version")) {

            String version_id = je["version"].id;
            String version_name = je["version"].name;

            version_id = removeQuotes(version_id);
            version_name = removeQuotes(version_name);

            compProcReq.addProperty("version_id", version_id);
            compProcReq.addProperty("version_name", version_name);

        }

        return compProcReq;

    }

    public removeQuotes(string) {

        string = (string == null) ? "" : string.replaceAll("\"", "");
        return string;

    }

    def printToLogFile(statement) {
        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        def logFile = new File(System.getProperty("user.home") + "/.ibm/cloud-sync/plugins/logs/reporting-ucd-plugin.log");

        if (logFile != null) {
            logFile << "[" + timestamp.format(now) + "]: " + statement + "\n";
        } else {
            println "[" + timestamp.format(now) + "]: " + statement;
        }
    }

}
