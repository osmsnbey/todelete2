package com.urbancode.plugin;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;

public class TeamSerializer {

    public TeamSerializer(){}

    public JsonObject processUser(roleMapping, role) {

        String userName = role["user"].name;
        String userId = role["user"].id;
        String userDeleted = role["user"].deleted;
        String userEmail = role["user"].email;

        userEmail = (userEmail == null) ? "" : userEmail.replaceAll("\"", "");

        roleMapping.addProperty("user_name", userName.replaceAll("\"", ""));
        roleMapping.addProperty("user_id", userId.replaceAll("\"", ""));
        roleMapping.addProperty("user_deleted", userDeleted.replaceAll("\"", ""));
        roleMapping.addProperty("user_email", userEmail.replaceAll("\"", ""));

        return roleMapping;

    }

    public JsonObject processGroup(roleMapping, role, deployHelper) {

        String groupName = role["group"].name;
        String groupId = role["group"].id;
        String groupEnabled = role["group"].enabled;

        roleMapping.addProperty("group_name", groupName.replaceAll("\"", ""));
        roleMapping.addProperty("group_id", groupId.replaceAll("\"", ""));
        roleMapping.addProperty("group_enabled", groupEnabled.replaceAll("\"", ""));

        groupName = groupName.replaceAll("\"", "");
        groupName = escapeChars(groupName);
        groupId = groupId.replaceAll("\"", "");

        JsonArray groupUsersArray = new JsonArray();
        JsonArray tempArray = new JsonArray();
        tempArray = deployHelper.getGroupInfo(groupName, groupId);

        for (user in tempArray){

            JsonObject groupUser = new JsonObject();
            String uName = user.userName;
            String uId = user.userId;
            String uEmail = user.userEmail;

            uName = uName.replaceAll("\"", "");
            uId = uId.replaceAll("\"", "");

            uEmail = (uEmail == null) ? "" : uEmail.replaceAll("\"", "");

            groupUser.addProperty("user_name", uName);
            groupUser.addProperty("user_id", uId);
            groupUser.addProperty("user_email", uEmail);

            groupUsersArray.add(groupUser);

        }

        roleMapping.add("user_mappings", groupUsersArray);
        return roleMapping;

    }

    public escapeChars(name) {

        name = name.replaceAll(" ", "%20");
        //name = name.replaceAll("\"", "%22");
        name = name.replaceAll("#", "%23");
        //name = name.replaceAll("%", "%25");
        name = name.replaceAll("&", "%26");
        name = name.replaceAll("\'", "%27");
        name = name.replaceAll(",", "%2C");
        name = name.replaceAll("@", "%40");
        name = name.replaceAll("`", "%60");
        name = name.replaceAll("/", "%2F");
        name = name.replaceAll(":", "%3A");
        name = name.replaceAll(";", "%3B");
        name = name.replaceAll("<", "%3C");
        name = name.replaceAll("=", "%3D");
        name = name.replaceAll(">", "%3E");
        name = name.replaceAll("~", "%7E");

        return name;

    }

    public JsonObject processRole(roleMapping, role) {

        String roleName = role["role"].name;
        String roleId= role["role"].id;
        String roleDel= role["role"].isDeletable;

        roleMapping.addProperty("role_name", roleName.replaceAll("\"", ""));
        roleMapping.addProperty("role_id", roleId.replaceAll("\"", ""));
        roleMapping.addProperty("role_deletable", roleDel.replaceAll("\"", ""));

        if(role["role"].has("description")) {
            String roleDesc = role["role"].description;
            roleMapping.addProperty("role_description", roleDesc.replaceAll("\"", ""));
        }

        return roleMapping;

    }

    public JsonObject processApp(app) {

        JsonObject application = new JsonObject();

        String app_name = app["resource"].name;
        String app_id = app["resource"].id;

        application.addProperty("app_name", app_name.replaceAll("\"", ""));
        application.addProperty("sec_res_id", app_id.replaceAll("\"", ""));

        JsonArray resourceRoles = new JsonArray();

        for (resRole in app.get("resourceRoles")) {

            if (!resRole.equals(new JsonNull())) {

                JsonObject resourceRole = new JsonObject();

                String res_name = resRole.name;
                String res_id = resRole.id;
                String res_desc = resRole.description;

                resourceRole.addProperty("res_name", res_name.replaceAll("\"", ""));
                resourceRole.addProperty("res_id", res_id.replaceAll("\"", ""));
                resourceRole.addProperty("res_desc", res_desc.replaceAll("\"", ""));

                resourceRoles.add(resourceRole);

            }

        }

        application.add("resource_roles", resourceRoles);

        return application;

    }

    public JsonObject processEnv(env) {

        JsonObject environment = new JsonObject();
        String env_name = env["resource"].name;
        String env_id = env["resource"].id;

        environment.addProperty("env_name", env_name.replaceAll("\"", ""));
        environment.addProperty("sec_res_id", env_id.replaceAll("\"", ""));

        JsonArray resourceRoles = new JsonArray();

        for (resRole in env.get("resourceRoles")) {
            if (!resRole.equals(new JsonNull())) {
                if(resRole.name != null) {
                    JsonObject resourceRole = new JsonObject();

                    String res_name = resRole.name;
                    String res_id = resRole.id;
                    String res_desc = resRole.description;

                    resourceRole.addProperty("res_name", res_name.replaceAll("\"", ""));
                    resourceRole.addProperty("res_id", res_id.replaceAll("\"", ""));
                    if (res_desc != null) {
                        resourceRole.addProperty("res_desc", res_desc.replaceAll("\"", ""));
                    } else {
                        resourceRole.addProperty("res_desc", "");
                    }

                    resourceRoles.add(resourceRole);
                }
            }
        }

        environment.add("resource_roles", resourceRoles);
        return environment;

    }

    public JsonObject processProc(proc) {

        JsonObject process = new JsonObject();

        String proc_name = proc["resource"].name;
        String proc_id = proc["resource"].id;

        process.addProperty("proc_name", proc_name.replaceAll("\"", ""));
        process.addProperty("sec_res_id", proc_id.replaceAll("\"", ""));

        JsonArray resourceRoles = new JsonArray();

        for (resRole in proc.get("resourceRoles")) {

            if (!resRole.equals(new JsonNull())) {

                JsonObject resourceRole = new JsonObject();

                String res_name = resRole.name;
                String res_id = resRole.id;
                String res_desc = resRole.description;

                res_desc = (res_desc == null) ? "" : res_desc.replaceAll("\"", "");

                resourceRole.addProperty("res_name", res_name.replaceAll("\"", ""));
                resourceRole.addProperty("res_id", res_id.replaceAll("\"", ""));
                resourceRole.addProperty("res_desc", res_desc);

                resourceRoles.add(resourceRole);

            }

        }

        process.add("resource_roles", resourceRoles);
        return process;

    }

}
