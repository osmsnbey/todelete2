package com.urbancode.plugin;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;

import java.text.SimpleDateFormat;

public class ApplicationProcessRequestSerializer {

    public ApplicationProcessRequestSerializer(){}

    public processApplication(apr) {

        JsonObject application = new JsonObject();

        String app_id = apr["application"].id;
        String app_sec_id = apr["application"].securityResourceId;
        String app_name = apr["application"].name;
        String app_desc = apr["application"].description;
        String app_active = apr["application"].active;

        app_id = removeQuotes(app_id);
        app_sec_id = removeQuotes(app_sec_id);
        app_name = removeQuotes(app_name);
        app_desc = removeQuotes(app_desc);
        app_active = removeQuotes(app_active);

        application.addProperty("app_id", app_id);
        application.addProperty("app_sec_id", app_sec_id);
        application.addProperty("app_name", app_name);
        application.addProperty("app_desc", app_desc);
        application.addProperty("app_active", app_active);

        return application;

    }

    public processEnvironment(apr) {

        JsonObject environment = new JsonObject();

        String env_id = apr["environment"].id;
        String env_name = apr["environment"].name;
        String env_sec_id = apr["environment"].securityResourceId;
        String env_desc = apr["environment"].description;
        String env_active = apr["environment"].active;
        String env_deleted = apr["environment"].deleted;

        env_id = removeQuotes(env_id);
        env_name = removeQuotes(env_name);
        env_sec_id = removeQuotes(env_sec_id);
        env_desc = removeQuotes(env_desc);
        env_active = removeQuotes(env_active);
        env_deleted = removeQuotes(env_deleted);

        environment.addProperty("env_id", env_id);
        environment.addProperty("env_name", env_name);
        environment.addProperty("env_sec_id", env_sec_id);
        environment.addProperty("env_desc", env_desc);
        environment.addProperty("env_active", env_active);
        environment.addProperty("env_deleted", env_deleted);

        return environment;

    }

    public processApproval(apr) {

        JsonObject approval = new JsonObject();

        String completed_by = "";
        String completed_time = "";
        JsonArray children = new JsonArray();
        JsonObject childJson;
        String type;
        String display_name;
        String role_id;
        String role_name;
        String finished = apr.finished;
        String failed = apr.failed;
        String cancelled = apr.cancelled;
        String state;
        String result;
        String duration;

        for (child in apr.get("activity").get("children")) {

            childJson = new JsonObject();
            role_id = "";
            role_name = "";
            duration = "";
            completed_by = "";
            completed_time = "";

            if (child.has("task")) {

                role_id = child.get("task").roleId;
                role_name = child.get("task").roleName;

                role_id = removeQuotes(role_id);
                role_name = removeQuotes(role_name);

                childJson.addProperty("role_id", role_id);
                childJson.addProperty("role_name", role_name);

                if (child.get("task").has("completedBy")) {
                    completed_by = child.get("task").completedBy;
                    completed_time = child.get("task").completedOn;
                    completed_by = removeQuotes(completed_by);
                    completed_time = removeQuotes(completed_time);
                    childJson.addProperty("completed_by", completed_by);
                    childJson.addProperty("completed_time", completed_time);
                }

            }

            type = child.type;
            display_name = child.displayName;
            state = child.state;
            result = child.result;

            type = removeQuotes(type);
            display_name = removeQuotes(display_name);
            state = removeQuotes(state);
            result = removeQuotes(result);


            if (state != "INITIALIZED") {
                duration = child.duration;
                duration = removeQuotes(duration);
            }

            childJson.addProperty("type", type);
            childJson.addProperty("display_name", display_name);
            childJson.addProperty("state", state);
            childJson.addProperty("result", result);
            childJson.addProperty("duration", duration);

            children.add(childJson);

        }

        String approval_id = apr.id;
        String approval_name = apr.name;
        String start_time = apr.startDate;
        state = apr.get("activity").state;
        result = apr.get("activity").result;

        approval_id = removeQuotes(approval_id);
        approval_name = removeQuotes(approval_name);
        start_time = removeQuotes(start_time);
        result = removeQuotes(result);
        state = removeQuotes(state);

        approval.addProperty("approval_id", approval_id);
        approval.addProperty("approval_name", approval_name);
        approval.addProperty("start_time", start_time);
        approval.addProperty("result", result);
        approval.addProperty("state", state);
        approval.add("approval_steps", children);

        return approval;

    }

    public processComponents(apr) {

        JsonObject component = new JsonObject();
        JsonArray flow = new JsonArray();
        if (apr.has("children")) {
            flow = apr["children"];
        } else {
            printToLogFile("Application Process Request did not have any children");
        }

        JsonArray components = new JsonArray();
        for (child in flow){
            components.add(processChildren(child));
        }

        return components;

    }

    public processChildren(children){

        for (child in children){
            if (child.has("children") ){
                return processChildren(child.get("children"));
            } else {
                return processComponent(child);
            }
        }

    }

    public processComponent(comp) {

        JsonObject compJson = new JsonObject();

        String child_id = comp["id"];
        String state = comp["state"];
        String result = comp["result"];
        String duration = comp["duration"];
        String start_date = comp["startDate"];
        String end_date = comp["endDate"];

        child_id = removeQuotes(child_id);
        state = removeQuotes(state);
        result = removeQuotes(result);
        duration = removeQuotes(duration);
        start_date = removeQuotes(start_date);
        end_date = removeQuotes(end_date);

        compJson.addProperty("child_id", child_id);
        compJson.addProperty("state", state);
        compJson.addProperty("result", result);
        compJson.addProperty("duration", duration);
        compJson.addProperty("start_date", start_date);
        compJson.addProperty("end_date", end_date);

        if (comp.has("componentProcess")) {

            String comp_proc_id = comp["componentProcess"].id;
            String name = comp["componentProcess"].name;
            String version_count = comp["componentProcess"].versionCount;
            String version = comp["componentProcess"].version;

            comp_proc_id = removeQuotes(comp_proc_id);
            name = removeQuotes(name);
            version_count = removeQuotes(version_count);
            version = removeQuotes(version);

            compJson.addProperty("comp_proc_id", comp_proc_id);
            compJson.addProperty("comp_proc_name", name);
            compJson.addProperty("comp_proc_version_count", version_count);
            compJson.addProperty("comp_proc_version", version);

        }

        if (comp.has("version")) {

            String comp_ver_id = comp["version"].id;
            String comp_ver_name = comp["version"].name;

            comp_ver_id = removeQuotes(comp_ver_id);
            comp_ver_name = removeQuotes(comp_ver_name);

            compJson.addProperty("comp_ver_id", comp_ver_id)
            compJson.addProperty("comp_ver_name", comp_ver_name);

        }

        if (comp.has("component")) {

            String comp_id = comp["component"].id;
            String comp_name = comp["component"].name;
            String comp_sec_id = comp["component"].securityResourceId;
            String comp_created = comp["component"].created;

            comp_id = removeQuotes(comp_id);
            comp_name = removeQuotes(comp_name);
            comp_sec_id = removeQuotes(comp_sec_id);
            comp_created = removeQuotes(comp_created);

            compJson.addProperty("comp_id", comp_id);
            compJson.addProperty("comp_name", comp_name);
            compJson.addProperty("comp_sec_id", comp_sec_id);
            compJson.addProperty("comp_created", comp_created);

        }

        if (comp.has("resource")) {

            String comp_id = comp["resource"].id;
            String comp_name = comp["resource"].name;
            String comp_sec_id = comp["resource"].securityResourceId;
            String comp_created = comp["resource"].created;

            comp_id = removeQuotes(comp_id);
            comp_name = removeQuotes(comp_name);
            comp_sec_id = removeQuotes(comp_sec_id);

            compJson.addProperty("comp_id", comp_id);
            compJson.addProperty("comp_name", comp_name);
            compJson.addProperty("comp_sec_id", comp_sec_id);

        }

        if (comp.has("fault")) {

            String fault_mes = comp["fault"].message;
            String fault_type = comp["fault"].type;
            String fault_trace = comp["fault"].trace;

            fault_mes = removeQuotes(fault_mes);
            fault_type = removeQuotes(fault_type);
            fault_trace = removeQuotes(fault_trace);

            compJson.addProperty("fault_mes", fault_mes);
            compJson.addProperty("fault_type", fault_type);
            compJson.addProperty("fault_trace", fault_trace);

        }

        return compJson;

    }

    public processApplicationProcess(je){

        JsonObject appProc = new JsonObject();

        String proc_id = je["applicationProcess"].id;
        String proc_name = je["applicationProcess"].name;
        String proc_desc = je["applicationProcess"].description;
        String proc_version = je["applicationProcess"].version;

        proc_id = removeQuotes(proc_id);
        proc_name = removeQuotes(proc_name);
        proc_desc = removeQuotes(proc_desc);
        proc_version = removeQuotes(proc_version);

        appProc.addProperty("process_id", proc_id);
        appProc.addProperty("process_name", proc_name);
        appProc.addProperty("process_desc", proc_desc);
        appProc.addProperty("process_version", proc_version);

        return appProc;

    }

    public processAPR(je, appProcReq){

        String apr_id = je.id;
        String submitted_time = je.submittedTime;
        String trace_id = je.traceId;
        String user_name = je.userName;
        String desc = je.desc;
        String proc_start_time = je.startTime;
        String result = je.result;
        String state = je.state;
        String status = je.status;
        String paused = je.paused;
        String proc_end_time = je.endTime;
        String duration = je.duration;
        String process_name = je["applicationProcess"].name;

        apr_id = removeQuotes(apr_id);
        submitted_time = removeQuotes(submitted_time);
        trace_id = removeQuotes(trace_id);
        user_name = removeQuotes(user_name);
        desc = removeQuotes(desc);
        proc_start_time = removeQuotes(proc_start_time);
        result = removeQuotes(result);
        state = removeQuotes(state);
        status = removeQuotes(status);
        paused = removeQuotes(paused);
        proc_end_time = removeQuotes(proc_end_time);
        duration = removeQuotes(duration);
        process_name = removeQuotes(process_name);

        appProcReq.addProperty("id", apr_id);
        appProcReq.addProperty("name", process_name);
        appProcReq.addProperty("submitted_time", submitted_time);
        appProcReq.addProperty("trace_id", trace_id);
        appProcReq.addProperty("user_name", user_name);
        appProcReq.addProperty("description", desc);
        appProcReq.addProperty("proc_start_time", proc_start_time);
        appProcReq.addProperty("result", result);
        appProcReq.addProperty("state", state);
        appProcReq.addProperty("status", status);
        appProcReq.addProperty("paused", paused);
        appProcReq.addProperty("proc_end_time", proc_end_time);
        appProcReq.addProperty("duration", duration);

        if (je.has("snapshot")) {

            String snapshot_id = je["snapshot"].id;
            String snapshot_name = je["snapshot"].name;

            snapshot_id = removeQuotes(snapshot_id);
            snapshot_name = removeQuotes(snapshot_name);

            appProcReq.addProperty("snapshot_id", snapshot_id);
            appProcReq.addProperty("snapshot_name", snapshot_name);

        }

        return appProcReq;

    }

    public removeQuotes(string) {

        string = (string == null) ? "" : string.replaceAll("\"", "");
        return string;

    }

    def printToLogFile(statement) {
        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        def logFile = new File(System.getProperty("user.home") + "/.ibm/cloud-sync/plugins/logs/reporting-ucd-plugin.log");

        if (logFile != null) {
            logFile << "[" + timestamp.format(now) + "]: " + statement + "\n";
        } else {
            println "[" + timestamp.format(now) + "]: " + statement;
        }
    }

}
