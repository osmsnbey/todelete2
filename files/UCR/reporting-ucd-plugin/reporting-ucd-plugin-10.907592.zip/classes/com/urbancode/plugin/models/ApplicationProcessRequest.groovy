package com.urbancode.plugin.models

public class ApplicationProcessRequest{
    def name;
    def id;
    def sec_res_id;
    def submitted_time;
    def user_name;
    def description;
    def start_time;
    def result;
    def state;
    def paused;
    def app_id;
    def app_name;
    def env_id;
    def env_name;
    def app_proc_id;
    def app_proc_desc;
    def snapshot_id;
    def snapshot_name;
    def end_time;
    def duration;
}
