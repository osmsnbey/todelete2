package com.urbancode.plugin.models

public class Environment{
    def id;
    def sec_res_id;
    def name;
    def description;
    def require_approvals;
    def no_self_approvals;
    def lock_snapshots;
    def calendar_id;
    def active;
    def deleted;
    def cleanup_days_to_keep;
    def cleanup_count_to_keep;
    def enable_process_history_cleanup;
    def use_system_default_days;
    def history_cleanup_days_to_keep;
    def conditions;
    def application_id;
}
