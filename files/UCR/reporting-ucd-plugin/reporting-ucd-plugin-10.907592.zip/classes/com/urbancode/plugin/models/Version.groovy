package com.urbancode.plugin.models

import com.google.gson.annotations.SerializedName;

public class Version{
    def id;
    def name;
    def type;
    def created;
    def active;
    def archived;
    def size_on_disk;
    def statuses;
    @SerializedName("componentId")
    def component_id;
    def component_name;
    def component_active;
    def component_deleted;
    def lastModified;
}
