package com.urbancode.plugin.models

import com.google.gson.annotations.SerializedName;

public class Snapshot{
    def id;
    def name;
    def description;
    @SerializedName("applicationId")
    def application_id;
    def created;
    @SerializedName("lastModified")
    def last_modified;
    def active;
    def deleted;
}
