package com.urbancode.plugin;

import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder;
import com.urbancode.commons.util.IO;
import com.urbancode.plugin.*;

import org.apache.http.*;
import org.apache.http.auth.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.protocol.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.*;
import org.apache.http.impl.auth.*;
import org.apache.http.impl.client.*;
import org.apache.http.util.*;

import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONArray

public class CheckAppProcess {
    def ucdUrl
    def appProcessId
    def callbackUrl
    def ucdToken

    def processState
    def processResult

    def COMPONENT_INDEX = 0
    def ALERTS_INDEX = 1
    def FAILED_INDEX = 2
    def IN_PROGRESS_INDEX = 3
    def COMPLETED_INDEX = 4

    CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder()
    CloseableHttpClient httpclient

    public CheckAppProcess (ucdUrl, ucdToken, appProcessId, callbackUrl) {
        this.ucdUrl = ucdUrl
        this.ucdToken = ucdToken
        this.appProcessId = appProcessId
        this.callbackUrl = callbackUrl

        builder.setPreemptiveAuthentication(true);
        builder.setUsername("PasswordIsAuthToken");
        builder.setPassword(ucdToken);
        builder.setTrustAllCerts(true);

        httpclient = builder.buildClient();
    }

    public startCheck () {
        try {
            while (this.processState != 'CLOSED') {
                def approvalResult = isPendingApproval()
                def result

                if (!approvalResult) {
                    def appProcessTrace = getAppProcessTrace()
                    result = parseTrace(appProcessTrace)
                } else {
                    if(approvalResult == "AWAITING APPROVAL") {
                        result = generateApprovalResponse(false)
                    } else if(approvalResult == "APPROVAL REJECTED") {
                        result = generateApprovalResponse(true)
                        sendFailureForJob()
                    }
                    
                }

                sendProgress(result)
                sleep(10000);
            }
        }
        finally {
            httpclient.close();
        }
    }

    public shouldConsiderFailuresAsNonfatal () {
        if(this.processState == 'CLOSED' || this.processState == 'CANCELLING' || this.processState == 'COMPENSATING' || this.processState == 'FAULTING') {
            if(this.processResult == 'CANCELED' || this.processResult == 'COMPENSATED' || this.processResult == 'FAULTED' || this.processResult == 'FAILED TO START') {
                return false
            }
        }
        return true
    }

    private isPendingApproval () {
        def content
        def requestUrl = ucdUrl.toString() + "/cli/applicationProcessRequest/requestStatus?request=" + appProcessId;

        HttpGet httpGet = new HttpGet(requestUrl);
        CloseableHttpResponse response = httpclient.execute(httpGet);

        def requestId
        try {
            System.out.println(response.getStatusLine());
            HttpEntity entity = response.getEntity();
            try {
                content = IO.readText(entity.getContent());

                if (response.getStatusLine().getStatusCode() >= 200 && response.getStatusLine().getStatusCode() < 300) {
                    def responseJson = new JSONObject(content);
                }
                else {
                    println content;
                }
            }
            finally {
                EntityUtils.consume(entity);
            }
        }
        finally {
            response.close();
        }

        // DEBUG
        println (new JSONObject(content))

        def jsonResult = new JSONObject(content)

        def result = jsonResult.get("result")
        def status = jsonResult.get("status")

        if(status == "PENDING" && result == "AWAITING APPROVAL") {
            return result
        }

        if(status == "CLOSED" && result == "APPROVAL REJECTED") {
            return result
        }

        return false;
    }

    private getAppProcessTrace () {
        def content
        def requestUrl = ucdUrl.toString() + "/cli/applicationProcessRequest/" + appProcessId;

        HttpGet httpGet = new HttpGet(requestUrl);
        CloseableHttpResponse response = httpclient.execute(httpGet);

        def requestId
        try {
            System.out.println(response.getStatusLine());
            HttpEntity entity = response.getEntity();
            try {
                content = IO.readText(entity.getContent());

                if (response.getStatusLine().getStatusCode() == 200) {
                    def responseJson = new JSONObject(content);
                }
                else {
                    println content;
                }
            }
            finally {
                EntityUtils.consume(entity);
            }
        }
        finally {
            response.close();
        }

        // DEBUG
        //println (new JSONObject(content))

        return new JSONObject(content);
    }


    private getChildTrace (childTraceId) {
        def content
        def requestUrl = ucdUrl.toString() + "/rest/workflow/componentProcessRequestChildren/" + childTraceId;

        HttpGet httpGet = new HttpGet(requestUrl);
        CloseableHttpResponse response = httpclient.execute(httpGet);

        try {
            System.out.println(response.getStatusLine());
            HttpEntity entity = response.getEntity();
            try {
                content = IO.readText(entity.getContent());

                if (response.getStatusLine().getStatusCode() == 200) {
                    def responseJson = new JSONArray(content);
                }
                else {
                    println content;
                }
            }
            finally {
                EntityUtils.consume(entity);
            }
        }
        finally {
            response.close();
        }

        // DEBUG
        //println (new JSONObject(content))

        return new JSONArray(content);
    }

    private sendProgress (body) {
        def checkProgressObj = new JSONObject();
        checkProgressObj.put("type", "CONNECT")
        checkProgressObj.put("stepName", "Check Process Request Progress")
        def propsObj = new JSONObject();
        propsObj.put("applicationProcessRequestId", this.appProcessId)
        checkProgressObj.put("props", propsObj)

        body.put("checkProgress", checkProgressObj)

        URIBuilder progressUriBuilder = new URIBuilder(callbackUrl)
        progressUriBuilder.setPath(progressUriBuilder.getPath() + "/progress")
        def progressRequestUrl = progressUriBuilder.toString();

        HttpPut httpPutProgress = new HttpPut(progressRequestUrl);
        httpPutProgress.setEntity(new StringEntity(body.toString(), ContentType.APPLICATION_JSON));
        CloseableHttpResponse progressResponse = httpclient.execute(httpPutProgress);

        try {
            HttpEntity entity = progressResponse.getEntity();
            try {
                def content = IO.readText(entity.getContent());

                if (progressResponse.getStatusLine().getStatusCode() >= 200 && progressResponse.getStatusLine().getStatusCode() < 300) {
                    println "Progress sent to Continuous Release UI"
                }
                else {
                    println content;
                }
            }
            finally {
                EntityUtils.consume(entity);
            }
        }
        finally {
            progressResponse.close();
        }
    }

    private getActivityJson (id, name, status, startDate, duration, info, nonfatal) {
        return getActivityJson (id, name, status, startDate, duration, info, nonfatal, null, null) 
    }

    private getActivityJson (id, name, status, startDate, duration, info, nonfatal, logLabel, logUrl) {
        def result = new JSONObject();
        result.put('id', id)
        result.put('name', name)
        result.put('status', status)
        result.put('startDate', startDate)
        result.put('duration', duration)
        result.put('info', info)
        result.put('nonfatal', nonfatal)
        result.put('logLabel', logLabel)
        result.put('logUrl', logUrl)

        return result
    }

    private getComponentInfo (childTrace, componentsJson) {
        def componentName
        def componentId
        def versionName
        def versionId
        def processAction
        def status

        // Is this activity a componentProcess?
        if(childTrace.has('type') && childTrace.get('type') == 'componentProcess') {

            // What type of component process? Install? Uninstall? Operational?
            if(childTrace.has('componentProcess') && childTrace.get('componentProcess').has('inventoryActionType')) {
                processAction = 'Operational' 
                if(childTrace.getJSONObject('componentProcess').get('inventoryActionType') == 'ADD') {
                    processAction = 'Install' 
                } else if(childTrace.getJSONObject('componentProcess').get('inventoryActionType') == 'REMOVE') {
                    processAction = 'Uninstall' 
                }
            }

            // What component?
            
            if(childTrace.has('component')) {
                componentName = childTrace.getJSONObject('component').get('name')
                componentId = childTrace.getJSONObject('component').get('id')
            }

            // What Version?
            
            if(childTrace.has('version')) {
                versionName = childTrace.getJSONObject('version').get('name')
                versionId = childTrace.getJSONObject('version').get('id')
            }
            
            def state
            def result

            if(childTrace.has('state')) {
                state = childTrace.get('state')
            }
            
            if(childTrace.has('result')) {
                result = childTrace.get('result')
            }
            
            if(state == 'INITIALIZED') {
                status = 'NOT_STARTED'
            } else if(state == 'EXECUTING') {
                status = 'IN_PROGRESS'
            } else if ( state == 'CLOSED') {
                if (result == 'SUCCEEDED') {
                    status = 'COMPLETE'
                } else if (result == 'CANCELED') {
                    status = 'FAIL'
                } else if (result == 'FAULTED') {
                    status = 'FAIL'
                } else if (result == 'COMPENSATED') {
                    status = 'FAIL'
                } else if (result == 'UNINITIALIZED') {
                    status = 'FAIL'
                }
            }
        }

        // If we know which component, version, and whether or not we are installing or uninstalling then we can report on it
        if(processAction && componentId && versionId) {
            def insertComp = true

            for (int i = 0; i < componentsJson.length(); i++ ) {
                def compJson = componentsJson.getJSONObject(i)

                if(compJson.get('action') == processAction && compJson.get('componentId') == componentId && compJson.get('versionId') == versionId ) {
                    insertComp = false;
                    if(status == 'COMPLETE') {
                        compJson.put('completedCount', compJson.get('completedCount') + 1);
                    } else if (status == 'IN_PROGRESS') {
                        compJson.put('executingCount', compJson.get('executingCount') + 1);
                    } else if (status == 'FAIL') {
                        compJson.put('failedCount', compJson.get('failedCount') + 1);
                    } else if (status == 'NOT_STARTED') {
                        compJson.put('notStartedCount', compJson.get('notStartedCount') + 1);
                    }
                    break;
                }
            }

            if(insertComp) {
                def newComp = new JSONObject();
                newComp.put('action', processAction);
                newComp.put('componentName', componentName);
                newComp.put('componentId', componentId);
                newComp.put('versionId', versionId);
                newComp.put('versionName', versionName);
                
                newComp.put('status', status)

                if(status == 'COMPLETE') {
                    newComp.put('completedCount', 1);
                    newComp.put('executingCount', 0);
                    newComp.put('skippedCount', 0);
                    newComp.put('failedCount', 0);
                    newComp.put('notStartedCount', 0);
                } else if (status == 'IN_PROGRESS') {
                    newComp.put('completedCount', 0);
                    newComp.put('executingCount', 1);
                    newComp.put('skippedCount', 0);
                    newComp.put('failedCount', 0);
                    newComp.put('notStartedCount', 0);
                } else if (status == 'FAIL') {
                    newComp.put('completedCount', 0);
                    newComp.put('executingCount', 0);
                    newComp.put('skippedCount', 0);
                    newComp.put('failedCount', 1);
                    newComp.put('notStartedCount', 0);
                }  else if (status == 'NOT_STARTED') {
                    newComp.put('completedCount', 0);
                    newComp.put('executingCount', 0);
                    newComp.put('skippedCount', 0);
                    newComp.put('failedCount', 0);
                    newComp.put('notStartedCount', 1);
                } else {
                    newComp.put('completedCount', 0);
                    newComp.put('executingCount', 0);
                    newComp.put('skippedCount', 0);
                    newComp.put('failedCount', 0);
                    newComp.put('notStartedCount', 0);
                }

                componentsJson.put(newComp)
            }
        }

        if(childTrace.has('children')) {
            def children = childTrace.getJSONArray('children')
            for(int i = 0; i < children.length(); i++) {
                def child = children.getJSONObject(i);
                getComponentInfo(child, componentsJson)
            }
        }
    }

    private generateComponentDetail(componentArray) {
        def result = new JSONArray()
        
        if(!componentArray) {
            return result
        }
        
        for (int i =0; i < componentArray.length(); i++) {
            def compInfo = componentArray.getJSONObject(i)

            def name = compInfo.get('action') + ' ' + compInfo.get('componentName') + ' (' + compInfo.get('versionName') + ')'

            def info = ''

            def executingCount = compInfo.get('executingCount')
            def failedCount = compInfo.get('failedCount')
            def completedCount = compInfo.get('completedCount')
            def skippedCount = compInfo.get('skippedCount')
            def notStartedCount = compInfo.get('notStartedCount')

            def total = executingCount + failedCount + completedCount + skippedCount + notStartedCount

            info = (completedCount + skippedCount) + '/' + total + ' Resources'

            def status

            if(failedCount > 0) {
                status = 'FAIL'
            } else if (executingCount > 0) {
                status = 'IN_PROGRESS'
            } else if (notStartedCount > 0) {
                if (completedCount > 0) {
                    status = 'IN_PROGRESS'
                } else {
                    status = 'NOT_STARTED'
                }
            } else {
                status = 'COMPLETE'
            }

            result.put(getActivityJson (null, name, status, null, null, info, null))
        }

        return result;
    }

    private parseTrace (trace) {

        if(trace.has("error") && !trace.has("state") && !trace.has("result")) {
            return generateErrorResponse(trace.get("error"))
        }

        def result = new JSONObject()

        def componentsArray = new JSONArray()
        def componentsInfo = new JSONArray()

        def completedArray = new JSONArray()
        def failedArray = new JSONArray()
        def inProgressArray = new JSONArray()
        def alertsArray = new JSONArray()

        if (trace.has("state")) {
            // If it doesn't have state, then we are probably waiting on UCD to actually provide that information.  We are 'Awaiting Progress'

            this.processState = trace.get("state")
            this.processResult = trace.get("result")

            def childrenArray = trace.getJSONArray('children')

            for(int i = 0; i < childrenArray.length(); i++) {
                def child = childrenArray.getJSONObject(i);

                //   'NOT_STARTED': 'NOT_STARTED',
                //   'IN_PROGRESS': 'IN_PROGRESS',
                //   'COMPLETE': 'COMPLETE',
                //   'FAILED': 'FAILED',
                //   'ERROR': 'ERROR'

                def id = child.get('id')
                def name = child.get('displayName')
                def startDate
                if (child.has('startDate')) {
                    startDate = child.get('startDate')
                }
                def duration
                if (child.has('duration')) {
                    duration = child.get('duration')
                }

                getComponentInfo(child, componentsArray)
                componentsInfo = componentsArray

                if(child.get('state') == 'EXECUTING') {
                    inProgressArray.put(getActivityJson(id, name, 'IN_PROGRESS', startDate, duration, '', null))
                } else if(child.get('state') == 'CLOSED') {
                    if (child.get('result') == 'SUCCEEDED') {
                        completedArray.put(getActivityJson(id, name, 'COMPLETE', startDate, duration, '', null))
                    } else if (child.get('result') == 'CANCELED') {
                        if(shouldConsiderFailuresAsNonfatal()) {
                            completedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'This step was cancelled', true))
                        } else {
                            failedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'This step was cancelled', false))
                        }
                    } else if (child.get('result') == 'FAULTED') {
                        if(shouldConsiderFailuresAsNonfatal()) {
                            completedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, '', true))
                        } else {

                            def deepFailures = getDeepFailures('', child, new JSONArray())

                            failedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, '', false))

                            for (int j =0; j < deepFailures.length(); j++) {
                                failedArray.put(deepFailures.getJSONObject(j))
                            }
                        }
                    } else if (child.get('result') == 'COMPENSATED') {
                        if(shouldConsiderFailuresAsNonfatal()) {
                            completedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'Marked as compensated', true))
                        } else {
                            failedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'Marked as compensated', false))
                        }
                    } else if (child.get('result') == 'UNINITIALIZED') {
                        if(shouldConsiderFailuresAsNonfatal()) {
                            completedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'Marked as unitialized', true))
                        } else {
                            failedArray.put(getActivityJson(id, name, 'FAIL', startDate, duration, 'Marked as unitialized', false))
                        }
                    }
                }
            }
        }
        

        result.put('categories', new JSONArray())

        def categories = new JSONArray()
        def completedObj = new JSONObject()
        completedObj.put('label', 'Completed')
        completedObj.put('records', completedArray)
        def failedObj = new JSONObject()
        failedObj.put('label', 'Failed')
        failedObj.put('records', failedArray)
        def inProgressObj = new JSONObject()
        inProgressObj.put('label', 'Executing')
        inProgressObj.put('records', inProgressArray)
        def alertsObj = new JSONObject()
        alertsObj.put('label', 'Alerts')
        alertsObj.put('records', alertsArray)
        def installedComponentsObj = new JSONObject()
        installedComponentsObj.put('label', 'Component Versions')
        def installedComponentsArray = generateComponentDetail(componentsInfo)
        installedComponentsObj.put('records', installedComponentsArray)

        result.categories.put(installedComponentsObj)
        result.categories.put(alertsObj)
        result.categories.put(failedObj)
        result.categories.put(inProgressObj)
        result.categories.put(completedObj)

        def sumState = null
        def sumResult = null
        if (trace.has("state") && trace.has("state")) {
            sumState = trace.get("state")
            sumState = trace.get("result")
        }
        def summary = generateSummaryMessage(componentsInfo, alertsObj, failedObj, inProgressObj, completedObj, sumState, sumResult)
        result.put('summary', summary)

        result.put('defaultTabIndex', getDefaultTabIndex (installedComponentsArray, alertsArray, failedArray, inProgressArray, completedArray) )

        return result
    }

    private generateApprovalResponse (rejected) {
        def message = 'Awaiting approvals for this deployment'
        def status = 'IN_PROGRESS'
        def summary = 'Process is waiting on Approvals, it will not start until approved.'

        if(rejected) {
            message = 'Approvals were rejected'
            status = 'FAIL'
            summary = 'Approvals were rejected.  This process is closed and will not run.'
        }

        return generateAlertResponse(message, status, summary)
    }

    private getDeepFailures (label, child, resultArray) {

        if (!resultArray) {
            resultArray = new JSONArray()
        }

        def name = ''

        if (child.get('type') == 'componentProcess' && child.has('componentProcess')) {
            name = child.getJSONObject('componentProcess').get('name')
        } else if(child.has('displayName')) {
            name = child.get('displayName')
        } else if(child.has('name')) {
            name = child.get('name')
        }

        if(child.has('children')) {
            def children = child.getJSONArray('children')

            for (int i =0; i < children.length(); i++) {
                def childCompProcess = children.get(i)
                resultArray = getDeepFailures(label + name + ' > ', childCompProcess, resultArray)
            }
        } else if(child.has('componentProcessRequestId')) {
            def childrenTrace = getChildTrace(child.get('componentProcessRequestId'))

            for (int i = 0; i < childrenTrace.length(); i++) {
                def step = childrenTrace.get(i)

                def stepName = ''
                if(step.has('displayName')) {
                    stepName = step.get('displayName')
                } else if(step.has('name')) {
                    stepName = step.get('name')
                }

                if(step.get('state') == 'CLOSED' && step.get('result') == 'FAULTED') {
                    if(step.has('workflowTraceId') && step.has('id')) {
                        def stepId = step.get('id')
                        def traceId = step.get('workflowTraceId')
                        def logUrl = (ucdUrl.toString() + "/rest/logView/trace/" + traceId + "/" + stepId + "/stdOut.txt")
                        def recordName = (label + name + ' > ' + stepName)
                        resultArray.put(getActivityJson(stepId, recordName, 'FAIL', step.get('startDate'), step.get('duration'), 'Component Process Step', false, 'Logs', logUrl))
                    }
                }
            }
        }

        return resultArray;
    }

    private generateErrorResponse (errorMessage) {
        def message = errorMessage
        def status = 'FAIL'
        def summary = errorMessage

        return generateAlertResponse(message, status, summary)
    }

    private generateAlertResponse (message, status, summary) {
        def result = new JSONObject()
        result.put('categories', new JSONArray())

        def alertsArray = new JSONArray()
        alertsArray.put(getActivityJson (null, message, status, null, null, null, null))

        def categories = new JSONArray()
        def completedObj = new JSONObject()
        completedObj.put('label', 'Completed')
        completedObj.put('records', new JSONArray())
        def failedObj = new JSONObject()
        failedObj.put('label', 'Failed')
        failedObj.put('records', new JSONArray())
        def inProgressObj = new JSONObject()
        inProgressObj.put('label', 'Executing')
        inProgressObj.put('records', new JSONArray())
        def alertsObj = new JSONObject()
        alertsObj.put('label', 'Alerts')
        alertsObj.put('records', alertsArray)
        def installedComponentsObj = new JSONObject()
        installedComponentsObj.put('label', 'Component Versions')
        installedComponentsObj.put('records', new JSONArray())

        result.categories.put(installedComponentsObj)
        result.categories.put(alertsObj)
        result.categories.put(failedObj)
        result.categories.put(inProgressObj)
        result.categories.put(completedObj)

        result.put('summary', summary)

        result.put('defaultTabIndex', ALERTS_INDEX)

        return result
    }

    private generateSummaryMessage (componentsInfo, alertsObj, failedObj, inProgressObj, completedObj, state, result) {
        def summary = ''
        if ( state == null) {
            return 'Awaiting Progress'
        }


        if(componentsInfo && componentsInfo.length() > 0) {
            def failedVersions = 0
            def completedVersions = 0
            def skippedVersions = 0
            def executingVersions = 0
            def currentlyRunning = ''

            for (int i = 0; i < componentsInfo.length(); i++) {
                def compInfo = componentsInfo.getJSONObject(i)

                def executingCount = compInfo.get('executingCount')
                def failedCount = compInfo.get('failedCount')
                def completedCount = compInfo.get('completedCount')
                def skippedCount = compInfo.get('skippedCount')
                def notStartedCount = compInfo.get('notStartedCount')

                def total = executingCount + failedCount + completedCount + skippedCount + notStartedCount

                if (failedCount > 0) {
                    failedVersions += 1
                } else {
                    if (skippedCount > 0) {
                        skippedVersions += 1
                    }
                    if ((completedCount + skippedCount) == total) {
                        completedVersions += 1
                    } else if (executingCount > 0) {
                        executingVersions += 1
                        currentlyRunning = 'Currently deploying ' + compInfo.get('componentName') + ' (' + compInfo.get('versionName') + ').  '
                    }
                }
            }

            if (failedVersions > 0) {
                summary = summary + failedVersions + ' versions failed to install.  '
            }

            summary = summary + 'Installed ' + completedVersions + '/' + componentsInfo.length() + ' component versions.  '

            if (failedVersions == 0) {
                if (executingVersions == 1) {
                    summary = summary + currentlyRunning
                } else if (executingVersions > 1) {
                    summary = summary + 'Currently deploying ' + executingVersions + ' versions.  '
                }

                if (skippedVersions > 0) {
                    summary = summary + 'Some version deployments were skipped.  '
                }
            }

        } else {
            if (inProgressObj && inProgressObj.getJSONArray('records').length() > 0) {
                summary = 'Running ' + inProgressObj.getJSONArray('records').length() + ' operational task(s), no components installed currently.'
            } else if(state == 'CLOSED') {
                if (result == 'SUCCEEDED') {
                    summary = 'The process completed, but no new components were installed.'
                } else if (result == 'CANCELED') {
                    summary = 'The process was canceled and no new components were installed.'
                } else if (child.get('result') == 'FAULTED') {
                    summary = 'The process failed and no new components were installed.'
                } else if (child.get('result') == 'COMPENSATED') {
                    summary = 'The process marked as COMPENSATED and no new components were installed.'
                } else if (child.get('result') == 'UNINITIALIZED') {
                    summary = 'The process marked as UNITIALIZED and no new components were installed.'
                }
            } else {
                summary = 'No components installed currently.'
            }
        }
        
        return summary
    }

    private sendFailureForJob() {
        def body = new JSONObject();
        body.put("status", "Failure")

        def failRequestUrl = callbackUrl.toString();
        HttpPut httpPutFail = new HttpPut(failRequestUrl);
        httpPutFail.setEntity(new StringEntity(body.toString(), ContentType.APPLICATION_JSON));
        CloseableHttpResponse failResponse = httpclient.execute(httpPutFail);

        try {
            HttpEntity entity = failResponse.getEntity();
            try {
                if (failResponse.getStatusLine().getStatusCode() >= 200 && failResponse.getStatusLine().getStatusCode() < 300) {
                    println "Failed task in CR UI"
                }
            }
            finally {
                EntityUtils.consume(entity);
            }
        }
        finally {
            failResponse.close();
        }
    }

    private getDefaultTabIndex (componentArray, alertsArray, failedArray, inProgressArray, completedArray) {

        if(failedArray.length() > 0) {
            return FAILED_INDEX
        } else if (alertsArray.length() > 0) {
            return ALERTS_INDEX
        } else if (componentArray.length() > 0) {
            return COMPONENT_INDEX
        } else if (inProgressArray.length() > 0) {
            return IN_PROGRESS_INDEX
        } else if (completedArray.length() > 0) {
            return COMPLETED_INDEX
        }

        return 0
    }
}
