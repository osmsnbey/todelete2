package com.urbancode.plugin;

import java.util.Date;
import java.text.SimpleDateFormat;

import com.urbancode.air.*;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.HttpEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;

import com.google.gson.JsonParser;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import java.security.cert.X509Certificate;

import groovy.json.JsonOutput;

import com.urbancode.plugin.models.UcdAuthToken;

public class UCDeployClient {

    private boolean debug = false;

    private File logFile = new File("/tmp/reporting-ucd-plugin.txt");

    private final String APPLICATIONS_ENDPOINT_URL = "rest/release/syncAllApplications?modifiedAfter=";
    private final String APPLICATIONS_COUNT_ENDPOINT_URL = "rest/release/applicationCount?modifiedAfter=";
    private final String APPLICATION_PROCESS_REQUESTS_ENDPOINT_URL = "cli/applicationProcessRequest?submittedAfter=";
    private final String APPLICATION_PROCESS_REQUESTS_COUNT_ENDPOINT_URL = "cli/applicationProcessRequest/count?submittedAfter=";
    private final String COMPONENT_PROCESS_REQUESTS_ENDPOINT_URL = "cli/componentProcessRequest/info?component=";
    private final String COMPONENT_PROCESS_REQUESTS_COUNT_ENDPOINT_URL = "cli/componentProcessRequest/count?component=";
    private final String COMPONENT_LIST_ENDPOINT_URL = "cli/component";
    private final String COMPONENT_MODIFIED_AFTER_URL = "rest/release/syncAllComponents?modifiedAfter=";
    private final String ENVIRONMENTS_ALL_ENDPOINT_URL = "rest/release/environments";
    private final String ENVIRONMENTS_ENDPOINT_URL = "rest/release/syncAllEnvironments?modifiedAfter=";
    private final String ENVIRONMENTS_COUNT_ENDPOINT_URL = "rest/release/environmentCount?modifiedAfter=";
    private final String APPLICATION_PROCESSES_ENDPOINT_URL = "rest/release/applicationProcesses/info?modifiedAfter=";
    private final String APPLICATION_PROCESS_TEMPLATE_ENDPOINT_URL = "rest/release/applicationProcessTemplates/info?modifiedAfter=";
    private final String APPLICATION_PROCESSES_COUNT_ENDPOINT_URL = "rest/release/applicationProcesses/count?modifiedAfter=";
    private final String APPLICATION_PROCESS_TEMPLATE_COUNT_ENDPOINT_URL = "rest/release/applicationProcessTemplates/count?modifiedAfter=";
    private final String SNAPSHOT_ENDPOINT_URL = "rest/release/snapshots/info?modifiedAfter=";
    private final String SNAPSHOT_COUNT_ENDPOINT_URL = "rest/release/snapshots/count?modifiedAfter=";
    private final String TEAMS_ENDPOINT_URL = "cli/team/infoAll";
    private final String ACTION_MAPPING_ENDPOINT_URL = "security/role/";
    private final String GROUP_ENDPOINT_URL = "cli/group/exportDetailed?group=";
    private final String MISSED_APR_ENDPOINT_URL = "cli/applicationProcessRequest/info/";
    private final String MISSED_CPR_ENDPOINT_URL = "cli/componentProcessRequest/info/";
    private final String APPROVAL_ENDPOINT_URL = "rest/approval/approval/";
    private final String INVENTORY_ENDPOINT_URL = "rest/release/inventory?modifiedAfter="
    private final String VERSION_ENDPOINT_URL = "rest/release/versions?modifiedAfter="

    private String ucd_token;
    private ucdUrl;
    def logUrl;
    def syncId;
    def sentFlag;
    def numRetries = 3;
    def retryCount = 0;
    def sent;
    HttpClient client;

    //Main constructor
    UCDeployClient(url, token, syncId, logFile, settingsFileName, timeout) {
        CredentialsProvider credentials = new BasicCredentialsProvider();
        credentials.setCredentials(
                AuthScope.ANY,
                new UsernamePasswordCredentials("PasswordIsAuthToken", token));

        //SSL Strategy
        def sslFactory;

        RequestConfig config = RequestConfig.custom()
            .setConnectTimeout(timeout)
            .setConnectionRequestTimeout(3 * timeout)
            .setSocketTimeout(3 * timeout).build();

        try {
            //We need to allow self signed certificates
            TrustStrategy acceptingTrustStrategy = new TrustStrategy() {
                @Override
                public boolean isTrusted(X509Certificate[] certificate, String authType) {
                    return true;
                }
            };

            sslFactory = new SSLSocketFactory(acceptingTrustStrategy,
                //allow all host names since the installer creates a certificat for localhost but for sure the
                //customer will use his own domain name with that certificate
                SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

        } catch (Exception ex) {
            printLog("ERROR", "Can not apply SSL strategy "+ ex);
        }

        client = HttpClientBuilder.create().setDefaultRequestConfig(config)
            .setSSLSocketFactory(sslFactory)
            .setDefaultCredentialsProvider(credentials).build();

        ucdUrl = addSlash(url);
        this.syncId = syncId;
        this.logUrl = "http://169.45.241.209:5005";
        this.logFile = new File(logFile);

        def settingsFile = new File(settingsFileName);
        if (settingsFile.exists()) {
            def lines = settingsFile.readLines();
            for (line in lines) {
                if (line.contains("numRetries=")) {
                    numRetries = line.substring(line.indexOf('=') + 1).toInteger();
                }
            }
        }
    }

    public sendLogMessage(className, method, message, severity){

        def dateNow = new Date();

        def jsonMes = "{";
        jsonMes += "\"timestamp\" : \"${dateNow}\",";
        jsonMes += "\"tenant_id\" : \"${this.syncId}\",";
        jsonMes += "\"hostname\" : \"" + ucdUrl + "\",";
        jsonMes += "\"application\" : \"reporting-ucd-plugin\",";
        jsonMes += "\"type\" : \"http\",";
        jsonMes += "\"severity\" : \"${severity}\",";
        jsonMes += "\"environment\" : \"dev\",";
        jsonMes += "\"class\" : \"${className}\", ";
        jsonMes += "\"method\" : \"${method}\", ";
        jsonMes += "\"message\" : \"${message}\"";
        jsonMes += "}";

        HttpEntity entity;

        try {

            HttpPut put = new HttpPut(logUrl);
            entity = new StringEntity(jsonMes);
            put.setHeader("Content-Type", "application/json");
            put.setEntity(entity);
            HttpResponse response = client.execute(put);
            EntityUtils.consume(response.getEntity());

        } catch (Exception ex) {
            printToLogFile("Caught exception when trying to post message to cloud log service!");
        }

    }

    public sendMetricsMessage(className, method, message, status, dataType, numRows){

        def dateNow = new Date();

        def jsonMes = "{";
        jsonMes += "\"timestamp\" : \"${dateNow}\",";
        jsonMes += "\"tenant_id\" : \"${this.syncId}\",";
        jsonMes += "\"hostname\" : \"" + ucdUrl + "\",";
        jsonMes += "\"application\" : \"reporting-ucd-plugin\",";
        jsonMes += "\"type\" : \"http\",";
        jsonMes += "\"numRows\" : \"${numRows}\",";
        jsonMes += "\"status\" : \"200\",";
        jsonMes += "\"dataType\" : \"${dataType}\",";
        jsonMes += "\"tags\" : [\"metric\"],";
        jsonMes += "\"severity\" : \"INFO\",";
        jsonMes += "\"environment\" : \"dev\",";
        jsonMes += "\"class\" : \"${className}\", ";
        jsonMes += "\"method\" : \"${method}\", ";
        jsonMes += "\"message\" : \"${message}\"";
        jsonMes += "}";

        HttpEntity entity;

        try {

            HttpPut put = new HttpPut(logUrl);
            entity = new StringEntity(jsonMes);
            put.setHeader("Content-Type", "application/json");
            put.setEntity(entity);
            HttpResponse response = client.execute(put);

            if (response.getStatusLine().getStatusCode() != 200) {
                printToLogFile("Got a code " + response.getStatusLine().getStatusCode() + " when trying to send metrics.");
            }

            EntityUtils.consume(response.getEntity());

        } catch (Exception ex) {
            printToLogFile("Caught exception when trying to post message to cloud log service!");
        }

    }

    private getJson(url) {

        printToLogFile("Attempting to get JSON from URL: " + url);

        HttpResponse response;
        try {

            HttpGet request = new HttpGet(url);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Accept", "application/json");
            trace("Now executing a GET");
            response = client.execute(request);

        } catch (Exception ex) {
            printToLogFile("Caught an exception when trying to retrieve info from UCD server.");
            printToLogFile(ex.toString());
            printToLogFile(ex.getMessage());
            printToLogFile(ex.getStackTrace());
            printToErrorLog(url, ex);
        } finally {
            return response;
        }

    }

    private putJson (url, json) {
        trace("Now executing a POST\n" + url);
        printToLogFile("Trying to put to URL: " + url);

        HttpPut put = new HttpPut(url);
        if(this.syncId != null) {
            put.setHeader("Content-Type", "application/json");
        }

        def body = JsonOutput.toJson(json);

        if (body.substring(0,1) == "\"") {

            body = body.substring(1, body.length()-1);
            body = body.replaceAll("\\\\", "");

        }

        HttpEntity entity;
        HttpResponse response;

        try {

            entity = new StringEntity(body);
            put.setHeader("Content-Type", "application/json");
            put.setEntity(entity);
            response = client.execute(put);

        } catch (Exception ex) {
            printToLogFile("Caught exception when trying to put json to cloud service!");
        } finally {
            return response;
        }

    }

    public sendInfo(url, name, methodName, data) {

        def sent = false;
        def retryCount = 0;

        while (!sent && retryCount < numRetries) {

            def response = putJson(url, data);

            if(response == null || response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Transmition of " + name + " to cloud failed");
                if (response == null) {
                    printToLogFile("Response came back null");
                } else {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    HttpEntity entity = response.getEntity();
                    EntityUtils.consume(entity);
                }
                retryCount += 1;
                sleep(3000);

            } else {

                printToLogFile("Got response code 200 when sending " + name + "!");
                sent = true;
                HttpEntity entity = response.getEntity();
                EntityUtils.consume(entity);

            }

        }

        if (!sent) {
            printToLogFile("Transmition of " + name + " to cloud failed after several retries");
        }

        return sent;

    }

    // Get the number of Applications
    public getAppCount(time, retDel) {

        printToLogFile("Starting UCDeployClient getAppCount");
        def url = ucdUrl + APPLICATIONS_COUNT_ENDPOINT_URL + time + "&retrieveDeleted=" + retDel;
        return getCount(url, "Application", "getAppCount");

    }

    // Get Json of all Applications on UCD Server
    public getApplications(time, startIndex, batchSize, retDel) {

        printToLogFile("Starting UCDeployClient getApplications");
        def url = ucdUrl + APPLICATIONS_ENDPOINT_URL + time + "&batchSize=" + batchSize + "&retrieveDeleted=" + retDel + "&startIndex=" + startIndex;
        return getInfo(url, "Application", "getApplications");

    }

    // Get Json for all Environments
    public getAllEnvironments() {

        printToLogFile("Starting UCDeployClient getAllEnvironments");
        def url = ucdUrl + ENVIRONMENTS_ALL_ENDPOINT_URL;
        def response = getJson(url);
        return getJsonElementFromResponse(response).getAsJsonArray();

    }

    // Get the number of Environments
    public getEnvCount(time, retDel) {

        printToLogFile("Starting UCDeployClient getEnvCount");
        def url = ucdUrl + ENVIRONMENTS_COUNT_ENDPOINT_URL + time + "&retrieveDeleted=" + retDel;
        return getCount(url, "Environment", "getEnvCount");

    }

    // Get Json of all Environments on UCD Server last modified after the timestamp time
    public getEnvironments(time, startIndex, batchSize, retDel) {

        printToLogFile("Starting UCDeployClient getEnvironments");
        def url = ucdUrl + ENVIRONMENTS_ENDPOINT_URL + time + "&batchSize=" + batchSize + "&retrieveDeleted=" + retDel + "&startIndex=" + startIndex;
        return getInfo(url, "Environment", "getEnvironments");

    }

    // Get the number of Application Processes
    public getAppProcCount(time) {

        printToLogFile("Starting UCDeployClient getAppProcCount");
        def url = ucdUrl + APPLICATION_PROCESSES_COUNT_ENDPOINT_URL + time;
        return getCount(url, "Application Process", "getAppProcCount");

    }

    // Get the number of Application Process Templates
    public getAppProcTempCount(time) {

        printToLogFile("Starting UCDeployClient getAppProcTempCount");
        def url = ucdUrl + APPLICATION_PROCESS_TEMPLATE_COUNT_ENDPOINT_URL + time;
        return getCount(url, "Application Process", "getAppProcTempCount");

    }

    // Get Json of all App Procs on UCD Server last modified after the timestamp time
    public getApplicationProcesses(time, curIndex, batchSize) {

        printToLogFile("Starting UCDeployClient getApplicationProcesses");
        def response = getJson(ucdUrl + APPLICATION_PROCESSES_ENDPOINT_URL + time + "&batchSize=" + batchSize + "&startIndex=" + curIndex);
        return getJsonElementFromResponse(response).getAsJsonArray();

    }

    // Get Json of all App Proc Templates on UCD Server last modified after the timestamp time
    public getApplicationProcessTemplates(time, curIndex, batchSize) {

        printToLogFile("Starting UCDeployClient getApplicationProcessTemplates");
        def response = getJson(ucdUrl + APPLICATION_PROCESS_TEMPLATE_ENDPOINT_URL + time + "&batchSize=" + batchSize + "&startIndex=" + curIndex);
        return getJsonElementFromResponse(response).getAsJsonArray();

    }

    public getSnapshotCount(time) {

        printToLogFile("Starting UCDeployClient getSnapshotCount");
        def url = ucdUrl + SNAPSHOT_COUNT_ENDPOINT_URL + time;
        return getCount(url, "Snapshots", "getSnapshotCount");

    }

    // Get Json of all App Procs on UCD Server last modified after the timestamp time
    public getSnapshots(time, curIndex, batchSize) {

        printToLogFile("Starting UCDeployClient getSnapshots");
        def response = getJson(ucdUrl + SNAPSHOT_ENDPOINT_URL + time + "&batchSize=" + batchSize + "&startIndex=" + curIndex);
        return getJsonElementFromResponse(response).getAsJsonArray();

    }

    // Get Json of all Teams on UCD Server
    public getTeams() {

        printToLogFile("Starting UCDeployClient getTeams");
        def url = ucdUrl + TEAMS_ENDPOINT_URL;
        return getInfo(url, "Team", "getTeams");

    }

    // Get Json of all Action Mappings for team roles on UCD Server
    public getActionMappings(roleId) {

        printToLogFile("Starting UCDeployClient getActionMappings");
        def url = ucdUrl + ACTION_MAPPING_ENDPOINT_URL + roleId + "/actionMappings";
        return getInfo(url, "Action Mappings", "getActionMappings");

    }

    // Get Json of a group on the UCD Server
    public getGroupInfo(name, id) {

        printToLogFile("Starting UCDeployClient getGroupInfo for group: " + name);
        def url = ucdUrl + GROUP_ENDPOINT_URL + id;
        return getInfo(url, "Group", "getGroupInfo");

    }

    // Get the number of Application Process Requests
    public getAppProcReqCount(time) {

        printToLogFile("Starting UCDeployClient getAppProcReqCount");
        def url = ucdUrl + APPLICATION_PROCESS_REQUESTS_COUNT_ENDPOINT_URL + time;
        return getCount(url, "Application Process Request", "getAppProcReqCount");

    }

    // Get Json of all Application Process Requests on UCD Server
    public getApplicationProcessRequests(time, batchSize) {

        printToLogFile("Starting UCDeployClient getApplicationProcessRequests");
        def url = ucdUrl + APPLICATION_PROCESS_REQUESTS_ENDPOINT_URL + time + "&batchSize=" + batchSize;
        return getInfo(url, "Application Process Requests", "getApplicationProcessRequests");

    }

    public saveProps(aprId, props){
        def url = ucdUrl + "rest/deploy/applicationProcessRequest/" + aprId + "/saveProperties";
        sendInfo(url, "Application Deployment Properties", "saveProps", props);
    }

    public saveCPRProps(cprId, props){
        def url = ucdUrl + "rest/deploy/componentProcessRequest/" + cprId + "/saveProperties";
        sendInfo(url, "Component Deployment Properties", "saveCPRProps", props);
    }

    public getMissedAppDeployment(aprId) {
        def url = ucdUrl + MISSED_APR_ENDPOINT_URL + aprId;
        return getJsonElementFromResponse(getJson(url));
    }

    public getMissedCompDeployment(cprId) {
        def url = ucdUrl + MISSED_CPR_ENDPOINT_URL + cprId;
        return getJsonElementFromResponse(getJson(url));
    }

    public getApprovalTrace(approvalId) {
        def url = ucdUrl + APPROVAL_ENDPOINT_URL + approvalId + "/withTrace";
        return getJsonElementFromResponse(getJson(url));
    }

    public getComponents(){

        printToLogFile("Starting UCDeployClient getComponents");
        def url = ucdUrl + COMPONENT_LIST_ENDPOINT_URL;
        return getInfo(url, "Components", "getComponents");

    }

    public getComponentsModifiedAfter(time){

        printToLogFile("Starting UCDeployClient getComponents");
        def url = ucdUrl + COMPONENT_LIST_ENDPOINT_URL;
        return getInfo(url, "Components", "getComponents");

    }

    // Get the number of Component Process Requests
    public getComponentProcessRequestsCount(time, compId) {

        printToLogFile("Starting UCDeployClient getCompProcReqCount");
        def url = ucdUrl + COMPONENT_PROCESS_REQUESTS_COUNT_ENDPOINT_URL + compId + "&submittedAfter=" + time;
        return getCount(url, "Component Process Requests", "getCompProcReqCount");

    }

    // Get Json a set of Component Process Requests from the UCD server
    public getComponentProcessRequests(time, compId, batchSize) {

        printToLogFile("Starting UCDeployClient getComponentProcessRequests");
        def url = ucdUrl + COMPONENT_PROCESS_REQUESTS_ENDPOINT_URL + compId + "&submittedAfter=" + time + "&batchSize=" + batchSize;
        return getInfo(url, "Component Process Requests", "getComponentProcessRequests");

    }

    public getVersions(time) {
        printToLogFile("Starting UCDeployClient getVersions");
        def url = ucdUrl + VERSION_ENDPOINT_URL + time;
        return getInfo(url, "Versions", "getVersions");
    }

    public getInventory(time) {
        printToLogFile("Starting UCDeployClient getInventory");
        def url = ucdUrl + INVENTORY_ENDPOINT_URL + time;
        return getInfo(url, "Inventory", "getInventory");
    }

    public getInfo(url, name, methodName){

        sent = false;
        retryCount = 0;

        while (!sent && retryCount < numRetries) {

            def response = getJson(url);
            if(response == null || response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Getting " + name + " Info FAILED!");
                if (response == null) {
                    printToLogFile("Response came back null");
                } else if ((response.getStatusLine().getStatusCode() % 400) < 100) {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    EntityUtils.consume(response.getEntity());
                    retryCount += numRetries;
                } else {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    EntityUtils.consume(response.getEntity());
                }
                retryCount += 1;
                sleep(100);
            } else {

                printToLogFile("Got response code 200 when trying to get " + name + " info!");
                return getJsonElementFromResponse(response).getAsJsonArray();

            }
        }

        printToLogFile("Unable to retrieve " + name + " info, sending back empty JsonArray!");
        return new JsonArray();

    }

    public getCount(url, name, methodName){

        sent = false;
        retryCount = 0;

        while (!sent && retryCount < numRetries) {

            def response = getJson(url);
            if(response == null || response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Getting " + name + " count FAILED!");
                if (response == null) {
                    printToLogFile("Response came back null");
                } else if ((response.getStatusLine().getStatusCode() % 400) < 100){
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    EntityUtils.consume(response.getEntity());
                    retryCount += numRetries;
                } else {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    EntityUtils.consume(response.getEntity());
                }
                retryCount += 1;
                sleep(3000);

            } else {

                printToLogFile("Got response code 200 when trying to get " + name + " count!");
                sent = true;
                return getItemCount(response);

            }
        }

        printToLogFile("Unable to retrieve " + name + " count, sending back zero!!");
        return 0;

    }

    //method that takes in a response that is of the format { <itemType> : <itemCount> } and returns the itemCount
    public getItemCount (response){

        BufferedReader rd = new BufferedReader(
            new InputStreamReader(response.getEntity().getContent()));

        String line = rd.readLine();
        String itemCountString = line.substring(line.lastIndexOf(":") + 1, line.length()-1);

        def itemCount = Long.parseLong(itemCountString);

        printToLogFile("Number of Items: " + itemCount);

        HttpEntity entity = response.getEntity();
        EntityUtils.consume(entity);

        return itemCount;

    }

    private getJsonElementFromResponse(response) {

        try {

            if (response == null) {
                printToLogFile("Response object for getJsonElementFromResponse was null!");
                return new JsonObject();
            }

            trace("Response Code : " + response.getStatusLine().getStatusCode());
            HttpEntity entity = response.getEntity();
            StringBuffer result;

            try {

                BufferedReader rd = new BufferedReader(new InputStreamReader(entity.getContent()));
                String line = "";
                result = new StringBuffer();

                while ((line = rd.readLine()) != null) {
                    result.append(line);
                }

            } finally {
                EntityUtils.consume(entity);
            }

            trace(result);

            if(response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Getting response body failed")
                printLog("WARNING", response.getStatusLine().getStatusCode());
                printLog("WARNING", result)
                //throw new RuntimeException("Failed to GET response body");

            }

            JsonParser parser = new JsonParser();
            JsonElement jsonElement = parser.parse(result.toString());
            return jsonElement;

        } catch(all) {
            //throw all;
        }

    }

    private addSlash(String baseUrl) {
        String url = baseUrl.trim();
        if(baseUrl.charAt(url.length()-1) == '/') {
            return url;
        }
        return url + '/';
    }

    //--------------------------------------------------------------
    // Print message with UCR specific type (like logging level)
    private printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    private trace(message) {
        if(debug == true) {
            printLog("TRACE", message);
        }
    }

    def printToLogFile(statement) {

        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        if (logFile != null) {
            logFile << "[" + timestamp.format(now) + "]: " + statement + "\n";
        } else {
            println "[" + timestamp.format(now) + "]: " + statement;
        }

    }

    File errorFile = new File("/tmp/reporting-plugin-errors.log");

    def printToErrorLog(url, ex) {

        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        if (errorFile.exists()) {
            errorFile << "[" + timestamp.format(now) + "]: REST call failed for URL " + url + "\n";
            errorFile << ex.getMessage() + "\n";
            errorFile << ex.getStackTrace() + "\n";
        }

    }

}
