package com.urbancode.plugin.models

public class UcdAuthToken {

    def id;
    def token;
    def description;
    def expiration;
    def host;
    def userId;
}
