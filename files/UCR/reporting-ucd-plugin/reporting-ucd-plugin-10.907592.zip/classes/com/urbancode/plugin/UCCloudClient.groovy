package com.urbancode.plugin

import java.util.Date;
import java.text.SimpleDateFormat;
import javax.net.ssl.SSLContext;

import com.urbancode.air.*
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.HttpEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import groovy.json.JsonSlurper;
import groovy.json.JsonOutput;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

public class UCCloudClient {

    private boolean debug = false;

    private File logFile = new File("/tmp/reporting-ucd-plugin.txt");

    private final String ENVIRONMENTS_SEND_ENDPOINT_URL = "api/v1/ucd/environments";
    private final String APPLICATIONS_SEND_ENDPOINT_URL = "api/v1/ucd/applications";
    private final String APPLICATION_PROCESS_REQUESTS_SEND_ENDPOINT_URL = "api/v1/ucd/appprocessrequests";
    private final String MISSED_APP_DEPLOYMENTS_SEND_ENDPOINT_URL = "api/v1/ucd/appprocessrequests/nowcompleted";
    private final String COMPONENT_PROCESS_REQUESTS_SEND_ENDPOINT_URL = "api/v1/ucd/workflows";
    private final String MISSED_COMP_DEPLOYMENTS_SEND_ENDPOINT_URL = "api/v1/ucd/workflows/nowcompleted";
    private final String APPLICATION_PROCESSES_SEND_ENDPOINT_URL = "api/v1/ucd/appprocesses";
    private final String SNAPSHOTS_SEND_ENDPOINT_URL = "api/v1/ucd/snapshots";
    private final String TEAMS_SEND_ENDPOINT_URL = "api/v1/ucd/teams";
    private final String ACTION_MAPPINGS_SEND_ENDPOINT_URL = "api/v1/ucd/roleactions";
    private final String MISSED_APP_DEPLOYMENTS_GET_ENDPOINT_URL = "api/v1/ucd/misseddeployments";
    private final String MISSED_COMP_DEPLOYMENTS_GET_ENDPOINT_URL = "api/v1/ucd/missedcprs";
    private final String FAILED_APP_DEPLOYMENTS_ENDPOINT_URL = "api/v1/ucd/failedtocollectdeployments";
    private final String FAILED_COMP_DEPLOYMENTS_ENDPOINT_URL = "api/v1/ucd/failedtocollectworkflows";
    private final String INVENTORY_SEND_ENDPOINT_URL = "api/v1/ucd/inventory";
    private final String VERSIONS_SEND_ENDPOINT_URL = "api/v1/ucd/versions"

    private String syncId;
    private String syncToken;
    private String syncName;
    private String adminUser;
    private String instanceId;

    def logUrl;
    def ucdUrl;
    def cloudUrl;
    def numRetries = 3;
    HttpClient client;

    //Main constructor
    UCCloudClient (ucdhost, url, syncId, syncToken, syncName, adminUser, integrationId, logFile, settingsFileName, timeout) {

        RequestConfig config = RequestConfig.custom()
            .setConnectTimeout(timeout)
            .setConnectionRequestTimeout(3 * timeout)
            .setSocketTimeout(3 * timeout).build();

        SSLContext context = null;
        try {
            context = SSLContext.getInstance("TLSv1.2");
            context.init(null, null, null);
        } catch (Exception e) {
            printToLogFile("Exception was caught when trying to set up SSLContext");
            printToLogFile(ex.getStackTrace());
        }

        client = HttpClientBuilder.create().setDefaultRequestConfig(config).setSslcontext(context).build();
        ucdUrl = addSlash(ucdhost);
        cloudUrl = addSlash(url);
        this.syncId = syncId;
        this.syncToken = syncToken;
        this.syncName = syncName;
        this.adminUser = adminUser;
        this.instanceId = integrationId;
        this.logUrl = "http://169.45.241.209:5005";
        this.logFile = new File(logFile);



        def settingsFile = new File(settingsFileName);
        if(settingsFile.exists()) {
            def lines = settingsFile.readLines();
            for (line in lines) {
                if (line.contains("numRetries=")) {
                    numRetries = line.substring(line.indexOf('=') + 1).toInteger();
                }
            }
        }

    }

    //Main constructor
    UCCloudClient (url, timeout) {

        RequestConfig config = RequestConfig.custom()
            .setConnectTimeout(timeout)
            .setConnectionRequestTimeout(3 * timeout)
            .setSocketTimeout(3 * timeout).build();
        client = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
        cloudUrl = addSlash(url);
        this.logUrl = "http://169.45.241.209:5005"
    }

    private postJson (url, json) {
        trace("Now executing a POST\n" + url);
        printToLogFile("Trying to post to URL: " + url);

        HttpPost post = new HttpPost(url);
        if(this.syncId != null) {
            post.setHeader("sync_id", this.syncId);
            post.setHeader("sync_token", this.syncToken);
            post.setHeader("sync_name", this.syncName);
            post.setHeader("admin_user", this.adminUser);
            post.setHeader("instance_id", this.instanceId);
            post.setHeader("instance_type", "UCD");
        }

        def body = JsonOutput.toJson(json);

        if (body.substring(0,1) == "\"") {

            body = body.substring(1, body.length()-1);
            body = body.replaceAll("\\\\", "");

        }

        HttpEntity entity;
        HttpResponse response;

        try {

            entity = new StringEntity(body);
            post.setHeader("Content-Type", "application/json");
            post.setEntity(entity);
            response = client.execute(post);

        } catch (Exception ex) {
            printToLogFile("Caught exception when trying to post json to cloud service!");
        } finally {
            return response;
        }

    }

    private getJson(url) {

        printToLogFile("Attempting to get JSON from URL: " + url);

        HttpResponse response;
        try {

            HttpGet request = new HttpGet(url);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Accept", "application/json");
            if(this.syncId != null) {
                request.setHeader("sync_id", this.syncId);
                request.setHeader("sync_token", this.syncToken);
                request.setHeader("sync_name", this.syncName);
                request.setHeader("instance_id", this.instanceId);
                request.setHeader("instance_type", "UCD");
            }
            trace("Now executing a GET");
            response = client.execute(request);

        } catch (Exception ex) {
            printToLogFile("Caught an exception when trying to retrieve the missed deployments.");
            printToLogFile(ex.toString());
            printToLogFile(ex.getMessage());
            printToLogFile(ex.getStackTrace());
        } finally {
            return response;
        }

    }

    public getInfo(url, name, methodName){

        def sent = false;
        def retryCount = 0;

        while (!sent && retryCount < numRetries) {

            def response = getJson(url);

            if(response == null || response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Getting " + name + " Info FAILED!");
                if (response == null) {
                    printToLogFile("Response came back null");
                } else if (response.getStatusLine().getStatusCode() == 400) {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    retryCount += numRetries;
                } else {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                }
                retryCount += 1;
                sleep(3000);

            } else {

                printToLogFile("Got response code 200 when trying to get " + name + " info!");
                return getJsonElementFromResponse(response).getAsJsonArray();

            }
        }

        printToLogFile("Unable to retrieve " + name + " info, sending back empty JsonArray!");
        return new JsonArray();

    }

    private getJsonElementFromResponse(response) {

        try {

          trace("Response Code : " + response.getStatusLine().getStatusCode());
          HttpEntity entity = response.getEntity();
          StringBuffer result;

          try {

              BufferedReader rd = new BufferedReader(new InputStreamReader(entity.getContent()));
              String line = "";
              result = new StringBuffer();

              while ((line = rd.readLine()) != null) {
                  result.append(line);
              }

          } finally {
              EntityUtils.consume(entity);
          }

          trace(result);

          if(response.getStatusLine().getStatusCode() != 200) {

              printLog("WARNING", "Getting response body failed")
              printLog("WARNING", response.getStatusLine().getStatusCode());
              printLog("WARNING", result)
              throw new RuntimeException("Failed to GET response body");

          }

          JsonParser parser = new JsonParser();
          JsonElement jsonElement = parser.parse(result.toString());
          return jsonElement;

        }

        catch (all) {
            throw all;
        }

    }

    public sendLogMessage(className, method, message, severity){

        def dateNow = new Date();

        def jsonMes = "{";
        jsonMes += "\"timestamp\" : \"${dateNow}\",";
        jsonMes += "\"tenant_id\" : \"${this.syncId}\",";
        jsonMes += "\"hostname\" : \"" + ucdUrl + "\",";
        jsonMes += "\"application\" : \"reporting-ucd-plugin\",";
        jsonMes += "\"type\" : \"http\",";
        jsonMes += "\"severity\" : \"${severity}\",";
        jsonMes += "\"environment\" : \"dev\",";
        jsonMes += "\"class\" : \"${className}\", ";
        jsonMes += "\"method\" : \"${method}\", ";
        jsonMes += "\"message\" : \"${message}\"";
        jsonMes += "}";

        HttpEntity entity;

        try {

            HttpPut put = new HttpPut(logUrl);
            entity = new StringEntity(jsonMes);
            put.setHeader("Content-Type", "application/json");
            put.setEntity(entity);
            HttpResponse response = client.execute(put);
            EntityUtils.consume(response.getEntity());

        } catch (Exception ex) {
            printToLogFile("Caught exception when trying to post message to cloud log service!");
        }

    }

    public sendMetricsMessage(className, method, message, status, dataType, numRows){

        def dateNow = new Date();

        def jsonMes = "{";
        jsonMes += "\"timestamp\" : \"${dateNow}\",";
        jsonMes += "\"tenant_id\" : \"${this.syncId}\",";
        jsonMes += "\"hostname\" : \"" + ucdUrl + "\",";
        jsonMes += "\"application\" : \"reporting-ucd-plugin\",";
        jsonMes += "\"type\" : \"http\",";
        jsonMes += "\"numRows\" : \"${numRows}\",";
        jsonMes += "\"status\" : \"200\",";
        jsonMes += "\"dataType\" : \"${dataType}\",";
        jsonMes += "\"tags\" : [\"metric\"],";
        jsonMes += "\"severity\" : \"INFO\",";
        jsonMes += "\"environment\" : \"dev\",";
        jsonMes += "\"class\" : \"${className}\", ";
        jsonMes += "\"method\" : \"${method}\", ";
        jsonMes += "\"message\" : \"${message}\"";
        jsonMes += "}";

        HttpEntity entity;

        try {

            HttpPut put = new HttpPut(logUrl);
            entity = new StringEntity(jsonMes);
            put.setHeader("Content-Type", "application/json");
            put.setEntity(entity);
            HttpResponse response = client.execute(put);

            if (response.getStatusLine().getStatusCode() != 200) {
                printToLogFile("Got a code " + response.getStatusLine().getStatusCode() + " when trying to send metrics.");
            }

            EntityUtils.consume(response.getEntity());

        } catch (Exception ex) {

            printToLogFile("Caught exception when trying to post message to cloud log service!");

        }

    }

    public saveProps(aprId, props){
        def url = ucdUrl + "rest/deploy/" + aprId + "/saveProperties";
        sendInfo(url, "test", "test", props);
    }

    // given a list of component process requests, send them via POST
    public getMissedAppDeployments() {

        printToLogFile("Starting UCCloudClient getMissedAppDeployments");
        def url = cloudUrl + MISSED_APP_DEPLOYMENTS_GET_ENDPOINT_URL;
        return getInfo(url, "Missed Application Deployments", "getMissedAppDeployments");

    }

    // given a list of component process requests, send them via POST
    public getMissedCompDeployments() {

        printToLogFile("Starting UCCloudClient getMissedCompDeployments");
        def url = cloudUrl + MISSED_COMP_DEPLOYMENTS_GET_ENDPOINT_URL;
        return getInfo(url, "Missed Component Deployments", "getMissedCompDeployments");

    }

    // given a list of APRs, send them via POST
    public sendApplicationProcessRequests(applicationProcessRequests) {

        printToLogFile("Starting UCCloudClient sendApplicationProcessRequests");
        def url = cloudUrl + APPLICATION_PROCESS_REQUESTS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Application Process Requests", "sendApplicationProcessRequests", applicationProcessRequests);

    }

    public sendMissedApplicationProcessRequests(applicationProcessRequests) {

        printToLogFile("Starting UCCloudClient sendMissedApplicationProcessRequests");
        def url = cloudUrl + MISSED_APP_DEPLOYMENTS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Missed Application Process Requests", "sendMissedApplicationProcessRequests", applicationProcessRequests);

    }

    public getFailedAPRInfo() {

        printToLogFile("Starting UCCloudClient getFailedAPRInfo");
        def url = cloudUrl + FAILED_APP_DEPLOYMENTS_ENDPOINT_URL;
        return getInfo(url, "Failed APR Info", "getFailedAPRInfo");

    }

    public sendFailedAPRInfo(failedAPR) {

        printToLogFile("Starting UCCloudClient sendFailedAPRInfo");
        def url = cloudUrl + FAILED_APP_DEPLOYMENTS_ENDPOINT_URL;
        return sendInfo(url, "Failed APR Info", "sendFailedAPRInfo", failedAPR);

    }

    // given a list of component process requests, send them via POST
    public sendComponentProcessRequests(componentProcessRequests) {

        printToLogFile("Starting UCCloudClient sendComponentProcessRequests");
        def url = cloudUrl + COMPONENT_PROCESS_REQUESTS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Component Process Requests", "sendComponentProcessRequests", componentProcessRequests);

    }

    public sendMissedComponentProcessRequests(componentProcessRequests) {

        printToLogFile("Starting UCCloudClient sendMissedComponentProcessRequests");
        def url = cloudUrl + MISSED_COMP_DEPLOYMENTS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Missed Component Process Requests", "sendMissedComponentProcessRequests", componentProcessRequests);

    }

    public getFailedCPRInfo() {

        printToLogFile("Starting UCCloudClient getFailedCPRInfo");
        def url = cloudUrl + FAILED_COMP_DEPLOYMENTS_ENDPOINT_URL;
        return getInfo(url, "Failed CPR Info", "getFailedCPRInfo");

    }

    public sendFailedCPRInfo(failedCPR) {

        printToLogFile("Starting UCCloudClient sendFailedCPRInfo");
        def url = cloudUrl + FAILED_COMP_DEPLOYMENTS_ENDPOINT_URL;
        return sendInfo(url, "Failed CPR Info", "sendFailedCPRInfo", failedCPR);

    }

    // given a list of action mappings, send them via POST
    public sendActionMappings(actionMappings) {

        printToLogFile("Starting UCCloudClient sendTeams");
        def url = cloudUrl + ACTION_MAPPINGS_SEND_ENDPOINT_URL;
        sendInfo(url, "Action Mappings", "sendActionMappings", actionMappings);

    }

    // given a list of teams, send them via POST
    public sendTeams(teams) {

        printToLogFile("Starting UCCloudClient sendTeams");
        def url = cloudUrl + TEAMS_SEND_ENDPOINT_URL;
        sendInfo(url, "Teams", "sendTeams", teams);

    }

    // given a list of application processes, send them via POST
    public sendApplicationProcesses(applicationProcesses) {

        printToLogFile("Starting UCCloudClient sendApplicationProcesses");
        def url = cloudUrl + APPLICATION_PROCESSES_SEND_ENDPOINT_URL;
        sendInfo(url, "Application Processes", "sendApplicationProcesses", applicationProcesses);

    }

    // given a list of snapshots, send them via POST
    public sendSnapshots(snapshots) {

        printToLogFile("Starting UCCloudClient sendSnapshots");
        def url = cloudUrl + SNAPSHOTS_SEND_ENDPOINT_URL;
        sendInfo(url, "Snapshots", "sendSnapshots", snapshots);

    }

    // given a list of versions, send them via POST
    public sendVersions(versions) {
        printToLogFile("Starting UCCloudClient sendVersions");

        def url = cloudUrl + VERSIONS_SEND_ENDPOINT_URL;
        sendInfo(url, "Versions", "sendVersions", versions);
    }

    // given a list of inventory, send via POST
    public sendInventory(inventory) {
        printToLogFile("Starting UCCloudClient sendInventory");

        def url = cloudUrl + INVENTORY_SEND_ENDPOINT_URL;
        sendInfo(url, "Inventory", "sendInventory", inventory);
    }

    // given a list of applications, send them via POST
    public sendApplications(applications) {

        printToLogFile("Starting UCCloudClient sendApplications");
        def url = cloudUrl + APPLICATIONS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Applications", "sendApplications", applications);

    }

    // given a list of environments, send them via POST
    public sendEnvironments(environments) {

        printToLogFile("Starting UCCloudClient sendEnvironments");
        def url = cloudUrl + ENVIRONMENTS_SEND_ENDPOINT_URL;
        return sendInfo(url, "Environments", "sendEnvironments", environments);

    }

    public sendInfo(url, name, methodName, data) {

        def sent = false;
        def retryCount = 0;
        while (!sent && retryCount < numRetries) {

            def response = postJson(url, data);

            if(response == null || response.getStatusLine().getStatusCode() != 200) {

                printLog("WARNING", "Transmition of " + name + " to cloud failed");
                if (response == null) {
                    printToLogFile("Response came back null");
                } else {
                    printToLogFile("Got response code " + response.getStatusLine().getStatusCode());
                    HttpEntity entity = response.getEntity();
                    EntityUtils.consume(entity);
                }
                retryCount += 1;
                sleep(3000);

            } else {

                printToLogFile("Got response code 200 when sending " + name + "!");
                sent = true;
                HttpEntity entity = response.getEntity();
                EntityUtils.consume(entity);

            }

        }

        if (!sent) {
            printToLogFile("Transmition of " + name + " to cloud failed after several retries");
        }

        return sent;

    }

    //--------------------------------------------------------------
    // If provided URL does not end with a slash, the slash will be added
    private addSlash(String baseUrl) {
        String url = baseUrl.trim();
        if(baseUrl.charAt(url.length()-1) == '/') {
            return url;
        }
        return url + '/';
    }

    //--------------------------------------------------------------
    // Print message with UCR specific type (like logging level)
    def printLog(type, message) {
        println "<span class=\""+type+"\">"+message+"</span>"
    }

    def printToLogFile(statement) {

        Date now = new Date();
        SimpleDateFormat timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

        if (logFile != null) {
            logFile << "[" + timestamp.format(now) + "]: " + statement + "\n";
        } else {
            println "[" + timestamp.format(now) + "]: " + statement;
        }

    }

    def trace(message) {
        if(debug == true) {
            printLog("TRACE", message);
        }
    }

}
