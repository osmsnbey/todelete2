package com.urbancode.plugin.models

import com.google.gson.annotations.SerializedName;

public class ApplicationProcess{
    def id;
    def name;
    def description;
    @SerializedName("applicationId")
    def application_id;
    def active;
    def deleted;
}
