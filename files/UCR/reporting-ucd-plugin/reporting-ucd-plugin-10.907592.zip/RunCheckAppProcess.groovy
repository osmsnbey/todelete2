#!/usr/bin/env groovy
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Release
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.*
import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder;
import com.urbancode.commons.util.IO;
import com.urbancode.plugin.*;

import org.apache.http.*;
import org.apache.http.auth.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.client.protocol.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.AllowAllHostnameVerifier;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.conn.ssl.X509HostnameVerifier;
import org.apache.http.entity.*;
import org.apache.http.impl.auth.*;
import org.apache.http.impl.client.*;
import org.apache.http.util.*;

import org.codehaus.jettison.json.JSONObject;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

println "******************************************"
println props

def uri = props['server_uri'];
def token = props['token'];
def callbackUrl = props['callbackUrl'];
def requestId = props['applicationProcessRequestId'];

while (uri.endsWith('/')) {
    uri = uri.substring(0, uri.length() - 1)
}

CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder();
builder.setPreemptiveAuthentication(true);
builder.setUsername("PasswordIsAuthToken");
builder.setPassword(token);
builder.setTrustAllCerts(true);

CloseableHttpClient httpclient = builder.buildClient();

println "Starting Check on UCD Process"

def checker = new CheckAppProcess(uri, token, requestId, callbackUrl)
checker.startCheck()

println "Finished Check on UCD Process"