import com.urbancode.air.plugin.ncover.NcoverHelper
import com.urbancode.air.AirPluginTool

final def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

final def ncover = new NcoverHelper(props)
ncover.parseNcover()