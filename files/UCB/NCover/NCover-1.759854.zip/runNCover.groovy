import com.urbancode.air.plugin.ncover.NcoverHelper
import com.urbancode.air.AirPluginTool

int exitCode = 0
try {
    final def apTool = new AirPluginTool(this.args[0], this.args[1])
    def props = apTool.getStepProperties()

    final def ncover = new NcoverHelper(props)
    int nCoverExitCode = ncover.runNcover()
    // nUnit's exit code is the number of failed tests. we don't want to fail our step when tests fail.
    if (nCoverExitCode < 0) {
        exitCode = nCoverExitCode
    }
}
catch (Exception e) {
    println "Error running NCover: ${e}"
    exitCode = 1
}
System.exit(exitCode)