package com.urbancode.air.plugin.quality.jacoco

public class CoverageCount {
    int missed = 0
    int covered = 0

    public def getPercentCoverage() {
        int total = missed + covered
        return (double) covered / (total ?: 1)
    }
}
