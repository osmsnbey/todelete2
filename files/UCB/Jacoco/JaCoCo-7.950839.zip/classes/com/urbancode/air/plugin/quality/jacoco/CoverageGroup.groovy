package com.urbancode.air.plugin.quality.jacoco

public class CoverageGroup {
    CoverageCount lineCounts = new CoverageCount()
    CoverageCount methodCounts = new CoverageCount()
    CoverageCount branchCounts = new CoverageCount()
    CoverageCount complexityCounts = new CoverageCount()
}
