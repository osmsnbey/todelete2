import com.urbancode.air.*
import com.urbancode.air.plugin.scm.*


final def workDir = new File('.').canonicalFile

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def dateParser = new DateParser();

final def stepProps = apTool.getStepProperties();

// Repo
final String scmCmd     = stepProps['source/repo/commandPath'] ?: 'git'
final String baseUrl    = stepProps['source/repo/repoBaseUrl']
final String username   = stepProps['source/repo/username']
final String password   = stepProps['source/repo/password'] ?: stepProps['source/repo/passScript']

// Source
final String srcName       = stepProps['source'];
final File dir             = new File(workDir, stepProps['source/dirOffset'] ?: '.').canonicalFile // get checkout directory
final String remoteUrl     = stepProps['source/remoteUrl']
final String branch        = stepProps['source/branch']
final String remoteName    = stepProps['source/remoteName']
//final String sourceRevision= stepProps['source/revision'];
final String userExcludesString   = stepProps['source/excludeUsers'] ?: ''
final String fileFiltersString    = stepProps['source/fileFilters'] ?: '';

// Step
final String message   = stepProps['message'] ?: ''
final String label     = stepProps['label'] ?: '';

// look for date based checkout (buildlife, then actual workspace date)
final Date date         = dateParser.parseDate(stepProps['date']) // this is from actualWorkspaceDate
final Date blDate       = dateParser.parseDate(stepProps['buildlife/workspace.date.$srcName']); // from checkout step
final String blRevision = stepProps["buildlife/workspace.revision.$srcName"];

//------------------------------------------------------------------------------
// PREPARE COMMAND LINE
//------------------------------------------------------------------------------

println "Source Name: " + srcName
println "Revision: " + blRevision

dir.mkdirs()

SCMTag step = new SCMTag();
step.directory  = dir;
step.scmCommand = scmCmd;
step.remoteBaseUrl  = baseUrl;
step.remoteUser = username;
step.remotePass = password;
step.remoteUrl  = remoteUrl;
step.remoteName = remoteName;
step.branch     = branch;
step.revision   = blRevision;

step.message = message;
step.tagName = label;
step.execute();