package com.urbancode.air.plugin.analytics

class SonargraphSummary {
    
    String name
    String description
    String severity
    int count
    
    SonargraphSummary(String name, String description, String severity) {
        this.name = name;
        this.description = description
        this.severity = severity
    }

}