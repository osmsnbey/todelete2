final def workDir = new File('.').canonicalFile
final def props = new Properties();
final def inputPropsFile = new File(args[0]);
try {
    inputPropsStream = new FileInputStream(inputPropsFile);
    props.load(inputPropsStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}

final def dir = props['dir']

try {
    dir.eachLine {
        if (new File(it).canonicalFile.mkdirs()) {
            println "Created new directory $it"
        }
        else {
            println "Directory $it already exists!"
        }
    }
}
catch (Exception e) {
    println "Error creating directory $dir: ${e.message}"
    System.exit(1)
}

System.exit(0)

