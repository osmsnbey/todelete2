package com.urbancode.air.plugin.test.mstest

class UnitTest {
    def name
    def className

    public UnitTest(def name, def className) {
        this.name = name
        this.className = className
    }
}
