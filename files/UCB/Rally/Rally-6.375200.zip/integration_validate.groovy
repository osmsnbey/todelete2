if(rallyPass && passScript) {
  errors.rallyPass = "Either Password or Password Script must be empty!"
  errors.passScript = "Either Password or Password Script must be empty!"
}