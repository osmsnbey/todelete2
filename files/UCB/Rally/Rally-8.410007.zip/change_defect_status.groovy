import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def out = System.out

//-------------------------------------------------------------------------
// Scripts variables
//=========================================================================

final def props = apTool.getStepProperties()

//get rally props for GETS and POSTS to rally
final String base_url       = new URL(props['automation/rallyUrl']).getHost()
final String url            = props['automation/rallyUrl'] + "/slm/webservice/" + props['automation/rallyVer']+"/"
final String user           = props['automation/rallyUser']
final String password       = props['automation/rallyPass'] ?: props['automation/passScript']
final String proxyHost      = props['automation/proxyHost']
final String proxyPort      = props['automation/proxyPort']
final String proxyPass      = props['automation/proxyPass']
final String proxyUser      = props['automation/proxyUser']
final String workspace      = props['automation/workspace']

final String defectKey      = props['defectKey']
final String defectType     = props['type']
final String newState       = props['newState']

println "Server:\t" + props['automation/rallyUrl']
println "Url:\t" + url
println "State:\t" + newState
println "Defect:\t"+ defectKey
println "Type:\t" + defectType

//-------------------------------------------------------------------------
// Execute
//=========================================================================

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.base_url = base_url
cds.url = url
cds.user = user
cds.password = password
cds.proxyHost = proxyHost
cds.proxyPort = proxyPort
cds.proxyPass = proxyPass
cds.proxyUser = proxyUser
cds.workspace = workspace

cds.defectKey = defectKey
cds.defectType = defectType
cds.newState = newState

cds.execute()