package com.urbancode.air.plugin.test.cppunit

public class TestCaseResult {

    String scope = null
    String name = null
    String failureType = null
    String line = null
    String message = null

    public boolean isSuccessful() {
        return failureType == null
    }
}
