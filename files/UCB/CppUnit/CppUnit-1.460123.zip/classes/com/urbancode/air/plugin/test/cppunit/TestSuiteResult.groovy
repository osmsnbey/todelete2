package com.urbancode.air.plugin.test.cppunit

public class TestSuiteResult {

    String name = null
    List<TestCaseResult> testCaseList = new ArrayList<TestCaseResult>()
}
