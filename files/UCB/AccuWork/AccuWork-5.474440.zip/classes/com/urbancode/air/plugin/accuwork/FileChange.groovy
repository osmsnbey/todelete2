package com.urbancode.air.plugin.accuwork

public class FileChange {
    
    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    String changeId
    String issueId
    String name
    String type
    String status
    String description
    String issueUrl
    String repoId
    String depotName
    
    public FileChange(String changeId, String issueId, String repoId, String depotName, String issueUrl) {
        this.changeId = changeId
        this.issueId = issueId
        this.repoId = repoId
        this.depotName = depotName
        this.issueUrl = issueUrl
    }
    
    @Override
    public int hashCode() {
        return changeId.hashCode() +
            (issueId.hashCode() * 3) +
            (repoId.hashCode() * 7) +
            (depotName.hashCode() * 11)
    }
    
    @Override
    public boolean equals(Object object) {
        if (object instanceof FileChange) {
            FileChange fc = (FileChange) object
            return changeId.equals(fc.changeId) &&
                issueId.equals(fc.issueId) &&
                repoId.equals(fc.repoId) &&
                depotName.equals(fc.depotName)
        }
        else {
            return false
        }
    }
}