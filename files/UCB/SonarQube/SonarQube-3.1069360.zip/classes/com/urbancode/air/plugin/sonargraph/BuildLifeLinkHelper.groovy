/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.sonargraph

import groovy.xml.MarkupBuilder

import org.apache.http.HttpResponse
import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity

import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.IO

public class BuildLifeLinkHelper {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    public BuildLifeLinkHelper() {
    }

    private String generateXml(String linkName, String linkUrl) {
        def writer = new StringWriter()
        def xml = new MarkupBuilder(writer)
        xml.links() {
            link() {
                name(linkName)
                url(linkUrl)
                description("The SonarQube dashboard for ${linkName}")
            }
        }

        return writer.toString();
    }

    public void uploadBuildLifeLink(String name, String linkUrl) {
        def authToken = System.getenv("AUTH_TOKEN")
        String buildLifeId = System.getenv("BUILD_LIFE_ID")

        String xml = generateXml(name, linkUrl)

        // construct the URL with property replacements
        String baseUrl = System.getenv("WEB_URL")

        baseUrl += baseUrl.endsWith("/") ? "" : "/"
        String url = baseUrl + "rest/buildlife/${buildLifeId}/links"

        HttpPost postMethod = new HttpPost(url)
        if (authToken) {
            postMethod.addHeader("Authorization-Token", authToken)
            postMethod.addHeader("Content-Type", "application/xml")
        }

        println "Uploading new Build Life link: \"${name}\" (points to ${linkUrl})"
        postMethod.setEntity(new StringEntity(xml))

        HttpClientBuilder builder = new HttpClientBuilder()
        builder.setTrustAllCerts(true)
        HttpClient client = builder.buildClient()

        HttpResponse response = client.execute(postMethod)
        def responseCode = response.statusLine.statusCode
        InputStream responseStream = response.entity.content
        if (isGoodResponseCode(responseCode)) {
            IO.copy(responseStream, System.out)
            println ""
        }
        else {
            IO.copy(responseStream, System.err)
            throw new RuntimeException("Failed to upload Build Life links. StatusCode: ${responseCode}")
        }
    }

    private boolean isGoodResponseCode(int responseCode) {
        return responseCode >= 200 && responseCode < 300;
    }

    private def encode = {
        return !it ? it : new java.net.URI(null, null, it, null).toASCIIString()
    }
}
