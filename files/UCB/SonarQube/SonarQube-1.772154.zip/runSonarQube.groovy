#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.air.plugin.sonargraph.BuildLifeLinkHelper

//------------------------------------------------------------------------------
// Utility methods and classes
//------------------------------------------------------------------------------

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def workDir = new File('.').canonicalFile
final CommandHelper cmdHelper = new CommandHelper(workDir)

final def addBuildLifeLink = { linkName, linkUrl ->
    def linkHelper = new BuildLifeLinkHelper()
    linkHelper.uploadBuildLifeLink(linkName, linkUrl)
}

//-------------------------------------------------------------------------
// Scripts variables
//-------------------------------------------------------------------------

final def PROP_FILE_NAME = "sonar-project.properties"
final def props = apTool.getStepProperties()

final def sonarCmd        = props['automation/commandPath'] ?: 'sonar-runner'
final def sonarUrl        = props['automation/sonarUrl']

final def projectKey      = props['projKey']
final def projectName     = props['projName']
final def srcDir          = props['srcDir']
final def excludes        = props['excludes']
final def version         = props['version'] ?: '1.0'
final def language        = props['language']
final def properties      = props['properties']

//------------------------------------------------------------------------------
// Script content
//------------------------------------------------------------------------------

File propsFile = new File(PROP_FILE_NAME)
try {
    // Configure SonarQube settings
    if (sonarUrl) {
        propsFile << "sonar.host.url=${sonarUrl}\n"
    }
    if (language) {
        propsFile << "sonar.language=${language}\n"
    }
    if (excludes) {
        propsFile << "sonar.exclusions=${excludes}\n"
    }

    if (properties) {
        properties.split('\\s+').each() {property ->
            if (property) {
                propsFile << property
            }
        }
    }

    propsFile << "sonar.sources=${srcDir}\n"
    propsFile << "sonar.projectKey=${projectKey}\n"
    propsFile << "sonar.projectName=${projectName}\n"
    propsFile << "sonar.projectVersion=${version}\n"

    println "Listing properties in the ${PROP_FILE_NAME} file"
    propsFile.eachLine {
        println it
    }

    cmdHelper.runCommand("Executing SonarQube", [sonarCmd])

    def sonarLink = sonarUrl + (sonarUrl.endsWith("/") ? "" : "/") + "project/index/${projectKey}"
    addBuildLifeLink("SonarQube: ${projectName}", sonarLink)
}
finally {
    if (propsFile.exists()) {
        propsFile.delete()
    }
}
