/*
* Licensed Materials - Property of HCL
* HCL Launch
* (c) Copyright HCL Technologies Ltd. 2018, 2019 , 2020. All Rights Reserved.
*/
import java.util.zip.*

import com.urbancode.air.AirPluginTool

final AirPluginTool airPluginTool = new AirPluginTool(this.args[0], this.args[1])
final Properties props = airPluginTool.getStepProperties()

def isEmpty(value) {
    return value == null || value.equals("")
}

def extractWAR(war, workDirString) {
    def zis = new ZipInputStream(new FileInputStream(war))
    def warEntry = zis.getNextEntry()
    while (warEntry != null) {
        def fileName = warEntry.getName()
        if (fileName =~ /(?i)web.xml/) {
            def newFile = new File(workDirString + File.separator + fileName)
            new File(newFile.getParent()).mkdirs()
            def outstream = new FileOutputStream(newFile)
            def buf = new byte[1024]
            def len = 0;
            while ((len = zis.read(buf)) > 0) {
                outstream.write(buf, 0, len);
            }
            outstream.close()
        }
        zis.closeEntry()
        warEntry = zis.getNextEntry()
        }
    zis.close()
}

def getWebModuleName(war, workDirString) {
    extractWAR(war, workDirString)
    def webXML = new File(workDirString + "WEB-INF" + File.separator + "web.xml")
    def webModName = ''
    if (webXML.exists()) {
        def webApp = new XmlParser(false, false).parse(webXML)
        def displayName = webApp."display-name"[0]
        if (!isEmpty(displayName)) {
            webModName = displayName.value()[0]
        }
    }
    return webModName
}

def findApplicationOID(name, tool, props) {
    def wpUser = props['wpUser']
    def wpPass = props['wpPass']
    def wasUser = props['wasUser']
    def wasPass = props['wasPass']

    // if user did not specify WAS user credentials, use portal credentials (behavior before version 6)
    if (wasUser.equals("")) {
      wasUser = props['wpUser']
    }
    if (wasPass.equals("")) {
      wasPass = props['wpPass']
    }

    File tempFile = new File("temp.py")
    tempFile.deleteOnExit();
    BufferedWriter temp = new BufferedWriter(new FileWriter(tempFile))
    temp.writeLine("Portal.login('" + wpUser + "', '" + wpPass + "')")
    temp.writeLine("try:")
    temp.writeLine("\tprint Portlet.find('webmodule', 'name', '" + name + "')")
    temp.writeLine("except:")
    temp.writeLine("\tprint 'Not Found'")
    temp.writeLine("Portal.logout()")
    temp.close()

    def commandArgs = []
    commandArgs << tool
    if (props["connectionPort"]) {
        commandArgs << "-port"
        commandArgs << props["connectionPort"]
    }
    commandArgs << "-username"
    commandArgs << wasUser
    commandArgs << "-password"
    commandArgs << wasPass
    commandArgs << "-lang"
    commandArgs << "jython"
    commandArgs << "-f"
    commandArgs << "temp.py"

    def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
    println "commandArgs ==> " + commandArgs.join(' ');
    def procBuilder = new ProcessBuilder(commandArgs)
    if (isWindows) {
        def envMap = procBuilder.environment()
        envMap.put("PROFILE_CONFIG_ACTION", "true")
    }

    def statusProc = procBuilder.start()
    def reader = new BufferedReader(new InputStreamReader(statusProc.getInputStream()))
    def outputLines = []
    def line = reader.readLine()
    // Find the OID
    while (line != null) {
        println "line ==> " + line;
        outputLines << line
        line = reader.readLine()
    }

    String result = "Not Found";
    if (outputLines.size() > 0) {
        println "outputLines size ==> " + outputLines.size();
        println "outputLines == > " + outputLines;
        // OID is the last line of the outputLines
        result = outputLines.get(outputLines.size()-1)
        println "result ==> " + result;
    }

    if (!(result.equals("Not Found"))) {
        /* No exception caught searching for the OID */
        return result
    } else {
        return '' /* An exception caught searching for the OID */
    }
}

def computeURL(props) {
    def host = props['vpHost']
    if (isEmpty(host)) {
        host = System.getenv("HOSTNAME");
    }

    def wpContextRoot = props['wpContextRoot']
    if (! isEmpty(wpContextRoot)) {
        if (!wpContextRoot.startsWith("/")) {
            wpContextRoot = "/" + wpContextRoot
        }
    } else {
        wpContextRoot = "/wps"
    }

    def urlString = "http://" + host + ":" + props['vpPort'] + wpContextRoot + "/config"

    def urlContext = props['vpContext']
    if (! isEmpty(urlContext)) {
        if (!urlContext.startsWith("/")) {
            urlContext = "/" + urlContext
        }
        urlString = urlString + urlContext
    }

    return urlString
}

////////////// MAIN ////////////////////
def xmlScript = '''
<request
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="PortalConfig_6.1.0.xsd"
    type="update">

    <portal action="locate">
    <web-app active="true" removable="true">
    </web-app>
    </portal>

</request>
'''
final def isWindows = (System.getProperty('os.name') =~ /(?i)windows/).find()
def wpscript = isWindows ? "wpscript.bat" : "wpscript.sh"
def xmlaccess = isWindows ? "xmlaccess.bat" : "xmlaccess.sh"

def componentName = new File(".").getCanonicalFile().name
def workDirString = new File(".").getCanonicalPath() + File.separator

def portalHome = props['portalHome']
if (!(portalHome.endsWith("\\") || portalHome.endsWith("/"))) {
    portalHome = portalHome + File.separator
}

def profHome = props['profHome']
if (!(profHome.endsWith("\\") || profHome.endsWith("/"))) {
    profHome = profHome + File.separator
}

def war = props['war']
if (isEmpty(war)) {
    war = componentName
}
if (!(war =~ /(?i)\.war/)) {
    war = war + ".war"
}

def webModName = getWebModuleName(war, workDirString)
if (isEmpty(webModName)) {
    webModName = componentName
}

def displayName = props['displayName']
if (isEmpty(displayName)) {
    displayName = "PA_" + webModName.replaceAll("\\s+", "_")
}
def contextRoot = props['contextRoot']
if (isEmpty(contextRoot)) {
    contextRoot = "/wps/" + displayName
}
if (!contextRoot.startsWith("/")) {
    contextRoot = "/" + contextRoot
}

def request = new XmlParser(false, false).parseText(xmlScript)
def portal = request.portal[0]
def webapp = portal.children()[0]

webapp.appendNode("url", "file://localhost" + workDirString + war)//TODO for windows
webapp.appendNode("context-root", contextRoot)
webapp.appendNode("display-name", displayName)

def application_oid = findApplicationOID(webModName, portalHome + "bin" + File.separator + wpscript, props)
if (!isEmpty(application_oid)) {
    webapp.@action = "update"
    webapp.@objectid = application_oid.toString()
} else {
    webapp.@action = "create"
}

def inputScript = "xmlAccessScript.xml"
def xmlNodePrinter = new XmlNodePrinter(new PrintWriter(new FileWriter(inputScript)))
xmlNodePrinter.with {
    preserveWhitespace = true
}
xmlNodePrinter.print(request)

def configPath = profHome + "PortalServer" + File.separator + "bin" + File.separator + xmlaccess
def deployWARCommandArgs = [configPath]
if (props['useSOAPProps'].equals("true")) {
    deployWARCommandArgs.add("-useEncryptedCredentials")
    deployWARCommandArgs.add(profHome + "properties" + File.separator + "soap.client.props")
} else {
    deployWARCommandArgs.add("-user")
    deployWARCommandArgs.add(props['wpUser'])
    deployWARCommandArgs.add("-password")
    deployWARCommandArgs.add(props['wpPass'])
}

def urlString = computeURL(props)

deployWARCommandArgs.add("-url")
deployWARCommandArgs.add(urlString)
deployWARCommandArgs.add("-in")
deployWARCommandArgs.add(workDirString + inputScript)
deployWARCommandArgs.add("-out")
deployWARCommandArgs.add(workDirString + (inputScript.substring(0, inputScript.length() - 4) + "_out.xml"))

println deployWARCommandArgs.join(' ');
def procBuilder = new ProcessBuilder(deployWARCommandArgs);

if (isWindows) {
    def envMap = procBuilder.environment();
    envMap.put("PROFILE_CONFIG_ACTION", "true");
}

def statusProc = procBuilder.start();
def outPrint = new PrintStream(System.out, true);
statusProc.waitForProcessOutput(outPrint, outPrint);
System.exit(statusProc.exitValue());
