/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.ContentType
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.util.EntityUtils
import org.codehaus.jettison.json.JSONObject

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()

String velocityUrl = props['automation/velocityUrl']
String velocityBearerToken = props['automation/velocityBearerToken']
String buildLifeId = props['uBuildLifeId']
String name = props['name']
String externalId = props['applicationExternalId']
String appName = props['applicationName']
String tenantId = props['tenantId']
String status = props['status']
String url = props['ucbUrl']
String startTime = props['startTime']
String requester = props['requesterName']
long revision = Long.valueOf(props['revision'] as String)
long number = Long.valueOf(props['buildNumber'] as String)
String source = props['source']

if (!velocityUrl.endsWith('/')) {
    velocityUrl += '/'
}

CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder()
builder.setTrustAllCerts(true)
builder.setPreemptiveAuthentication(true)

CloseableHttpClient httpClient = null
CloseableHttpResponse response = null

try {
    httpClient = builder.buildClient()
    JSONObject payload = new JSONObject()
    payload.put("id", buildLifeId)
    payload.put("name", name)
    JSONObject application = new JSONObject()
    application.put("name", appName)
    application.put("externalId", externalId)
    payload.put("application", application)
    payload.put("tenant_id", tenantId)
    payload.put("status", status)
    payload.put("url", url)
    payload.put("startTime", startTime)
    payload.put("requester", requester)
    payload.put("revision", revision)
    payload.put("number", number)
    payload.put("source", source)

    println("Uploading Build Info to UrbanCode Velocity...")

    HttpPost postMethod = new HttpPost(velocityUrl + 'api/v1/builds')
    postMethod.setHeader("Authorization", "Bearer " + velocityBearerToken)
    postMethod.setEntity(new StringEntity(payload.toString(), ContentType.APPLICATION_JSON))

    response = httpClient.execute(postMethod)
    String resStr = EntityUtils.toString(response.getEntity())

    int statusCode = response.getStatusLine().getStatusCode()
    if (statusCode < 200 || statusCode >= 300) {
        throw new RuntimeException("Bad response when uploading metrics file: $statusCode - $resStr")
    }
    println("Successfully uploaded metrics data.")
}
finally {
    if (response) {
        response.close()
    }
    if (httpClient) {
        httpClient.close()
    }
}