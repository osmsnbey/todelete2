package com.urbancode.air.plugin.automation

import com.urbancode.air.*


public class AutomationBase {
    
    //*********************************************************************************************
    // CLASS
    //*********************************************************************************************
    
    //*********************************************************************************************
    // INSTANCE
    //*********************************************************************************************
    
    final def workDir = new File('.').canonicalFile
    CommandHelper ch = new CommandHelper(workDir)
    String fileSep = File.separator
    
    String serverUrl
    String serverUserName
    String serverPassword
    String tfsVersion
}