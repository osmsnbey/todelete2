import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String serverUrl = props['automation/serverUrl']
final String serverUserName = props['automation/serverUserName']
final String serverPassword = props['automation/serverPassword']
final String tfsVersion = props['automation/tfsVersion']

final String issueProject = props['issueProject']
final String type = props['type']
final String title = props['title']
final String assignedTo = props['assignedTo']
final String description = props['description']


CreateDefect cd = new CreateDefect()
cd.serverUrl = serverUrl
cd.serverUserName = serverUserName
cd.serverPassword = serverPassword
cd.tfsVersion = tfsVersion

cd.issueProject = issueProject
cd.type = type
cd.title = title
cd.assignedTo = assignedTo
cd.description = description

cd.execute()