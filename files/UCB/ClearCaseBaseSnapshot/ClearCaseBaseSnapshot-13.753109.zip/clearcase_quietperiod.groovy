import com.urbancode.air.*
import com.urbancode.air.plugin.clearcasebasesnapshot.*

//standard preamble stuff
def apTool = new AirPluginTool(args[0], args[1]);
def props = apTool.getStepProperties();
ClearCaseHelper clearCaseHelper = new ClearCaseHelper(apTool, props);
clearCaseHelper.getChangeLogStep(true);
clearCaseHelper.uploadLastUpdatedTime();