/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2015. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/



class StatusBase {
    String name
    String description
    String color


    StatusBase(String sName, String sDesc, String sColor) {
        name = sName
        description = sDesc
        color = sColor
    }

    public String getName() {
       return name

    }
    public String getDescription() {
        return description

    }
    public String getColor() {
        return color
    }

}
