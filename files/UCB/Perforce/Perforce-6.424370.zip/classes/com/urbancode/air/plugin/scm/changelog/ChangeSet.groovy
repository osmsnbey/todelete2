package com.urbancode.air.plugin.scm.changelog

public class ChangeSet {
    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    String id= null;
    String user = null;
    String message = null;
    Date date = null; 
    final Set<ChangeSetFileEntry> fileSet = [];
    Map<String,String> properties = [:];
    
    public boolean hasAllowedPath(ChangeSetFilter changeSetFilter) {
        return fileSet.find{ changeSetFilter.pathIsIncluded(it.path) } != null;
    }
    
    public boolean hasAllowedAuthor(ChangeSetFilter changeSetFilter) {
        return changeSetFilter.authorIsIncluded(user);
    }
}
