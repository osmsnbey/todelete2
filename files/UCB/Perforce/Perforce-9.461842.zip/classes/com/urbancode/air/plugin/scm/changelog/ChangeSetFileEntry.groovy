package com.urbancode.air.plugin.scm.changelog

public class ChangeSetFileEntry {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    String type = null; // A D M
    String revision = null; // should match changeSet.id
    String path = null;
}