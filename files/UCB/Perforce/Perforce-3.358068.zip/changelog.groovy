import com.urbancode.air.*
import com.urbancode.air.plugin.scm.*
import java.text.SimpleDateFormat

final def apTool = new AirPluginTool(args[0], args[1])
def DateParser dateParser = new DateParser()

//------------------------------------------------------------------------------
// GET ALL INPUT PARAMETERS
//------------------------------------------------------------------------------

final def  workDir           = new File('.').canonicalFile
final File resourceHome      = new File(System.getenv()['PLUGIN_HOME'])
final def  props             = apTool.getStepProperties()

final def client             = props['source/client']
final boolean isLoggingIn    = Boolean.valueOf(props['source/isLoggingIn'])
final def commandPath        = props['source/repo/commandPath'] ?: 'p4'
final def port               = props['source/repo/port']
final def username           = props['source/repo/username']
final def password           = props['source/repo/password'] ?: props['source/repo/passScript']
final def charset            = props['source/repo/charset']
final def commandCharset     = props['source/repo/commandCharset']

final def userExcludes       = props['source/excludeUsers']
final def fileFilters        = props['source/fileFilters']

final def dir                = new File(workDir, props['source/dirOffset']).canonicalFile

// Timezone Difference is in hours and can be a decimal like 1.5
final Double timeDifference  = props['buildlife/timezoneDifference']?.toDouble()

final def startDate          = dateParser.parseDate(props['startDate']).getTime()
final def endDate            = dateParser.parseDate(props['endDate']).getTime()
final def persistToDB        = Boolean.valueOf(props['persistingChanges'])
final def changesUrl         = props['changesUrl']

dir.mkdirs()

SCMChangelog changelog = new SCMChangelog();
// Login info
changelog.scmCommand = commandPath
changelog.isLoggingIn = isLoggingIn
changelog.client = client
changelog.port = port
changelog.username = username
changelog.password = password
changelog.charset = charset
changelog.commandCharset = commandCharset

// Changelog Info
changelog.startDate = startDate
changelog.endDate = endDate
changelog.changeSetFilter.setUserExcludes(userExcludes);
changelog.changeSetFilter.setFileFilters(fileFilters);
changelog.timezoneDifference = timeDifference
changelog.changesUrl = changesUrl

changelog.workDir = dir

changelog.execute()