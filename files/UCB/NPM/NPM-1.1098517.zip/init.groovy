/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2017. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()
final File workDir = new File('.').canonicalFile
CommandHelper ch = new CommandHelper(workDir)

String NPMExecutable = props['NPMExecutable'] ?: "npm"

List<String> initCommandLine = [NPMExecutable, "init", "-y"]

ch.runCommand("Creating package.json file with default values", initCommandLine)

//write the output properties to the file
apTool.storeOutputProperties()