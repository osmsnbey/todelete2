/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.plugin.automation.UploadReport


import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def stepProps = apTool.getStepProperties()
final def workDir = new File('.').canonicalFile

final String reportXml = stepProps['reportXml']
final String reportName = stepProps['reportName']


UploadReport step = new UploadReport();
step.reportXml = reportXml;
step.reportName = reportName;
step.parseAndUploadResults()