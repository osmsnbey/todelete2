/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import com.urbancode.air.plugin.automation.RunScript


import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*


final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def stepProps = apTool.getStepProperties()
final def workDir = new File('.').canonicalFile

//path is the file AppScanSrcCli.exe's path
final String path = stepProps['automation/path']
final String scriptFile = stepProps['scriptFile']


RunScript step = new RunScript();
step.path = path;
step.scriptFile = scriptFile;
step.runScript()
