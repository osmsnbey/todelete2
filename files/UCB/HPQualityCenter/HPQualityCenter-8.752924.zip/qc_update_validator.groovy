/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
if (!assignee && !summary && !priority && !severity && !status && !props) {
    errors.assignee = "Step currently updates nothing. Supply a value to one of these."
	errors.summary  = "Step currently updates nothing. Supply a value to one of these."
	errors.priority = "Step currently updates nothing. Supply a value to one of these."
	errors.severity = "Step currently updates nothing. Supply a value to one of these."
	errors.status   = "Step currently updates nothing. Supply a value to one of these."
	errors.props    = "Step currently updates nothing. Supply a value to one of these."
}