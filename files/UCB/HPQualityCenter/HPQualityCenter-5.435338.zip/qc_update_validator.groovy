if (!assignee && !summary && !priority && !severity && !status && !props) {
    errors.assignee = "Step currently updates nothing. Supply a value to one of these."
	errors.summary  = "Step currently updates nothing. Supply a value to one of these."
	errors.priority = "Step currently updates nothing. Supply a value to one of these."
	errors.severity = "Step currently updates nothing. Supply a value to one of these."
	errors.status   = "Step currently updates nothing. Supply a value to one of these."
	errors.props    = "Step currently updates nothing. Supply a value to one of these."
}