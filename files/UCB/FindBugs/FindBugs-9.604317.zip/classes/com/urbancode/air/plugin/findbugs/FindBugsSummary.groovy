/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.findbugs

class FindBugsSummary {
    
    String name
    String description
    String severity
    int count
    
    FindBugsSummary(String name, String description, String severity) {
        this.name = name;
        this.description = description
        this.severity = severity
    }

}