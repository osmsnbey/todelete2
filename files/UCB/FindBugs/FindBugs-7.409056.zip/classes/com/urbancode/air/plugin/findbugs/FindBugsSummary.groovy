package com.urbancode.air.plugin.findbugs

class FindBugsSummary {
    
    String name
    String description
    String severity
    int count
    
    FindBugsSummary(String name, String description, String severity) {
        this.name = name;
        this.description = description
        this.severity = severity
    }

}