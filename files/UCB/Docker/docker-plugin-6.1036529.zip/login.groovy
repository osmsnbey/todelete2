/*
 * Licensed Materials - Property of IBM* and/or HCL**
 * UrbanCode Build
 * (c) Copyright IBM Corporation 2012, 2017. All Rights Reserved.
 * (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 *
 * * Trademark of International Business Machines
 * ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])

final def stepProps = apTool.getStepProperties()
final def workDir = new File('.').canonicalFile
CommandHelper commandHelper = new CommandHelper(workDir)

String dockerOptions = stepProps['dockerOptions']
String username = stepProps['username']
String password = stepProps['password']
String server = stepProps['server']
String dockerRuntimeOptions

if (dockerOptions) {
    dockerOptions.split('\\s+').each() { dockerOption ->
        if (dockerOption) {
            dockerRuntimeOptions << dockerOption
        }
    }
}
if (!username) {
    throw new Exception("Username is not set")
}
if (!password) {
    throw new Exception("Password is not set")
}

def loginCommandLine = ['docker']
if (dockerRuntimeOptions) {
    loginCommandLine << dockerRuntimeOptions
}
loginCommandLine << 'login'
loginCommandLine << "-u=${username}"
loginCommandLine << "-p=${password}"

if (server) {
    loginCommandLine << server
}
commandHelper.runCommand("Logging in to the Docker registry", loginCommandLine)
