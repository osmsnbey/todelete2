import com.urbancode.air.*
import com.urbancode.air.plugin.scm.*

final def workDir = new File('.').canonicalFile

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def dateParser = new DateParser()

final SCMHelper scmHelper = new SCMHelper()
final def stepProps = apTool.getStepProperties()

final String host         = stepProps['source/repo/host']
final String username     = stepProps['source/repo/username']
final String password     = stepProps['source/repo/password'] ?: stepProps['source/repo/passScript']
final String scmCommand = stepProps['source/repo/commandPath'] ?: 'dmcli'
final String database     = stepProps['source/repo/database']
final String dsn          = stepProps['source/repo/dsn']

final String srcName      = stepProps['source']
final File dir          = new File(workDir, stepProps['source/dirOffset'] ?: '.').canonicalFile // get checkout directory
final String workset      = stepProps['source/workset']
final String templateId   = stepProps['source/templateId'] ?: "ALL_ITEMS_LATEST"
final String part         = stepProps['source/part']
final String product      = stepProps['source/productId']
final String newLabelName = stepProps['label']

// use buildlife revision (from checkout), then buildlife revision
final String blRevision   = stepProps["buildlife/workspace.revision.$srcName"]
final String srcRevision  = stepProps['source/revision']

// use step-date, buildlife date (from checkout), then global workspace date
final Date date           = dateParser.parseDate(stepProps['date'])
final Date blDate         = dateParser.parseDate(stepProps["buildlife/workspace.date.$srcName"])
final Date wsDate         = dateParser.parseDate(stepProps['buildlife/workspace.date'])

//------------------------------------------------------------------------------
// PREPARE COMMAND LINE
//------------------------------------------------------------------------------

SCMTag tag = new SCMTag()
tag.scmCommand = scmCommand
tag.host = host
tag.username = username
tag.password = password
tag.database = database
tag.dsn = dsn

tag.directory = dir
tag.part = part
tag.templateId = templateId
tag.workset = workset
tag.product = product

tag.revision = blRevision ?: srcRevision
tag.date = date ?: blDate ?: wsDate
tag.tag = newLabelName
tag.execute()