package com.urbancode.air.plugin.scm;

import com.urbancode.air.*

import java.io.File;
import java.util.Date;
import java.util.regex.Pattern
import com.urbancode.commons.util.IO
import org.apache.commons.lang.math.RandomUtils;

abstract public class SCMStep {

    //**************************************************************************
    // CLASS
    //**************************************************************************
    static protected final String REPO_TYPE = 'dimensions'
    static protected final SCMHelper scmHelper = new SCMHelper()
    static protected final String CMD_FILE = "dmCmdFile";
    static protected final String PARAM_FILE = "dmDownloadParam";
    static protected final String DM_DOWNLOAD_PARAM = "DM_DOWNLOAD_PARAM";
    
    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    String scmCommand = "dmcli";

    String host = null;
    String username = null;
    String password = null;
    String database = null
    String dsn = null
    
    String product = null

    File cmdFile
    File paramFile
    File directory;
    Date date;
    
    final CommandHelper cmdHelper = new CommandHelper(directory);

    protected String prependProductId(String value) {
        String result = null;

        println "Prepending product id to ${value}"
        if (value.indexOf(":") <= 1) {
            result = product + ":" + value;
        }
        else {
            result = value;
        }

        println "New name: ${result}"
        return result;
    }
    
    protected void cleanupFiles() {
        cmdFile = new File(directory, CMD_FILE)
        paramFile = new File(directory, PARAM_FILE)
        
        if (cmdFile.exists()) {
            cmdFile.delete()
        }
        
        if (paramFile.exists()) {
            paramFile.delete()
        }
    }
}
