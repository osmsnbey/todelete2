package com.urbancode.air.plugin.scm

import com.urbancode.air.*

import java.io.File
import java.util.Date

public class SCMTag extends SCMStep {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    def date
    def revision
    String tag
    String part
    String workset
    String templateId

    /**
     *
     */
    public void execute() {
        if (workset) {
            workset = prependProductId(workset)
        }
        
        prepareCommandLineFile()
        def command = prepareCommand()
        cmdHelper.runCommand("Adding label to source", command)
        
        cleanupFiles()
    }
    
    public void prepareCommandLineFile() {
        File cmdFile = new File(directory, CMD_FILE)
        cmdFile.delete()
        FileOutputStream fos = new FileOutputStream(cmdFile, true)
        Writer writer = new BufferedWriter(new OutputStreamWriter(fos, "US-ASCII"))
        try {
            StringBuffer sb = new StringBuffer()
            sb.append("cbl ")
            sb.append("\"" + tag + "\" ")
            sb.append("/PART=\"" + part + "\" ")
            sb.append("/WORKSET=\"" + workset + "\" ")
            sb.append("/TEMPLATE_ID=\"" + templateId + "\"")
            
            writer.write(sb.toString() + "\n")
        }
        finally {
            writer.close()
        }
    }
    
    public def prepareCommand() {
        def command = [scmCommand, 
                "-host", host,
                "-user", username,
                "-pass", password,
                "-dbname", database, 
                "-dsn", dsn,
                "-file", directory.getCanonicalPath() + File.separator + CMD_FILE]
            
        return command
    }
}
