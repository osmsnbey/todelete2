package com.urbancode.air.plugin.scm

import java.text.SimpleDateFormat

import org.apache.http.client.HttpClient
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.DefaultHttpClient

import com.urbancode.air.*
import com.urbancode.air.plugin.scm.changelog.*
import com.urbancode.commons.httpcomponentsutil.HttpClientBuilder
import com.urbancode.commons.util.IO


public class SCMChangelog extends SCMStep {

    //**************************************************************************
    // CLASS
    //**************************************************************************
    final static protected SimpleDateFormat DIMENSIONS_DATE = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss")

    final static public String ITEMS_TOKEN = "ITEMS"
    final static public String ITEM_COUNT_TOKEN = "Number of Items"
    final static public String HEADER_TOKEN = "Work Set Directory"
    final static public String FINISH_TOKEN = "Operation completed"
    final static public String SPECIAL_TOKEN = "Special:"

    final static protected long MIN_MILLIS_BETWEEN_REVISIONS = 2 * 1000

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    // changelog boundaries
    Date startDate = null
    Date endDate = null
    String startRevision = null
    String endRevision = null
    String changesUrl = null
    
    String workset = null

    // filters for changeset
    final ChangeSetFilter changeSetFilter = new ChangeSetFilter()
    List<ChangeSet> changeSets

    public def execute() {
        if (workset) {
            workset = prependProductId(workset)
        }
        
        prepareCommandLineFile()
        def logOutput = runLogCommand()
        
        if (logOutput) {
            parseLogIntoChangeSets(logOutput)
            
            if (changeSets) {
                ChangeSetXMLHelper xmlHelper = new ChangeSetXMLHelper()
                xmlHelper.repoType = REPO_TYPE
                String xml = xmlHelper.toXML(changeSets)
                sendPostRequest(xml)
            }
            else {
                println "No changes detected"
            }
        }
        else {
            println "No changelog found"
        }
        
        cleanupFiles()
    }

    public void parseLogIntoChangeSets(String logOutput) {
        if (!changeSets) {
            changeSets = []
        }

        def fileChangeGroups = createFileChangeSet(logOutput).groupBy{ [it.author, it.comment] }
        def result = groupByDate(fileChangeGroups)

        result.each { fileGroup ->
            ChangeSet changeSet = new ChangeSet()
            def firstChange = fileGroup[0]

            println "Setting Change Set date: ${firstChange.date}"
            println "Setting Change Set user: ${firstChange.author}"
            println "Setting Change Set message: ${firstChange.comment}"
            changeSet.date = firstChange.date
            changeSet.user = firstChange.author
            changeSet.message = firstChange.comment

            fileGroup.each { change ->
                ChangeSetFileEntry entry = new ChangeSetFileEntry()
                
                println "Setting File Entry path: ${change.fileName}"
                println "Setting File Entry type: ${change.state}"
                entry.path = change.fileName
                entry.type = change.state

                changeSet.fileSet << entry
            }

            boolean hasAllowedAuthor = changeSet.hasAllowedAuthor(changeSetFilter)
            boolean hasAllowedFile = changeSet.hasAllowedPath(changeSetFilter)
            
            if (hasAllowedAuthor && hasAllowedFile) {
                changeSets << changeSet
            }
            else {
                def message = new StringBuilder("Changeset skipped because ")
                if (!hasAllowedAuthor) {
                    message << "it has excluded author ${changeSet.user}"
                }
                if (!hasAllowedAuthor && !hasAllowedFile) {
                    message << " and "
                }
                if (!hasAllowedFile) {
                    message << "it contains only excluded file paths (${changeSet.fileSet.collect{it.path}})"
                }
                println message
            }
        }
    }

    protected List<FileChange> createFileChangeSet(String logOutput) {
        List<FileChange> fileChanges = []

        def usernameExp = "^\\s+\\S+"
        def indentedExp = "^\\s+\\S"
        def itemExp = "\"\\S+:.+;\\d+\""
        def dateExp = "\\d{1,2}-\\D{3}-\\d{4} \\d{1,2}:\\d{1,2}:\\d{1,2}"

        def isIndented = false
        def headerDone = false
        def headerTokenFound = false

        String path
        logOutput.eachLine { line ->
            if (line) {
                isIndented = line.find(indentedExp) != null
                if (!headerTokenFound) {
                    if (line.startsWith(HEADER_TOKEN)) {
                        println "Found header token"
                        headerTokenFound = true
                    }
                }
                else if (!headerDone) {
                    if (!line.startsWith(SPECIAL_TOKEN) && !line.trim() && !isIndented) {
                        println "Finished parsing header"
                        headerDone = true
                    }
                }

                if (headerDone) {
                    if (line.trim().startsWith(ITEMS_TOKEN) || line.trim().startsWith(ITEM_COUNT_TOKEN)) {
                        println "Found 'ITEMS:' or 'Number of Items'. Skipping line."
                        // skip this line
                        return
                    }
                    else if (isIndented) {
                        FileChange fileChange = new FileChange()

                        String itemDescriptor = line.find(itemExp) { match, descriptor -> return descriptor }
                        String dateStr = line.find(dateExp) { match, date -> return date }
                        String username = line.find(usernameExp) { match, user -> return user }
                        
                        println "Item Descriptor: ${itemDescriptor}"
                        println "Date String: ${dateStr}"
                        println "Username: ${username}"

                        String fileName
                        int descriptorIndex = line.indexOf(itemDescriptor)
                        int indexEndOfDescriptor = descriptorIndex + itemDescriptor.length()
                        if (line.length() > (indexEndOfDescriptor + 2)) {
                            fileName = line.substring(indexEndOfDescriptor + 1).trim()
                        }

                        int dateIndex = line.indexOf(dateStr)
                        int indexEndOfDate = dateIndex + dateStr.length()

                        String status = line.substring(indexEndOfDate + 1, descriptorIndex).trim()
                        Date changeDate = DIMENSIONS_DATE.parse(dateStr)
                        String fullyQualifiedFilename = path + fileName
                        
                        println "Status: ${status}"
                        println "Change Date: ${changeDate}"
                        println "Filename: ${fullyQualifiedFilename}"
                        println "Path: ${path}"

                        fileChange.author = username
                        fileChange.date = changeDate
                        fileChange.filePath = filePath
                        fileChange.fileName = fullyQualifiedFilename
                        fileChange.state = status
                        fileChange.comment = itemDescriptor

                        fileChanges << fileChange
                    }
                    else {
                        if (line.trim() && !line.startsWith(FINISH_TOKEN)) {
                            // new directory
                            int endColon = line.lastIndexOf(':')
                            path = line.substring(0, endColon).trim()
                        }
                    }
                }
            }
        }

        return fileChanges
    }

    protected def groupByDate(def fileChangeGroups) {
        List<List<FileChange>> result = []
        
        List<List<FileChange>> fileChangeList = []
        fileChangeGroups.each { authorGroup ->
            fileChangeList << authorGroup.value
        }
        
        fileChangeList.each{ List<FileChange> changeGroup ->
            changeGroup = changeGroup.sort{it.date}
            List<FileChange> tmpGroup = null
            changeGroup.eachWithIndex{ FileChange change, i ->
                if (i > 0 && (change.date.time - changeGroup[i-1].date.time < MIN_MILLIS_BETWEEN_REVISIONS)) {
                    tmpGroup << change
                }
                else {
                    tmpGroup = []
                    tmpGroup << change
                    result << tmpGroup
                }
            }
        }
        
        return result
    }
    
    public void prepareCommandLineFile() {
        cmdFile = new File(directory, CMD_FILE)
        cmdFile.delete()
        FileOutputStream fos = new FileOutputStream(cmdFile, true)
        Writer writer = new BufferedWriter(new OutputStreamWriter(fos, "US-ASCII"))
        try {
            StringBuffer sb = new StringBuffer()
            sb.append("lwsd ")
            sb.append("/RECURSIVE ")
            sb.append("/FILES/ITEMS ")
            sb.append("/WORKSET=\"" + workset + "\"")
            
            writer.write(sb.toString() + "\n")
        }
        finally {
            writer.close()
        }
    }
    
    public def prepareCommand() {
        def command = [scmCommand,
            "-host", host,
            "-user", username,
            "-pass", password,
            "-dbname", database,
            "-dsn", dsn,
            "-file", directory.getCanonicalPath() + File.separator + CMD_FILE]
        
        return command
    }
    
    public def runLogCommand() {
        def logOutput
        def command = prepareCommand()
        cmdHelper.runCommand("Getting changes", command) { Process proc ->
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            logOutput = proc.text
            println logOutput
        }
        
        return logOutput?.trim()
    }
    
    private void sendPostRequest(String xml) {
        // construct the URL with property replacements
        String url = changesUrl
        def authToken = System.getenv("AUTH_TOKEN")
        
        println "Sending request to $url"

        // Debug/testing stub
        if (url.startsWith("file://")) {
            File xmlOut = new File(directory, "xmlOut.xml")
            xmlOut << xml
        }
        else {
            HttpClientBuilder clientBuilder = new HttpClientBuilder();
            clientBuilder.setTrustAllCerts(true);
            DefaultHttpClient client = clientBuilder.buildClient();

            HttpPost postMethod = new HttpPost(url);
            if (authToken) {
                postMethod.setHeader("Authorization-Token", authToken)
                postMethod.setHeader("Content-Type", "application/xml")
            }

            println "Sending ${changeSets.size()} changes"
            postMethod.setEntity(new StringEntity(xml));

            def httpResponse = client.execute(postMethod)
            def responseCode = httpResponse.getStatusLine().getStatusCode()
            if (isGoodResponseCode(responseCode)) {
                IO.copy(postMethod.getEntity().getContent(), System.out)
                println ""
            }
            else {
                IO.copy(postMethod.getEntity().getContent(), System.err)
                throw new RuntimeException("Failed to upload source changes. StatusCode: ${responseCode}")
            }
        }
    }
    
    private boolean isGoodResponseCode(int responseCode) {
        return responseCode >= 200 && responseCode < 300
    }
}