package com.urbancode.air.plugin.scm

import com.urbancode.air.*

import java.text.*
import java.util.Date
import java.util.List

public class SCMCheckout extends SCMStep {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    def workset = null
    def baseline = null
    def date
    def revision
    /**
     *
     */
    public void execute() {
        if (baseline) {
            baseline = prependProductId(baseline)
        }
        else if (workset) {
            workset = prependProductId(workset)
        }
        
        prepareCommandLineFile()
        def command = prepareCommand()
        cmdHelper.addEnvironmentVariable(DM_DOWNLOAD_PARAM, directory.getCanonicalPath() + File.separator + PARAM_FILE)
        cmdHelper.runCommand("Populating Workspace", command)
        
        cleanupFiles()
    }
    
    private prepareCommandLineFile() {
        File cmdFile = new File(directory, CMD_FILE)
        cmdFile.delete()
        FileOutputStream fos = new FileOutputStream(cmdFile, true)
        Writer writer = new BufferedWriter(new OutputStreamWriter(fos, "US-ASCII"))
        try {
            StringBuffer sb = new StringBuffer()
            sb.append("download ")
            if (baseline) {
                sb.append("/BASELINE=\"" + baseline + "\" ")
            }
            else if(workset) {
                sb.append("/WORKSET=\"" + workset + "\" ")
            }
            sb.append("/USER_DIRECTORY=\"" + directory.getCanonicalPath() + "\"")
            
            writer.write(sb.toString() + "\n")
        }
        finally {
            writer.close()
        }
    }
    
    private def prepareCommand() {
        def command = [scmCommand,
            "-host", host,
            "-user", username,
            "-pass", password,
            "-dbname", database,
            "-dsn", dsn,
            "-file", directory.getCanonicalPath() + File.separator + CMD_FILE]
        
        return command
    }
}