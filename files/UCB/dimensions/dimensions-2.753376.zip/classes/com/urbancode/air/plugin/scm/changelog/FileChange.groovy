package com.urbancode.air.plugin.scm.changelog

import java.util.Date;

public class FileChange {
    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    // Revision Block
    String revision = null;
    String author = null;
    String state = null;
    String comment = null
    Date date = null;
    
    // File Block
    String fileName = null
    String filePath = null
}
