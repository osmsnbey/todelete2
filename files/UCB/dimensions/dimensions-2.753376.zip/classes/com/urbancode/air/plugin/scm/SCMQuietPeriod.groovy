package com.urbancode.air.plugin.scm

import com.urbancode.air.*
import com.urbancode.air.plugin.scm.changelog.*

import java.util.Date;
import java.util.TimeZone;
import java.text.SimpleDateFormat


public class SCMQuietPeriod extends SCMChangelog {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    /**
     *
     * @return date of the last change
     */
    public def execute() {
        if (workset) {
            workset = prependProductId(workset)
        }
        
        prepareCommandLineFile()
        def logOutput = runLogCommand()
        
        cleanupFiles()
        return getLatestChangeDate(logOutput)
    }
        
    protected def getLatestChangeDate(String logOutput) {
        def latestChangeDate
        
        def fileChangeGroups = createFileChangeSet(logOutput).groupBy{ [it.author, it.comment] }
        def result = groupByDate(fileChangeGroups)
        
        result.each { fileGroup ->
            ChangeSet changeSet = new ChangeSet()
            def firstChange = fileGroup[0]

            println "Change Set Date: ${firstChange.date}"
            def changeSetDate = firstChange.date
            changeSet.user = firstChange.author
            changeSet.message = firstChange.comment

            fileGroup.each { change ->
                ChangeSetFileEntry entry = new ChangeSetFileEntry()
                entry.path = change.fileName
                entry.type = change.state

                changeSet.fileSet << entry
            }

            boolean hasAllowedAuthor = changeSet.hasAllowedAuthor(changeSetFilter)
            boolean hasAllowedFile = changeSet.hasAllowedPath(changeSetFilter)
            
            if (hasAllowedAuthor && hasAllowedFile && latestChangeDate.before(changeSetDate)) {
                println "Updating latest change date to ${changeSetDate}"
                latestChangeDate = changeSetDate
            }
        }
        
        return latestChangeDate
    }
}
