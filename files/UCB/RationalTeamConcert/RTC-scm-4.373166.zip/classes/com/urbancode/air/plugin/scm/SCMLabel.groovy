package com.urbancode.air.plugin.scm


public class SCMLabel extends SCMStep {
    
    String description
    String baselineName
    
    public void execute() {
        createBaseLine()
    }
    
    public void createBaseLine() {
        def cmd = [command, '--non-interactive', 'create', 'baseline',
             '--overwrite-uncommitted',
             '-r', serverUrl,
             '-u', username,
             '-P', password,
             '--description', description ?: "",
             '--all', workspace, 
             baselineName]
        
        getCmdHelper().runCommand('Create baseline', cmd)
    }
}