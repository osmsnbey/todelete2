println("Snapshots are created as part of the Populate Workspace step unless building from snapshot or baseline.")
println("This step should not be used.")