package com.urbancode.air.plugin.scm;

import com.urbancode.air.*

import java.io.File;
import java.util.Date;

abstract public class SCMStep {

    //**************************************************************************
    // CLASS
    //**************************************************************************

    static protected final SCMHelper scmHelper = new SCMHelper();
    static protected final String REPO_TYPE = "svn";

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    def out = System.out;

    String scmCommand = "svn";
    String username = null;
    String password = null;
    File directory;

    CommandHelper cmdHelper = new CommandHelper(directory)

    public void println(String msg) {
        out.println(msg);
    }
}
