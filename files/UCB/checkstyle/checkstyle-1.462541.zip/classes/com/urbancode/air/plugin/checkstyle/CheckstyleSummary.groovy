package com.urbancode.air.plugin.checkstyle

class CheckstyleSummary {
    
    String name
    String description
    String severity
    int count
    
    CheckstyleSummary(String name, String description, String severity) {
        this.name = name;
        this.description = description
        this.severity = severity
    }

}