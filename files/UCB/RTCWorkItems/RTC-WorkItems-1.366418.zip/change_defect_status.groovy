import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String projectName = props['automation/projectName']
final String url = props['automation/url']
final String username = props['automation/username']
final String password = props['automation/password']
final String passScript = props['automation/passScript']

def ids = props['defectKey'].split(',');
final String newState = props['newState'];

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.projectName = projectName
cds.url = url
cds.username = username
cds.password = password
cds.passScript = passScript

cds.ids = ids
cds.newState = newState

cds.execute(props, apTool)