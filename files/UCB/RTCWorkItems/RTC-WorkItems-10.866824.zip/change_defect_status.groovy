/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String projectName        = props['automation/projectName']
final String url                = props['automation/url']
final String username           = props['automation/username']
final String password           = props['automation/password']
final String passScript         = props['automation/passScript']

List<String> ids                = props['defectKey'].split(',').collect{it};
final String action             = props['action'];
final String newState           = props['newState'];
List<String> defectTypes        = props['defectTypes'].split(',').collect{it};

ChangeDefectStatus cds = new ChangeDefectStatus()
cds.projectName = projectName
cds.url = url
cds.username = username
cds.password = password
cds.passScript = passScript

cds.ids = ids
cds.action = action
cds.newState = newState
cds.defectTypes = defectTypes

cds.execute(props, apTool)