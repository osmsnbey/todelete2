package com.urbancode.air.plugin.automation

import com.urbancode.air.*


public class AutomationBase {
    
    //*********************************************************************************************
    // CLASS
    //*********************************************************************************************
    
    //*********************************************************************************************
    // INSTANCE
    //*********************************************************************************************
    
    final def workDir = new File('.').canonicalFile
    
    String projectName
    String url
    String username
    String password
    String passScript
}