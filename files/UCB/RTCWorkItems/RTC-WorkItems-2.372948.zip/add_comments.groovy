import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def props = apTool.getStepProperties()

final String projectName        = props['automation/projectName']
final String url                = props['automation/url']
final String username           = props['automation/username']
final String password           = props['automation/password']
final String passScript         = props['automation/passScript']

String defectPattern            = props['defectPattern'] ?: ".*"
final boolean chnglgComments    = props['chnglgComments']
final String comment            = props['comment']

AddComment ac = new AddComment()
ac.projectName = projectName
ac.url = url
ac.username = username
ac.password = password
ac.passScript = passScript

ac.defectPattern = defectPattern
ac.chnglgComments = chnglgComments
ac.comment = comment

ac.execute(props, apTool)