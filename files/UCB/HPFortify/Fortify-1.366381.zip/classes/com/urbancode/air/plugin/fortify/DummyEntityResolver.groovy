package com.urbancode.air.plugin.fortify

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

class DummyEntityResolver implements EntityResolver {
    InputSource resolveEntity(String publicID, String systemID)
    throws SAXException {
        return new InputSource(new StringReader(""));
    }
}