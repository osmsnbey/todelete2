import com.urbancode.air.*
import com.urbancode.air.plugin.automation.*
import org.codehaus.jettison.json.JSONObject
import groovy.json.JsonSlurper

//------------------------------------------------------------------------------
// GET ALL INPUT PARAMETERS
//------------------------------------------------------------------------------
final def workDir = new File('.').canonicalFile
final def javaHome = System.getenv('JAVA_HOME')
final def webUrl = System.getenv('WEB_URL')
final def authToken = System.getenv('AUTH_TOKEN')
final def buildLifeId = System.getenv('BUILD_LIFE_ID')
final def pluginHome = System.getenv("PLUGIN_HOME")

final def apTool = new AirPluginTool(this.args[0], this.args[1])
final def stepProps = apTool.getStepProperties()
final def CommandHelper cmdHelper = new CommandHelper(workDir)

final def javaFile = new File(new File(javaHome), 'bin/java' + (apTool.isWindows ? '.exe' : ''))
final def udClientJarFile = new File(new File(pluginHome), 'lib/udeploy-client.jar')

def url = stepProps['automation/url']
def user = stepProps['automation/user']
def password = stepProps['automation/passScript'] ?: stepProps['automation/password']
def componentName = stepProps['componentName']
def versionName = stepProps['versionName']
def statusName = stepProps['status']
def description = stepProps['versionDesc']
def includes = stepProps['includes']
def excludes = stepProps['excludes']
def publishFiles = Boolean.valueOf(stepProps['publishFiles'])
def propertiesTextArea = stepProps['propertiesTextArea']

def cmdArgs = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
               "-weburl", url,
               "-username", user,
               "-password", password,
               "createVersion", 
               "-component", componentName,
               "-name", versionName]
if (description) {
    cmdArgs << '-description'
    cmdArgs << description
}

println "Creating version ${versionName} on component ${componentName}"
def versionId = null
def createVersionOutput = null
int exitCode = cmdHelper.runCommand("Creating uDeploy Component Version", cmdArgs){ Process proc ->
    proc.out.close() // close stdin
    proc.consumeProcessErrorStream(System.out) // forward stderr
    createVersionOutput = proc.text.trim()
}
// Only try to parse as JSON if there was no error
if (exitCode == 0) {
    def versionJson = new JSONObject(createVersionOutput)
    versionId = versionJson.getString("id")
}
if (versionId) {
    println "Created version ${versionName} on component ${componentName} with id ${versionId}"
    
    apTool.setOutputProperty("buildlife/udeploy.versionId", versionId)
    apTool.setOutputProperties()
    
    if (statusName) {
        cmdArgs = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
            "-weburl", url,
            "-username", user,
            "-password", password,
            "getStatuses",
            "-type", "version"
           ]
        
        def addVersionCommand = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
            "-weburl", url,
            "-username", user,
            "-password", password,
            "addVersionStatus",
            "-component", componentName,
            "-version", versionName,
            "-status", statusName
           ]

        def statusOutput
        def statusList
        cmdHelper.ignoreExitValue(true)
        int statusExitCode = cmdHelper.runCommand("Getting the list of version statuses", cmdArgs) { proc ->
         proc.out.close() // close stdin
         proc.consumeProcessErrorStream(System.out) // forward stderr
         statusOutput = proc.text.trim()
        }
        cmdHelper.ignoreExitValue(false)
        
        // Only try to parse as JSON if there was no error
        if (statusExitCode == 0) {
            statusList = new JsonSlurper().parseText(statusOutput).name
            if (!statusList) {
                println "No statuses were found on the uDeploy server."
                System.exit(1)
            }
            
            if (!statusList.contains(statusName)) {
                println "The status '${statusName}' does not exist on the uDeploy server. Valid statuses: ${statusList}"
                System.exit(1);
            }
            
            cmdHelper.runCommand("Adding status '${statusName}' to version '${versionName}' on component '${componentName}'", addVersionCommand)
        }
        else {
            println "Could not get any status information from uDeploy. Trying to add the status to the version anyway."
            try {
                cmdHelper.runCommand("Adding status '${statusName}' to version '${versionName}' on component '${componentName}'", addVersionCommand)
            }
            catch (Exception e) {
                println "Failed to assign status ''${statusName}' to version '${versionName}' on component '${componentName}'. " +
                        "This is typically caused by using a status that does not exist."
                System.exit(1);
            }
        }
    }
    
    if (publishFiles) {
        cmdArgs = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
                   "--weburl", url,
                   "--username", user,
                   "--password", password,
                   "addVersionFiles",
                   "--component", componentName,
                   "--version", versionName,
                   "--base", workDir.absolutePath]
        if (includes) {
            includes.split("\\n").each { include ->
                cmdArgs << "--include" << include
            }
        }
        
        if (excludes) {
            excludes.split("\\n").each { exclude ->
                cmdArgs << "--exclude" << exclude
            }
        }
    
        println "Publishing files for version ${versionName} on component ${componentName}"
        cmdHelper.runCommand("Publish uDeploy Component Version Files", cmdArgs) { proc ->
            def out = new StringBuffer()
            def err = new StringBuffer()
            proc.out.close() // close stdin
            proc.waitForProcessOutput(out, err)
            commandOutput = err.toString().trim()
        }
        if (commandOutput.contains("Request error")) {
            println commandOutput
            System.exit(1)
        }
        println "Files published"
    }

    if (propertiesTextArea) {
        def httpHelper = new HttpHelper()
        if (user && password) {
            httpHelper.setUsernameAndPassword(user, password)
        }
        def propsHelper = new PropsHelper(httpHelper)
        propsHelper.setComponentVersionProperties(url, componentName, versionName, propertiesTextArea)
    }
}
else {
    println "Unable to create version ${versionName} on component ${componentName}"
    System.exit(exitCode)
}