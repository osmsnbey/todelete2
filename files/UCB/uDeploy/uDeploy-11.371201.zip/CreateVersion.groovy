import com.urbancode.air.*;
import com.urbancode.air.plugin.automation.*;
import org.codehaus.jettison.json.JSONObject;

//------------------------------------------------------------------------------
// GET ALL INPUT PARAMETERS
//------------------------------------------------------------------------------
final def workDir = new File('.').canonicalFile
final def javaHome = System.getenv('JAVA_HOME')
final def webUrl = System.getenv('WEB_URL')
final def authToken = System.getenv('AUTH_TOKEN')
final def buildLifeId = System.getenv('BUILD_LIFE_ID')
final def pluginHome = System.getenv("PLUGIN_HOME");

final def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def stepProps = apTool.getStepProperties();
final def CommandHelper cmdHelper = new CommandHelper(workDir);

final def javaFile = new File(new File(javaHome), 'bin/java' + (apTool.isWindows ? '.exe' : ''))
final def udClientJarFile = new File(new File(pluginHome), 'lib/udeploy-client.jar')

def url = stepProps['automation/url'];
def user = stepProps['automation/user'];
def password = stepProps['automation/passScript'];
def componentName = stepProps['componentName'];
def versionName = stepProps['versionName'];
def description = stepProps['versionDesc'];
def includes = stepProps['includes'];
def excludes = stepProps['excludes'];
def publishFiles = Boolean.valueOf(stepProps['publishFiles'])
def propertiesTextArea = stepProps['propertiesTextArea'];
if (password == null || password.trim() == "") {
    password = stepProps['automation/password'];
}

def cmdArgs = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
               "-weburl", url,
               "-username", user,
               "-password", password,
               "createVersion", 
               "-component", componentName,
               "-name", versionName];
if (description) {
    cmdArgs << '-description'
    cmdArgs << description
}

println "Creating version ${versionName} on component ${componentName}"
def versionId = null;
def createVersionOutput = null
int exitCode = cmdHelper.runCommand("Creating uDeploy Component Version", cmdArgs){ Process proc ->
    proc.out.close() // close stdin
    proc.consumeProcessErrorStream(System.out) // forward stderr
    createVersionOutput = proc.text.trim();
};
// Only try to parse as JSON if there was no error
if (exitCode == 0) {
    def versionJson = new JSONObject(createVersionOutput);
    versionId = versionJson.getString("id");
}
if (versionId) {
    println "Created version ${versionName} on component ${componentName} with id ${versionId}"
    
    apTool.setOutputProperty("buildlife/udeploy.versionId", versionId)
    apTool.setOutputProperties()
    
    if (publishFiles) {
        cmdArgs = [javaFile.absolutePath, '-jar', udClientJarFile.absolutePath,
                   "--weburl", url,
                   "--username", user,
                   "--password", password,
                   "addVersionFiles",
                   "--component", componentName,
                   "--version", versionName,
                   "--base", workDir.absolutePath];
        if (includes) {
            includes.split("\\n").each { include ->
                cmdArgs << "--include" << include
            }
        }
        
        if (excludes) {
            excludes.split("\\n").each { exclude ->
                cmdArgs << "--exclude" << exclude
            }
        }
    
        println "Publishing files for version ${versionName} on component ${componentName}"
        cmdHelper.runCommand("Publish uDeploy Component Version Files", cmdArgs) { proc ->
            def out = new StringBuffer()
            def err = new StringBuffer()
            proc.out.close() // close stdin
            proc.waitForProcessOutput(out, err)
            commandOutput = err.toString().trim()
        }
        if (commandOutput.contains("Request error")) {
            println commandOutput
            System.exit(1);
        }
        println "Files published"
    }

    if (propertiesTextArea) {
        def httpHelper = new HttpHelper()
        if (user && password) {
            httpHelper.setUsernameAndPassword(user, password)
        }
        def propsHelper = new PropsHelper(httpHelper)
        propsHelper.setComponentVersionProperties(url, componentName, versionName, propertiesTextArea)
    }
}
else {
    println "Unable to create version ${versionName} on component ${componentName}"
    System.exit(exitCode)
}