/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/

import com.urbancode.air.AirPluginTool
import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder
import org.apache.http.HttpEntity
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.ContentType
import org.apache.http.entity.mime.MultipartEntityBuilder
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.util.EntityUtils
import org.codehaus.jettison.json.JSONObject

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()
File workDir = new File('.').canonicalFile

String velocityUrl = props['automation/velocityUrl']
String velocityBearerToken = props['automation/velocityBearerToken']
String tenantId = props['tenantId']
String recordName = props['recordName']

String filePath = props['filePath']
File metricFile = new File(workDir, filePath)
if (!metricFile.exists()) {
    throw new Exception("Error: the sppecified metrics file \"$filePath\" does not exist.")
}

String dataSet = props['dataSet']
String environment = props['environment']
boolean combineTestSuites = Boolean.valueOf(props['combineTestSuites'] as String)
String pluginType = props['pluginType']
String dataFormat = props['dataFormat']
String metricDefinitionId = props['metricDefinitionId']
String metricDefinitionName = props['metricDefinitionName']
String buildId = props['buildId']
String appName = props['appName']
String appId = props['appId']
String appExtId = props['appExtId']

if (!velocityUrl.endsWith('/')) {
    velocityUrl += '/'
}

if (!appName && !appId && !appExtId) {
    throw new Exception("Must define at least one of the following properties: 'appId', 'appName', or 'appExtId'")
}
if (!metricDefinitionId && !metricDefinitionName) {
    throw new Exception("Must define at least one of the following properties: 'metricDefinitionId', 'metricDefinitionName'")
}

JSONObject payload = new JSONObject()

payload.put("dataSet", dataSet)
payload.put("environment", environment)
payload.put("tenant_id", tenantId)

JSONObject application = new JSONObject()
application.put("id", appId)
application.put("name", appName)
application.put("externalId", appExtId)
payload.put("application", application)

JSONObject record = new JSONObject()
record.put("pluginType", pluginType)
record.put("dataFormat", dataFormat)
record.put("recordName", recordName)
record.put("category", metricDefinitionId)
payload.put("metricName", recordName)
payload.put("record", record)

JSONObject options = new JSONObject()
options.put("combineTestSuites", combineTestSuites)
payload.put("options", options)

JSONObject build = new JSONObject()
build.put("buildId", buildId)
payload.put("build", build)

println("TEST payload: " + payload.toString(2))

CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder()
builder.setTrustAllCerts(true)
builder.setPreemptiveAuthentication(true)

CloseableHttpClient httpClient = null
CloseableHttpResponse response = null

try {
    httpClient = builder.buildClient()

    println("Uploading metric file \"$filePath\" to UrbanCode Velocity...")
    HttpEntity entity = MultipartEntityBuilder
            .create()
            .addTextBody("payload", payload.toString())
            .addBinaryBody("testArtifact", metricFile, ContentType.create("application/octet-stream"), metricFile.name)
            .build()

    HttpPost postMethod = new HttpPost(velocityUrl + '/reporting-consumer/qualityData')
    postMethod.setHeader("Authorization", "Bearer " + velocityBearerToken)
    postMethod.setEntity(entity)

    response = httpClient.execute(postMethod)
    String resStr = EntityUtils.toString(response.getEntity())

    int statusCode = response.getStatusLine().getStatusCode()
    if (statusCode < 200 || statusCode >= 300) {
        throw new RuntimeException("Bad response when uploading metrics file: $statusCode - $resStr")
    }

    println("Successfully uploaded metrics data.")
}
finally {
    if (response) {
        response.close()
    }
    if (httpClient) {
        httpClient.close()
    }
}