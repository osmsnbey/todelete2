/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/


import com.urbancode.air.AirPluginTool
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.util.EntityUtils
import com.urbancode.plugin.ucv.VelocityHelper

AirPluginTool apTool = new AirPluginTool(this.args[0], this.args[1])
Properties props = apTool.getStepProperties()
File workDir = new File('.').canonicalFile

String velocityUrl = props['automation/velocityUrl']
String accessKey = props["automation/accessKey"]
String tenantId = props["automation/tenantId"]

String dataSet = props['dataSet']

String appName = props['appName']
String metricDefinitionName = props['metricDefinitionName']
String pluginType = props['pluginType']
String dataFormat = props['dataFormat']
String value = props['value']

if (!velocityUrl.endsWith('/')) {
    velocityUrl += '/'
}

CloseableHttpResponse response = null

try {
    println("Uploading Metrics data")
    VelocityHelper helper = new VelocityHelper(velocityUrl, accessKey)
    response = helper.uploadMetricsData(tenantId, dataSet, appName, metricDefinitionName, pluginType, dataFormat, value)
    String responseString = EntityUtils.toString(response.getEntity())
    println("response string  $responseString")

    int statusCode = response.getStatusLine().getStatusCode()
    if (statusCode < 200 || statusCode >= 300) {
        throw new RuntimeException("Bad response when uploading metrics data: $statusCode - $responseString")
    }
    println("Successfully uploaded metrics data.")
}
finally {
    if (response) {
        response.close()
    }
}