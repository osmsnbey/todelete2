/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
package com.urbancode.plugin.ucv

import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder
import org.apache.http.HttpHeaders
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.CloseableHttpClient

class VelocityHelper {

    private final String serverUrl
    private final String accessKey

    private final CloseableHttpClient httpClient

    VelocityHelper(String serverUrl, String accessKey) {
        if (!serverUrl.endsWith('/')) {
            serverUrl += '/'
        }
        this.serverUrl = serverUrl
        this.accessKey = accessKey
        CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder()
        builder.setTrustAllCerts(true)
        builder.setPreemptiveAuthentication(true)
        httpClient = builder.buildClient()
    }

    /**
     * Upload build data to UrbanCode Velocity.
     * @param buildLifeId
     * @param tenantId
     * @param buildName
     * @param versionName
     * @param status
     * @param applicationName
     * @param sourceUrl
     * @param startTime
     * @param requester
     * @return
     */
    CloseableHttpResponse uploadBuildData(
            String buildLifeId,
            String tenantId,
            String buildName,
            String versionName,
            String status,
            String applicationName,
            String sourceUrl,
            String revision,
            String startTime,
            String requester) {
        BuildData buildData = BuildData.create()
            .withBuildLifeId(buildLifeId)
            .withTenantId(tenantId)
            .withBuildName(buildName)
            .withVersionName(versionName)
            .withStatus(status)
            .withApplicationName(applicationName)
            .withSourceUrl(sourceUrl)
            .withRevision(revision)
            .withStartTime(startTime)
            .withRequester(requester)
            .withSource("UrbanCode Build")
        String json = buildData.toEscapedJsonString()
        CloseableHttpResponse response = sendGraphQLRequest("mutation", "uploadBuildData", json)
        return response
    }

    /**
     * Upload Metrics Data to UrbanCode Velocity.
     * @param tenantId
     * @param applicationName
     * @param pluginType
     * @param dataFormat
     * @param fileMeta
     * @return
     */
    CloseableHttpResponse uploadMetricsData(
            String tenantId,
            String dataSet,
            String applicationName,
            String metricDefinitionName,
            String pluginType,
            String dataFormat,
            String value) {
        MetricsData metricData = MetricsData.create()
                .withTenantId(tenantId)
                .withDataSet(dataSet)
                .withApplicationName(applicationName)
                .withMetricDefinitionName(metricDefinitionName)
                .withPluginType(pluginType)
                .withDataFormat(dataFormat)
                .withValue(value);
        String json = metricData.toEscapedJsonString()
        CloseableHttpResponse response = sendGraphQLRequest("mutation", "uploadMetrics", json)
        return response
    }

    /**
     * Construct and send a GraphQL request to UrbanCode Velocity.
     * @param operationType The type of the operation resulting from this request. This may be "query" or "mutation".
     * @param schema The schema name to use. Examples for Velocity's release-events-api: uploadBuildData, uploadMetricsFile
     * @param dataJson The input data to send with this request, that would comply with the given schema.
     * @return CloseableHttpResponse the response object
     */
    CloseableHttpResponse sendGraphQLRequest(String operationType, String schema, String dataJson) {
        String payload = "{\"query\": \"${operationType} { ${schema}(data: ${dataJson}){_id}}\" }"
        println("Payload data: $payload")
        HttpPost request = new HttpPost(serverUrl + "graphql")
        request.setHeader(HttpHeaders.AUTHORIZATION, "UserAccessKey " + accessKey)
        request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        StringEntity entity = new StringEntity(payload)
        request.setEntity(entity)
        return httpClient.execute(request)
    }
}
