/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
package com.urbancode.plugin.ucv

class MetricsData {

    static MetricsData create() {
        return new MetricsData()
    }

    private String tenantId
    private String dataSet
    private String metricDefinitionName
    private String applicationName
    private String pluginType
    private String dataFormat
    private String value

    MetricsData withTenantId(String tenantId) {
        this.tenantId = tenantId
        return this
    }

    MetricsData withDataSet(String dataSet) {
        this.dataSet = dataSet
        return this
    }

    MetricsData withApplicationName(String applicationName) {
        this.applicationName = applicationName
        return this
    }

    MetricsData withMetricDefinitionName(String metricDefinitionName) {
        this.metricDefinitionName = metricDefinitionName
        return this
    }

    MetricsData withPluginType(String pluginType) {
        this.pluginType = pluginType
        return this
    }

    MetricsData withDataFormat(String dataFormat) {
        this.dataFormat = dataFormat
        return this
    }

    MetricsData withValue(String value) {
        this.value = value
        return this
    }

    String toEscapedJsonString() {
        String json = "{" +
                "tenantId: \\\"${tenantId}\\\", dataSet : \\\"${dataSet}\\\", application: { name: \\\"${applicationName}\\\" }," +
                "record : { metricDefinitionName: \\\"${metricDefinitionName}\\\" pluginType: \\\"${pluginType}\\\", dataFormat: \\\"${dataFormat}\\\", value: ${value}}" +
                "}"
        return json
    }

}

