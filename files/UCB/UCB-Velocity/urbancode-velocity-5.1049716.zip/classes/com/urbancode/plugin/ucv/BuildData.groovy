/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Build
* (c) Copyright IBM Corporation 2016, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
package com.urbancode.plugin.ucv

class BuildData {

    static BuildData create() {
        return new BuildData()
    }

    private String buildLifeId
    private String tenantId
    private String buildName
    private String versionName
    private String status
    private String applicationName
    private String sourceUrl
    private String revision
    private String startTime
    private String requester
    private String source

    BuildData withBuildLifeId(String buildLifeId) {
        this.buildLifeId = buildLifeId
        return this
    }

    BuildData withTenantId(String tenantId) {
        this.tenantId = tenantId
        return this
    }

    BuildData withBuildName(String buildName) {
        this.buildName = buildName
        return this
    }

    BuildData withVersionName(String versionName) {
        this.versionName = versionName
        return this
    }

    BuildData withStatus(String status) {
        this.status = status
        return this
    }

    BuildData withApplicationName(String applicationName) {
        this.applicationName = applicationName
        return this
    }

    BuildData withSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl
        return this
    }

    BuildData withRevision(String revision) {
        this.revision = revision
        return this
    }

    BuildData withStartTime(String startTime) {
        this.startTime = startTime
        return this
    }

    BuildData withRequester(String requester) {
        this.requester = requester
        return this
    }

    BuildData withSource(String source) {
        this.source = source
        return this
    }

    String toEscapedJsonString() {
        String json = "{" +
                "id: \\\"${buildLifeId}\\\", tenantId: \\\"${tenantId}\\\", name: \\\"${buildName}\\\", " +
                "versionName: \\\"${versionName}\\\", status: ${status}, " +
                "application: { name: \\\"${applicationName}\\\" }, " +
                "url: \\\"${sourceUrl}\\\", revision: \\\"${revision}\\\", startTime: \\\"${startTime}\\\", " +
                "requestor: \\\"${requester}\\\", source: \\\"${source}\\\"" +
                "}"
        return json
    }
}
