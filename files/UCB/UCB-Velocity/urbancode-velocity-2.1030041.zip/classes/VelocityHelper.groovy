import com.urbancode.commons.httpcomponentsutil.CloseableHttpClientBuilder
import org.codehaus.jettison.json.JSONObject
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.HttpHeaders

class VelocityHelper {

    private final String serverUrl
    private final String accessKey

    private final CloseableHttpClient httpClient

    VelocityHelper(String serverUrl, String accessKey) {
        if (!serverUrl.endsWith('/')) {
            serverUrl += '/'
        }
        this.serverUrl = serverUrl
        this.accessKey = accessKey
        CloseableHttpClientBuilder builder = new CloseableHttpClientBuilder()
        builder.setTrustAllCerts(true)
        builder.setPreemptiveAuthentication(true)
        httpClient = builder.buildClient()
    }

    /**
     * Upload build data to UrbanCode Velocity.
     * @param buildLifeId
     * @param tenantId
     * @param name
     * @param status
     * @param applicationName
     * @param sourceUrl
     * @param startTime
     * @param requester
     * @return
     */
    CloseableHttpResponse uploadBuildData(
            String buildLifeId,
            String tenantId,
            String name,
            String status,
            String applicationName,
            String sourceUrl,
            String revision,
            String startTime,
            String requester) {
        String json = "{" +
                "id: \\\"${buildLifeId}\\\", tenantId: \\\"${tenantId}\\\", name: \\\"${name}\\\", status: ${status}, " +
                "application: { name: \\\"${applicationName}\\\" }, " +
                "url: \\\"${sourceUrl}\\\", revision: \\\"${revision}\\\", startTime: \\\"${startTime}\\\", " +
                "requestor: \\\"${requester}\\\"" +
        "}"
        println "Json data: $json"
        CloseableHttpResponse response = sendGraphQLRequest("mutation", "uploadBuildData", json)
        return response
    }

    /**
     * Construct and send a GraphQL request to UrbanCode Velocity.
     * @param operationType The type of the operation resulting from this request. This may be "query" or "mutation".
     * @param schema The schema name to use. Examples for Velocity's release-events-api: uploadBuildData, uploadMetricsFile
     * @param dataJson The input data to send with this request, that would comply with the given schema.
     * @return CloseableHttpResponse the response object
     */
    CloseableHttpResponse sendGraphQLRequest(String operationType, String schema, String dataJson) {
        String payload = "{\"query\": \"${operationType} { ${schema}(data: ${dataJson}){_id}}\" }"
        println "Json data: " + payload
        HttpPost request = new HttpPost(serverUrl + "graphql")
        request.setHeader(HttpHeaders.AUTHORIZATION, "UserAccessKey " + accessKey)
        request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json")
        StringEntity entity = new StringEntity(payload)
        request.setEntity(entity)
        return httpClient.execute(request)
    }
}
