if(!workItemProperty && !workItemRegex) {
  errors.workItemProperty = "Either Work Item Property or Work Item Id Pattern must be specified!"
  errors.workItemRegex = "Either Work Item Property or Work Item Id Pattern must be specified!"
}