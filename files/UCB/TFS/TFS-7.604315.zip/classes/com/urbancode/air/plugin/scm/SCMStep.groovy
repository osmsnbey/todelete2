/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* (c) Copyright IBM Corporation 2012, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
package com.urbancode.air.plugin.scm

import java.util.Date;

import com.urbancode.air.*

public class SCMStep {
    
    //**************************************************************************
    // CLASS
    //**************************************************************************
    static protected final String REPO_TYPE = 'tfs'

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    def out = System.out
    
    String scmCommand = "tf.exe"
    File workDir = new File(".").canonicalFile
    String serverUrl
    String serverUserName
    String serverPassword
    String tfsVersion
    String sourceLocation
}