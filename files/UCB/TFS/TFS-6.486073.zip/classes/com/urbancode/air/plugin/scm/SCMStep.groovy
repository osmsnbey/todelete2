package com.urbancode.air.plugin.scm

import java.util.Date;

import com.urbancode.air.*

public class SCMStep {
    
    //**************************************************************************
    // CLASS
    //**************************************************************************
    static protected final String REPO_TYPE = 'tfs'

    //**************************************************************************
    // INSTANCE
    //**************************************************************************

    def out = System.out
    
    String scmCommand = "tf.exe"
    File workDir = new File(".").canonicalFile
    String serverUrl
    String serverUserName
    String serverPassword
    String tfsVersion
    String sourceLocation
}