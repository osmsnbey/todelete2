package com.urbancode.air.plugin.scm.changelog

public class ChangeSet {
    //**************************************************************************
    // CLASS
    //**************************************************************************

    //**************************************************************************
    // INSTANCE
    //**************************************************************************
    
    String id = null;
    Date date = null; 
    final Set<String> fileSet = [];
    
    public boolean hasAllowedPath(ChangeSetFilter changeSetFilter) {
        return fileSet.find{ changeSetFilter.pathIsIncluded(it.path) } != null;
    }
    
    public boolean hasAllowedAuthor(ChangeSetFilter changeSetFilter) {
        return changeSetFilter.authorIsIncluded(user);
    }
}
