import com.urbancode.air.AirPluginTool
import com.urbancode.ud.client.UDRestClient
import com.urbancode.air.plugin.udeploy.resources.ResourceHelper
def apTool = new AirPluginTool(this.args[0], this.args[1])

ResourceHelper helper = new ResourceHelper(new AirPluginTool(this.args[0], this.args[1]))

helper.addTagToResource()