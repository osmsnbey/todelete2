#!/bin/sh
eval exec "\"${JAVA_HOME}/bin/java\" $JAVA_OPTS \"\$@\""