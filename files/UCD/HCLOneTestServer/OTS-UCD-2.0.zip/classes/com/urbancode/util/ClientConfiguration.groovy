package com.urbancode.util

class ClientConfiguration {
	String user
	 String password
	 String api
	 boolean returnValueOnly = false
	 boolean loggingEnabled = false
	 boolean isSecure = false
	 String method
	 String postingData = null
	 String contentType
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getApi() {
		return api;
	}
	public void setApi(String api) {
		this.api = api;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	 
	 
}
