/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebSphereLibertyHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1])

def props = apTool.getStepProperties();

def wlpHome = props['wlpHome'];
def wlpUserDir = props['wlpUserDir'];
def hostToUnregister = props['hostToUnregister'];
def controllerHostName = props['controllerHostName'];
def controllerPort = props['controllerPort'];
def adminUser = props['adminUser'];
def adminPassword = props['adminPassword'];

def wslh = new WebSphereLibertyHelper(wlpHome, wlpUserDir);
wslh.unregisterHost(hostToUnregister, controllerHostName, controllerPort, adminUser, adminPassword, apTool.isWindows);


