/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2017. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphereliberty.WebserverHelper;


def apTool = new AirPluginTool(this.args[0], this.args[1])

def props            = apTool.getStepProperties();
def webserverHome    = props['webserverHome'].trim();
def pluginConfigPath = props['pluginConfigPath'].trim();
def wasPlugin        = props['wasPlugin'].trim();

println("OS: " + System.properties['os.name']);
def wh = new WebserverHelper(webserverHome, pluginConfigPath, wasPlugin);
wh.backupHttpdConf();
wh.modifyHttpdConf();
wh.copyPluginConfig();
