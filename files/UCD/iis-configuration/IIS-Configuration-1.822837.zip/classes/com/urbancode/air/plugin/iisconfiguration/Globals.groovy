/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Deploy
 * (c) Copyright IBM Corporation 2016. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
package com.urbancode.air.plugin.iisconfiguration

class Globals{
    static String ROOT_ROLE_NAME = "IISRoot"
    static String SITE_ROLE_NAME = "IISSite"
    static String APP_ROLE_NAME = "IISApp"
    static String APP_POOL_ROLE_NAME = "IISAppPool"
    static String WEBSERVER_RESOURCE_NAME = "webServer"
    static String UCD_METADATA_FILE_NAME = "ucd_metadata.properties"
    static String CONFIG_FILE = "archive.xml"
}
