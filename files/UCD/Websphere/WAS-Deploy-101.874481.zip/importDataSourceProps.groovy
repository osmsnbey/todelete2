/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphere.WebSphereBatchScriptHelper;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

clusterName = props['clusterName'];
jdbcProviderName = props['jdbcProviderName'];
datasourceName = props['datasourceName'];
statementCacheSize = props['statementCacheSize'];
connectionTimeout = props['connectionTimeout'];

StringBuilder builder = new StringBuilder();
builder.append("importDataSourceProps(")
           .append("\"").append(clusterName).append("\"").append(",")
           .append("\"").append(jdbcProviderName).append("\"").append(",")
           .append("\"").append(datasourceName).append("\"").append(",")
           .append("\"").append(statementCacheSize).append("\"").append(",")
           .append("\"").append(connectionTimeout).append("\"")
builder.append(")")
command = builder.toString();

WebSphereBatchScriptHelper helper = new WebSphereBatchScriptHelper(props);
helper.execute(command);
