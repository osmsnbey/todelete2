/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2016. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphere.WebSphereBatchScriptHelper

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();

props['batch'] = "false";

def nodenames = props['nodenames'];

StringBuilder nodeNameBuilder = new StringBuilder();
StringBuilder builder = new StringBuilder();
builder.append("checkNodeStatus(");
if (nodenames != null && nodenames.trim() != "" && nodenames.trim() != "*") {
    boolean first = true;
    nodeNameBuilder.append("[");
    nodenames.eachLine { line ->
        if (first) {
            first = false;
        }
        else {
            nodeNameBuilder.append(", ");
        }
        nodeNameBuilder.append("\"").append(line.trim()).append("\"");
    }
    nodeNameBuilder.append("]");
    builder.append(nodeNameBuilder.toString());
}
builder.append(")");
command = builder.toString();

WebSphereBatchScriptHelper helper = new WebSphereBatchScriptHelper(props);
helper.execute(command);
