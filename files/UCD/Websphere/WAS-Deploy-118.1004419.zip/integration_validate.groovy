/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
if(cluster && (node || server || cell)) {
  errors.cell = "If cluster is specified than server, node, and cell should not be!"
  errors.node = "If cluster is specified than server, node, and cell should not be!"
  errors.server = "If cluster is specified than server, node, and cell should not be!"
  errors.cluster = "If cluster is specified than server, node, and cell should not be!"
}
if(!cluster) {
    if(!node || !server) {
        errors.node = "A node and Server must be specified if cluster is not specified"
        errors.server = "A node and Server must be specified if cluster is not specified"
    }
}