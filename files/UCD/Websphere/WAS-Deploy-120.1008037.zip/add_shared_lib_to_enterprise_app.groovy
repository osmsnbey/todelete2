/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* (c) Copyright IBM Corporation 2002-2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool;
import com.urbancode.air.plugin.websphere.WebSphereCmdLineHelper
import com.urbancode.air.plugin.websphere.WebSphereBatchScriptHelper

def apTool = new AirPluginTool(this.args[0], this.args[1]);
def props = apTool.getStepProperties();
def appName = props['appName'];
def appEdition = props['appEdition']
def sharedLibNames = props['sharedLibName'].split("\n");

def batch = props['batch'];
props['batch'] = true;
for (int i = 0; i < sharedLibNames.length; i++) {
    String sharedLibName = sharedLibNames[i].trim();
    StringBuilder builder = new StringBuilder();
    builder.append("addSharedLibraryToApplication(")
               .append("\"").append(appName).append("\"").append(",")
               .append("\"").append(appEdition?:"").append("\"").append(",")
               .append("\'").append(sharedLibName).append("\'")
           .append(")")
    command = builder.toString();
    
    if (i == sharedLibNames.length -1) {
        props['batch'] = batch;
    }
    WebSphereBatchScriptHelper helper = new WebSphereBatchScriptHelper(props);
    helper.execute(command);
}

