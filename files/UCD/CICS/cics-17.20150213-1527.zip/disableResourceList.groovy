/* <copyright                                       */
/* notice="cics-lm-source-program"                  */
/* pids="CA0U"                                      */
/* years="2014,2015"                                */
/* crc="2800743495" >                               */
/* 	Licensed Materials - Property of IBM            */
/* 	CA0U                                            */
/* 	(C) Copyright IBM Corp. 2014, 2015 All Rights Reserved. */
/* 	US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. */
/* </copyright>                                     */
import com.ibm.cics.ucd.exceptions.StepFailedException
import com.ibm.cics.ucd.steps.DisableResourceStep
import com.ibm.cics.ucd.steps.Step

try {
	Step step = new DisableResourceStep(this.args[0], this.args[1]);
	step.run()
} catch (StepFailedException e) {
	System.exit(1)

} catch (Exception e){
	throw e
}
//TODO this try/catch may need further refinement to see if other exceptions need to be caught

//Indicating step end with pass result
System.exit(0)