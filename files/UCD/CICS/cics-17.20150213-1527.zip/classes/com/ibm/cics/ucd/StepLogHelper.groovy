/* <copyright                                       */
/* notice="cics-lm-source-program"                  */
/* pids="CA0U"                                      */
/* years="2014"                                     */
/* crc="371205838" >                                */
/* 	Licensed Materials - Property of IBM            */
/* 	CA0U                                            */
/* 	(C) Copyright IBM Corp. 2014 All Rights Reserved. */
/* 	US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. */
/* </copyright>                                     */
package com.ibm.cics.ucd

import java.text.SimpleDateFormat

class StepLogHelper {

	static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS z"); //set date format
	
	public StepLogHelper() { }
	
	public static void printStepLog(String msg) {
		String date = dateFormat.format(new Date())
		System.out.println(date + " " + msg) //print msg with timestamp prefixed
	}
}
