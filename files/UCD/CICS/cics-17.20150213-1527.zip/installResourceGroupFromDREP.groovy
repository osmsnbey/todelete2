/* <copyright                                       */
/* notice="cics-lm-source-source"                   */
/* pids=""                                          */
/* years="2014"                                     */
/* crc="" >                                         */
/* </copyright>                                     */
import com.ibm.cics.ucd.exceptions.StepFailedException
import com.ibm.cics.ucd.steps.InstallResourceGroupFromDREPStep
import com.ibm.cics.ucd.steps.Step

try {
	Step step = new InstallResourceGroupFromDREPStep(this.args[0], this.args[1]);
	step.run()
} catch (StepFailedException e) {
	System.exit(1)

} catch (Exception e){
	throw e
}
//TODO this try/catch may need further refinement to see if other exceptions need to be caught

//Indicating step end with pass result
System.exit(0)
