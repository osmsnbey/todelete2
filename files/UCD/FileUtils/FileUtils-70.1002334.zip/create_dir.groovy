/*
* Licensed Materials - Property of IBM* and/or HCL**
* UrbanCode Deploy
* UrbanCode Build
* UrbanCode Release
* AnthillPro
* (c) Copyright IBM Corporation 2011, 2017. All Rights Reserved.
* (c) Copyright HCL Technologies Ltd. 2018. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*
* * Trademark of International Business Machines
* ** Trademark of HCL Technologies Limited
*/
import com.urbancode.air.AirPluginTool

final AirPluginTool airTool = new AirPluginTool(args[0], args[1])
final Properties props = airTool.getStepProperties()

final def workDir = new File('.').canonicalFile

final def dir = props['dir']

def errors = [];
try {
    dir.eachLine {
        File file = new File(it).canonicalFile;
        if (file.isDirectory()) {
            println "Directory '$file.absolutePath' already exists!"
        }
        else if (file.isFile()) {
            errors << "There is a file at '$file.absolutePath'";
        }
        else if (file.mkdirs()) {
            println "Created new directory '$file.absolutePath'"
        }
        else {
            errors << "Could not create directory '$file.absolutePath'";
        }
    }
}
catch (Exception e) {
    println "Error creating directory '$dir': ${e.message}"
    System.exit(1)
}

if (errors.size() > 0) {
    errors.each { it ->
        println it;
    }
    System.exit(1);
}

System.exit(0)
