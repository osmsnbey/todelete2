/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.udeploy.applications.ApplicationHelper

ApplicationHelper helper = new ApplicationHelper(new AirPluginTool(this.args[0], this.args[1]))

helper.applicationProcessExists()