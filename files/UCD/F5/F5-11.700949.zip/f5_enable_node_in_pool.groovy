#!/usr/bin/env groovy

import com.urbancode.air.AirPluginTool

def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()
final def helper = new F5Helper(props)

try {
    helper.enableNodeInPool()
}
catch (Exception e) {
    e.printStackTrace()
    System.exit(1)
}