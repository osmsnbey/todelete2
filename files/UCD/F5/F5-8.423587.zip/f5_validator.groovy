if (doWaitForConnectionClose && !sleepInterval) {
    errors.sleepInterval = "Sleep interval is required when 'Wait for existing connections' is selected"
}                                                                                  