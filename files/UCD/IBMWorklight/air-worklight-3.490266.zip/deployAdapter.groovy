/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2013, 2014 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def serverpath = props['serverpath']
def adapter = props['adapter']
def worklightAntJar = props['worklightAntJar']
def user = props['user']
def password = props['password']

try {
    println "Deploying the Worklight adapter with the following properties:"
    println "Server Path: ${serverpath}"
    println "Adapter: ${adapter}"
    println "Worklight Ant Deployer JAR Path: ${worklightAntJar}"

    File adapterFile = new File(adapter)
    def fileName = adapterFile.getName()
    int extension = fileName.lastIndexOf(".")
    if(extension == -1 || fileName.substring(extension) != ".adapter") {
        println "Error: The Worklight adapter file name must include the .adapter extension: ${adapterFile.getName()}. For example, file.adapter."
        System.exit(1)
    }
    
    File worklightAntJarFile = new File(worklightAntJar)
    if(!worklightAntJarFile.exists() || !worklightAntJarFile.isFile()) {
        println "Error: The path to the Worklight Ant Deployer JAR file is invalid: " +
                "${worklightAntJarFile.getCanonicalPath()}. Change the value of the " +
                "Worklight Ant JAR File Path attribute to the path to the Worklight " +
                "Ant Deployer JAR file. For example, use " +
                "/opt/IBM/Worklight/WorklightServer/worklight-ant-deployer.jar."
        System.exit(1)
    }
	
    def ant = new AntBuilder();
    try {
        ant.taskdef ( name: "deployer", classname:"com.worklight.ant.deployers.AdapterDeployerTask", classpath: worklightAntJarFile.absolutePath )
    } catch (Exception e) {
        println "Error: The class com.worklight.ant.deployers.AdapterDeployerTask is " +
                "not found in the specified Worklight Ant Deployer JAR file: " +
                "${worklightAntJarFile.getCanonicalPath()}."
        println "Explanation: This error occurs if the JAR file specified in the " +
                "Worklight Ant JAR File Path attribute is not correct."
        println "User response: Change the value of the Worklight Ant JAR File Path " +
                "attribute to the path to the Worklight Ant Deployer JAR file. For " +
                "example, use " +
                "/opt/IBM/Worklight/WorklightServer/worklight-ant-deployer.jar."
        System.exit(1)
    }
    if(user?.trim()) {
        if(password?.trim()) {
            ant.deployer ( worklightServerHost:serverpath, deployable:adapter, 
                userName:user, password:password )
        }
        else {
            println "Error: A password must be provided for the user."
            System.exit(1)
        }
    } else {
        ant.deployer ( worklightServerHost:serverpath, deployable:adapter )
    }
} catch (Exception e) {
    println "An error occurred while deploying the Worklight adapter: ${e.message}"
    System.exit(1)
}

println "The Deploy Adapter to Worklight Server step completed successfully."