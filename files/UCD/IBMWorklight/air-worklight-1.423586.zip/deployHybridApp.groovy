/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2013 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def serverpath = props['serverpath']
def wlapp = props['wlapp']

try {
    println "Deploying the Worklight application with the following properties:"
    println "Server Path: ${serverpath}"
    println "Application: ${wlapp}"

    File wlappFile = new File(wlapp)
    def fileName = wlappFile.getName()
    int extension = fileName.lastIndexOf(".")
    if(extension == -1 || fileName.substring(extension) != ".wlapp") {
        println "Error: The Worklight application file name must include the .wlapp extension: ${wlappFile.getName()}. For example, file.wlapp."
        System.exit(1)
    }
	
    def PLUGIN_HOME = System.getenv("PLUGIN_HOME")
    def pluginHomeFile = new File(PLUGIN_HOME);
    def pluginLib = new File(pluginHomeFile, "lib");
    def worklightAntJar = new File(pluginLib, "worklight-ant.jar");
    def ant = new AntBuilder();
    ant.taskdef ( name: "deployer", classname:"com.worklight.ant.deployers.ApplicationDeployerTask", classpath: worklightAntJar.absolutePath )
    ant.deployer ( worklightServerHost:serverpath, deployable:wlapp )
} catch (Exception e) {
    println "An error occurred while deploying the Worklight application: ${e.message}"
    System.exit(1)
}

println "The Deploy Hybrid Application to Worklight Server step completed successfully."