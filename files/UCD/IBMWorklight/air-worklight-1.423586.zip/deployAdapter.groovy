/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2013 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def serverpath = props['serverpath']
def adapter = props['adapter']

try {
    println "Deploying the Worklight adapter with the following properties:"
    println "Server Path: ${serverpath}"
    println "Adapter: ${adapter}"

    File adapterFile = new File(adapter)
    def fileName = adapterFile.getName()
    int extension = fileName.lastIndexOf(".")
    if(extension == -1 || fileName.substring(extension) != ".adapter") {
        println "Error: The Worklight adapter file name must include the .adapter extension: ${adapterFile.getName()}. For example, file.adapter."
        System.exit(1)
    }
	
    def PLUGIN_HOME = System.getenv("PLUGIN_HOME")
    def pluginHomeFile = new File(PLUGIN_HOME);
    def pluginLib = new File(pluginHomeFile, "lib");
    def worklightAntJar = new File(pluginLib, "worklight-ant.jar");
    def ant = new AntBuilder();
    ant.taskdef ( name: "deployer", classname:"com.worklight.ant.deployers.AdapterDeployerTask", classpath: worklightAntJar.absolutePath )
    ant.deployer ( worklightServerHost:serverpath, deployable:adapter )
} catch (Exception e) {
    println "An error occurred while deploying the Worklight adapter: ${e.message}"
    System.exit(1)
}

println "The Deploy Adapter to Worklight Server step completed successfully."