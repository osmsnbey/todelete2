/**
* Licensed Materials - Property of IBM
* 5748-XX8
* (C) Copyright IBM Corp. 2013 All Rights Reserved
* US Government Users Restricted Rights - Use, duplication or
* disclosure restricted by GSA ADP Schedule Contract with
* IBM Corp.
**/

import com.urbancode.air.AirPluginTool;

def apTool = new AirPluginTool(this.args[0], this.args[1]);
final def props = apTool.getStepProperties();

def serverpath = props['serverpath']
def context = props['context']
def user = props['user']
def password = props['password']
def desc = props['desc']
def label = props['label']
boolean isActive = Boolean.parseBoolean(props['isActive'])
boolean isInstaller = Boolean.parseBoolean(props['isInstaller'])
boolean isReadyForProduction = Boolean.parseBoolean(props['isReadyForProduction'])
boolean isRecommended = Boolean.parseBoolean(props['isRecommended'])
boolean force = Boolean.parseBoolean(props['force'])
boolean disableSSL = Boolean.parseBoolean(props['disableSSL'])
def file = props['file']

try {
    println "Uploading the application with the following properties:"
    println "Server Path: ${serverpath}"
    println "Context: ${context}"
	if(desc != null)
		println "Description: ${desc}"
	if(label != null)
		println "Label: ${label}"
    println "Active: ${isActive}"
    println "Installer: ${isInstaller}"
    println "Ready for production: ${isReadyForProduction}"
    println "Recommended: ${isRecommended}"
    println "Force Upload: ${force}"
    println "Disable SSL: ${disableSSL}"
    println "File: ${file}"

	if(serverpath == null || context == null || serverpath.trim().length() == 0 || context.trim().length() == 0) {
		println "Error: You must specify both the server path and the server context."
		System.exit(1)
	}

    File filePath = new File(file)
	def fileName = new File(file).getName()
    int extension = fileName.lastIndexOf(".")
    if(extension == -1 || (fileName.substring(extension) != ".apk" && fileName.substring(extension) != ".ipa")) {
        println "Error: The application file name must include either the .apk or .ipa extension: ${fileName}. For example, file.apk."
        System.exit(1)
    }
    
    if(context.charAt(0) != '/' && !serverpath.endsWith("/")) {
        context = "/" + context
    }
    
    def PLUGIN_HOME = System.getenv("PLUGIN_HOME")
    def pluginHomeFile = new File(PLUGIN_HOME);
    def pluginLib = new File(pluginHomeFile, "lib");
    def json4jJar = new File(pluginLib, "json4j.jar");
    def appCenterDeployToolJar = new File(pluginLib, "applicationcenterdeploytool.jar");
    def taskdefClasspath = appCenterDeployToolJar.absolutePath + ":" + json4jJar.absolutePath
    def ant = new AntBuilder();
    ant.taskdef ( name: "uploadApp", classname:"com.ibm.appcenter.ant.UploadApps", classpath: taskdefClasspath )
    ant.uploadApp ( serverPath:serverpath, context:context, loginUser:user, loginPass:password, description:desc, fallbackLabel:label, active:isActive, installer:isInstaller, readyForProduction:isReadyForProduction, recommended:isRecommended, forceOverwrite:force, disableSSLSecurity:disableSSL, file:filePath )
} catch (Exception e) {
    println "An error occurred while uploading the application: ${e.message}"
    System.exit(1)
}

println "The Upload Application to Application Center step completed successfully."