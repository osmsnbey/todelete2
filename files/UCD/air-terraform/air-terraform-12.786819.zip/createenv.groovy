import com.urbancode.air.AirPluginTool
import com.urbancode.air.plugin.terraform.TerraformHelper

def apTool = new AirPluginTool(this.args[0], this.args[1])
def helper = new TerraformHelper(apTool)
helper.createEnv()