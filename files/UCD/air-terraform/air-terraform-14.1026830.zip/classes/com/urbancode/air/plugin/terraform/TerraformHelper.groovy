package com.urbancode.air.plugin.terraform

import java.util.UUID
import java.net.URI
import java.io.InputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import com.urbancode.air.AirPluginTool
import com.urbancode.air.CommandHelper
import com.urbancode.ud.client.UDRestClient
import org.codehaus.jettison.json.JSONObject;
import org.codehaus.jettison.json.JSONArray;

public class TerraformHelper {
    def props = []
    def apTool
    final def workDir = new File('.').canonicalFile
    def ch = new CommandHelper(workDir)
    def internalAgentNames = []
    def weburl
    def udUser
    def udPw
    def client
    
    TerraformHelper(def apToolIn) {
        apTool = apToolIn
        props = apTool.getStepProperties()
        weburl = System.getenv("AH_WEB_URL")
        udUser = apTool.getAuthTokenUsername()
        udPw = apTool.getAuthToken()
        client = new UDRestClient(new URI(weburl), udUser, udPw)
    }
    
    
    def createEnv() {
        final def terraformExec = props['terraformExec']
        final def templateFile = props['templateFile']
        final def credsFile = props['credsFile']
        final def unparsedProps = props['terraformProperties']
        
        def commandLineArgs = []
        def agentNames = []
        
        if (!terraformExec) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!templateFile) {
            throw new IllegalArgumentException("No terraform template file was specified.")
        }
        if (!credsFile) {
            throw new IllegalArgumentException("No terraform credentials file was specified.")
        }
        println "preparing to run Terraform and create the environment specified by ${templateFile}"
        
        final def terraExecFile = new File(workDir, terraformExec)
        final def terraExecAbsolutePath = terraExecFile.absolutePath
        
        commandLineArgs << terraExecAbsolutePath
        commandLineArgs << "create"
        commandLineArgs << templateFile
        commandLineArgs << credsFile
        if (unparsedProps) {
            unparsedProps.split(" ").each() { prop ->
                if (prop) {
                    commandLineArgs << prop
                }
            }
        }
        def instanceXmlFile = ""
        def pb = ch.getProcessBuilder()
        ch.runCommand("Running Terraform to create environment", commandLineArgs){ Process proc ->
            InputStream is = proc.getIn()
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(is));
            def line
            def foundXml = false
            String magicXmlOutFinder = "Writing context out to "
           // read the output from the command
           while ((line = stdInput.readLine()) != null) {
               println "${line}"
               //find the instance xml file name
               if (!foundXml && line.contains(magicXmlOutFinder)) {
                   foundXml = true
                   int fileNameBeginIndex = line.indexOf(magicXmlOutFinder) + magicXmlOutFinder.length()
                   instanceXmlFile = line.substring(fileNameBeginIndex)
                   instanceXmlFile = instanceXmlFile.replace("\r", "")
                   apTool.setOutputProperty("instanceXmlFile", instanceXmlFile)
               }
           }
            
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            String output = proc.text
            println output
            proc.in.close()
        }
        Thread.sleep(5000)
        //parse out agent names from xml file
        if (instanceXmlFile) {
            def xmlFile = new File(instanceXmlFile)
            def fileText = xmlFile.getText()
            def slurper = new XmlSlurper().parseText(fileText).declareNamespace('udeploy':'org.urbancode.terraform.tasks.vmware.udeploy', 'vmware':'org.urbancode.terraform.tasks.vmware')
            def cloneElements = slurper."*"."clone"
            
            println "number of clone elements: " + cloneElements.size()
            
            int count = 1
            int agentCount = 1
            int publicIpCount = 1
            cloneElements.each{element ->
                
                //set agent/resource name output property
                def agentElements = element."udeploy:post-create-task"
                def currentAgentName = ""
                agentElements.each{agentElement ->
                    currentAgentName = agentElement.@"agent-name".text()
                    println "adding agent name " + currentAgentName
                    agentNames << currentAgentName
                    internalAgentNames << currentAgentName
                }
                if (currentAgentName) {
                    apTool.setOutputProperty("resourceName" + agentCount, currentAgentName)
                    agentCount++
                }
                
                //set IP list property
                String ipList = element.@"ip-list".text()
                println "found ip list " + ipList
                apTool.setOutputProperty("ip" + count, ipList)
                
                //set public and private IP output properties, and resource props if they are agents
                def publicIp = element.@"public-ip".text()
                def privateIp = element.@"private-ip".text()
                
                if (publicIp && privateIp) {
                    println "found public IP ${publicIp} mapping to private IP ${privateIp}"
                    apTool.setOutputProperty("publicIp" + publicIpCount, publicIp)
                    apTool.setOutputProperty("privateIp" + publicIpCount, privateIp)
                    if (currentAgentName) {
                        client.setResourceProperty(currentAgentName, "publicIp", publicIp, false)
                        client.setResourceProperty(currentAgentName, "privateIp", privateIp, false)
                    }
                    publicIpCount++
                }
                count++
            }

            apTool.setOutputProperty("resourceNameList", agentNames.join(","))
            
            def envElements = slurper."environment"
            envElements.each{element ->
                String envName = element.@"name".text()
                println "setting environment name to " + envName
                apTool.setOutputProperty("environment.name", envName)
            }
        }
        apTool.setOutputProperties()
    }
    
    def createSnapshot() {
        final def terraformExec = props['terraformExec']
        final def instanceFile = props['instanceFile']
        final def credsFile = props['credsFile']
        final def unparsedProps = props['terraformProperties']
        
        def commandLineArgs = []
        def agentNames = []
        
        if (!terraformExec) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!instanceFile) {
            throw new IllegalArgumentException("No terraform instance file was specified.")
        }
        if (!credsFile) {
            throw new IllegalArgumentException("No terraform credentials file was specified.")
        }
        
        final def terraExecFile = new File(workDir, terraformExec)
        final def terraExecAbsolutePath = terraExecFile.absolutePath
        
        commandLineArgs << terraExecAbsolutePath
        commandLineArgs << "snapshot"
        commandLineArgs << instanceFile
        commandLineArgs << credsFile
        if (unparsedProps) {
            unparsedProps.split(" ").each() { prop ->
                if (prop) {
                    commandLineArgs << prop
                }
            }
        }
        def instanceXmlFile = ""
        def pb = ch.getProcessBuilder()
        ch.runCommand("Running Terraform to create snapshot", commandLineArgs){ Process proc ->
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            String output = proc.text
            println "log output incoming!"
            println output
            String[] outAsLines = output.split("\n")
            String magicXmlOutFinder = "Writing context out to "
            def foundXml = false
            for (String line : outAsLines) {
                //find the instance xml file name
                if (!foundXml && line.contains(magicXmlOutFinder)) {
                    foundXml = true
                    int fileNameBeginIndex = line.indexOf(magicXmlOutFinder) + magicXmlOutFinder.length()
                    instanceXmlFile = line.substring(fileNameBeginIndex)
                    instanceXmlFile = instanceXmlFile.replace("\r", "")
                    apTool.setOutputProperty("instanceXmlFile", instanceXmlFile)
                }
            }
        }
    }
    
    def suspendEnv() {
        final def terraformExec = props['terraformExec']
        final def instanceFile = props['instanceFile']
        final def credsFile = props['credsFile']
        final def unparsedProps = props['terraformProperties']
        
        def commandLineArgs = []
        def agentNames = []
        
        if (!terraformExec) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!instanceFile) {
            throw new IllegalArgumentException("No terraform instance file was specified.")
        }
        if (!credsFile) {
            throw new IllegalArgumentException("No terraform credentials file was specified.")
        }
        
        final def terraExecFile = new File(workDir, terraformExec)
        final def terraExecAbsolutePath = terraExecFile.absolutePath
        
        commandLineArgs << terraExecAbsolutePath
        commandLineArgs << "suspend"
        commandLineArgs << instanceFile
        commandLineArgs << credsFile
        if (unparsedProps) {
            unparsedProps.split(" ").each() { prop ->
                if (prop) {
                    commandLineArgs << prop
                }
            }
        }
        def instanceXmlFile = ""
        def pb = ch.getProcessBuilder()
        ch.runCommand("Running Terraform to create snapshot", commandLineArgs){ Process proc ->
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            String output = proc.text
            println "log output incoming!"
            println output
            String[] outAsLines = output.split("\n")
            String magicXmlOutFinder = "Writing context out to "
            def foundXml = false
            for (String line : outAsLines) {
                //find the instance xml file name
                if (!foundXml && line.contains(magicXmlOutFinder)) {
                    foundXml = true
                    int fileNameBeginIndex = line.indexOf(magicXmlOutFinder) + magicXmlOutFinder.length()
                    instanceXmlFile = line.substring(fileNameBeginIndex)
                    instanceXmlFile = instanceXmlFile.replace("\r", "")
                    apTool.setOutputProperty("instanceXmlFile", instanceXmlFile)
                }
            }
        }
    }
    
    def resumeEnv() {
        final def terraformExec = props['terraformExec']
        final def instanceFile = props['instanceFile']
        final def credsFile = props['credsFile']
        final def unparsedProps = props['terraformProperties']
        
        def commandLineArgs = []
        def agentNames = []
        
        if (!terraformExec) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!instanceFile) {
            throw new IllegalArgumentException("No terraform instance file was specified.")
        }
        if (!credsFile) {
            throw new IllegalArgumentException("No terraform credentials file was specified.")
        }
        final def terraExecFile = new File(workDir, terraformExec)
        final def terraExecAbsolutePath = terraExecFile.absolutePath
        
        commandLineArgs << terraExecAbsolutePath
        commandLineArgs << "resume"
        commandLineArgs << instanceFile
        commandLineArgs << credsFile
        if (unparsedProps) {
            unparsedProps.split(" ").each() { prop ->
                if (prop) {
                    commandLineArgs << prop
                }
            }
        }
        def instanceXmlFile = ""
        def pb = ch.getProcessBuilder()
        ch.runCommand("Running Terraform to resume environment", commandLineArgs){ Process proc ->
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            String output = proc.text
            println "log output incoming!"
            println output
            String[] outAsLines = output.split("\n")
            String magicXmlOutFinder = "Writing context out to "
            def foundXml = false
            for (String line : outAsLines) {
                //find the instance xml file name
                if (!foundXml && line.contains(magicXmlOutFinder)) {
                    foundXml = true
                    int fileNameBeginIndex = line.indexOf(magicXmlOutFinder) + magicXmlOutFinder.length()
                    instanceXmlFile = line.substring(fileNameBeginIndex)
                    instanceXmlFile = instanceXmlFile.replace("\r", "")
                    apTool.setOutputProperty("instanceXmlFile", instanceXmlFile)
                }
            }
        }
    }
    
    def addChildrenToQueue (def rootResource, def queue){
        if (rootResource.has("children")) {
            JSONArray children = rootResource.getJSONArray("children");
            for (int i = 0 ; i < children.length(); i ++ ) {
                JSONObject child = children.getJSONObject(i);
                queue.offer(child.getString("name"));
                addChildrenToQueue(child, queue);
            }
        }
    }
    
    def removeOldSubResources(String rootResourceName) {
        JSONArray resourceTree = client.getResourceTree();
    
        //first we need to find the root resource in the tree
        Queue<JSONObject> queue = new LinkedList<JSONObject>();
    
        for (int i = 0 ; i < resourceTree.length(); i ++ ) {
            queue.offer(resourceTree.get(i));
        }
    
        JSONObject current = null;
        JSONObject rootResource = null;
        while ((current = queue.poll()) != null) {
    
            if (current.getString("name") == rootResourceName) {
                rootResource = current;
                break;
            }
    
            if (current.has("children")) {
                JSONArray children = current.getJSONArray("children");
        
                for (int i = 0 ; i < children.length(); i ++ ) {
                    queue.offer(children.get(i));
                }
            }
        }
    
        if (rootResource == null) {
            throw new Exception("Root resource not found in resource tree for cleanup");
        }
    
        //flatten into Queue
        Queue<String> resQueue = new LinkedList<String>();
        addChildrenToQueue(rootResource, resQueue);
        
        println "size of queue " + resQueue.size()
    
        //remove res no longer needed
        def curResName = null;
        Collections.reverse(resQueue);
        while((curResName = resQueue.poll()) != null) {
            println "Attempting to remove child resource ${curResName}"
            client.deleteResource(curResName);
            println "Removing child resource ${curResName}"
        }
    }
    
    def destroyEnv() {
        final def terraformExec = props['terraformExec']
        final def instanceFile = props['instanceFile']
        final def credsFile = props['credsFile']
        final def unparsedProps = props['terraformProperties']
        
        def commandLineArgs = []
        def agentNames = []
        
        if (!terraformExec) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!instanceFile) {
            throw new IllegalArgumentException("No terraform instance file was specified.")
        }
        if (!credsFile) {
            throw new IllegalArgumentException("No terraform credentials file was specified.")
        }
        
        def xmlFile = new File(instanceFile)
        def fileText = xmlFile.getText()
        def slurper = new XmlSlurper().parseText(fileText).declareNamespace('udeploy':'org.urbancode.terraform.tasks.vmware.udeploy')
        def agentElements = slurper."*"."*"."udeploy:post-create-task"
        
        final def terraExecFile = new File(workDir, terraformExec)
        final def terraExecAbsolutePath = terraExecFile.absolutePath
        
        commandLineArgs << terraExecAbsolutePath
        commandLineArgs << "destroy"
        commandLineArgs << instanceFile
        commandLineArgs << credsFile
        if (unparsedProps) {
            unparsedProps.split(" ").each() { prop ->
                if (prop) {
                    commandLineArgs << prop
                }
            }
        }
        def pb = ch.getProcessBuilder()
        ch.runCommand("Running Terraform to destroy environment", commandLineArgs){ Process proc ->
            InputStream is = proc.getIn()
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(is));
            def line
           // read the output from the command
           while ((line = stdInput.readLine()) != null) {
               println "${line}"
           }
            
            proc.out.close()
            proc.consumeProcessErrorStream(System.out)
            String output = proc.text
            println output
            proc.in.close()
        }
        println "sleeping until uDeploy acknowledges that agents are offline"
        Thread.sleep(45000)
        agentElements.each{element ->
            String currentAgentName = element.@"agent-name".text()
            println "attempting to delete resource and agent with name " + currentAgentName
            removeOldSubResources(currentAgentName)
            client.deleteResource(currentAgentName)
            client.deleteAgent(currentAgentName)
            println "deleted resource and agent with name " + currentAgentName
        }
    }
    
    def createUD() {
        final def appName = props['appName']
        final def envPrefix = props['envPrefix']
        String resourceGroupPath = props['resourceGroup']
        final def unparsedResourceNames = props['resourceNames']
        final def unparsedComponents = props['components']
        def components = []
        
        if (!appName) {
            throw new IllegalArgumentException("No terraform executable was specified.")
        }
        if (!envPrefix) {
            throw new IllegalArgumentException("No environment prefix name was specified.")
        }
        if (!resourceGroupPath) {
            throw new IllegalArgumentException("No resource group was specified.")
        }
        if (!unparsedResourceNames && !internalAgentNames) {
            throw new IllegalArgumentException("No provisioned resources were found.")
        }
        def resourceNames
        if (internalAgentNames) {
            resourceNames = internalAgentNames
        }
        else {
            resourceNames = unparsedResourceNames.split("\n")
        }
        if (unparsedComponents) {
            components = unparsedComponents.split("\n")
        }
        
        
        //create environment
        def envName = envPrefix + "-" + UUID.randomUUID().toString().substring(0,6)
        UUID envUUID = client.createEnvironment(appName, envName, "generated-by-the-Terraform-plugin", "#FFF000", false)
        println "created environment with name " + envName + " for application " + appName
        
        //sanitize trailing slashes of resource group path
        while (resourceGroupPath.endsWith("/")) {
            resourceGroupPath = resourceGroupPath.substring(0, resourceGroupPath.length()-1);
        }
        //add resources to resource group
        def lastSlash = resourceGroupPath.lastIndexOf('/')
        def resourceGroupParent
        def resourceGroupChild
        
        //parse resource group parent and child
        if (lastSlash > 0) {
            resourceGroupParent = resourceGroupPath.substring(0, lastSlash)
            resourceGroupChild = resourceGroupPath.substring(lastSlash + 1)
        }
        else if (lastSlash == 0) {
            resourceGroupParent = "/"
            resourceGroupChild = resourceGroupPath.substring(1)
        }
        else {
            resourceGroupParent = "/"
            resourceGroupChild = "" + resourceGroupPath
        }
        if (resourceGroupPath.charAt(0) != '/') {
            resourceGroupPath = "/" + resourceGroupPath
        }
        //create resource group (returns status OK if already exists or Created if successfully created
        if (resourceGroupParent && resourceGroupChild) {
            client.createResourceGroup(resourceGroupParent, resourceGroupChild)
        }
        
        resourceNames.each {resourceName ->
            client.addResourceToGroup(resourceName, resourceGroupPath)
            println "added resource " + resourceName + " to resource group at path " + resourceGroupPath
        }
        
        components.each {component ->
            client.createComponentMapping(envUUID, component, "", resourceGroupPath)
            println "created component mapping for new environment with component " + component
        }
    }
}