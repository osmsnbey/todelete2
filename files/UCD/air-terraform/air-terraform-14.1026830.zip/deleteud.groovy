import com.urbancode.air.CommandHelper
import com.urbancode.air.AirPluginTool

final def workDir = new File('.').canonicalFile
def ch = new CommandHelper(workDir)
def apTool = new AirPluginTool(this.args[0], this.args[1])
def props = apTool.getStepProperties()

final def udUser = props['udUser']
final def udPassword = props['udPassword']
final def appName = props['appName']
final def envName = props['envName']
final def agentName = props['agentName']