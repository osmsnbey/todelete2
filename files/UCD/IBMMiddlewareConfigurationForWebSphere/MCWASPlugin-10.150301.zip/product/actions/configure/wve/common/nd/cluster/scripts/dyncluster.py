"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: dyncluster.py
	
	This script is to manage the dynamic cluster configuration.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f dyncluster.py 
		-scope <scope: cell/cluster> 
		-scopename <cell name/cluster name> 
		-nodeName <node name> 
		-properties <server xml file>	
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import *

from AdminHelper import AdminHelper

newline = java.lang.System.getProperty("line.separator")

class DynClusterMediator:
	
	ID = 'id'
	ATTRS = 'attrs'
	CHILD = 'children'
	
	def __init__(self, mode, scope, configType, excludedAttributes = []):
		self.LOGGER = _Logger("DynClusterMediator", MessageManager.RB_WEBSPHERE_WVE)
		self.configWriter = ConfigWriter()
		self.configReader = ConfigReader()
		self.mode = mode
		self.scope = scope
		self.configType = configType
	#endDef
	
	def findClustersInScope(self, scopeName, scopeType):
		cellName = AdminControl.getCell()
		dynclusterConfigId = []
		if (scopeType == 'cluster'):
			# Obtain config id for the specified dynamic cluster
			dynclusterConfigId.append(AdminConfig.getid('/Cell:' + cellName + '/DynamicCluster:' + scopeName + '/'))
		elif (scopeType == 'cell'):
			# Obtain config id for all dynamic clusters in the specified cell
			dynclusters = AdminConfig.list('DynamicCluster').split(newline)
			for dyncluster in dynclusters:
				dynclusterName = AdminConfig.showAttribute (dyncluster, 'name')
				clusterId = AdminConfig.getid('/Cell:' + cellName + '/DynamicCluster:' + dynclusterName + '/')
				dynclusterConfigId.append(clusterId)
				#endIf
			#endFor
		else:
			self.LOGGER.log("CRWVE1000E")
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WVE, "CRWVE1000E", None)
		#endIf
		return dynclusterConfigId
	#endDef
	
	def processServer(self, clusterIds, xmlFile, marker, scopeType, save="1"):
		if (self.mode == MODE_EXECUTE):
			self.executeServers(clusterIds, xmlFile, marker, scopeType, save)
		elif (self.mode == MODE_IMPORT):
			self.importServers(clusterIds, xmlFile, marker, scopeType)
		elif (self.mode == MODE_COMPARE):
			self.compareServers(clusterIds, xmlFile, marker, scopeType)
		else:
			print "Unsupported MODE supplied: " + self.mode
		#endIf
	#endDef
	
	def readConfigData(self, clusterIds, scopeType):
		self.LOGGER.traceEnter([clusterIds, scopeType])
		# this is going to get the info for each server in scope, comparing to find the correct value
		data = []
		
		cellName = AdminControl.getCell()
		for clusterId in clusterIds:
			print "processing cluster: " + clusterId
			parent = self.configReader.showAll(clusterId)
			parent[DynClusterMediator.ID] = self.configType
			
			dynclusterName = AdminConfig.showAttribute(clusterId, 'name')
			serverClusterId = AdminConfig.getid('/Cell:' + cellName + '/ServerCluster:' + dynclusterName + '/')
			
			dynamicWeightCfgId = AdminConfig.list('DynamicWtCtrlr', serverClusterId)
			wlmChild = self.configReader.showAll(dynamicWeightCfgId)
			wlmChild[DynClusterMediator.ID] = 'DynamicWtCtrlr'
			parent[DynClusterMediator.CHILD].append(wlmChild)
			
			clusterMembers = AdminConfig.list('ClusterMember', serverClusterId).split(newline)
			if (len(clusterMembers) > 0):
				for mem in clusterMembers:
					memChild = {}
					memChild[DynClusterMediator.ATTRS] = {}
					memChild[DynClusterMediator.ID] = 'ClusterMember'
					memChild[DynClusterMediator.ATTRS]['memberName'] = AdminConfig.showAttribute(mem, 'memberName')
					memChild[DynClusterMediator.ATTRS]['nodeName'] = AdminConfig.showAttribute(mem, 'nodeName')
					memChild[DynClusterMediator.ATTRS]['weight'] = AdminConfig.showAttribute(mem, 'weight')
					memChild[DynClusterMediator.CHILD] = []
					parent[DynClusterMediator.CHILD].append(memChild)
				#endFor
			#endIf
			
			data.append(parent)
		#endFor
		
		self.LOGGER.traceExit(data)
		return data
	#endDef
	
	def importServers(self, clusterIds, xmlFile, marker, scopeType):
		print "Importing Dynamic Cluster configuration in scope: " + self.scope
		data = self.readConfigData(clusterIds, scopeType)
		GenericConfigFileWriter.processBasicFile(xmlFile, data, marker)
	#endDef
	
	def executeServers(self, clusterIds, xmlFile, marker, scopeType, save="1"):
	
		print "Updating Dynamic Cluster configuration in scope: " + self.scope
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray(self.configType)
		
		clusterNameIdMap = {}
		cellName = AdminControl.getCell()
		for clusterId in clusterIds:
			clusterName = AdminConfig.showAttribute(clusterId, "name")
			clusterNameIdMap[clusterName] = clusterId
		#endFor
		
		for xmlNode in nodeArray:
			if (xmlNode.hasAttr("name")):
				dynclusterName = xmlNode.getAttrValue("name")
				if (dynclusterName in clusterNameIdMap.keys()):
					configId = clusterNameIdMap[dynclusterName]
					self.configWriter.modify(configId, xmlNode)
				else:
					self.LOGGER.error("Invalid Name: Dynamic cluster '" + dynclusterName +  "' not found in WebSphere configuration")
				#endIf
				for child in xmlNode.getChildrenArray():
					if (child.getNodeNameFixed() == 'DynamicWtCtrlr'):
						dynamicWtCfgId = AdminConfig.list('DynamicWtCtrlr', AdminConfig.getid('/Cell:' + cellName + '/ServerCluster:' + dynclusterName + '/'))
						self.configWriter.modify(dynamicWtCfgId, child)
					elif (child.getNodeNameFixed() == 'ClusterMember'):
						clusterMemName = child.getAttrValue("memberName")
						weight = child.getAttrValue("weight")
						memCfgId =  AdminConfig.getid('/ClusterMember:' + clusterMemName + '/')
						## Only cluster members 'weight' modification is allowed, other attribute values
						## cannot be changed. Hence call AdminConfig.modify() explicitly.
						AdminConfig.modify(memCfgId, [['weight', weight]])
					#endIf
				#endFor
			else:
				raise "Attribute 'name' missing in the 'DynamicCluster' XML node"
			#endIf
		#endFor
		if save is not None:
			AdminHelper.saveAndSyncCell()
		#endIf
	#endDef
	
	def compareServers(self, clusterIds, xmlFile, marker, scopeType):
		self.LOGGER.traceEnter([clusterIds, xmlFile, marker, scopeType])
		print "Comparing Dynamic Cluster configuration in RAF and WAS at scope: " + self.scope
		for clusterId in clusterIds:
			# get wasConfig
			wasConfig = self.readConfigData([clusterId], scopeType)
			
			# get rafwConfig
			xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
			xmlProp = xmlProp.findRAFWContainerNode(marker)
			filteredNodes = xmlProp.getFilteredNodeArray(self.configType)
			xmlConfigReader = XMLConfigReader()
			rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
			
			ConfigComparor.compare(self.configType, wasConfig, rafwConfig)
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
#endClass

def export(optDict=None):
	scope = optDict['wasscopetype']
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	
	# configType refers to parent config type i.e, DynamicCluster
	configType = optDict['type']
	marker = optDict['marker']
	thisMediator = DynClusterMediator(mode, scope, configType)
	
	clusterIds = thisMediator.findClustersInScope(scopeName, scopeType)
	thisMediator.processServer(clusterIds, xmlFile, marker, scopeType, None)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt(sys.argv, 'scope:;scopename:;nodename:;properties:;mode:')
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	
	# configType refers to parent config type i.e, DynamicCluster
	configType = 'DynamicCluster'
	marker = 'dynamicCluster'
	thisMediator = DynClusterMediator(mode, scope, configType)
	
	clusterIds = thisMediator.findClustersInScope(scopeName, scopeType)
	thisMediator.processServer(clusterIds, xmlFile, marker, scopeType)
#endIF