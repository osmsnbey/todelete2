-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM 
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- (C) Copyright IBM Corporation 2006. All rights reserved. 
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

CREATE TABLE PERSISTENTLOCK (
  LOCKID INTEGER NOT NULL,
  SEQUENCEID INTEGER NOT NULL,
  OWNER INTEGER NOT NULL,
  MODULENAME VARCHAR(250),
  COMPNAME VARCHAR(250),
  METHOD VARCHAR(250),
  MSGHANDLESTRING VARCHAR(128));

ALTER TABLE PERSISTENTLOCK
  ADD CONSTRAINT PK_PERSISTENTLOCK PRIMARY KEY (LOCKID, SEQUENCEID);

