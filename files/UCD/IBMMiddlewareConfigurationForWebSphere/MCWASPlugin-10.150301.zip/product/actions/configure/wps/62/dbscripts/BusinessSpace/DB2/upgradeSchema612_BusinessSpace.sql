-- Licensed Materials - Property of IBM
-- 5724-M24
-- Copyright IBM Corporation 2008, 2009.  All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- -----------------------------------------------------------------------------
--
-- Script file to perform schema changes for Business Space during
-- migration from 6.1.2 to 6.2
--
-- Customize the following variable before running this script:
--   @SCHEMA@ = DB2 Schema qualifier
--
-- Process this script in the DB2 command line processor
-- Example:
--    db2 connect to IBMBUSSP
--    db2 -tf upgradeSchema612_BusinessSpace.sql
--

---------------------------------
-- Create, modify, drop tables --
---------------------------------

	DROP TABLE @SCHEMA@.DASHBOARD_DATA_T;

-- No change to the USER_DATA_T table
-- No change to the SPACES table
-- No change to the NLSINFO table

	CREATE INDEX @SCHEMA@.I0000010 ON @SCHEMA@.PAGE ( OWNER ASC );
	CREATE INDEX @SCHEMA@.I0000011 ON @SCHEMA@.PAGE ( SPACEID ASC );

-- No change to the WIDGET table
-- No change to the REGISTERED_WIDGET table
-- No change to the REGISTERED_WIDGET_NLS table
-- No change to the REGISTERED_CATEGORY table
-- No change to the REGISTERED_CATEGORY_NLS table

	ALTER TABLE @SCHEMA@.REGISTERED_ENDPOINT
		ADD COLUMN TYPE           VARCHAR(256) ;
	ALTER TABLE @SCHEMA@.REGISTERED_ENDPOINT
		ADD COLUMN NAME           VARCHAR(256) ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_ENDPOINT_NLS (
		  EXTENSION               BLOB(10K) ,
		  ID_LOCALE               VARCHAR(356) NOT NULL ,
		  ENDPOINT_ID_VERSION     VARCHAR(322) NOT NULL ,
		  LOCALE                  VARCHAR(32) ,
		  NAME                    VARCHAR(256) ,
		  DESCRIPTION             VARCHAR(1024) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( ENDPOINT_ID_VERSION )
			REFERENCES @SCHEMA@.REGISTERED_ENDPOINT ( ID_VERSION )
			ON DELETE CASCADE
		) IN BSPACE ;
	
	CREATE TABLE @SCHEMA@.REGISTERED_WCCM_ENDPOINT (
		  EXTENSION               BLOB(10K) ,
		  ID_VERSION              VARCHAR(322) NOT NULL ,
		  LAST_CHANGE             VARCHAR(32) NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) IN BSPACE ;
	
-- No change to the REGISTRY_FILE table
