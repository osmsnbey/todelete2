--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to drop tablespaces for DB2 UDB
-- Run the script with the following sequence:
--      db2 connect to BPEDB
--      db2 -tf dropTablespace.sql


----------------------
-- Drop tablespaces --
----------------------

DROP TABLESPACE AUDITLOG;

DROP TABLESPACE INSTANCE;

DROP TABLESPACE STAFFQRY;

DROP TABLESPACE TEMPLATE;

DROP TABLESPACE WORKITEM;

-----------------------------------------
-- Drop 8 K tablespaces and bufferpool --
-----------------------------------------
DROP TABLESPACE BPETS8K;

DROP TABLESPACE BPETEMP8K;

DROP BUFFERPOOL BPEBP8K;



-- start import scheduler DDL: dropTablespaceDB2.ddl

DROP TABLESPACE SCHEDTS;
-- end import scheduler DDL: dropTablespaceDB2.ddl

