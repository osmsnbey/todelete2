--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to clear schema in Oracle 9i and Oracle 10g
-- Process this script using SQL*Plus
----------------------------------------------------------------------
-- The following variable needs to be changed for customization and
-- before running this script.
-- @SCHEMA@ = Schema name
----------------------------------------------------------------------
-- Example: sqlplus scott/tiger@mydb @clearSchema_Observer.sql
-- or, at the sqlplus prompt, enter
-- SQL> @clearSchema_Observer.sql

DELETE FROM @SCHEMA@.INST_PRC_T;
DELETE FROM @SCHEMA@.INST_ACT_T;
DELETE FROM @SCHEMA@.EVENT_PRC_T;
DELETE FROM @SCHEMA@.EVENT_ACT_T;
DELETE FROM @SCHEMA@.QUERY_T;
DELETE FROM @SCHEMA@.OPEN_EVENTS_T;
QUIT
