--BEGIN CMVC
--*************************************************************************
--
--  Workfile: WBISRVR/ws/code/scheduler.wbi/src/dbscripts/CommonDB/DB2/dropTable_AppScheduler.sql, wbi.scheduler, WBI62.WBISRVR, of0914.16
--  Last update: 07/03/16 03:24:20
--  SCCS path, id: /family/botp/vc/10/9/8/9/s.68 1.2
--
--*************************************************************************
--END CMVC
--BEGIN COPYRIGHT
--*************************************************************************
--
--  Licensed Materials - Property of IBM
--  5724-L01, 5655-N53, 5724-I82, 5655-R15
--  (C) Copyright IBM Corporation 2004, 2006.
--  All rights reserved. US Government Users Restricted Rights - Use,
--  duplication, or disclosure restricted by GSA ADP Schedule Contract with
--  IBM Corp.
--
--*************************************************************************
--END COPYRIGHT
--
-- Scriptfile to drop schema for DB2
-- 1. Process this script in the DB2 command line processor
-- Example:
--             db2 connect to WPRCSDB
--             db2 -tf dropTable_AppScheduler.sql
--
--
-- Indices
DROP INDEX WSCH_TASK_IDX1;

DROP INDEX WSCH_TASK_IDX2;

-- Auxillary table indices
DROP INDEX WSCH_LMPR_IDX1;

-- Main table
DROP TABLE WSCH_TASK;

-- Registry table
DROP TABLE WSCH_TREG;

-- Lease Manager Tables
DROP TABLE WSCH_LMGR;

DROP TABLE WSCH_LMPR;

