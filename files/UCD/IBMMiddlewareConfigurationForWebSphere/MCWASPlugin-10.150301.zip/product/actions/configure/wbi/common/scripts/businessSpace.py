"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: businessSpace.py
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

businessSpaceLogger = _Logger("businessSpace", MessageManager.RB_WEBSPHERE_WP)

class businessSpace:
	def deployBusinessSpace(self):
		commandOptions = '-clusterName ' + optDict['clusterName']
		businessSpaceLogger.debug("AdminTask.installBusinessSpace( " + commandOptions + ")")
		AdminTask.installBusinessSpace(commandOptions)
	#endDef
	
	def enableBusinessSpace(self):
		commandOptions = '-clusterName ' + optDict['clusterName'] + ' -dbName ' + optDict['dbName'] + ' -schemaName ' + optDict['schemaName'] + ' -tableSpaceName ' + optDict['tableSpaceName'] + ' -productTypeForDatasource ' + optDict['productTypeForDatasource']
		businessSpaceLogger.debug("AdminTask.configureBusinessSpace( " + commandOptions + ")")
		AdminTask.configureBusinessSpace(commandOptions)
		
		## Above command sets a default value for the authentication alias for the business space data source.
		## We need to map the correct authentication alias for the business space data source.
		bSpaceAuthAlias = "BSPACE_Auth_Alias"
		wbiAliases = AdminConfig.list("WBIAuthAlias").split(newline)
		for alias in wbiAliases:
			if(alias != ""):
				# Find the WBI authentication alias defined for business space component
				if(AdminConfig.showAttribute(alias, "component") == "WBI_BSPACE"):
					bSpaceAuthAlias = AdminConfig.showAttribute(alias, "name")
					break
				#endIf
			#endIf
		#endIf
		
		cellName = AdminControl.getCell()
		clusterId = AdminConfig.getid('/Cell:'+ cellName + '/ServerCluster:' + optDict['clusterName'] + '/')
		dataSources = AdminConfig.list('DataSource', clusterId).split(newline)
		for ds in dataSources:
			if(ds != ""):
				# Find the exact data source on the cluster, defined for business space component
				if (AdminConfig.showAttribute(ds, 'jndiName') == "jdbc/bpm/BusinessSpace"):
					# Modify authentication alias for the business space data source
					AdminConfig.modify(ds, '[[authDataAlias ' + bSpaceAuthAlias + '] [xaRecoveryAuthAlias ' + bSpaceAuthAlias + ']]')
					break
				#endIf
			#endIf
		#endFor
	#endDef
	
	def getBusinessSpaceStatus(self):
		commandOptions = '-clusterName ' + optDict['clusterName']
		businessSpaceLogger.debug("AdminTask.getBusinessSpaceDeployStatus(" + commandOptions + ")")
		AdminTask.getBusinessSpaceDeployStatus(commandOptions)
	#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;clusterName:;dbName:;schemaName:;tableSpaceName:;productTypeForDatasource:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

businessSpaceLogger = _Logger("businessSpace", MessageManager.RB_WEBSPHERE_BPM)
thisBusinessSpace = businessSpace()

if(mode == MODE_EXECUTE):
	print "Configuring WebSphere Business Space on %s" % optDict['clusterName']

	if(action == "DEPLOY"):
		thisBusinessSpace.deployBusinessSpace()
		AdminHelper.saveAndSyncCell()
	if(action == "ENABLE"):
		thisBusinessSpace.enableBusinessSpace()
		AdminHelper.saveAndSyncCell()
	if(action == "STATUS"):
		thisBusinessSpace.getBusinessSpaceStatus();
	else:
		#print "Unsupported ACTION supplied: " + action
		businessSpace.log("CRWWP2002I",[action])
else:
	#print "Unsupported MODE supplied: " + mode
	businessSpace.log("CRWWP2001I",[mode])
