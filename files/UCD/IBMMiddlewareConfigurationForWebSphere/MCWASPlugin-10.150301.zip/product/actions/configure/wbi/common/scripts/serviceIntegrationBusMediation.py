"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: serviceIntegrationBusMediation.py
"""

import java.util as util
import java.io as javaio
import sys

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

serviceIntegrationBusMediationLogger = _Logger("serviceIntegrationBusMediation", MessageManager.RB_WEBSPHERE_WP)

class serviceIntegrationBusMediation:
    def createMediationOnBus(self):
        #required parameters
        busName = properties.get('sib.Mediation.SIBusName')
        mediationName = properties.get('sib.Mediation.Name')
        handlerListName = properties.get('sib.Mediation.HandlerListName')
        commandOptions = '-bus ' + busName + ' -mediationName ' + mediationName + ' -handlerListName ' + handlerListName
        #optional parameters
        if(properties.get('sib.Mediation.Description') is not None):
            commandOptions = commandOptions + ' -description ' + properties.get('sib.Mediation.Description')
        if(properties.get('sib.Mediation.AllowConcurrentMediation')  is not None):
            commandOptions = commandOptions + ' -allowConcurrentMediation ' + properties.get('sib.Mediation.AllowConcurrentMediation')
        if(properties.get('sib.Mediation.Selector') is not None):
            commandOptions = commandOptions + ' -selector ' + properties.get('sib.Mediation.Selector')
        if(properties.get('sib.Mediation.Discriminator') is not None):
            commandOptions = commandOptions + ' -discriminator ' + properties.get('sib.Mediation.Discriminator')
        siBusMediationLogger.info('AdminTask.modifySIBMediation(' + commandOptions +')')
        AdminTask.createSIBMediation(commandOptions)
        
    def findMediationOnBus(self):
        commandOptions = '-bus ' + optDict['busName'] + ' -mediationName ' + optDict['mediationName']
        siBusMediationLogger.info('AdminTask.showSIBMediation(' + commandOptions +')')
        AdminTask.showSIBMediation(commandOptions)
        
    def readProperties(self, aFile):
       siBusMediationLogger.debug("Reading properties file: " + aFile)
       properties = util.Properties()
       propertiesFileInputStream =javaio.FileInputStream(aFile)
       properties.load(propertiesFileInputStream)
       return properties
        
# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;clusterName:;contextRoot:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

siBusMediationLogger = _Logger("siBusMediation", MessageManager.RB_WEBSPHERE_BPM)
thisSIBusMediation = serviceIntegrationBusMediation()

properties = thisSIBusMediation.readProperties(xmlFile);

if(mode == MODE_EXECUTE):
    #print "Configuring Service Integration Bus Mediation on: %s" % optDict['clusterName']
    serviceIntegrationBusMediationLogger.log("CRWBP0206I",[optDict['clusterName']])
    
    if(action == "CREATE_MEDIATION"):
        thisSIBusMediation.createMediationOnBus();
        AdminHelper.saveAndSyncCell()
else:
    #print "Unsupported MODE supplied: %s" % optDict['mode']
    serviceIntegrationBusMediationLogger.log("CRWBP0207I",[optDict['mode']])
