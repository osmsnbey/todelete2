"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: manageServer.py
	
	This script is to manage an existing server sub config based on type
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f manageServer.py 
		-scope <scope: node/cluster/server/cell> 
		-scopename <server/cluster name> 
		-nodeName <node name> 
		-properties <server xml file> 
		-config_type <sub config element name>
"""

import sys
from ConfigWriter import ConfigWriterException
from XmlProperty import SkipEmptyAttributes
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from java.util import ArrayList, HashSet
from ConfigComparor import ConfigComparor
from com.ibm.rational.rafw.wsadmin.websphere import MessageRecorder
import Globals
from ConfigMediator import MODE_IMPORT, MODE_EXECUTE, MODE_COMPARE
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import  org.w3c.dom.Node as Node
from com.ibm.rational.rafw.wsadmin.websphere.config import LegacyWsadminConfigHelper,\
	WsadminConfigUtils
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter,\
	WsadminConfigXmlBuilder
from com.ibm.rational.rafw.wsadmin.websphere.config.compare import ConfigCompareTools,\
	WsadminConfigComparator, AllAttributesConfigComparator, Compare, CompareDisplay, CompareDisplayProperties
from java.io import PrintWriter
from java.lang import Integer

"""
	Manages application server configuration
"""




class ServerConfigMediator:

	INVALID_NODEAGENT_CONFIG_TYPES = ["ApplicationServer", "ApplicationServer.Classloader", 
									"HTTPAccessLoggingService", "ApplicationProfileService", "SIBService"]
	INVALID_DMGR_CONFIG_TYPES = ["ApplicationServer", "ApplicationServer.Classloader", "SIBService", "TPVService"]
	PROXY_CONFIG_TYPES = ["ProxySettings", "SIPProxySettings", "ProxyVirtualHostSettings", "ProxyVirtualHost"]

	## the following types apply to APPLICATION_SERVER server types, 
	## in addition to standard ones that fall under the applicaton server
	## WAS_60_CONFIG_TYPES = [ "AdminService", "ApplicationProfileService", "ApplicationServer.Classloader",
	##			"CoreGroupBridgeService", "CustomService", "HAManagerService", "HTTPAccessLoggingService",
	##			"JavaProcessDef", "MessageListenerService", "NameServer", "ObjectRequestBroker",
	##			"PMIModule", "PMIService", "RASLoggingService", "SIBService", "StatisticsProvider", 
	##			"ThreadPoolManager", "TPVService", "TraceService", "TransportChannelService", 
	##			"SERVER.outputStreamRedirect", "SERVER.errorStreamRedirect" ]
	WAS_60_CONFIG_TYPES = [ "HAManagerService", "PMEServerExtension", "PME51ServerExtension",
						"PMIModule", "SIBService", "ApplicationServer.Classloader"] 
	WAS_61_ADTL_CONFIG_TYPES = ["EventInfrastructureService", "ProxySettings"]
	WAS_70_ADTL_CONFIG_TYPES = ["SIPProxySettings", "ProxyVirtualHostConfig"]
	WAS_80_ADTL_CONFIG_TYPES = ["HighPerformanceExtensibleLogging", "CEASettings"]

	# application server has many dependencies on other configuration (including ThreadPools), 
	# running 'ApplicationServer' at the end so that references can be found 
	WAS_FINAL_CONFIG_TYPES = ["ApplicationServer"]
						
	"""
	"""
	def __init__(self, messageRecorder):
		self.LOGGER = _Logger("manageServer", MessageManager.RB_WEBSPHERE_WAS)	
		self.configWriter = ConfigWriter();
		self.configReader = ConfigReader()
		self.xmlProp = None
		self.ignoreEmptyXml = 0
		self.ignoreConfigDifferences = 0
		self.messageRecorder = messageRecorder
	#endDef

	"""
		True if xml nodes which contain no data should be ignored.  
		If false, execute mode will fail with an error
	"""	
	def setIgnoreEmptyXml(self, ignoreIt):
		self.ignoreEmptyXml = ignoreIt
	#endDef

	"""
		True if differences between servers should be ignored.
		If false, import mode will fail with an error when importing 2 servers that have 
		different configuration.
	"""	
	def setIgnoreConfigDifferences(self, ignoreIt):
		self.ignoreConfigDifferences = ignoreIt
	#endDef

	""" 
		This is the entry point to this class, based on mode 
		execute, import, compare or augment modes will be run
	"""
	def processServer(self, serverIds, xmlFile, configType, scopeType):
		
		if (mode == MODE_EXECUTE):
			self.executeServers(serverIds, xmlFile, configType, scopeType)
		elif (mode == MODE_AUGMENT):
			self.augmentServers(serverIds, xmlFile, configType, scopeType)
		elif (mode == MODE_IMPORT):
			self.importServers(serverIds, xmlFile, configType, scopeType)
		elif (mode == MODE_COMPARE):
			self.compareServers(serverIds, xmlFile, configType, scopeType)
		else:
			#print "Unsupported MODE supplied: " + mode
			self.LOGGER.log("CRWWA0008W",[mode])
		#endIf
	#endDef

	def executeAllConfigTypes(self, serverIds, xmlFile, scopeType):
		if (self.xmlProp is None):
			self.xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		#endIf
		later = []
		for xmlPropertyNode in self.xmlProp.getNodeArray():
			if (xmlPropertyNode.getXmlNode().getNodeType() == Node.ELEMENT_NODE): 
				nodeName = xmlPropertyNode.getXmlNode().getNodeName()
				if (nodeName.find("RAFW_") >= 0):
					nodeName = nodeName[5:]
				#endIf
				if (scopeType == "cluster" and nodeName == "Server"):
					continue
				elif (nodeName in ServerConfigMediator.WAS_FINAL_CONFIG_TYPES):
					## do this later
					later.append(nodeName)
				else:
					self.executeServers(serverIds, xmlFile, nodeName, scopeType)
				#endIf
			#endIf
		#endFor
		for nodeName in later:
			self.executeServers(serverIds, xmlFile, nodeName, scopeType)
		#endFor
	#endDef
	
	"""
		Updates or creates server configuration based on config type 
		from the supplied xmlFile
		
		If the element can be identified by attribute name, it will
		be updated.  If the attribute is a singleton (exists only once in 
		a WAS config) it will be updated.
	"""
	def executeServers(self, serverIds, xmlFile, configType, scopeType):
		
		#print "Updating server config: "
		self.LOGGER.log("CRWWA2005I",[configType])
		if (self.xmlProp is None):
			self.xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		#endIf
		self.manageDataReplicationDomain()		
		## some attributes must be skipped if they do not contain a value
		if (configType == "TransportChannelService"):
			self.xmlProp.addSkipAttributeOnWriteFilter(SkipEmptyAttributes("addressExcludeList"))
			self.xmlProp.addSkipAttributeOnWriteFilter(SkipEmptyAttributes("addressIncludeList"))
			self.xmlProp.addSkipAttributeOnWriteFilter(SkipEmptyAttributes("hostNameExcludeList"))
			self.xmlProp.addSkipAttributeOnWriteFilter(SkipEmptyAttributes("hostNameIncludeList"))
		#endIf
		if (configType == "Server"):
			self.xmlProp.addSkipAttributeOnWriteFilter(SkipNamedAttribute("serverType"))
		#endIf
			
		xmlProp = self.xmlProp.findRAFWContainerNode(configType)
		nodeArray = xmlProp.getFilteredNodeArray(configType)
		
		excludedTypes = self.getExcludedTypes(configType, scopeType)
		configElements = ConfigElements()
	
		for serverId in serverIds:
			serverType = AdminConfig.showAttribute(serverId, 'serverType')
			## special handling for nodeagents and dmgr since all server actions are published as available 
			## at nodeagent and dmgr scope even if they shouldn't be
			if (serverType == 'NODE_AGENT' and configType in ServerConfigMediator.INVALID_NODEAGENT_CONFIG_TYPES):
				self.LOGGER.log("CRWWA0129I", [serverId, configType, serverType])
				continue
			elif (serverType == 'DEPLOYMENT_MANAGER' and configType in ServerConfigMediator.INVALID_DMGR_CONFIG_TYPES):
				self.LOGGER.log("CRWWA0129I", [serverId, configType, serverType])
				continue
			# SERVER is used to denote that the configuration type is accessible 
			# as an attribute of the server
			if (configType == 'Server'):
				if (len(nodeArray) == 1):
					AdminConfig.modify(serverId, nodeArray[0].buildNodeAttrsAsJyString(excludedTypes))
					nodeArray[0].setConfigId(serverId)
				#endIf
			elif (configType.find('SERVER.') >= 0):
				attrName = configType.split('.')[1]
				objId = AdminConfig.showAttribute(serverId, attrName)
				if (len(nodeArray) != 1):
					## if ALL, don't fail, instead, print a helpful message and return
					if (self.ignoreEmptyXml):
						msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
								"CRWWA0010I", [configType, scopeType])
						self.messageRecorder.addMessage(msg)
						return
					else:
						msg = "configuration elements whose parent type is a Server attribute must have 1 XML configuration stanza"
						self.LOGGER.error(msg)
						raise ConfigWriterException(msg)
					#endIf
				else:
					self.configWriter.modify(objId, nodeArray[0], excludedTypes)
					## Cannot update references for attributes under SERVER because the configType in the 
					## XML node array matches the attribute name, not the WAS config type.  
					## As of now, there are no actions that need this capability.
					## configElements.addReferenceIds(objId, nodeArray)
				#endIf
			else:
				objId, actualConfigType = self.processConfigType(serverId, configType)
				if (len(objId) > 0):
					## empty xml files supplied to server will wack most server configuration
					## protect the user from breaking everything...
					## only non-singletons can be entirely removed
					if (len(nodeArray) == 0 and configType != "CustomService" and configType != "ApplicationServer.Classloader"):
						## if ALL, don't fail, instead, print a helpful message and return
						if (self.ignoreEmptyXml):
							msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
								"CRWWA0010I", [configType, scopeType])
							self.messageRecorder.addMessage(msg)
							return
						else:
							msg = ("0 elements for type '" + configType + "' found in the data file.  " +
							"You must supply configuration for this type before running this action.")
							self.LOGGER.error(msg)
							raise ConfigWriterException(msg)
						#endIf
					elif (configType == "JavaProcessDef"):
						## server configuration for JavaProcessDef puts config in 2 places 
						## processDefinition ProcessDef(JavaProcessDef)
						## processDefinitions ProcessDef(JavaProcessDef)*
						## so when we update or manage, we want to create them under the expected attribute
						nodesByAttr = {}
						for node in nodeArray:
							if (node.hasAttr(Globals.WAS_KEY_ATTR_NAME)):
								attr = node.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
							else:
								attr = "processDefinitions"
							#endIf
							if (not nodesByAttr.has_key(attr)):
								nodesByAttr[attr] = []
							nodesByAttr[attr].append(node)
						#endFor
					
						for attr in ["processDefinition", "processDefinitions"]:
							if (self.configReader.hasAttr(serverId, attr)):
								if (nodesByAttr.has_key(attr)):
									nodes = nodesByAttr[attr]
								else:
									nodes = []
								#endIf
								existingIds = AdminHelper.extractWASIdsFromList(
									AdminConfig.showAttribute( serverId, attr ))
	 							self.configWriter.processChildren(existingIds, nodes, serverId, excludedTypes)
	 						#endIf
	 					#endFor
						## Update WAS references for each server, after other attribute values are modified
						self.configWriter.updateWASReferenceAttributes(nodeArray, serverId)
					else:
						# singletons with no unique attrs will fail the reference processing
						referenceExcludedTypes = ['ApplicationProfileService','ObjectPoolService']
						pmeServices = ['startupbeansservice', ' activitysessionservice', 'workareaservice', 
										'workmanagerservice', 'i18nservice', 'schedulerservice', 
										'applicationprofileservice', 'objectpoolservice', 'compensationservice', 
										'workareapartitionservice']
						nodesByAttr = {}
						for node in nodeArray:
							if (node.hasAttr(Globals.WAS_KEY_ATTR_NAME)):
								attr = node.getAttrValue(Globals.WAS_KEY_ATTR_NAME)								
								if (str(pmeServices).find(attr.lower()) == -1):
									if (not nodesByAttr.has_key(attr)):
										nodesByAttr[attr] = []
									#endIf								
									nodesByAttr[attr].append(node)
								#endIf
							#endIf
						#endFor
						if (len(nodesByAttr) > 0):
							for attr in nodesByAttr.keys():
								if (self.configReader.hasAttr(serverId, attr)):
									nodes = nodesByAttr[attr]
									existingIds = AdminHelper.extractWASIdsFromList(
										AdminConfig.showAttribute( serverId, attr ))
									idsToMod = []
									## filter out those ids who refer to different was types than the 1 we are managing
									for id in existingIds:
										wasType = self.configReader.getWASType(id)
										if (wasType == configType):
											idsToMod.append(id)
									#endFor
	 								self.configWriter.processChildren(idsToMod, nodes, serverId, excludedTypes)
	 		 					#endIf
	 						#endFor
	 					else:
							## for the other WASKeys, update all remaining nodes against the ids in the attribute
							self.configWriter.updateWASObject(nodeArray, objId, actualConfigType, excludedTypes)
							## Commenting the below line, since we don't have to explicitly store the object id references 
							## configElements.addReferenceIds(objId, nodeArray)
	 					#endIf
						
						## Update WAS references for each server, after other attribute values are modified
						self.configWriter.updateWASReferenceAttributes(nodeArray, objId, referenceExcludedTypes)
					#endIf
				else:
					## The parent configuration id doesn't exist, so we cannot update the child or its references
					## this implies an invalid WAS configuration
					self.LOGGER.log("CRWWA0126E", [configType, serverId, str(nodeArray)])
				#endIf
			#endIf
		#endFor
	#endDef
	
	"""
	Used to create or update DataReplicationDomain
	
	Supported configTypes are:
	DataReplicationDomain
	"""
	
	def manageDataReplicationDomain(self):
		myConfigWriter = ConfigWriter();
		xmlProp = self.xmlProp.findRAFWContainerNode(configType)
		domainArray = xmlProp.getFilteredNodeArray('DataReplicationDomain')
		if (len(domainArray) != 0):
			for xmlNode in domainArray:
				domains = AdminConfig.list('DataReplicationDomain').split(newline)
				domainName = domainArray[0].getAttrValue("name")
				cellName = AdminControl.getCell()
				cellId = AdminConfig.getid("/Cell:" + cellName)
				if (str(domains).find(domainName) == -1):
					myConfigWriter.createWASObject(xmlNode, cellId)				
				else:
					domainId = AdminConfig.getid("/Cell:" + cellName +"/DataReplicationDomain:" + domainName)
					configValidator = ConfigValidator()
					childId = configValidator.validateUniqueAttr2(xmlNode, domainId, "name")
					myConfigWriter.modify(childId, xmlNode)
				#endIf
			#endFor
			AdminConfig.save()
		#endIf
	#endDef
	
	"""
	Used to augment a server configuration 
	nothing will be deleted or updated, but new entries are created
	
	Supported configTypes are:
	CustomService
	ApplicationServer.Classloader
	
	ALL is not supported by augment, this method does not support any features of ALL
	"""
	def augmentServers(self, serverIds, xmlFile, configType, scopeType):
		
#print "Augmenting server config: "
		self.LOGGER.log("CRWWA5028I")
	
		configElements = ConfigElements()
		if (configType == "CustomService" or configType == "ApplicationServer.Classloader"):
			xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
			xmlProp = xmlProp.findRAFWContainerNode(configType)
			nodeArray = xmlProp.getFilteredNodeArray(configType)
		
			excludedTypes = self.getExcludedTypes(configType, scopeType)
	
			for serverId in serverIds:
				serverType = AdminConfig.showAttribute(serverId, 'serverType')
				## special handling for nodeagents and dmgr since all server actions are published as available 
				## at nodeagent and dmgr scope even if they shouldn't be
				if (serverType == 'NODE_AGENT' and configType in ServerConfigMediator.INVALID_NODEAGENT_CONFIG_TYPES):
					self.LOGGER.log("CRWWA0129I", [serverId, configType, serverType])
					continue
				elif (serverType == 'DEPLOYMENT_MANAGER' and configType in ServerConfigMediator.INVALID_DMGR_CONFIG_TYPES):
					self.LOGGER.log("CRWWA0129I", [serverId, configType, serverType])
					continue
				objId, actualConfigType = self.processConfigType(serverId, configType)
				for xmlNode in nodeArray:
					self.LOGGER.log("Processing xmlNode: " + str(xmlNode))
					if (configType == "ApplicationServer.Classloader"):
						if (len(objId) > 0):
							self.augmentServersProcessClassLoader(objId, xmlNode, actualConfigType)
							configElements.addReferenceId(objId, xmlNode)
						else:
							## The parent configuration id doesn't exist, so we cannot update the child or its references
							self.LOGGER.log("CRWWA0128E", [serverId, str(xmlNode)])
						#endIf
					elif (configType == "CustomService"):
						self.augmentServersProcessCustomService(objId, xmlNode, actualConfigType)
						configElements.addReferenceId(objId, xmlNode)
					#endIf
				#endFor
			#endFor
			
			## Update references
			processedNodeDict = configElements.getReferenceIds()
			for objId in processedNodeDict.keys():
				self.configWriter.updateWASReferenceAttributes(processedNodeDict[objId], objId)
			#endFor
		else:
			#print "Error: ConfigType: " + configType + " is not supported in augment mode"
			self.LOGGER.error("CRWWA2006E",[configType])
		#endIf
	#endDef
	
	"""
		Used to augment CustomService types.
		
		Attempts to find a matching CustomService by displayName, 
		if it can be found a message will be displayed.
		
		If a matching CustomService cannot be found it will be created
	"""
	def augmentServersProcessCustomService(self, objId, xmlNode, actualConfigType):
		
		displayName = xmlNode.getAttrValue("displayName")
		customServices = AdminConfig.list(actualConfigType, objId).split(newline)
		for customService in customServices:
			if (len(customService) > 0):
				self.LOGGER.trace("Found a customService:" + str(customService))
				
				# if the class loader modes match, this could be our classloader
				wasDisplayName = AdminConfig.showAttribute(customService, 'displayName')
				self.LOGGER.trace("comparing customService displayName: wasDisplayName:" + str(wasDisplayName))
				self.LOGGER.trace("                                     displayName:" + str(displayName))
				if (wasDisplayName == displayName):
					#print "Warning: A CustomService with the same displayName already exists."
					self.LOGGER.log("CRWWA2007W")
					#print "         The CustomService with displayName '" + displayName + "' will not be created."
					self.LOGGER.log("CRWWA5008I",[displayName])
					return
				#endIf
			#endIf -- len(classLoader) > 0
		#endFor 
	
		## create missing custom service
		##print "Info: Creating ##print "Info: Creating CustomService with name " + displayName
		self.LOGGER.log("CRWWA5009I")
		self.configWriter.createWASObject(xmlNode, objId)
	#endDef
	
	"""
		Used to augment ApplicationServer.Classloader types.
		
		Attempts to find a matching classloader, if it can be found it will 
		be augmented by augmentServersProcessClassLoaderLibs
		
		If a matching classloader cannot be found, the entire classloader 
		and Library refs  are created by this method.
	"""
	def augmentServersProcessClassLoader(self, objId, xmlNode, actualConfigType):
		
		foundClassloader = 0
		## find all the classloaders under the application server
		clMode = xmlNode.getAttrValue("mode")
		classLoaders = AdminConfig.list(actualConfigType, objId).split(newline)
		for classLoader in classLoaders:
			if (len(classLoader) > 0):
				self.LOGGER.trace("Found a classloader:" + str(classLoader))
				# if the class loader modes match, this could be our classloader
				wasCLMode = AdminConfig.showAttribute(classLoader, 'mode')
				self.LOGGER.trace("comparing classloader modes: wasCLMode:" + str(wasCLMode))
				self.LOGGER.trace("                             clMode:" + str(clMode))
				if (wasCLMode == clMode):
					self.LOGGER.trace("classloader mode in WAS matches:" + str(wasCLMode) + " for classloader:" + str(classLoader))
					foundClassloader = self.augmentServersProcessClassLoaderLibs(classLoader, xmlNode)
					if (foundClassloader):
						break
				#endIf
			#endIf -- len(classLoader) > 0
		#endFor 
	
		## create missing class loaders 
		if (not foundClassloader):
			#print "Info: Creating ClassLoader and associated LibraryRef objects"
			self.LOGGER.log("CRWWA5010I")
			self.LOGGER.log("CRWWA5011I")
			self.LOGGER.log("CRWWA5012I",[str(objId)])
			self.LOGGER.log("CRWWA5013I",[str(xmlNode)])
			self.configWriter.createWASObject(xmlNode, objId)
		#endIf
	#endDef
	
	"""
		Used to augment ApplicationServer.Classloader types.
		
		If a classloader contains at least one of the same LibraryRef objects
		as the supplied xmlNode, it is augmented with any additional LibraryRef 
		objects which exist in the xmlNode
		
		If no matching LibraryRef objects can be found, this method returns false
		to indicate to the caller that the entire Classloader should be created.
	"""
	def augmentServersProcessClassLoaderLibs(self, classLoader, xmlNode):
		## we might have found a classloader match, lets see
		foundClassloader = 0;
		## find all the LibraryRef types and see if they match
		wasLibraries = AdminHelper.extractWASIdsFromList(AdminConfig.showAttribute(classLoader, 'libraries'))
		missingLibraries = []	
		xmlLibraries = xmlNode.getFilteredChildrenArray('LibraryRef')
		foundAnyLibrary = 0
		## determine if xml nodes represent a similar class loader
		for xmlLibrary in xmlLibraries:
			self.LOGGER.log("CRWWA5014I",[str(xmlLibrary)])
			foundLibrary = 0
			libraryName = xmlLibrary.getAttrValue('libraryName')
			for wasLibrary in wasLibraries:
				wasLibraryName = AdminConfig.showAttribute(wasLibrary, 'libraryName')
				if (wasLibraryName == libraryName):
					# found a matching library
					foundAnyLibrary = 1
					foundLibrary = 1
					break
				#endIf
			#endFor
			if (not foundLibrary):
				missingLibraries.extend([xmlLibrary])
		#endFor	
		## if we find at least 1 library ref, then we create any that 
		## we cannot find and continue
		if (foundAnyLibrary and len(missingLibraries) is 0):
			foundClassloader = 1
			#print "Warning: A ClassLoader with the same mode and LibraryRef objects already exists."
			self.LOGGER.log("CRWWA5015I")
			#print "         The ClassLoader will not be created."
			self.LOGGER.log("CRWWA5016I")
		elif (foundAnyLibrary and len(xmlLibraries) != len(missingLibraries)):
			foundClassloader = 1
			for xmlLibrary in missingLibraries:
				#print "Info: Creating missing LibraryRef in existing ClassLoader"
				self.LOGGER.log("CRWWA5017I")
				self.LOGGER.log("CRWWA5018I: ",[str(classLoader)])
				self.LOGGER.log("CRWWA5019I: ",[str(xmlLibrary)])
				self.configWriter.createWASObject(xmlLibrary, classLoader)
			#endFor
		#endIf
		return foundClassloader
	#endDef

	"""
		Used to import all configuration from the server which matches the supplied type.
		
		The data will be injected into xmlFile according to the configType
		
		If multiple servers are being considered in the same import, and the configuration
		is different from one server to another, then nothing is imported and
		the system prints a message and exits.
	"""
	def importServers(self, serverIds, xmlFile, configType, scopeType):
		self.LOGGER.traceEnter([serverIds, xmlFile, configType, scopeType])
		#print "Importing server config: " 
		self.LOGGER.log("CRWWA5021I")
		lastData = None
		data = []
		# this is going to get the info for each server in scope, comparing to find the correct value
		for serverId in serverIds:
			#print "processing server: " + serverId
			self.LOGGER.log("CRWWA5020I",[serverId])
			data = self.readServerConfigData(serverId, configType, scopeType)
			# compare data to last and stop if different
			if (lastData != None):
				# compare data to lastData
				if (not ConfigComparor.compareJyObject(configType, data, lastData)):
					## helpful message for ALL, printed at the end of the run.
					if (self.ignoreConfigDifferences):
						msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
								"CRWWA0011I", [configType, scopeType])
						self.messageRecorder.addMessage(msg)
						return
					else:
						self.messageRecorder.displayRecordedMessages()
						self.LOGGER.log("CRWWA0004E",[scopeType])
						raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0004E", scopeType)
					#endIf
				#endIf
			#endIf
			lastData = data
		#endFor
	
		# inject it into the file
		GenericConfigFileWriter.processBasicFile(xmlFile, data, configType)
	#endDef

	""" 
	based on product version and server type, return a list of config types which are 
	not directly under the server configuration in the WAS configuration model
	"""
	def getAdditionalConfigTypes(self, serverId, version):
		type = AdminConfig.showAttribute(serverId, 'serverType')
		addTypes = []
		addTypes.extend(ServerConfigMediator.WAS_60_CONFIG_TYPES)
		if (version > 60):
			addTypes.extend(ServerConfigMediator.WAS_61_ADTL_CONFIG_TYPES)
		if (version > 61):
			addTypes.extend(ServerConfigMediator.WAS_70_ADTL_CONFIG_TYPES)
		if (version > 70):
			addTypes.extend(ServerConfigMediator.WAS_80_ADTL_CONFIG_TYPES)
		#endIf
		## APPLICATION_SERVER
		## ONDEMAND_ROUTER
		## PROXY_SERVER
		## NODE_AGENT
		## DEPLOYMENT_MANAGER
		return addTypes
	#endDef
	
	def importAllConfigTypes(self, serverIds, xmlFile, scopeType, configList):
		self.LOGGER.traceEnter([serverIds, xmlFile, scopeType])
		#print "Importing all server config"
		self.LOGGER.log("CRWWA5022I")
		 
		configIntersection = self.readAllConfigTypes(serverIds, scopeType, 1, configList)	
		# inject it into the file
		fileWriter = XmlConfigFileWriter();
		fileWriter.build(xmlFile, configIntersection, 1)
	#endDef

	def compareAllConfigTypes(self, serverIds, xmlFile, scopeType, configList):
		self.LOGGER.traceEnter([serverIds, xmlFile, scopeType])
		#print "Comparing all server config"
		self.LOGGER.log("CRWWA5023I")
		wasConfig = self.readAllConfigTypes(serverIds, scopeType, 0, configList)	
		localConfig = WsadminConfigXmlBuilder.readFile(xmlFile)
		ConfigComparor.compareWsadminConfig("All Server Configuration", wasConfig, localConfig)
	#endDef

	def readAllConfigTypes(self, serverIds, scopeType, importMode, configList):
		
		# compare used to display differences between servers
		compare = Compare()

		## all of the config that matches all of the servers
		configIntersection = None
		compareTools = ConfigCompareTools(WsadminConfigComparator(), AllAttributesConfigComparator())
		differingConfigTypes = HashSet()
		# this is going to get the info for each server in scope, comparing to find the correct value
		for serverId in serverIds:
			serverName = AdminConfig.showAttribute(serverId, "name")
			if (serverName is None or len(serverName) == 0):
				serverName = serverId
			#print "processing server: " + serverName
			self.LOGGER.log("CRWWA5024I",[serverName])
		
			data = self.readServerConfiguration(serverId, scopeType)
			## based on serverName and version, read additional config NOT under the server object in WAS config
			if (configList == None):
				configList = self.getAdditionalConfigTypes(serverId, version)

			for configType in configList:
				data['children'].extend(self.readServerConfigData(serverId, configType, scopeType))
			#endFor
			#print "finished reading configuration for server: " + serverId
			self.LOGGER.log("CRWWA5025I",[serverId])
			config = LegacyWsadminConfigHelper.buildWsadminConfig(JavaConversionHelper.mapToJava(data, None))
			normalizedConfig = WsadminConfigUtils.normalize(config)
			# compare data to last and stop if different
			if (configIntersection != None):
				# compare data to lastData
				newIntersection = compareTools.findRecursiveIntersection(configIntersection, normalizedConfig)
				if (not newIntersection.size() == normalizedConfig.size()):
					## helpful message for ALL, printed at the end of the run.
					if (self.ignoreConfigDifferences):
						result = compare.computeComparison(str(serverName), configIntersection, normalizedConfig)
						differingConfigTypes.add(result)
						# complements = compareTools.findComplementInA(normalizedConfig, newIntersection)
						#for complement in complements:
						#	differingConfigTypes.add(complement.getId())
						#endFor
					else:
						self.messageRecorder.displayRecordedMessages()
						self.LOGGER.log("CRWWA0004E", [scopeType])
						raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0004E", scopeType)
					#endIf
				#endIf
				configIntersection = newIntersection
			else:
				configIntersection = normalizedConfig
			#endIf
		#endFor
		if (importMode and differingConfigTypes.size() > 0):
			displayProps = CompareDisplayProperties()
			displayProps.setFirstColDisplay("Other Servers")
			display = CompareDisplay(displayProps)
			for result in differingConfigTypes:
				serverName = result.getTopLevelConfigType()
				displayProps.setOnlyFirst("Configuration is not defined for server " + serverName + "\n")
				displayProps.setOnlySecond("Only Server " + serverName + "\n")
				displayProps.setSecondColDisplay("Server " + serverName)
				msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
					"CRWWA0013I", [serverName, scopeType])
				displayProps.setSummaryMessage(msg);
				writer = StringWriter()
				# compare it with the xml file
				display.displayComparison(result, writer)
				self.messageRecorder.addMessage("\n" + writer.toString())
			#endFor
		#endIf
		return configIntersection
	#endDef
	
	"""
		Determines if the server configuration matches what is in the supplied xmlFile
		for the specified configType
	"""
	def compareServers(self, serverIds, xmlFile, configType, scopeType):
		self.LOGGER.traceEnter([serverIds, xmlFile, configType, scopeType])
		excludedTypes = self.getExcludedTypes(configType, scopeType)
		if (self.xmlProp is None):
			self.xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		#endIf
		for serverId in serverIds:
			# get wasConfig
			wasConfig = self.readServerConfigData(serverId, configType, scopeType)
			
			## XMLConfigReader will "fix" the node ids and remove anything before the .
			## therefore, we will also do that for the wasConfig to match
			for wasElement in wasConfig:
				wasId = wasElement['id']
				lastIndexOfDot = wasId.rfind('.') + 1
				if (lastIndexOfDot > 0):
					end = len(wasId)
					wasIdFixed = wasId[lastIndexOfDot:end]
					wasElement['id'] = wasIdFixed
				#endIf
			#endFor	
			
			# get rafwConfig
			xmlProp = self.xmlProp.findRAFWContainerNode(configType)
			filteredNodes = xmlProp.getFilteredNodeArray(configType)
			xmlConfigReader = XMLConfigReader()
			rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
	
			ConfigComparor.compare(configType, wasConfig, rafwConfig)
		#endFor
		self.LOGGER.traceExit()
	#endDef
		
	"""
		Processes the supplied configType starting from scopeId.
		
		If the configType contains a dot, the configType is split by .
		For each type found in the string, the object given by scopeId is
		used to locate the first matching type.  
		
		The process repeats on the located object id and sub type until
		the configType does not contain any more dots.  
		
		For example: ApplicationServer.Classloader is supplied.
		This results in the first ApplicationServer object which is a child of the
		object given by scopeId being located.  The return value is this object's 
		id and Classloader, since that is the last config type.
		
		This method may return "" if the config type cannot be found under the supplied scope
	"""	
	def processConfigType(self, scopeId, configType):
		self.LOGGER.traceEnter([scopeId, configType])
		origScopeId = scopeId
		origConfigType = configType
		## if configType contains [.] process until the last type 
		## and use that id as the scopeid
		start = configType.rfind('.') + 1
		if (start > 0):
			preTypes = configType[0:configType.rfind('.')]
			end = len(configType)
			configType = configType[start:end]
			types = preTypes.split('.')
			for type in types:
				if (len(scopeId) > 0):
					self.LOGGER.debug("Finding " + type + " config id under: " + scopeId);
					scopeId = AdminConfig.list( type, scopeId ).split( newline )[0]
				else:
					## we could not find the parent id for the previous type, so we cannot find each subsequent child
					## this is a programming error if someone has suggested we find an invalid type
					## however, we don't fail here b/c we come very close with our handling of ApplicationServer.ClassLoader 
					## on a node agent server.  (One more . and we'd have failed here)
					self.LOGGER.log("CRWWA0127E", [origConfigType, origScopeId, type])
					scopeId = ""
				#endIf
			#endFor
			self.LOGGER.debug("Computed final configType as: " + configType)
		#endIf
		self.LOGGER.traceExit([scopeId, configType])
		return [scopeId, configType]
	#endDef

	"""
	   Special cases result in excluding child config types from parents since they are
	   supported by other actions.  This method returns a list of excluded types
	   based on the supplied configType and scopeType
	"""
	def getExcludedTypes(self, configType, scopeType):
		excludedTypes = []
		## For ApplicationServer, exclude Classloader, 
		## since we have a seperate target to handle that and don't need any confusion
		if (configType == "ApplicationServer"):
			excludedTypes.append("Classloader")
			## also exclude the key name when there are no classloaders defined
			excludedTypes.append("classloaders")
			## longer term, Security uses this other pattern, Server should move toward this pattern as well
			# excludedTypes.append("Classloader.classloaders")
			## this implies the somewhat confusing
			## xmlNode.buildNodeAttrsAsJyString(excludedTypes)
			## would be fixed to work off the same pattern
		#endIf
			
		## only manage EndPoint if scopeType is server
		if (scopeType != "server"):
			excludedTypes.append('EndPoint')
		#endIf
		return excludedTypes
	#endDef
	
	"""
		Reads the configuration for the supplied server, including all of its 
		child configuration types
	"""
	def readServerConfiguration(self, scopeId, scopeType):
		self.LOGGER.traceEnter([scopeId, scopeType])
	
		importedIds = []
		## exclude the serverId from the import, so that we don't get the parent, 
		## but only the children config elements
		importedIds.append(scopeId)
		
		excludedTypes = []
		excludedTypes.append('EndPoint')
					
		self.configReader = ConfigReader(importedIds, excludedTypes)
		self.configReader.processTypeFirst("Chain")
		configData = self.configReader.showAll(scopeId)
		self.LOGGER.traceExit(configData)
		return configData
	#endDef
	
	"""
		Reads server configuration for the supplied configType under the
		parent given by scopeId	

	"""
	def readServerConfigData(self, scopeId, configType, scopeType):
		self.LOGGER.traceEnter([scopeId, configType, scopeType])
		## save original config type for later usage in writing the xml
		rafwConfigType = configType
		objIdsByAttr = {}
		## if hashed by 'default' then the attribute isn't relevant, else the attribute
		## must be used when re-creating the configuration
		DEFAULT_ATTR = "default"
	
		# SERVER is used to denote that the configuration type is accessible 
		# as an attribute of the server
		if (configType.find('SERVER.') >= 0):
			configType = configType.split('.')[1]
			objIdsByAttr[DEFAULT_ATTR] = [AdminConfig.showAttribute(scopeId, configType)]
		else:
			origConfigType = configType
			serverId = scopeId
			scopeId, configType = self.processConfigType(scopeId, configType)
			if (len(scopeId) > 0):
				# special case for JavaProcessDef
				if (configType == "JavaProcessDef"):
					# read the attribute object ids by attribute name for both attributes 
					# "processDefinition" and "processDefinitions"
					for attr in ["processDefinition", "processDefinitions"]:
						# if an attribute is not defined in WAS, skip it
						if (self.configReader.hasAttr(serverId, attr)):
							objIdsByAttr[attr] = AdminHelper.extractWASIdsFromList(
								AdminConfig.showAttribute( serverId, attr ))
						#endIf
					#endFor
				else:
					objIdsByAttr[DEFAULT_ATTR] = AdminConfig.list( configType, scopeId ).split( newline )
			else:
				## parent id could not be located, log a message and continue, there is no valid data to read
				self.LOGGER.log("CRWWA0125I", [origConfigType, serverId])
				objIdsByAttr[DEFAULT_ATTR] = []
			#endIf
		#endIf
		data = []
		for attr in objIdsByAttr.keys():
			objIds = objIdsByAttr[attr]
			for objId in objIds:
				if ( len(objId) > 0 ):
					#print "found: " + objId
					self.LOGGER.log("CRWWA5026I",[objId])
					importedIds = []
					## exclude the serverId from the import, so that we don't get the parent, 
					## but only the children config elements
					importedIds.append(scopeId)
					
					excludedTypes = self.getExcludedTypes(configType, scopeType)
					
					self.configReader = ConfigReader(importedIds, excludedTypes)
					## If we are processing the TransportChannelService, we need to process Chains first
					## NOTE: as of the current implementation, channel order cannot be modified in a chain
					## NOTE: channels cannot be added or removed - 
					##       this will happen if they are deleted from the xmlFile -- you have been warned
					##
					if (configType == "TransportChannelService"):
						self.configReader.processTypeFirst("Chain")
					#endIf
					configData = self.configReader.showAll(objId)
					configData['id'] = rafwConfigType
					if (attr != DEFAULT_ATTR):
						configData['attrs'][Globals.WAS_KEY_ATTR_NAME] = attr
					#endIf
					data.append(configData)
					
					configDomainData = self.readDataReplicationDomainConfigData(objId, configType)
					if ( str(configDomainData) != "None"):
						data.append(configDomainData)
					#endIf
				#endIf
			#endFor
		#endFor
		self.LOGGER.traceExit(data)
		return data
	#endDef

	"""
		Reads Data Replication Domain for the supplied configType under the
		parent given by scopeId	

	"""
	def readDataReplicationDomainConfigData(self, objId, configType):
		if (configType == "ApplicationServer"):
			services = AdminConfig.showAttribute(objId, "services")
			if (services.find("DynamicCache") >= 0):
				dynamicService = AdminConfig.list("DynamicCache", objId)
				enable = AdminConfig.showAttribute(dynamicService, "enableCacheReplication")
				if (enable == "true"):
					cacheRep = AdminConfig.showAttribute(dynamicService, "cacheReplication")
					domainName = AdminConfig.showAttribute(cacheRep, "messageBrokerDomainName")
					cellName = AdminControl.getCell()
					cellId = AdminConfig.getid("/Cell:" + cellName)
					drds = AdminConfig.list("DataReplicationDomain", cellId)
					if (drds.find(domainName) >= 0):
						drdId = AdminConfig.getid("/Cell:" + cellName + "/DataReplicationDomain:" + domainName)
						configDomainData = self.configReader.showAll(drdId)
						configDomainData['id'] = "DataReplicationDomain"
						return configDomainData
					#endIf
				#endIf
			#endIf
		#endIf
	#endDef

	"""
		Identifies the serverIds in the supplied scope.  
		If the scope is server this will be the serverId for the supplied server.  
		If the scope is cluster this will be all serverIds for the cluster members.
		If the scope is node this will be all serverIds contained on the node
		If the scope is cell this will be all serverIds contained in the cell
	"""
	def findServersInScope(self, scopeName, scopeType, nodeName):
		
		cellName = AdminControl.getCell()
		
		serverIds = []
		
		# if scope = node and serverName is set, process server
		# else, process all servers on the node 
		if (scopeType == "node" or scopeType == "server"):
		
			# Check if it is a valid node
			node = AdminConfig.getid( '/Cell:' + cellName + '/Node:' + nodeName + '/' )
		
			if node == "":
				raise "Error -- Invalid node name: " + nodeName 
			#endIf
			if (len(scopeName) > 0 and scopeType != "node"):
				# if scopeName is set, then we are targetting a particular server
				# Check if a server by this name on the node
				serverId = AdminConfig.getid("/Cell:" + cellName + "/Node:" + nodeName + "/Server:" + scopeName + "/")
				if serverId == "":
					raise "Error -- Server " + scopeName + " does not exist on node " + nodeName
				#endIf
				type = AdminConfig.showAttribute(serverId, 'serverType')
				if (self.checkIfValidType(type, scopeType)):
					serverIds.append(serverId)
				#endIf
			else:
				# else, we want to operate on all servers in the node
				for serverId in AdminConfig.list("Server", node).split(newline):
					if (len (serverId) > 0):
						type = AdminConfig.showAttribute(serverId, 'serverType')
						if (self.checkIfValidType(type, scopeType)):
							serverIds.append(serverId)
						#endIf
					#endIf
				#endFor
			#endIf	
		# if scope = cluster and clusterName is set, update cluster
		# else, update all clusters in scope
		elif ( scopeType == "cluster" or scopeType == "cell"):
			if (len(scopeName) > 0 and scopeType != "cell"):
				clusterId = AdminConfig.getid("/Cell:" + cellName + "/ServerCluster:" + scopeName + "/")
				if clusterId == "":
					raise "Error -- Invalid cluster name: " + scopeName 
				#endIf
				
				## For proxy clusters configuration (such as SIP proxy settings) is managed 
				## directly at cluster level. Hence add cluster config id to serverId. 
				if (configType in ServerConfigMediator.PROXY_CONFIG_TYPES):
					clusterType = AdminConfig.showAttribute(clusterId, 'serverType')
					if (clusterType == "PROXY_SERVER"):
						serverIds.append(clusterId)
					#endIf
				else:
					memberlist = AdminConfig.showAttribute(clusterId, "members" )
					members = memberlist[1:len(memberlist)-1]
					for member in members.split():
						nodeName = AdminConfig.showAttribute(member, "nodeName" )
						serverName = AdminConfig.showAttribute(member, "memberName" )
						serverId = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
						type = AdminConfig.showAttribute(serverId, 'serverType')
						if (self.checkIfValidType(type, scopeType)):
							#print "Managing " + serverName + " on node " + nodeName
							self.LOGGER.log("CRWWA5027I",[serverName,nodeName])
							serverIds.append(serverId)
						#endIf
					#endFor
				#endIf
			else:
				# we want to operate on all servers in the cell
				for serverId in AdminConfig.list("Server").split(newline):
					type = AdminConfig.showAttribute(serverId, 'serverType')
					if (self.checkIfValidType(type, scopeType)):
						serverIds.append(serverId)
					#endIf
				#endFor
			#endIf
		else:
			raise "Scope: %s is invalid. Exiting!" % (scopeType)
		#endIf
		return serverIds
	#endDef
	
	"""
		Validates if the supplied server type (type) exists in the list of 
		applicable types, at the specified scope (sType)
	"""
	def checkIfValidType(self, type, sType):
		result=0
		
		## Check for proxy servers first  
		if (configType in ServerConfigMediator.PROXY_CONFIG_TYPES):
			if (type == "PROXY_SERVER"):
				result = 1
			#endIf
		else:			
			if (sType == "cluster" or sType == "cell"):
				if (sType == "cluster"):
					if (type == "APPLICATION_SERVER" or type == "ONDEMAND_ROUTER" or type == "PROXY_SERVER"):
						result = 1
					#endIf
				else:
					if (type == "APPLICATION_SERVER" or type == "PROXY_SERVER"):
						result = 1
					#endIf
				#endIf
			elif (sType == "node" or sType == "server"):
				if (sType == "node"):
					if (type == "APPLICATION_SERVER" or type == "PROXY_SERVER"):
						result = 1
					#endIf
				else:
					## scope is server, we'll look at the config of anything at this point
					result = 1
				#endIf
			#endIf
		#endIf
		        
		return result
	#endDef
	
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;scopename:;nodename:;properties:;mode:;config_type:;version:;config_list:' )
version = Integer.valueOf(optDict['version'])
# get scope
scopeName = optDict['scopename']
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
nodeName = optDict['nodename']

mode = optDict['mode']
xmlFile  = optDict['properties']
configType = optDict['config_type']
configList = optDict['config_list']

if (configList == "null"):
	configList = None

if (configList != None) and (len(configList) > 0):
	configList = configList.split(' ')

messageRecorder = MessageRecorder();
ConfigComparor.addMessageListener(messageRecorder)
		
configMediator = ServerConfigMediator(messageRecorder)
serverIds = configMediator.findServersInScope(scopeName, scopeType, nodeName)
if (configType == "ALL"):
	configMediator.setIgnoreEmptyXml(1)
	configMediator.setIgnoreConfigDifferences(1)
	if (mode == MODE_IMPORT):
		configMediator.importAllConfigTypes(serverIds, xmlFile, scopeType, configList)
	elif (mode == MODE_EXECUTE):
		configMediator.executeAllConfigTypes(serverIds, xmlFile, scopeType)
	elif (mode == MODE_COMPARE):
		configMediator.compareAllConfigTypes(serverIds, xmlFile, scopeType, configList)
	else:
		#print "Unsupported MODE supplied: " + mode
		self.LOGGER.log("CRWWA0008W",[mode])
	#endIf	
else:
	configMediator.processServer(serverIds, xmlFile, configType, scopeType)
#endIf

if (mode == MODE_EXECUTE or mode == MODE_AUGMENT):
	AdminHelper.saveAndSyncCell()
#endIf

## print any messages that we wanted to defer to the end
messageRecorder.displayRecordedMessages()
