"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listVariables.py
	
	TODO: description
"""


from java.util import Hashtable

for obj in [ 'Cell','ServerCluster','Server','Node' ]:
	print "## Working on: %s" % obj
	for subObj in AdminConfig.list( obj ).split( newline ):
		if (len (subObj) > 0):
			print subObj.split( '(',1 )[0]
			for varSub in AdminConfig.list( 'VariableSubstitutionEntry', subObj ).split( newline ):
				try:
					if ( (( varSub.find('node') > 0 ) or ( varSub.find('luster') > 0) ) and (obj == "Cell") ):
						raise
					elif ( (varSub.find('server') > 0 ) and (obj == "Node") ):
						raise
					#endIf
					print varSub
				except:
					pass
				#endTryExcept
			#endfor
		#endIf 
	#endfor
#endfor
