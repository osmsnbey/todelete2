"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: jaas.py
	
	JAAS Entries
	TODO: description
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
	sys.modules['AdminControl'] = AdminControl
except:
	pass
import AdminConfig
import AdminTask
import AdminControl
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

"""
 Handles specifics related to creating JAAS configuration objects in WAS

 scope - WAS scope to write JAAS config data
 scopeType - cell, node, server, cluster - used to filter objects which are not in scope
 xmlFile - contains the configuration data to write
 typeNames - WAS configuration type names to write to WAS config 
"""
def createJAASConfig(scope, scopeType, xmlFile, marker, typeNames):

	myConfigWriter = ConfigWriter();	
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeid = AdminConfig.getid( scope )
	if (len(scopeid) == 0):
		print "ERROR: unable to find parent scope: " + scope
		print "Cannot write WAS config."
		return
	#endIf
	
	for typeName in typeNames:
		## read existing
		existingConfigs = {}
		existingConfigIds = AdminConfig.list(typeName,scopeid).split( newline )
		if (existingConfigIds != ""):
			for existingId in existingConfigIds:
				if (existingId != ""):
					configName = AdminConfig.showAttribute(existingId, 'alias')
					existingConfigs[configName] = existingId
		#endFor
		
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		for xmlNode in nodeArray:
			alias = xmlNode.getAttrValue("alias")
			## modify those object configurations that exist
			if (existingConfigs.has_key(alias)):
				attrs = xmlNode.buildNodeAttrsAsJyString()
				AdminConfig.modify(existingConfigs[alias], attrs)
				del existingConfigs[alias]
			else:
				## create those configurations that do not exist
				myConfigWriter.createWASObject(xmlNode, scopeid)
			#endIf
		#endFor
		## remove the left-over config data
		for existingId in existingConfigs.keys():
			AdminConfig.remove(existingConfigs[existingId])
		#endFor
	#endFor

#endDef

"""
 
 Handles specifics related to augmenting JAAS configuration objects in WAS

 scope - WAS scope to write JAAS config data
 scopeType - cell, node, server, cluster - used to filter objects which are not in scope
 xmlFile - contains the configuration data to write
 typeNames - WAS configuration type names to write to WAS config 
 
"""
def augmentJAASConfig(scope, scopeType, xmlFile, marker, typeNames):

	myConfigWriter = ConfigWriter();	
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeid = AdminConfig.getid( scope )
	if (len(scopeid) == 0):
		print "ERROR: unable to find parent scope: " + scope
		print "Cannot augment WAS config."
		return
	#endIf
	
	for typeName in typeNames:
		## read existing
		existingConfigs = {}
		existingConfigIds = AdminConfig.list(typeName,scopeid).split( newline )
		if (existingConfigIds != ""):
			for existingId in existingConfigIds:
				if (existingId != ""):
					configName = AdminConfig.showAttribute(existingId, 'alias')
					existingConfigs[configName] = existingId
		#endFor
		
		nodeArray = xmlProp.getFilteredNodeArray(typeName)	
		for xmlNode in nodeArray:
			alias = xmlNode.getAttrValue("alias")
			## modify those object configurations that exist
			if (existingConfigs.has_key(alias)):
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(existingConfigs[alias], xmlNode)
				else:
					print "Warning: An object of type " + typeName + " with alias" 
					print "         '" + alias + "' already exists."
					print "         You must use a unique value for alias"
					print "         when creating objects of type " + typeName;
				#endIf
			else:
				## create those configurations that do not exist
				print "Info: Creating " + typeName + " with alias " + alias
				myConfigWriter.createWASObject(xmlNode, scopeid)
			#endIf
		#endFor
	#endFor

#endDef

def export(optDict=None):
	global newline
	newline = java.lang.System.getProperty("line.separator")
	scopeType=optDict['scope']
	cellName = AdminControl.getCell()
	scope = '/Cell:' + cellName + '/Security:/' 
	
	propFile = optDict['properties'] 
	
	typeNames = [optDict['type']]
	mode = optDict['mode']
	marker = optDict['marker']
	createJAASConfig(scope, scopeType, propFile, marker, typeNames)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:' )
		
	# get scope
	scopeType="cell"
	cellName = AdminControl.getCell()
	scope = '/Cell:' + cellName + '/Security:/' 
	
	propFile = optDict['properties'] 
	
	typeNames = ['JAASAuthData']
	mode = optDict['mode']
	marker = "jaas"
	if (mode == MODE_EXECUTE):
	
		print "Creating JAAS entries in scope: " + scope
		createJAASConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_AUGMENT):
		print "Augmenting JAAS entries in scope: " + scope
		augmentJAASConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		print "Importing JAAS entries in scope: " + scope
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames)
		
	elif (mode == MODE_COMPARE):
		print "Comparing JAAS entries in RAFW and WAS in cell: " + cellName
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames)
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf