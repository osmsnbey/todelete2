"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: commonEventInfrastructure.py
"""

import java.util as util
import java.io as javaio

class commonEventInfrastructure:
	
	#create CEI resources for Oracle
	def configureOracle(self, clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword):
		ceiLogger.debug("entering Oracle")
		sysUser = properties.get('wbi.DB.CEIEvent.DBAUser');
		sysPassword = properties.get('wbi.DB.CEIEvent.DBAPassword');
		commandOptions = '[-clusterName ' + clusterName + ' -jdbcClassPath ' + jdbcClassPath + ' -dbHostName ' + dbHostName + ' -dbPort ' + dbPort + ' -dbName ' + dbName + ' -dbUser ' + dbUser + ' -dbPassword ' + dbPassword + ' -sysUser ' + sysUser + ' -sysPassword ' + sysPassword + ']'
		ceiLogger.debug("AdminTask.configEventServiceOracleDB('" + commandOptions + "')")
		AdminTask.configEventServiceOracleDB(commandOptions);
	#create CEI resources for DB2
	def configureDB2(self, clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword):
		ceiLogger.debug("entering DB2_Universal")
		commandOptions = '[-clusterName ' + clusterName + ' -jdbcClassPath ' + jdbcClassPath + ' -dbHostName ' + dbHostName + ' -dbPort ' + dbPort + ' -dbName ' + dbName + ' -dbUser ' + dbUser + ' -dbPassword ' + dbPassword + ']'
		ceiLogger.debug("AdminTask.configEventServiceDB2DB('" + commandOptions + "')")
		AdminTask.configEventServiceDB2DB(commandOptions);
	#create CEI resources for DB2 ZOS
	def configureDB2UDBOS390(self, clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword):
		ceiLogger.debug("entering DB2UDBOS390_V8_1")
		storageGroup = properties.get('wbi.DB.CEIEvent.DbStorageGroup')
		bufferPool4K = properties.get('wbi.DB.CEIEvent.DbBufferPool4K')
		bufferPool8K = properties.get('wbi.DB.CEIEvent.DbBufferPool8K')
		bufferPool16K = properties.get('wbi.DB.CEIEvent.DbBufferPool16K')
		#the -dbSubSystemName parameter may be a WPS 6.1.0.1 bug as the InfoCenter says -dbName instead
		commandOptions = '[-clusterName ' + clusterName + ' -jdbcClassPath ' + jdbcClassPath + ' -dbHostName ' + dbHostName + ' -dbPort ' + dbPort + ' -dbSubSystemName ' + dbName + ' -dbUser ' + dbUser + ' -dbPassword ' + dbPassword + ' -storageGroup ' + storageGroup + ' -bufferPool4K ' + bufferPool4K + ' -bufferPool8K ' + bufferPool8K + ' -bufferPool16K ' + bufferPool16K + ']'
		ceiLogger.debug("AdminTask.configEventServiceDB2ZOSDB('" + commandOptions + "')")
		AdminTask.configEventServiceDB2ZOSDB(commandOptions);
	#Deploy CEI to specified cluster
	def deployEventService(self):
		commandOptions = '-clusterName ' + optDict['clusterName']
		ceiLogger.debug("AdminTask.deployEventService('" + commandOptions + "')")
		AdminTask.deployEventService(commandOptions)
	#Enable CEI on specified cluster
	def enableEventService(self):
		commandOptions = '-clusterName ' + optDict['clusterName']
		ceiLogger.debug("AdminTask.enableEventService('" + commandOptions + "')")
		AdminTask.enableEventService(commandOptions)
	def readProperties(self, aFile):
	   ceiLogger.debug("Reading properties file: " + aFile)
	   properties = util.Properties()
	   propertiesFileInputStream =javaio.FileInputStream(aFile)
	   properties.load(propertiesFileInputStream)
	   return properties
		
	#The following functions overlap with some of the functionality in siBusModifier, 
	#Whereas siBusModifier is concerned with SIBuses in general, these functions are 
	#specific to installing and initail configuration of the CEI bus.  Please note that
	#there are some "hardcoded" values in the commands but these values are required
	#by WPS and therefore should not change.
	#add a bus member to CEI bus
	def addCEIBusMember(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		ceiLogger.trace(clusterName)
		schemaName = properties.get('wbi.DB.CEIME.DbSchemaName')
		ceiLogger.trace(schemaName)
		dataSourceName = 'jdbc/com.ibm.ws.sib/' + clusterName + '-CommonEventInfrastructure_Bus'
		ceiLogger.trace(dataSourceName)
		authAlias = 'CEIME_' + clusterName + '_Auth_Alias'
		ceiLogger.trace(authAlias)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -cluster ' + clusterName + ' -dataStore -createDefaultDatasource FALSE -createTables FALSE -schemaName ' + schemaName + ' -datasourceJndiName ' + dataSourceName + ' -authAlias ' + authAlias + ' ]'
		ceiLogger.debug("AdminTask.addSIBusMember('" + commandOptions + "')")
		AdminTask.addSIBusMember(commandOptions)		
	#add a Messaging Engine to CEI bus
	def addCEIBusMessagingEngine(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		ceiLogger.trace(clusterName)
		schemaName = properties.get('wbi.DB.CEIME.DbSchemaName')
		ceiLogger.trace(schemaName)
		dataSourceName = 'jdbc/com.ibm.ws.sib/' + clusterName + '-CommonEventInfrastructure_Bus'
		ceiLogger.trace(dataSourceName)
		authAlias = 'CEIME_' + clusterName + '_Auth_Alias'
		ceiLogger.trace(authAlias)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -cluster ' + clusterName + ' -dataStore -createDefaultDatasource FALSE -createTables FALSE -schemaName ' + schemaName + ' -datasourceJndiName ' + dataSourceName + ' -authAlias ' + authAlias +']'
		ceiLogger.debug("AdminTask.createSIBEngine('" + commandOptions + "')")
		AdminTask.createSIBEngine(commandOptions)
	#delete a Messaging Engine from the CEI bus
	def deleteCEIMessagingEngine(self):
		clusterName = properties.get('wbi.SupportCluster.Name')
		ceiLogger.trace(clusterName)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -cluster ' + clusterName + ']'
		ceiLogger.debug("AdminTask.deleteSIBEngine('" + commandOptions + "')")
		AdminTask.deleteSIBEngine(commandOptions)
	#delete a Bus member from the CEI bus
	def deleteCEIBusMember(self):
		clusterName = properties.get('wbi.SupportCluster.Name')
		ceiLogger.trace(clusterName)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -cluster ' + clusterName + ']'
		ceiLogger.debug("AdminTask.removeSIBusMember('" + commandOptions + "')")
		AdminTask.removeSIBusMember(commandOptions)
	#add a destination to the CEI messaging engine
	def addCEIBusMessagingEngineDestinations(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		ceiLogger.trace(clusterName)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -name ' + clusterName + '.CommonEventInfrastructureQueueDestination -type Queue -cluster ' + clusterName + ' -description -reliability ASSURED_PERSISTENT ]'
		ceiLogger.debug("AdminTask.createSIBDestination('" + commandOptions + "')")
		AdminTask.createSIBDestination(commandOptions)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -name ' + clusterName + '.CommonEventInfrastructureTopicDestination -type TopicSpace -cluster ' + clusterName + ' -description -reliability ASSURED_PERSISTENT ]'
		ceiLogger.debug("AdminTask.createSIBDestination('" + commandOptions + "')")
		AdminTask.createSIBDestination(commandOptions)
	#delete a destination from the CEI messaging engine
	def deleteCEIBusMessagingEngineDestination(self):
		clusterName = properties.get('wbi.SupportCluster.Name')
		ceiLogger.trace(clusterName)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -name ' + clusterName + '.CommonEventInfrastructureTopicDestination ]'
		ceiLogger.debug("AdminTask.deleteSIBDestination('" + commandOptions + "')")
		AdminTask.deleteSIBDestination(commandOptions)
	#add user to CEI bus connector role
	def addUserToCEIBusConnectorRole(self):
		userName = properties.get('wbi.JMS.CEI.JMSUser')
		ceiLogger.trace(userName)
		commandOptions = '[-bus CommonEventInfrastructure_Bus -user ' + userName + ']'
		ceiLogger.debug("AdminTask.addUserToBusConnectorRole('" + commandOptions + "')")
		AdminTask.addUserToBusConnectorRole(commandOptions)
	#add user to inter-engine alias
	def addUserToCEIBusInterEngineAndMediationsAlias(self):
		commandOptions = '[-bus CommonEventInfrastructure_Bus -mediationsAuthAlias CommonEventInfrastructureJMSAuthAlias -interEngineAuthAlias CommonEventInfrastructureJMSAuthAlias]'
		ceiLogger.debug("AdminTask.modifySIBus('" + commandOptions + "')")
		AdminTask.modifySIBus(commandOptions)
	#move CEI jms/cei/notification/AllEventsTopic to correct cluster
	def modifyCEIAllEventsTopic(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		sibJMSTopicName = 'CommonEventInfrastructure_AllEventsTopic'
		sibJMSTopicID = self.findConfigItemIDByName('J2CAdminObject', sibJMSTopicName)
		commandOptions = '[-name ' + sibJMSTopicName + ' -jndiName jms/cei/notification/AllEventsTopic -description "Common Event Infrastrucure All Events Topic" -topicSpace ' + clusterName + '.CommonEventInfrastructureTopicDestination -topicName CommonEventInfrastructure_AllEventsTopic -deliveryMode NonPersistent -readAhead AsConnection -busName CommonEventInfrastructure_Bus]'
		ceiLogger.debug("AdminTask.modifySIBJMSTopic('" + sibJMSTopicID + ',' + commandOptions + "')")
		AdminTask.modifySIBJMSTopic(sibJMSTopicID, commandOptions) 
	#move CEI jms/cei/EventQueue to correct cluster	
	def modifyCEIQueue(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		sibJMSQueueName = 'CommonEventInfrastructure_Queue'
		sibJMDQueueID = self.findConfigItemIDByName('J2CAdminObject', sibJMSQueueName)
		commandOptions = '[-name ' + sibJMSQueueName + ' -jndiName jms/cei/EventQueue -description "Common Event Infrastructure Queue" -queueName ' + clusterName + '.CommonEventInfrastructureQueueDestination -deliveryMode NonPersistent -readAhead AsConnection -busName CommonEventInfrastructure_Bus]'
		ceiLogger.debug("AdminTask.modifySIBJMSQueue('" + sibJMDQueueID + ',' + commandOptions + "')") 
		AdminTask.modifySIBJMSQueue(sibJMDQueueID, commandOptions)
	#assign authentication alias to CEI jms/cei/QueueActivationSpec		
	def modifyCEIActivationSpec(self):
		clusterName = properties.get('wbi.MessagingCluster.Name')
		sibActivationSpecName = 'CommonEventInfrastructure_ActivationSpec'
		sibActivationSpecID = self.findConfigItemIDByName('J2CActivationSpec', sibActivationSpecName)
		commandOptions = '[-name ' + sibActivationSpecName + ' -jndiName jms/cei/QueueActivationSpec -destinationJndiName jms/cei/EventQueue -description -acknowledgeMode Auto-acknowledge -authenticationAlias CommonEventInfrastructureJMSAuthAlias -busName CommonEventInfrastructure_Bus -clientId -destinationType javax.jms.Queue -durableSubscriptionHome -maxBatchSize 1 -maxConcurrency 10 -messageSelector -subscriptionDurability NonDurable -subscriptionName -shareDurableSubscriptions InCluster -readAhead Default -target -targetType BusMember -targetSignificance Preferred -targetTransportChain -shareDataSourceWithCMP false]'
		ceiLogger.debug("AdminTask.modifySIBJMSActivationSpec('" + sibActivationSpecID + ',' + commandOptions + "')") 
		AdminTask.modifySIBJMSActivationSpec(sibActivationSpecID, commandOptions)
	#get id of J2CAdminObject or J2CActivationSpec
	def findConfigItemIDByName(self, type, name):
		array = AdminConfig.list(type).splitlines()
		for item in array:
			if AdminConfig.showAttribute(item, 'name') == name:
				ceiLogger.debug("Found: " + name + " : " + item)
				return item
		return None
		
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;clusterName:')

#;dbType:;jdbcClassPath:;dbHostName:;dbPort:;dbName:;dbUser:;dbPassword:;sysUser:;sysPassword:;storageGroup:;bufferPool4K:;bufferPool8K:;bufferPool16K:

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
clusterName = optDict['clusterName']
action = optDict['action']

ceiLogger = _Logger("commonEventInfrastucture", MessageManager.RB_WEBSPHERE_BPM)
thisCommonEventInfrastructure = commonEventInfrastructure()

properties = thisCommonEventInfrastructure.readProperties(xmlFile);

if(mode == MODE_EXECUTE):
	if(action == "DEPLOY"):
		thisCommonEventInfrastructure.deployEventService()
	elif(action == "ENABLE"):
		thisCommonEventInfrastructure.enableEventService()
	elif(action == 'DBSETUP'):
		#get all common properties and pass to functions as parameters
		#get all function specific parameters within said function
		dbType = properties.get('wbi.DB.DbType');
		jdbcClassPath = properties.get('wbi.DB.jdbcDriverPath');
		dbHostName = properties.get('wbi.DB.CEIEvent.DbHost');
		dbPort = properties.get('wbi.DB.CEIEvent.DbPort');
		dbName = properties.get('wbi.DB.CEIEvent.DbName');
		dbUser = properties.get('wbi.DB.CEIEvent.DbUser');
		dbPassword = properties.get('wbi.DB.CEIEvent.DbPassword');
		if(dbType == "Oracle10g"):
			thisCommonEventInfrastructure.configureOracle(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		elif(dbType == "DB2_Universal"):
			thisCommonEventInfrastructure.configureDB2(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		elif(dbType == "DB2UDBOS390_V8_1"):
			thisCommonEventInfrastructure.configureDB2UDBOS390(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		else:
			print "Invalid dbType!"
	elif(action == 'ADD_BUS_MEMBER'):
		thisCommonEventInfrastructure.addCEIBusMember();
	elif(action == 'ADD_MESSAGING_ENGINE'):
		thisCommonEventInfrastructure.addCEIBusMessagingEngine();
	elif(action == 'DELETE_BUS_MEMBER'):
		thisCommonEventInfrastructure.deleteCEIBusMember();
	elif(action == 'DELETE_MESSAGING_ENGINE'):
		thisCommonEventInfrastructure.deleteCEIMessagingEngine();
	elif(action == 'ADD_MESSAGING_ENGINE_DESTINATIONS'):
		thisCommonEventInfrastructure.addCEIBusMessagingEngineDestinations();
	elif(action == 'DELETE_MESSAGING_ENGINE_DESTINATION'):
		thisCommonEventInfrastructure.deleteCEIBusMessagingEngineDestination();
	elif(action == 'ADD_USER_TO_BUS_CONNECTOR_ROLE'):
		thisCommonEventInfrastructure.addUserToCEIBusConnectorRole();
	elif(action == 'ADD_USER_TO_BUS_ALIASES'):
		thisCommonEventInfrastructure.addUserToCEIBusInterEngineAndMediationsAlias();
	elif(action == 'CORRECT_CEI_TOPIC_CLUSTER'):
		thisCommonEventInfrastructure.modifyCEIAllEventsTopic();
	elif(action == 'CORRECT_CEI_QUEUE_CLUSTER'):
		thisCommonEventInfrastructure.modifyCEIQueue();
	elif(action == 'ADD_CEI_USER_TO_ACTIVATION_SPEC'):
		thisCommonEventInfrastructure.modifyCEIActivationSpec();
	else:
		ceiLogger.fail("Invalid action: " + action)

	AdminHelper.saveAndSyncCell()
else:
	ceiLogger.fail("Unsupported MODE supplied: " + mode)
