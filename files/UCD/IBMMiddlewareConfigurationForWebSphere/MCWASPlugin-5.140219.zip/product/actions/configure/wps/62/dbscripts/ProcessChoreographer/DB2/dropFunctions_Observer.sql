--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2005,2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.3
--   Last update: 07/07/17 03:06:30
--------------------------------------------------------------------------------
--
-- SQL snippet to drop Observer UDFs
-- for DB2 (distributed)
--
--------------------------------------------------------------------------------
--
-- Note:
--
-- If you used the java based Observer functions, you also must uninstall the
-- jar file bpcodbutil.jar from the database using the setupEventCollector tool
-- or by using the following command, locally on the database server,
-- connected to the database:
--
--    db2 call sqlj.remove_jar('BPCODBUTIL')
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- Following variables needs to be changed for customization and
-- before running this script:
--
--   @SCHEMA@ = Schema Qualifier
--------------------------------------------------------------------------------

--------------------
-- Drop functions --
--------------------

DROP FUNCTION @SCHEMA@.INTERVALIN ( INT, TIMESTAMP,  TIMESTAMP);
DROP FUNCTION @SCHEMA@.INTERVALIN ( INT, TIMESTAMP,  VARCHAR(26));
DROP FUNCTION @SCHEMA@.INTERVALIN ( INT, VARCHAR(26),  TIMESTAMP);
DROP FUNCTION @SCHEMA@.INTERVALIN ( INT, VARCHAR(26),  VARCHAR(26));

DROP FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE();
