--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create database and schema for DB2 UDB
-- Run the script in the DB2 command line processor using:
--              db2 -tf createDatabase.sql
-- (Optionally, use the -z option for redirecting the output to a file)
--
-- Then run binding of the cli programs against the new database.
-- Usually, this happens automatically if the 'first' user has BINDADD authority,
-- however, it is good practice to do this manually.
-- Path syntax may require changes for different operating systems.
--        For Windows:
--              db2 connect to BPEDB
--              db2 bind %DB2PATH%\bnd\@db2cli.lst blocking all grant public
--              db2 connect reset
--
--        For Unix:
--              db2 connect to BPEDB
--              db2 bind $DB2DIR/bnd/@db2cli.lst blocking all grant public
--              db2 connect reset
--
-- If the database name should not be 'BPEDB' or another userid should be used
-- to create the schema, the CREATE DATABASE and/or CONNECT statements needs to
-- be modfied in this script.
--
-- For a prodcution environment consider usage of dedicated tablespace
-- containers. Use scripts named createTablespace.sql and createSchema.sql in this case.

-- create the database
CREATE DATABASE BPEDB USING CODESET UTF-8 TERRITORY en-us PAGESIZE 8 K;

-- connect to the created database:
-- Use CONNECT TO BPEDB USER xxx when another user should become owner of the schema
CONNECT TO BPEDB;

-------------------
-- Create tables --
-------------------

CREATE TABLE SCHEMA_VERSION
(
  SCHEMA_VERSION                     INTEGER                           NOT NULL ,
  DATA_MIGRATION                     SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SCHEMA_VERSION )
);

CREATE TABLE PROCESS_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  DEFINITION_NAME                    VARCHAR(220)                               ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  EXECUTION_MODE                     INTEGER                           NOT NULL ,
  IS_SHARED                          SMALLINT                          NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  VALID_FROM                         TIMESTAMP                         NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR(250)                               ,
  CREATED                            TIMESTAMP                         NOT NULL ,
  AUTO_DELETE                        SMALLINT                          NOT NULL ,
  EXTENDED_AUTO_DELETE               INTEGER                           NOT NULL ,
  VERSION                            VARCHAR(32)                                ,
  SCHEMA_VERSION                     INTEGER                           NOT NULL ,
  ABSTRACT_BASE_NAME                 VARCHAR(254)                               ,
  S_BEAN_LOOKUP_NAME                 VARCHAR(254)                               ,
  S_BEAN60_LOOKUP_NAME               VARCHAR(254)                               ,
  E_BEAN_LOOKUP_NAME                 VARCHAR(254)                               ,
  PROCESS_BASE_NAME                  VARCHAR(254)                               ,
  S_BEAN_HOME_NAME                   VARCHAR(254)                               ,
  E_BEAN_HOME_NAME                   VARCHAR(254)                               ,
  BPEWS_UTID                         CHAR(16)            FOR BIT DATA           ,
  WPC_UTID                           CHAR(16)            FOR BIT DATA           ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  ADMINISTRATOR_QTID                 CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  A_TKTIDFOR_ACTS                    CHAR(16)            FOR BIT DATA           ,
  COMPENSATION_SPHERE                INTEGER                           NOT NULL ,
  AUTONOMY                           INTEGER                           NOT NULL ,
  CAN_CALL                           SMALLINT                          NOT NULL ,
  CAN_INITIATE                       SMALLINT                          NOT NULL ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  IGNORE_MISSING_DATA                INTEGER                           NOT NULL ,
  PRIMARY KEY ( PTID )
);

ALTER TABLE PROCESS_TEMPLATE_B_T VOLATILE;

CREATE UNIQUE INDEX PTB_NAME_VALID ON PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM
);

CREATE INDEX PTB_NAME_VF_STATE ON PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM, STATE, PTID
);

CREATE INDEX PTB_TOP_APP ON PROCESS_TEMPLATE_B_T
(   
  APPLICATION_NAME
);

CREATE INDEX PTB_STATE_PTID ON PROCESS_TEMPLATE_B_T
(   
  STATE, PTID
);

CREATE INDEX PTB_NAME ON PROCESS_TEMPLATE_B_T
(   
  PTID, NAME
);

CREATE TABLE PROCESS_TEMPLATE_ATTRIBUTE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(220)                      NOT NULL ,
  VALUE                              VARCHAR(254)                               ,
  PRIMARY KEY ( PTID, ATTR_KEY )
);

ALTER TABLE PROCESS_TEMPLATE_ATTRIBUTE_B_T VOLATILE;

CREATE INDEX PTAB_PTID ON PROCESS_TEMPLATE_ATTRIBUTE_B_T
(   
  PTID
);

CREATE TABLE SCOPE_TEMPLATE_B_T
(
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_STID                        CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COMP_HANDLER_ATID                  CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTS_EHTID                   CHAR(16)            FOR BIT DATA           ,
  FOR_EACH_ATID                      CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  ISOLATED                           SMALLINT                          NOT NULL ,
  IS_COMPENSABLE                     SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  IS_IMPLICIT                        SMALLINT                          NOT NULL ,
  PRIMARY KEY ( STID )
);

CREATE INDEX ST_PTID ON SCOPE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE SERVICE_TEMPLATE_B_T
(
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_UTID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  OPERATION_NAME                     VARCHAR(254)                      NOT NULL ,
  NAME                               VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  TRANSACTION_BEHAVIOR               INTEGER                           NOT NULL ,
  IS_TWO_WAY                         SMALLINT                          NOT NULL ,
  NUMBER_OF_RECEIVE_ACTS             INTEGER                           NOT NULL ,
  PRIMARY KEY ( VTID )
);

CREATE INDEX VT_VTID_PTUTID ON SERVICE_TEMPLATE_B_T
(   
  VTID, PORT_TYPE_UTID
);

CREATE INDEX VT_PTID ON SERVICE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE ACTIVITY_SERVICE_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR(220)                               ,
  INPUT_CTID                         CHAR(16)            FOR BIT DATA           ,
  OUTPUT_CTID                        CHAR(16)            FOR BIT DATA           ,
  LINK_ORDER_NUMBER                  INTEGER                                    ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  UNDO_MSG_TEMPLATE                  BLOB(1073741823)                           ,
  PRIMARY KEY ( ATID, VTID, KIND )
);

CREATE INDEX AST_PTID ON ACTIVITY_SERVICE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE SERVICE_LOCATION_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  MODULE_NAME                        VARCHAR(220)                      NOT NULL ,
  EXPORT_NAME                        CLOB(4096)                                 ,
  COMPONENT_NAME                     CLOB(4096)                        NOT NULL ,
  PRIMARY KEY ( PTID, VTID )
);

CREATE INDEX SLT_PTID ON SERVICE_LOCATION_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE SERVICE_FAULT_TEMPLATE_B_T
(
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(220)                      NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                       NOT NULL ,
  PRIMARY KEY ( VTID, FAULT_NAME )
);

CREATE INDEX SFT_PTID ON SERVICE_FAULT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE ACTIVITY_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_STID                        CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTS_STID                    CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IMPLEMENTS_EHTID                   CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_ATID            CHAR(16)            FOR BIT DATA           ,
  IS_EVENT_HANDLER_END_ACTIVITY      SMALLINT                          NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  NAME                               VARCHAR(220)                               ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  JOIN_CONDITION                     INTEGER                           NOT NULL ,
  JOIN_CONDITION_NAME                VARCHAR(254)                               ,
  EXIT_CONDITION                     INTEGER                           NOT NULL ,
  EXIT_CONDITION_NAME                VARCHAR(254)                               ,
  EXIT_CONDITION_EXECUTE_AT          INTEGER                           NOT NULL ,
  NUMBER_OF_LINKS                    INTEGER                           NOT NULL ,
  SUPPRESS_JOIN_FAILURE              SMALLINT                          NOT NULL ,
  SOURCES_TYPE                       INTEGER                           NOT NULL ,
  TARGETS_TYPE                       INTEGER                           NOT NULL ,
  CREATE_INSTANCE                    SMALLINT                                   ,
  IS_END_ACTIVITY                    SMALLINT                          NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  HAS_OWN_FAULT_HANDLER              SMALLINT                          NOT NULL ,
  COMPLEX_BEGIN_ATID                 CHAR(16)            FOR BIT DATA           ,
  CORRESPONDING_END_ATID             CHAR(16)            FOR BIT DATA           ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA           ,
  HAS_CROSSING_LINK                  SMALLINT                                   ,
  SCRIPT_NAME                        VARCHAR(254)                               ,
  AFFILIATION                        INTEGER                           NOT NULL ,
  TRANSACTION_BEHAVIOR               INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  FAULT_NAME_UTID                    CHAR(16)            FOR BIT DATA           ,
  FAULT_VARIABLE_CTID                CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  IS_TRANSACTIONAL                   SMALLINT                          NOT NULL ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  ENCLOSED_FTID                      CHAR(16)            FOR BIT DATA           ,
  EXPRESSION                         CLOB(3900K)                                ,
  EXIT_EXPRESSION                    CLOB(3900K)                                ,
  HAS_INBOUND_LINK                   SMALLINT                          NOT NULL ,
  COMPENSATION_STID                  CHAR(16)            FOR BIT DATA           ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  CUSTOM_IMPLEMENTATION              BLOB(3900K)                                ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  EXIT_EXPRESSION_MAP                BLOB(3900K)                                ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( ATID )
);

CREATE INDEX ATB_PTID ON ACTIVITY_TEMPLATE_B_T
(   
  PTID
);

CREATE INDEX ATB_NAME ON ACTIVITY_TEMPLATE_B_T
(   
  NAME
);

CREATE INDEX ATB_KIND_BR_NAME ON ACTIVITY_TEMPLATE_B_T
(   
  KIND, BUSINESS_RELEVANCE, NAME
);

CREATE TABLE ALARM_TEMPLATE_B_T
(
  XTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EXPRESSION                         BLOB(3900K)                                ,
  EXPRESSION_NAME                    VARCHAR(254)                               ,
  DURATION                           VARCHAR(254)                               ,
  CALENDAR                           VARCHAR(254)                               ,
  CALENDAR_JNDI_NAME                 VARCHAR(254)                               ,
  REPEAT_KIND                        INTEGER                           NOT NULL ,
  REPEAT_EXPRESSION                  BLOB(3900K)                                ,
  REPEAT_EXP_NAME                    VARCHAR(254)                               ,
  ON_ALARM_ORDER_NUMBER              INTEGER                                    ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  REPEAT_EXPRESSION_MAP              BLOB(3900K)                                ,
  PRIMARY KEY ( XTID )
);

CREATE INDEX XT_PTID ON ALARM_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE FAULT_HANDLER_TEMPLATE_B_T
(
  FTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  CTID                               CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA           ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  FAULT_LINK_SOURCE_ATID             CHAR(16)            FOR BIT DATA           ,
  FAULT_LINK_TARGET_ATID             CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTATION_ATID                CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME_UTID                    CHAR(16)            FOR BIT DATA           ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  PRIMARY KEY ( FTID )
);

CREATE INDEX FT_PTID ON FAULT_HANDLER_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE LINK_TEMPLATE_B_T
(
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  FLOW_BEGIN_ATID                    CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_ATID            CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  NAME                               VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  LIFETIME                           INTEGER                           NOT NULL ,
  TRANSITION_CONDITION               INTEGER                           NOT NULL ,
  TRANSITION_CONDITION_NAME          VARCHAR(254)                               ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  SEQUENCE_NUMBER                    INTEGER                           NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  EXPRESSION                         CLOB(3900K)                                ,
  IS_INBOUND_LINK                    SMALLINT                          NOT NULL ,
  OUTBOUND_ATID                      CHAR(16)            FOR BIT DATA           ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID )
);

CREATE INDEX LNK_PTID ON LINK_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE LINK_BOUNDARY_TEMPLATE_B_T
(
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  BOUNDARY_STID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_OUTMOST_BOUNDARY                SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID, BOUNDARY_STID )
);

CREATE INDEX BND_PTID ON LINK_BOUNDARY_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE RESET_TEMPLATE_B_T
(
  LOOP_ENTRY_ATID                    CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOOP_BODY_ATID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PRIMARY KEY ( LOOP_ENTRY_ATID, LOOP_BODY_ATID )
);

CREATE INDEX RST_PTID ON RESET_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE VARIABLE_MAPPING_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE_CTID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_CTID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARAMETER                          VARCHAR(254)                      NOT NULL ,
  PRIMARY KEY ( PTID, ATID, VTID, SOURCE_CTID, TARGET_CTID )
);

CREATE INDEX VMT_TCTID ON VARIABLE_MAPPING_TEMPLATE_B_T
(   
  PTID, ATID, VTID, TARGET_CTID
);

CREATE TABLE VARIABLE_TEMPLATE_B_T
(
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA           ,
  FTID                               CHAR(16)            FOR BIT DATA           ,
  DERIVED                            SMALLINT                          NOT NULL ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  FROM_SPEC                          INTEGER                           NOT NULL ,
  NAME                               VARCHAR(254)                      NOT NULL ,
  MESSAGE_TEMPLATE                   BLOB(3900K)                                ,
  IS_QUERYABLE                       SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( CTID )
);

CREATE INDEX CT_PTID ON VARIABLE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE VARIABLE_STACK_TEMPLATE_B_T
(
  VSID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FTID                               CHAR(16)            FOR BIT DATA           ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  NAME                               VARCHAR(255)                      NOT NULL ,
  PRIMARY KEY ( VSID )
);

CREATE INDEX VS_PTID ON VARIABLE_STACK_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE ACTIVITY_FAULT_TEMPLATE_B_T
(
  AFID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                      NOT NULL ,
  FAULT_UTID                         CHAR(16)            FOR BIT DATA           ,
  MESSAGE                            BLOB(3900K)                       NOT NULL ,
  PRIMARY KEY ( AFID )
);

CREATE INDEX AF_PTID ON ACTIVITY_FAULT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE PARTNER_LINK_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR(220)                      NOT NULL ,
  PROCESS_NAME                       VARCHAR(220)                               ,
  TARGET_NAMESPACE                   VARCHAR(250)                               ,
  RESOLUTION_SCOPE                   INTEGER                           NOT NULL ,
  MY_ROLE                            SMALLINT                          NOT NULL ,
  MY_ROLE_IMPL                       BLOB(3900K)                                ,
  MY_ROLE_LOCALNAME                  VARCHAR(220)                               ,
  MY_ROLE_NAMESPACE                  VARCHAR(220)                               ,
  THEIR_ROLE                         SMALLINT                          NOT NULL ,
  THEIR_ROLE_IMPL                    BLOB(3900K)                                ,
  THEIR_ROLE_LOCALNAME               VARCHAR(220)                               ,
  THEIR_ROLE_NAMESPACE               VARCHAR(220)                               ,
  PRIMARY KEY ( PTID, PARTNER_LINK_NAME )
);

CREATE TABLE URI_TEMPLATE_B_T
(
  UTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  URI                                VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( UTID )
);

CREATE UNIQUE INDEX UT_PTID_URI ON URI_TEMPLATE_B_T
(   
  PTID, URI
);

CREATE INDEX UT_UTID_URI ON URI_TEMPLATE_B_T
(   
  UTID, URI
);

CREATE TABLE CLIENT_SETTING_TEMPLATE_B_T
(
  CSID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA           ,
  SETTINGS                           BLOB(3900K)                                ,
  PRIMARY KEY ( CSID )
);

CREATE INDEX CS_PTID ON CLIENT_SETTING_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE ASSIGN_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_SPEC                          INTEGER                           NOT NULL ,
  FROM_VARIABLE_CTID                 CHAR(16)            FOR BIT DATA           ,
  FROM_PARAMETER2                    VARCHAR(254)                               ,
  FROM_PARAMETER3                    BLOB(1073741823)                           ,
  FROM_PARAMETER3_LANGUAGE           INTEGER                           NOT NULL ,
  TO_SPEC                            INTEGER                           NOT NULL ,
  TO_VARIABLE_CTID                   CHAR(16)            FOR BIT DATA           ,
  TO_PARAMETER2                      VARCHAR(254)                               ,
  TO_PARAMETER3                      BLOB(3900K)                                ,
  TO_PARAMETER3_LANGUAGE             INTEGER                           NOT NULL ,
  FROM_EXPRESSION_MAP                BLOB(3900K)                                ,
  TO_EXPRESSION_MAP                  BLOB(3900K)                                ,
  PRIMARY KEY ( ATID, ORDER_NUMBER )
);

CREATE INDEX ASTB_PTID ON ASSIGN_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE CORRELATION_SET_TEMPLATE_B_T
(
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(255)                      NOT NULL ,
  PRIMARY KEY ( COID )
);

CREATE INDEX CSTB_PTID ON CORRELATION_SET_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE CORRELATION_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_FOR_EVENT_HANDLER               SMALLINT                          NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  INITIATE                           INTEGER                           NOT NULL ,
  PATTERN                            INTEGER                           NOT NULL ,
  PRIMARY KEY ( ATID, VTID, COID, IS_FOR_EVENT_HANDLER )
);

CREATE INDEX COID_PTID ON CORRELATION_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE PROPERTY_ALIAS_TEMPLATE_B_T
(
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SEQUENCE_NUMBER                    INTEGER                           NOT NULL ,
  PROPERTY_UTID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  PROPERTY_NAME                      VARCHAR(255)                      NOT NULL ,
  JAVA_TYPE                          VARCHAR(255)                      NOT NULL ,
  MSG_TYPE_UTID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  MSG_TYPE_NAME                      VARCHAR(255)                      NOT NULL ,
  MSG_TYPE_KIND                      INTEGER                           NOT NULL ,
  PROPERTY_TYPE_UTID                 CHAR(16)            FOR BIT DATA           ,
  PROPERTY_TYPE_NAME                 VARCHAR(255)                               ,
  PART                               VARCHAR(255)                               ,
  QUERY                              VARCHAR(255)                               ,
  QUERY_LANGUAGE                     INTEGER                           NOT NULL ,
  IS_DEFINED_INLINE                  SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PAID )
);

CREATE INDEX PATB_COID_UTID ON PROPERTY_ALIAS_TEMPLATE_B_T
(   
  COID, MSG_TYPE_UTID
);

CREATE INDEX PATB_PTID_UTIDS ON PROPERTY_ALIAS_TEMPLATE_B_T
(   
  PTID, MSG_TYPE_UTID, PROPERTY_UTID
);

CREATE TABLE EVENT_HANDLER_TEMPLATE_B_T
(
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IMPL_ATID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA           ,
  INPUT_CTID                         CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  KIND                               INTEGER                           NOT NULL ,
  PRIMARY KEY ( EHTID )
);

CREATE INDEX EHT_PTID ON EVENT_HANDLER_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE EHALARM_TEMPLATE_B_T
(
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  EXPRESSION                         BLOB(3900K)                                ,
  EXPRESSION_NAME                    VARCHAR(254)                               ,
  DURATION                           VARCHAR(254)                               ,
  CALENDAR                           VARCHAR(254)                               ,
  CALENDAR_JNDI_NAME                 VARCHAR(254)                               ,
  REPEAT_KIND                        INTEGER                           NOT NULL ,
  REPEAT_EXPRESSION                  BLOB(3900K)                                ,
  REPEAT_EXP_NAME                    VARCHAR(254)                               ,
  REPEAT_DURATION                    VARCHAR(254)                               ,
  REPEAT_CALENDAR                    VARCHAR(254)                               ,
  REPEAT_CALENDAR_JNDI_NAME          VARCHAR(254)                               ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  REPEAT_EXPRESSION_MAP              BLOB(3900K)                                ,
  PRIMARY KEY ( EHTID )
);

CREATE INDEX EXT_PTID ON EHALARM_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE CUSTOM_EXT_TEMPLATE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  TEMPLATE_INFO                      BLOB(3900K)                                ,
  INSTANCE_INFO                      BLOB(3900K)                                ,
  PRIMARY KEY ( PKID )
);

CREATE INDEX CETB_PTID ON CUSTOM_EXT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE CUSTOM_STMT_TEMPLATE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  PURPOSE                            VARCHAR(220)                      NOT NULL ,
  STATEMENT                          BLOB(3900K)                                ,
  PRIMARY KEY ( PKID )
);

CREATE INDEX CST_PTID_NS_LN_P ON CUSTOM_STMT_TEMPLATE_B_T
(   
  PTID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE TABLE PROCESS_CELL_MAP_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CELL                               VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( PTID, CELL )
);

CREATE TABLE ACTIVITY_TEMPLATE_ATTR_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(192)                      NOT NULL ,
  ATTR_VALUE                         VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PRIMARY KEY ( ATID, ATTR_KEY )
);

CREATE INDEX ATAB_PTID ON ACTIVITY_TEMPLATE_ATTR_B_T
(   
  PTID
);

CREATE INDEX ATAB_VALUE ON ACTIVITY_TEMPLATE_ATTR_B_T
(   
  ATTR_VALUE
);

CREATE TABLE FOR_EACH_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COUNTER_CTID                       CHAR(16)            FOR BIT DATA  NOT NULL ,
  SUCCESSFUL_BRANCHES_ONLY           SMALLINT                          NOT NULL ,
  START_COUNTER_LANGUAGE             INTEGER                           NOT NULL ,
  FINAL_COUNTER_LANGUAGE             INTEGER                           NOT NULL ,
  COMPLETION_CONDITION_LANGUAGE      INTEGER                           NOT NULL ,
  START_COUNTER_EXPRESSION           BLOB(3900K)                                ,
  FINAL_COUNTER_EXPRESSION           BLOB(3900K)                                ,
  COMPLETION_COND_EXPRESSION         BLOB(3900K)                                ,
  FOR_EACH_METHOD                    VARCHAR(254)                               ,
  START_COUNTER_EXPRESSION_MAP       BLOB(3900K)                                ,
  FINAL_COUNTER_EXPRESSION_MAP       BLOB(3900K)                                ,
  COMPLETION_COND_EXPRESSION_MAP     BLOB(3900K)                                ,
  PRIMARY KEY ( ATID )
);

CREATE INDEX FET_PTID ON FOR_EACH_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE GRAPHICAL_PROCESS_MODEL_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE                             VARCHAR(100)                      NOT NULL ,
  KIND                               VARCHAR(100)                      NOT NULL ,
  GRAPHICAL_DATA                     BLOB(10000K)                               ,
  ID_MAPPING                         BLOB(10000K)                               ,
  PRIMARY KEY ( PTID, SOURCE, KIND )
);

CREATE TABLE QUERYABLE_VARIABLE_TEMPLATE_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  QUERY_TYPE                         INTEGER                           NOT NULL ,
  PRIMARY KEY ( PKID )
);

CREATE INDEX QVT_PTID ON QUERYABLE_VARIABLE_TEMPLATE_T
(   
  PTID
);

CREATE TABLE STAFF_QUERY_TEMPLATE_T
(
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  T_QUERY                            VARCHAR(32)                       NOT NULL ,
  QUERY                              BLOB(3900K)                       NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  STAFF_VERB                         BLOB(3900K)                                ,
  PRIMARY KEY ( QTID )
);

CREATE INDEX SQT_HASH ON STAFF_QUERY_TEMPLATE_T
(   
  ASSOCIATED_OID, HASH_CODE, T_QUERY, ASSOCIATED_OBJECT_TYPE
);

CREATE TABLE PROCESS_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  PENDING_REQUEST                    INTEGER                           NOT NULL ,
  CREATED                            TIMESTAMP                                  ,
  STARTED                            TIMESTAMP                                  ,
  COMPLETED                          TIMESTAMP                                  ,
  LAST_STATE_CHANGE                  TIMESTAMP                                  ,
  LAST_MODIFIED                      TIMESTAMP                                  ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  PARENT_NAME                        VARCHAR(220)                               ,
  TOP_LEVEL_NAME                     VARCHAR(220)                      NOT NULL ,
  COMPENSATION_SPHERE_NAME           VARCHAR(100)                               ,
  STARTER                            VARCHAR(128)                               ,
  DESCRIPTION                        VARCHAR(254)                               ,
  INPUT_SNID                         CHAR(16)            FOR BIT DATA           ,
  INPUT_ATID                         CHAR(16)            FOR BIT DATA           ,
  INPUT_VTID                         CHAR(16)            FOR BIT DATA           ,
  OUTPUT_SNID                        CHAR(16)            FOR BIT DATA           ,
  OUTPUT_ATID                        CHAR(16)            FOR BIT DATA           ,
  OUTPUT_VTID                        CHAR(16)            FOR BIT DATA           ,
  FAULT_NAME                         VARCHAR(254)                               ,
  TOP_LEVEL_PIID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_AIID                        CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  TERMIN_ON_REC                      SMALLINT                          NOT NULL ,
  AWAITED_SUB_PROC                   SMALLINT                          NOT NULL ,
  IS_CREATING                        SMALLINT                          NOT NULL ,
  PREVIOUS_STATE                     INTEGER                                    ,
  EXECUTING_ISOLATED_SCOPE           SMALLINT                          NOT NULL ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  RESUMES                            TIMESTAMP                                  ,
  PENDING_SKIP_REQUEST               SMALLINT                          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
);

ALTER TABLE PROCESS_INSTANCE_B_T VOLATILE;

CREATE UNIQUE INDEX PIB_NAME ON PROCESS_INSTANCE_B_T
(   
  NAME
);

CREATE INDEX PIB_TOP ON PROCESS_INSTANCE_B_T
(   
  TOP_LEVEL_PIID
);

CREATE INDEX PIB_PAP ON PROCESS_INSTANCE_B_T
(   
  PARENT_PIID
);

CREATE INDEX PIB_PAR ON PROCESS_INSTANCE_B_T
(   
  PARENT_AIID
);

CREATE INDEX PIB_PTID ON PROCESS_INSTANCE_B_T
(   
  PTID
);

CREATE INDEX PIB_PIID_STATE ON PROCESS_INSTANCE_B_T
(   
  PIID, STATE
);

CREATE INDEX PIB_STATE ON PROCESS_INSTANCE_B_T
(   
  STATE
);

CREATE INDEX PIB_PIID_PTID_STAT ON PROCESS_INSTANCE_B_T
(   
  PIID, PTID, STATE, STARTER, STARTED
);

CREATE TABLE SCOPE_INSTANCE_B_T
(
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_SIID                        CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FEIID                    CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_END_AIID        CHAR(16)            FOR BIT DATA           ,
  COMPENSATE_AIID                    CHAR(16)            FOR BIT DATA           ,
  PARENT_COMP_SIID                   CHAR(16)            FOR BIT DATA           ,
  LAST_COMP_SIID                     CHAR(16)            FOR BIT DATA           ,
  RUNNING_EVENT_HANDLERS             INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  NOTIFY_PARENT                      SMALLINT                          NOT NULL ,
  AWAITED_SCOPES                     INTEGER                           NOT NULL ,
  AWAITED_SUB_PROCESSES              INTEGER                           NOT NULL ,
  BPEL_EXCEPTION                     BLOB(1073741823)                           ,
  IS_ACTIVE                          SMALLINT                          NOT NULL ,
  INITIATED_COMP                     SMALLINT                          NOT NULL ,
  IS_TERMINATION_FROM_FOR_EACH       SMALLINT                          NOT NULL ,
  TOTAL_COMPL_NUMBER                 BIGINT                            NOT NULL ,
  SCOPE_COMPL_NUMBER                 BIGINT                            NOT NULL ,
  A_TKIID                            CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SIID )
);

ALTER TABLE SCOPE_INSTANCE_B_T VOLATILE;

CREATE INDEX SI_PI_ST_EH_STA_FE ON SCOPE_INSTANCE_B_T
(   
  PIID, STID, STATE, EHIID, ENCLOSING_FEIID
);

CREATE INDEX SI_PI_ST_EH_ACT_FE ON SCOPE_INSTANCE_B_T
(   
  PIID, STID, IS_ACTIVE, EHIID, ENCLOSING_FEIID
);

CREATE INDEX SI_PIID_PARSI ON SCOPE_INSTANCE_B_T
(   
  PIID, PARENT_SIID, IS_ACTIVE
);

CREATE INDEX SI_PARCOMP_STA_ST ON SCOPE_INSTANCE_B_T
(   
  PARENT_COMP_SIID, STATE, STID
);

CREATE INDEX SI_PIID_STATE ON SCOPE_INSTANCE_B_T
(   
  PIID, STATE
);

CREATE INDEX SI_LAST_COMPSIID ON SCOPE_INSTANCE_B_T
(   
  LAST_COMP_SIID
);

CREATE TABLE ACTIVITY_INSTANCE_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FEIID                    CHAR(16)            FOR BIT DATA           ,
  P_TKIID                            CHAR(16)            FOR BIT DATA           ,
  A_TKIID                            CHAR(16)            FOR BIT DATA           ,
  INVOKED_INSTANCE_ID                CHAR(16)            FOR BIT DATA           ,
  INVOKED_INSTANCE_TYPE              INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  TRANS_COND_VALUES                  VARCHAR(66)         FOR BIT DATA  NOT NULL ,
  NUMBER_LINKS_EVALUATED             INTEGER                           NOT NULL ,
  FINISHED                           TIMESTAMP                                  ,
  ACTIVATED                          TIMESTAMP                                  ,
  FIRST_ACTIVATED                    TIMESTAMP                                  ,
  STARTED                            TIMESTAMP                                  ,
  LAST_MODIFIED                      TIMESTAMP                                  ,
  LAST_STATE_CHANGE                  TIMESTAMP                                  ,
  OWNER                              VARCHAR(128)                               ,
  DESCRIPTION                        VARCHAR(254)                               ,
  LINK_ORDER_NUMBER                  INTEGER                                    ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  EXPIRES                            TIMESTAMP                                  ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB(1073741823)                           ,
  STOP_REASON                        INTEGER                           NOT NULL ,
  PREVIOUS_STATE                     INTEGER                                    ,
  INVOCATION_COUNTER                 INTEGER                           NOT NULL ,
  FOR_EACH_START_COUNTER_VALUE       BIGINT                                     ,
  FOR_EACH_FINAL_COUNTER_VALUE       BIGINT                                     ,
  FOR_EACH_CURRENT_COUNTER_VALUE     BIGINT                                     ,
  FOR_EACH_COMPLETED_BRANCHES        BIGINT                                     ,
  FOR_EACH_FAILED_BRANCHES           BIGINT                                     ,
  FOR_EACH_MAX_COMPL_BRANCHES        BIGINT                                     ,
  FOR_EACH_AWAITED_BRANCHES          BIGINT                                     ,
  IS51_ACTIVITY                      SMALLINT                          NOT NULL ,
  MAY_HAVE_SUBPROCESS                SMALLINT                                   ,
  SKIP_REQUESTED                     SMALLINT                          NOT NULL ,
  JUMP_TARGET_ATID                   CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID )
);

ALTER TABLE ACTIVITY_INSTANCE_B_T VOLATILE;

CREATE INDEX AIB_PI_ATID_EH_FE ON ACTIVITY_INSTANCE_B_T
(   
  PIID, ATID, EHIID, ENCLOSING_FEIID
);

CREATE INDEX AIB_PTID ON ACTIVITY_INSTANCE_B_T
(   
  PTID
);

CREATE INDEX AIB_PIID_STAT_AIID ON ACTIVITY_INSTANCE_B_T
(   
  PIID, STATE, AIID, ACTIVATED
);

CREATE INDEX AIB_AI_AT_STAT_PI ON ACTIVITY_INSTANCE_B_T
(   
  AIID, ATID, STATE, PIID, OWNER, ACTIVATED
);

CREATE INDEX AIB_SIID ON ACTIVITY_INSTANCE_B_T
(   
  SIID
);

CREATE TABLE VARIABLE_INSTANCE_B_T
(
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CTID, PIID )
);

ALTER TABLE VARIABLE_INSTANCE_B_T VOLATILE;

CREATE INDEX CI_PIID ON VARIABLE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE SCOPED_VARIABLE_INSTANCE_B_T
(
  SVIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  DATA                               BLOB(1073741823)                           ,
  DATA_IL                            VARCHAR(3000)       FOR BIT DATA           ,
  IS_ACTIVE                          SMALLINT                          NOT NULL ,
  IS_INITIALIZED                     SMALLINT                          NOT NULL ,
  IS_QUERYABLE                       SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SVIID )
);

ALTER TABLE SCOPED_VARIABLE_INSTANCE_B_T VOLATILE;

CREATE INDEX SVI_PI_CT_EH_FE ON SCOPED_VARIABLE_INSTANCE_B_T
(   
  PIID, CTID, IS_ACTIVE, EHIID, FEIID
);

CREATE INDEX SVI_CT_SI_EH_AC ON SCOPED_VARIABLE_INSTANCE_B_T
(   
  SIID, CTID, IS_ACTIVE, EHIID
);

CREATE TABLE STAFF_MESSAGE_INSTANCE_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID, KIND )
);

ALTER TABLE STAFF_MESSAGE_INSTANCE_B_T VOLATILE;

CREATE INDEX SMI_PIID ON STAFF_MESSAGE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE EVENT_INSTANCE_B_T
(
  EIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_TWO_WAY                         SMALLINT                          NOT NULL ,
  IS_PRIMARY_EVENT_INSTANCE          SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  NEXT_POSTED_EVENT                  CHAR(16)            FOR BIT DATA           ,
  LAST_POSTED_EVENT                  CHAR(16)            FOR BIT DATA           ,
  POST_COUNT                         INTEGER                           NOT NULL ,
  MESSAGE                            BLOB(1073741823)                           ,
  REPLY_CONTEXT                      BLOB(3900k)                                ,
  POST_TIME                          TIMESTAMP                                  ,
  MAX_NUMBER_OF_POSTS                INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( EIID )
);

ALTER TABLE EVENT_INSTANCE_B_T VOLATILE;

CREATE INDEX EI_PIID_PRIM ON EVENT_INSTANCE_B_T
(   
  PIID, IS_PRIMARY_EVENT_INSTANCE, STATE
);

CREATE INDEX EI_PIID_VTID ON EVENT_INSTANCE_B_T
(   
  PIID, VTID, IS_PRIMARY_EVENT_INSTANCE
);

CREATE INDEX EI_AIID ON EVENT_INSTANCE_B_T
(   
  AIID
);

CREATE INDEX EI_STATE_VTID ON EVENT_INSTANCE_B_T
(   
  VTID, STATE, EIID, AIID, PIID
);

CREATE TABLE REQUEST_INSTANCE_B_T
(
  RIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  INSTANTIATING                      SMALLINT                          NOT NULL ,
  REPLY_CONTEXT                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( RIID )
);

ALTER TABLE REQUEST_INSTANCE_B_T VOLATILE;

CREATE INDEX RI_PIID_VTID_EHIID ON REQUEST_INSTANCE_B_T
(   
  PIID, VTID
);

CREATE TABLE PARTNER_LINK_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  ENDPOINT_REFERENCE                 BLOB(3900k)                                ,
  SERVICE_DEFINITION                 BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, NAME )
);

ALTER TABLE PARTNER_LINK_INSTANCE_B_T VOLATILE;

CREATE INDEX PA_PIID ON PARTNER_LINK_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE VARIABLE_SNAPSHOT_B_T
(
  SNID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  COPY_VERSION                       SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SNID )
);

ALTER TABLE VARIABLE_SNAPSHOT_B_T VOLATILE;

CREATE INDEX SN_PIID_CTID ON VARIABLE_SNAPSHOT_B_T
(   
  PIID, CTID
);

CREATE TABLE SUSPENDED_MESSAGE_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ENGINE_MESSAGE                     BLOB(1073741823)                  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE SUSPENDED_MESSAGE_INSTANCE_B_T VOLATILE;

CREATE INDEX PIID ON SUSPENDED_MESSAGE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE CROSSING_LINK_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  CONDITION_VALUE                    INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE CROSSING_LINK_INSTANCE_B_T VOLATILE;

CREATE INDEX CL_PI_TAT_EH_FE_SA ON CROSSING_LINK_INSTANCE_B_T
(   
  PIID, TARGET_ATID, EHIID, FEIID, SOURCE_ATID
);

CREATE TABLE INVOKE_RESULT_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  INVOKE_RESULT                      BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, ATID )
);

ALTER TABLE INVOKE_RESULT_B_T VOLATILE;

CREATE TABLE INVOKE_RESULT2_B_T
(
  IRID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  INVOKE_RESULT                      BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IRID )
);

ALTER TABLE INVOKE_RESULT2_B_T VOLATILE;

CREATE INDEX IR2_PI_AT_EH_FE ON INVOKE_RESULT2_B_T
(   
  PIID, ATID, EHIID, FEIID
);

CREATE TABLE EVENT_HANDLER_INSTANCE_B_T
(
  EHIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( EHIID )
);

ALTER TABLE EVENT_HANDLER_INSTANCE_B_T VOLATILE;

CREATE INDEX EHI_PIID_EHTID ON EVENT_HANDLER_INSTANCE_B_T
(   
  PIID, EHTID
);

CREATE INDEX EHI_SIID_EHTID ON EVENT_HANDLER_INSTANCE_B_T
(   
  SIID, EHTID
);

CREATE TABLE CORRELATION_SET_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PROCESS_NAME                       VARCHAR(220)                      NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATUS                             INTEGER                           NOT NULL ,
  HASH_CODE                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               VARCHAR(3072)                              ,
  DATA_LONG                          CLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, COID, SIID )
);

ALTER TABLE CORRELATION_SET_INSTANCE_B_T VOLATILE;

CREATE UNIQUE INDEX CSIB_HASH_PN ON CORRELATION_SET_INSTANCE_B_T
(   
  HASH_CODE, PROCESS_NAME
);

CREATE INDEX CSIB_PIID ON CORRELATION_SET_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE CORRELATION_SET_PROPERTIES_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, COID, SIID )
);

ALTER TABLE CORRELATION_SET_PROPERTIES_B_T VOLATILE;

CREATE TABLE UNDO_ACTION_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_AIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  PROCESS_NAME                       VARCHAR(220)                      NOT NULL ,
  CSCOPE_ID                          VARCHAR(100)                      NOT NULL ,
  UUID                               VARCHAR(100)                      NOT NULL ,
  COMP_CREATION_TIME                 TIMESTAMP                         NOT NULL ,
  DO_OP_WAS_TXNAL                    SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  INPUT_DATA                         BLOB(1073741823)                  NOT NULL ,
  FAULT_DATA                         BLOB(1073741823)                           ,
  CREATED                            INTEGER                           NOT NULL ,
  PROCESS_ADMIN                      VARCHAR(128)                      NOT NULL ,
  IS_VISIBLE                         SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE UNDO_ACTION_B_T VOLATILE;

CREATE INDEX UA_CSID_DOOP_UUID ON UNDO_ACTION_B_T
(   
  CSCOPE_ID, DO_OP_WAS_TXNAL, UUID
);

CREATE INDEX UA_CSID_STATE_CCT ON UNDO_ACTION_B_T
(   
  CSCOPE_ID, STATE, UUID
);

CREATE INDEX UA_STATE_ISV ON UNDO_ACTION_B_T
(   
  STATE, IS_VISIBLE
);

CREATE INDEX UA_AIID_STATE_UUID ON UNDO_ACTION_B_T
(   
  PARENT_AIID, STATE, UUID
);

CREATE INDEX UA_PIID ON UNDO_ACTION_B_T
(   
  PARENT_PIID
);

CREATE INDEX UA_PT_AT_CS_UU_CCT ON UNDO_ACTION_B_T
(   
  PTID, ATID, CSCOPE_ID, UUID, COMP_CREATION_TIME
);

CREATE TABLE CUSTOM_STMT_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SVIID                              CHAR(16)            FOR BIT DATA           ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  PURPOSE                            VARCHAR(220)                      NOT NULL ,
  STATEMENT                          BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

CREATE INDEX CSI_PIID_NS_LN_P ON CUSTOM_STMT_INSTANCE_B_T
(   
  PIID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE INDEX CSI_SVIID_NS_LN_P ON CUSTOM_STMT_INSTANCE_B_T
(   
  SVIID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE TABLE COMP_WORK_PENDING_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  CSCOPE_ID                          VARCHAR(100)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE COMP_WORK_PENDING_B_T VOLATILE;

CREATE INDEX CWP_PI_AT_CS_EH_FE ON COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, CSCOPE_ID, PARENT_EHIID, PARENT_FEIID
);

CREATE INDEX CWP_PI_AT_EHI ON COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, PARENT_EHIID
);

CREATE TABLE COMP_PARENT_ACTIVITY_INST_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COMPLETION_NUMBER                  BIGINT                            NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID )
);

ALTER TABLE COMP_PARENT_ACTIVITY_INST_B_T VOLATILE;

CREATE INDEX CPAI_SI_S_CN_AI_PI ON COMP_PARENT_ACTIVITY_INST_B_T
(   
  SIID, STATE, COMPLETION_NUMBER, AIID, PIID
);

CREATE INDEX CPAI_PIID ON COMP_PARENT_ACTIVITY_INST_B_T
(   
  PIID
);

CREATE TABLE RESTART_EVENT_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PORT_TYPE                          VARCHAR(254)                      NOT NULL ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  INPUT_MESSAGE                      BLOB(1073741823)                           ,
  REPLY_CTX                          BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE RESTART_EVENT_B_T VOLATILE;

CREATE INDEX REB_PIID ON RESTART_EVENT_B_T
(   
  PIID
);

CREATE TABLE PROGRESS_COUNTER_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COUNTER                            BIGINT                            NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
);

ALTER TABLE PROGRESS_COUNTER_T VOLATILE;

CREATE TABLE RELEVANT_SCOPE_ATASK_T
(
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SIID, TKIID )
);

ALTER TABLE RELEVANT_SCOPE_ATASK_T VOLATILE;

CREATE TABLE CONFIG_INFO_T
(
  IDENTIFIER                         VARCHAR(64)                       NOT NULL ,
  DESCRIPTION                        VARCHAR(128)                               ,
  PROPERTY                           INTEGER                                    ,
  COUNTER                            BIGINT                                     ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IDENTIFIER )
);

ALTER TABLE CONFIG_INFO_T VOLATILE;

CREATE TABLE PROCESS_INSTANCE_ATTRIBUTE_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(220)                      NOT NULL ,
  VALUE                              VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, ATTR_KEY )
);

ALTER TABLE PROCESS_INSTANCE_ATTRIBUTE_T VOLATILE;

CREATE INDEX PIA_VALUE ON PROCESS_INSTANCE_ATTRIBUTE_T
(   
  VALUE
);

CREATE INDEX PIA_DATY ON PROCESS_INSTANCE_ATTRIBUTE_T
(   
  DATA_TYPE
);

CREATE TABLE PROCESS_CONTEXT_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  REPLY_CONTEXT                      BLOB(3900K)                                ,
  SERVICE_CONTEXT                    BLOB(3900K)                                ,
  STARTER_EXPIRES                    TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
);

ALTER TABLE PROCESS_CONTEXT_T VOLATILE;

CREATE TABLE ACTIVITY_INSTANCE_ATTR_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  ATTR_KEY                           VARCHAR(189)                      NOT NULL ,
  ATTR_VALUE                         VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE ACTIVITY_INSTANCE_ATTR_B_T VOLATILE;

CREATE UNIQUE INDEX AIA_UNIQUE ON ACTIVITY_INSTANCE_ATTR_B_T
(   
  PIID, ATID, EHIID, FEIID, ATTR_KEY
);

CREATE INDEX AIA_AIID ON ACTIVITY_INSTANCE_ATTR_B_T
(   
  AIID
);

CREATE INDEX AIA_VALUE ON ACTIVITY_INSTANCE_ATTR_B_T
(   
  ATTR_VALUE
);

CREATE INDEX AIA_DATY ON ACTIVITY_INSTANCE_ATTR_B_T
(   
  DATA_TYPE
);

CREATE TABLE NAVIGATION_EXCEPTION_T
(
  CORRELATION_ID                     VARCHAR(220)        FOR BIT DATA  NOT NULL ,
  EXCEPTION_TYPE                     INTEGER                           NOT NULL ,
  OUTPUT_MESSAGE                     BLOB(1073741823)                           ,
  TYPE_SYSTEM                        VARCHAR(32)                                ,
  PROCESS_EXCEPTION                  BLOB(3900K)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CORRELATION_ID, EXCEPTION_TYPE )
);

CREATE TABLE AWAITED_INVOCATION_T
(
  CORRELATION_ID                     VARCHAR(254)        FOR BIT DATA  NOT NULL ,
  CORRELATION_INFO                   BLOB(3900K)                       NOT NULL ,
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CORRELATION_ID )
);

CREATE INDEX AWI_PIID ON AWAITED_INVOCATION_T
(   
  PIID
);

CREATE INDEX AWI_AIID ON AWAITED_INVOCATION_T
(   
  AIID
);

CREATE TABLE STORED_QUERY_T
(
  SQID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  NAME                               VARCHAR(64)                       NOT NULL ,
  OWNER_ID                           VARCHAR(128)                      NOT NULL ,
  SELECT_CLAUSE                      CLOB(20K)                         NOT NULL ,
  WHERE_CLAUSE                       CLOB(20K)                                  ,
  ORDER_CLAUSE                       VARCHAR(254)                               ,
  THRESHOLD                          INTEGER                                    ,
  TIMEZONE                           VARCHAR(63)                                ,
  CREATOR                            VARCHAR(128)                               ,
  TYPE                               VARCHAR(128)                               ,
  PROPERTY                           BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SQID )
);

CREATE UNIQUE INDEX SQ_NAME ON STORED_QUERY_T
(   
  KIND, OWNER_ID, NAME
);

CREATE TABLE FOR_EACH_INSTANCE_B_T
(
  FEIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( FEIID )
);

CREATE INDEX FEI_PIID ON FOR_EACH_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE QUERYABLE_VARIABLE_INSTANCE_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VARIABLE_NAME                      VARCHAR(254)                      NOT NULL ,
  PROPERTY_NAME                      VARCHAR(255)                      NOT NULL ,
  PROPERTY_NAMESPACE                 VARCHAR(254)                      NOT NULL ,
  TYPE                               INTEGER                           NOT NULL ,
  GENERIC_VALUE                      VARCHAR(512)                               ,
  STRING_VALUE                       VARCHAR(512)                               ,
  NUMBER_VALUE                       BIGINT                                     ,
  DECIMAL_VALUE                      DOUBLE                                     ,
  TIMESTAMP_VALUE                    TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE QUERYABLE_VARIABLE_INSTANCE_T VOLATILE;

CREATE INDEX QVI_PI_CT_PA ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, CTID, PAID
);

CREATE INDEX QVI_PI_VARNAME ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, VARIABLE_NAME
);

CREATE INDEX QVI_PI_PROPNAME ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAME
);

CREATE INDEX QVI_PI_NAMESPACE ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAMESPACE
);

CREATE INDEX QVI_PI_GEN_VALUE ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, GENERIC_VALUE
);

CREATE INDEX QVI_PI_STR_VALUE ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, STRING_VALUE
);

CREATE INDEX QVI_PI_NUM ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, NUMBER_VALUE
);

CREATE INDEX QVI_PI_DEC ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, DECIMAL_VALUE
);

CREATE INDEX QVI_PI_TIME ON QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, TIMESTAMP_VALUE
);

CREATE TABLE SYNC_T
(
  IDENTIFIER                         VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IDENTIFIER )
);

CREATE TABLE MV_CTR_T
(
  ID                                 INTEGER                           NOT NULL ,
  SELECT_CLAUSE                      VARCHAR(1024)                     NOT NULL ,
  WHERE_CLAUSE                       VARCHAR(1024)                              ,
  ORDER_CLAUSE                       VARCHAR(512)                               ,
  TBL_SPACE                          VARCHAR(32)                       NOT NULL ,
  UPDATED                            TIMESTAMP                         NOT NULL ,
  UPD_STARTED                        TIMESTAMP                                  ,
  AVG_UPD_TIME                       BIGINT                                     ,
  UPD_INTERVAL                       BIGINT                            NOT NULL ,
  IS_UPDATING                        SMALLINT                          NOT NULL ,
  ACTIVE_MV                          SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ID )
);

CREATE TABLE MV_MODS_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  MODIFIED                           TIMESTAMP                         NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE MV_MODS_T VOLATILE;

CREATE TABLE SAVED_ENGINE_MESSAGE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA           ,
  CREATION_TIME                      TIMESTAMP                         NOT NULL ,
  REASON                             INTEGER                           NOT NULL ,
  ENGINE_MESSAGE_S                   VARCHAR(2000)       FOR BIT DATA           ,
  ENGINE_MESSAGE_L                   BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE SAVED_ENGINE_MESSAGE_B_T VOLATILE;

CREATE INDEX SEM_PIID ON SAVED_ENGINE_MESSAGE_B_T
(   
  PIID
);

CREATE INDEX SEM_REAS ON SAVED_ENGINE_MESSAGE_B_T
(   
  REASON
);

CREATE TABLE NAVIGATION_CLEANUP_TIMER_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SCHEDULED_TIME                     TIMESTAMP                         NOT NULL ,
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE NAVIGATION_CLEANUP_TIMER_B_T VOLATILE;

CREATE TABLE SCHEDULER_ACTION_T
(
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  ACTION_OBJECT                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SCHEDULER_ID )
);

ALTER TABLE SCHEDULER_ACTION_T VOLATILE;

CREATE INDEX SCEACT_OID ON SCHEDULER_ACTION_T
(   
  OID
);

CREATE TABLE QUERY_TABLE_T
(
  NAME                               VARCHAR(32)                       NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  TYPE                               INTEGER                           NOT NULL ,
  VERSION                            INTEGER                           NOT NULL ,
  LAST_UPDATED                       TIMESTAMP                         NOT NULL ,
  PRIMARY_VIEW                       VARCHAR(32)                                ,
  DEFINITION                         BLOB(1073741823)                  NOT NULL ,
  VV_CFG                             BLOB(1073741823)                           ,
  DV_CFG                             BLOB(1073741823)                           ,
  MV_CFG                             BLOB(1073741823)                           ,
  MT_CFG                             BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( NAME )
);

ALTER TABLE QUERY_TABLE_T VOLATILE;

CREATE INDEX QT_KI ON QUERY_TABLE_T
(   
  KIND
);

CREATE INDEX QT_TY ON QUERY_TABLE_T
(   
  TYPE
);

CREATE TABLE QUERY_TABLE_REF_T
(
  REFEREE                            VARCHAR(32)                       NOT NULL ,
  SOURCE                             VARCHAR(32)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( REFEREE, SOURCE )
);

ALTER TABLE QUERY_TABLE_REF_T VOLATILE;

CREATE INDEX QTR_SRC ON QUERY_TABLE_REF_T
(   
  SOURCE
);

CREATE TABLE AUDIT_LOG_T
(
  ALID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVENT_TIME                         TIMESTAMP                         NOT NULL ,
  EVENT_TIME_UTC                     TIMESTAMP                                  ,
  AUDIT_EVENT                        INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA           ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  VARIABLE_NAME                      VARCHAR(254)                               ,
  PROCESS_TEMPL_NAME                 VARCHAR(254)                      NOT NULL ,
  PROCESS_INST_NAME                  VARCHAR(254)                               ,
  TOP_LEVEL_PI_NAME                  VARCHAR(254)                               ,
  TOP_LEVEL_PIID                     CHAR(16)            FOR BIT DATA           ,
  PARENT_PI_NAME                     VARCHAR(254)                               ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  VALID_FROM                         TIMESTAMP                                  ,
  VALID_FROM_UTC                     TIMESTAMP                                  ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  ACTIVITY_NAME                      VARCHAR(254)                               ,
  ACTIVITY_KIND                      INTEGER                                    ,
  ACTIVITY_STATE                     INTEGER                                    ,
  CONTROL_LINK_NAME                  VARCHAR(254)                               ,
  IMPL_NAME                          VARCHAR(254)                               ,
  PRINCIPAL                          VARCHAR(128)                               ,
  TERMINAL_NAME                      VARCHAR(254)                               ,
  VARIABLE_DATA                      BLOB(1073741823)                           ,
  EXCEPTION_TEXT                     CLOB(4096)                                 ,
  DESCRIPTION                        VARCHAR(254)                               ,
  CORR_SET_INFO                      CLOB(4096)                                 ,
  USER_NAME                          VARCHAR(128)                               ,
  ADDITIONAL_INFO                    CLOB(4096)                                 ,
  OBJECT_META_TYPE                   INTEGER                                    ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ALID )
);

CREATE TABLE WORK_ITEM_T
(
  WIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_WIID                        CHAR(16)            FOR BIT DATA           ,
  OWNER_ID                           VARCHAR(128)                               ,
  GROUP_NAME                         VARCHAR(128)                               ,
  EVERYBODY                          SMALLINT                          NOT NULL ,
  EXCLUDE                            SMALLINT                          NOT NULL ,
  QIID                               CHAR(16)            FOR BIT DATA           ,
  OBJECT_TYPE                        INTEGER                           NOT NULL ,
  OBJECT_ID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA           ,
  REASON                             INTEGER                           NOT NULL ,
  CREATION_TIME                      TIMESTAMP                         NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  AUTH_INFO                          INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( WIID )
);

ALTER TABLE WORK_ITEM_T VOLATILE;

CREATE INDEX WI_ASSOBJ_REASON ON WORK_ITEM_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE, REASON, PARENT_WIID
);

CREATE INDEX WI_OBJID_TYPE_QIID ON WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, QIID
);

CREATE INDEX WI_OBJID_TYPE_REAS ON WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, REASON
);

CREATE INDEX WI_GROUP_NAME ON WORK_ITEM_T
(   
  GROUP_NAME
);

CREATE INDEX WI_AUTH_L ON WORK_ITEM_T
(   
  EVERYBODY, GROUP_NAME, OWNER_ID, QIID
);

CREATE INDEX WI_AUTH_U ON WORK_ITEM_T
(   
  AUTH_INFO, QIID
);

CREATE INDEX WI_AUTH_O ON WORK_ITEM_T
(   
  AUTH_INFO, OWNER_ID DESC
);

CREATE INDEX WI_AUTH_G ON WORK_ITEM_T
(   
  AUTH_INFO, GROUP_NAME
);

CREATE INDEX WI_AUTH_E ON WORK_ITEM_T
(   
  AUTH_INFO, EVERYBODY
);

CREATE INDEX WI_AUTH_R ON WORK_ITEM_T
(   
  AUTH_INFO, REASON DESC
);

CREATE INDEX WI_REASON ON WORK_ITEM_T
(   
  REASON
);

CREATE INDEX WI_OWNER ON WORK_ITEM_T
(   
  OWNER_ID, OBJECT_ID, REASON, OBJECT_TYPE
);

CREATE INDEX WI_QIID ON WORK_ITEM_T
(   
  QIID
);

CREATE INDEX WI_QRY ON WORK_ITEM_T
(   
  OBJECT_ID, REASON, EVERYBODY, OWNER_ID
);

CREATE INDEX WI_QI_OID_RS_OWN ON WORK_ITEM_T
(   
  QIID, OBJECT_ID, REASON, OWNER_ID
);

CREATE INDEX WI_QI_OID_OWN ON WORK_ITEM_T
(   
  QIID, OBJECT_ID, OWNER_ID
);

CREATE INDEX WI_OT_OID_RS ON WORK_ITEM_T
(   
  OBJECT_TYPE, OBJECT_ID, REASON
);

CREATE INDEX WI_WI_QI ON WORK_ITEM_T
(   
  WIID, QIID
);

CREATE INDEX WI_PARENT_WIID ON WORK_ITEM_T
(   
  PARENT_WIID
);

CREATE INDEX WI_AUTH_GR_O_E ON WORK_ITEM_T
(   
  AUTH_INFO, GROUP_NAME, OWNER_ID, EVERYBODY
);

CREATE TABLE RETRIEVED_USER_T
(
  QIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  OWNER_ID                           VARCHAR(128)                      NOT NULL ,
  REASON                             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QIID, OWNER_ID )
);

ALTER TABLE RETRIEVED_USER_T VOLATILE;

CREATE INDEX RUT_OWN_QIID ON RETRIEVED_USER_T
(   
  OWNER_ID, QIID
);

CREATE INDEX RUT_ASSOC ON RETRIEVED_USER_T
(   
  ASSOCIATED_OID
);

CREATE INDEX RUT_QIID ON RETRIEVED_USER_T
(   
  QIID
);

CREATE INDEX RUT_OWN_QIDESC ON RETRIEVED_USER_T
(   
  OWNER_ID, QIID DESC
);

CREATE TABLE STAFF_QUERY_INSTANCE_T
(
  QIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVERYBODY                          SMALLINT                          NOT NULL ,
  NOBODY                             SMALLINT                          NOT NULL ,
  IS_SHAREABLE                       SMALLINT                          NOT NULL ,
  IS_TRANSFERRED                     SMALLINT                          NOT NULL ,
  SR_HASH_CODE                       INTEGER                                    ,
  GROUP_NAME                         VARCHAR(128)                               ,
  CONTEXT_VALUES                     VARCHAR(3072)                              ,
  CONTEXT_VALUES_LONG                CLOB(3096K)                                ,
  HASH_CODE                          INTEGER                                    ,
  EXPIRES                            TIMESTAMP                                  ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QIID )
);

CREATE INDEX SQI_QTID ON STAFF_QUERY_INSTANCE_T
(   
  QTID, HASH_CODE
);

CREATE INDEX SQI_ASSOCID ON STAFF_QUERY_INSTANCE_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE
);

CREATE INDEX SQI_QIIDGN ON STAFF_QUERY_INSTANCE_T
(   
  QIID, GROUP_NAME
);

CREATE INDEX SQI_QIIDTREX ON STAFF_QUERY_INSTANCE_T
(   
  QIID, IS_TRANSFERRED, EXPIRES
);

CREATE TABLE STAFF_LOCK_T
(
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QTID, HASH_CODE )
);

CREATE TABLE APPLICATION_COMPONENT_T
(
  ACOID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(64)                       NOT NULL ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                      NOT NULL ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  INSTANCE_CREATOR_QTID              CHAR(16)            FOR BIT DATA           ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  PRIMARY KEY ( ACOID )
);

CREATE UNIQUE INDEX ACO_NAME ON APPLICATION_COMPONENT_T
(   
  NAME
);

CREATE TABLE ESCALATION_TEMPLATE_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  FIRST_ESTID                        CHAR(16)            FOR BIT DATA           ,
  PREVIOUS_ESTID                     CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  MNTID                              CHAR(16)            FOR BIT DATA           ,
  NAME                               VARCHAR(220)                               ,
  ACTIVATION_STATE                   INTEGER                           NOT NULL ,
  AT_LEAST_EXPECTED_STATE            INTEGER                           NOT NULL ,
  DURATION_UNTIL_ESCALATION          VARCHAR(254)                               ,
  DURATION_UNTIL_REPEATS             VARCHAR(254)                               ,
  INCREASE_PRIORITY                  INTEGER                           NOT NULL ,
  ACTION                             INTEGER                           NOT NULL ,
  ESCALATION_RECEIVER_QTID           CHAR(16)            FOR BIT DATA           ,
  RECEIVER_EMAIL_QTID                CHAR(16)            FOR BIT DATA           ,
  PRIMARY KEY ( ESTID )
);

ALTER TABLE ESCALATION_TEMPLATE_T VOLATILE;

CREATE INDEX ET_TKTID ON ESCALATION_TEMPLATE_T
(   
  TKTID
);

CREATE INDEX ET_CCID ON ESCALATION_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE ESC_TEMPL_CPROP_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  PRIMARY KEY ( ESTID, NAME )
);

ALTER TABLE ESC_TEMPL_CPROP_T VOLATILE;

CREATE INDEX ETCP_TKTID ON ESC_TEMPL_CPROP_T
(   
  TKTID
);

CREATE INDEX ETCP_CCID ON ESC_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE ESC_TEMPL_LDESC_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  PRIMARY KEY ( ESTID, LOCALE )
);

ALTER TABLE ESC_TEMPL_LDESC_T VOLATILE;

CREATE INDEX ETLD_TKTID ON ESC_TEMPL_LDESC_T
(   
  TKTID
);

CREATE INDEX ETLD_CCID ON ESC_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TTASK_MESSAGE_DEFINITION_T
(
  TMTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                                ,
  PRIMARY KEY ( TMTID )
);

CREATE INDEX TTMD_TKTID ON TTASK_MESSAGE_DEFINITION_T
(   
  TKTID
);

CREATE INDEX TTMD_CCID ON TTASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_TEMPLATE_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  DEFINITION_NAME                    VARCHAR(220)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR(254)                      NOT NULL ,
  VALID_FROM                         TIMESTAMP                         NOT NULL ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  APPLICATION_DEFAULTS_ID            CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  SVTID                              CHAR(16)            FOR BIT DATA           ,
  KIND                               INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  AUTO_DELETE_MODE                   INTEGER                           NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  IS_INLINE                          SMALLINT                          NOT NULL ,
  IS_SHARED                          SMALLINT                          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  CONTEXT_AUTHORIZATION              INTEGER                           NOT NULL ,
  AUTONOMY                           INTEGER                           NOT NULL ,
  ADMIN_QTID                         CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  INSTANCE_CREATOR_QTID              CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_STARTER_QTID             CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  DEFAULT_LOCALE                     VARCHAR(32)                                ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  DURATION_UNTIL_DUE                 VARCHAR(254)                               ,
  DURATION_UNTIL_EXPIRES             VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                      NOT NULL ,
  TYPE                               VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  PRIORITY                           INTEGER                                    ,
  PRIORITY_DEFINITION                VARCHAR(254)                               ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  CONTACTS_QTIDS                     BLOB(3900k)                                ,
  UI_SETTINGS                        BLOB(3900k)                                ,
  PRIMARY KEY ( TKTID )
);

ALTER TABLE TASK_TEMPLATE_T VOLATILE;

CREATE UNIQUE INDEX TT_NAME_VF_NS ON TASK_TEMPLATE_T
(   
  NAME, VALID_FROM, NAMESPACE
);

CREATE INDEX TT_CCID_STATE ON TASK_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID, STATE
);

CREATE INDEX TT_KND_INLN_VAL ON TASK_TEMPLATE_T
(   
  KIND, IS_INLINE, VALID_FROM
);

CREATE TABLE TASK_TEMPL_CPROP_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA_TYPE                          VARCHAR(254)                               ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  PRIMARY KEY ( TKTID, NAME )
);

ALTER TABLE TASK_TEMPL_CPROP_T VOLATILE;

CREATE INDEX TTCP_TKTID ON TASK_TEMPL_CPROP_T
(   
  TKTID
);

CREATE INDEX TTCP_CCID ON TASK_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_TEMPL_LDESC_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  PRIMARY KEY ( TKTID, LOCALE )
);

ALTER TABLE TASK_TEMPL_LDESC_T VOLATILE;

CREATE INDEX TTLD_TKTID ON TASK_TEMPL_LDESC_T
(   
  TKTID
);

CREATE INDEX TTLD_CCID ON TASK_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX TTLD_TT_LOC ON TASK_TEMPL_LDESC_T
(   
  TKTID, LOCALE DESC
);

CREATE TABLE TSERVICE_DESCRIPTION_T
(
  SVTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_ONE_WAY                         SMALLINT                          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR(254)                               ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  PORT                               VARCHAR(254)                               ,
  PORT_TYPE_NS                       VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR(254)                               ,
  SERVICE                            VARCHAR(254)                               ,
  PRIMARY KEY ( SVTID )
);

CREATE INDEX TSD_TKTID ON TSERVICE_DESCRIPTION_T
(   
  TKTID
);

CREATE INDEX TSD_CCID ON TSERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_CELL_MAP_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CELL                               VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( TKTID, CELL )
);

CREATE TABLE TMAIL_T
(
  MNTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_STATE                         INTEGER                           NOT NULL ,
  TO_STATE                           INTEGER                           NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  SUBJECT                            VARCHAR(254)                      NOT NULL ,
  BODY_TEXT                          CLOB(4096)                                 ,
  PRIMARY KEY ( MNTID, FROM_STATE, TO_STATE, LOCALE )
);

CREATE INDEX EMT_HC ON TMAIL_T
(   
  HASH_CODE
);

CREATE TABLE ESCALATION_INSTANCE_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  ESTID                              CHAR(16)            FOR BIT DATA           ,
  FIRST_ESIID                        CHAR(16)            FOR BIT DATA           ,
  PREVIOUS_ESIID                     CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  MNTID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                               ,
  STATE                              INTEGER                           NOT NULL ,
  ACTIVATION_STATE                   INTEGER                           NOT NULL ,
  AT_LEAST_EXPECTED_STATE            INTEGER                           NOT NULL ,
  ACTIVATION_TIME                    TIMESTAMP                                  ,
  ESCALATION_TIME                    TIMESTAMP                                  ,
  DURATION_UNTIL_ESCALATION          VARCHAR(254)                               ,
  DURATION_UNTIL_REPEATS             VARCHAR(254)                               ,
  INCREASE_PRIORITY                  INTEGER                           NOT NULL ,
  ACTION                             INTEGER                           NOT NULL ,
  ESCALATION_RECEIVER_QTID           CHAR(16)            FOR BIT DATA           ,
  RECEIVER_EMAIL_QTID                CHAR(16)            FOR BIT DATA           ,
  SCHEDULER_ID                       VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID )
);

ALTER TABLE ESCALATION_INSTANCE_T VOLATILE;

CREATE INDEX ESI_FIRST ON ESCALATION_INSTANCE_T
(   
  FIRST_ESIID
);

CREATE INDEX ESI_TKIID_ASTATE ON ESCALATION_INSTANCE_T
(   
  TKIID, ACTIVATION_STATE, STATE
);

CREATE INDEX ESI_TKIID_STATE ON ESCALATION_INSTANCE_T
(   
  TKIID, STATE
);

CREATE INDEX ESI_PREV ON ESCALATION_INSTANCE_T
(   
  PREVIOUS_ESIID
);

CREATE INDEX ESI_ESTID ON ESCALATION_INSTANCE_T
(   
  ESTID
);

CREATE INDEX ESI_CCID ON ESCALATION_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX ESI_EST_ESI ON ESCALATION_INSTANCE_T
(   
  ESTID, ESIID
);

CREATE TABLE ESC_INST_CPROP_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, NAME )
);

ALTER TABLE ESC_INST_CPROP_T VOLATILE;

CREATE INDEX EICP_CCID ON ESC_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE ESC_INST_LDESC_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, LOCALE )
);

ALTER TABLE ESC_INST_LDESC_T VOLATILE;

CREATE INDEX EILD_CCID ON ESC_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE EIDOCUMENTATION_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, LOCALE )
);

ALTER TABLE EIDOCUMENTATION_T VOLATILE;

CREATE INDEX EIDOC_CCID ON EIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE ISERVICE_DESCRIPTION_T
(
  SVTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_ONE_WAY                         SMALLINT                          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR(254)                               ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  PORT                               VARCHAR(254)                               ,
  PORT_TYPE_NS                       VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR(254)                               ,
  SERVICE                            VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SVTID )
);

ALTER TABLE ISERVICE_DESCRIPTION_T VOLATILE;

CREATE INDEX ISD_TKIID ON ISERVICE_DESCRIPTION_T
(   
  TKIID
);

CREATE INDEX ISD_CCID ON ISERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_INSTANCE_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  TOP_TKIID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  FOLLOW_ON_TKIID                    CHAR(16)            FOR BIT DATA           ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  APPLICATION_DEFAULTS_ID            CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  PARENT_CONTEXT_ID                  CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  AUTO_DELETE_MODE                   INTEGER                           NOT NULL ,
  HIERARCHY_POSITION                 INTEGER                           NOT NULL ,
  TYPE                               VARCHAR(254)                               ,
  SVTID                              CHAR(16)            FOR BIT DATA           ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  IS_ESCALATED                       SMALLINT                          NOT NULL ,
  IS_INLINE                          SMALLINT                          NOT NULL ,
  IS_SUSPENDED                       SMALLINT                          NOT NULL ,
  IS_WAITING_FOR_SUBTASK             SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  IS_CHILD                           SMALLINT                          NOT NULL ,
  HAS_ESCALATIONS                    SMALLINT                                   ,
  START_TIME                         TIMESTAMP                                  ,
  ACTIVATION_TIME                    TIMESTAMP                                  ,
  LAST_MODIFICATION_TIME             TIMESTAMP                                  ,
  LAST_STATE_CHANGE_TIME             TIMESTAMP                                  ,
  COMPLETION_TIME                    TIMESTAMP                                  ,
  DUE_TIME                           TIMESTAMP                                  ,
  EXPIRATION_TIME                    TIMESTAMP                                  ,
  FIRST_ACTIVATION_TIME              TIMESTAMP                                  ,
  DEFAULT_LOCALE                     VARCHAR(32)                                ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  DURATION_UNTIL_DUE                 VARCHAR(254)                               ,
  DURATION_UNTIL_EXPIRES             VARCHAR(254)                               ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                               ,
  CONTEXT_AUTHORIZATION              INTEGER                           NOT NULL ,
  ORIGINATOR                         VARCHAR(128)                               ,
  STARTER                            VARCHAR(128)                               ,
  OWNER                              VARCHAR(128)                               ,
  ADMIN_QTID                         CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_STARTER_QTID             CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  PRIORITY                           INTEGER                                    ,
  SCHEDULER_ID                       VARCHAR(254)                               ,
  SERVICE_TICKET                     VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  RESUMES                            TIMESTAMP                                  ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  DELETION_TIME                      TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
);

ALTER TABLE TASK_INSTANCE_T VOLATILE;

CREATE INDEX TI_PARENT ON TASK_INSTANCE_T
(   
  PARENT_CONTEXT_ID
);

CREATE INDEX TI_ACOID ON TASK_INSTANCE_T
(   
  APPLICATION_DEFAULTS_ID
);

CREATE INDEX TI_NAME ON TASK_INSTANCE_T
(   
  NAME
);

CREATE INDEX TI_STATE ON TASK_INSTANCE_T
(   
  STATE
);

CREATE INDEX TI_SERVICET ON TASK_INSTANCE_T
(   
  SERVICE_TICKET
);

CREATE INDEX TI_CCID ON TASK_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX TI_TK_TOPTK ON TASK_INSTANCE_T
(   
  TKTID, TKIID, TOP_TKIID
);

CREATE INDEX TI_TOPTKIID ON TASK_INSTANCE_T
(   
  TOP_TKIID
);

CREATE INDEX TI_TI_KND_ST ON TASK_INSTANCE_T
(   
  TKIID, KIND, STATE
);

CREATE INDEX TI_ST_KND_TI_NAME ON TASK_INSTANCE_T
(   
  STATE, KIND, TKIID, NAME
);

CREATE INDEX TI_TT_KND ON TASK_INSTANCE_T
(   
  TKTID, KIND
);

CREATE TABLE TASK_CONTEXT_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  SERVICE_CONTEXT                    BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
);

CREATE INDEX TC_CCID ON TASK_CONTEXT_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE CONTACT_QUERIES_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTACTS_QTIDS                     BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
);

ALTER TABLE CONTACT_QUERIES_T VOLATILE;

CREATE INDEX CQ_CCID ON CONTACT_QUERIES_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE UISETTINGS_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  UI_SETTINGS                        BLOB(3900k)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
);

ALTER TABLE UISETTINGS_T VOLATILE;

CREATE INDEX UIS_CCID ON UISETTINGS_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE REPLY_HANDLER_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  REPLY_HANDLER                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
);

ALTER TABLE REPLY_HANDLER_T VOLATILE;

CREATE INDEX RH_CCID ON REPLY_HANDLER_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_TIMER_T
(
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( OID, KIND )
);

ALTER TABLE TASK_TIMER_T VOLATILE;

CREATE TABLE TASK_INST_CPROP_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA_TYPE                          VARCHAR(254)                               ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, NAME )
);

ALTER TABLE TASK_INST_CPROP_T VOLATILE;

CREATE INDEX TICP_CCID ON TASK_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_INST_LDESC_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, LOCALE )
);

ALTER TABLE TASK_INST_LDESC_T VOLATILE;

CREATE INDEX TILD_CCID ON TASK_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TIDOCUMENTATION_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, LOCALE )
);

ALTER TABLE TIDOCUMENTATION_T VOLATILE;

CREATE INDEX TIDOC_CCID ON TIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE ITASK_MESSAGE_DEFINITION_T
(
  TMTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  KIND                               INTEGER                           NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TMTID )
);

ALTER TABLE ITASK_MESSAGE_DEFINITION_T VOLATILE;

CREATE INDEX ITMD_IDKINSTYPE ON ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, MESSAGE_TYPE_NS, MESSAGE_TYPE_NAME, KIND
);

CREATE INDEX ITMD_TKIIDKINDFN ON ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, KIND, FAULT_NAME
);

CREATE INDEX ITMD_CCID ON ITASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_MESSAGE_INSTANCE_T
(
  TMIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TMTID                              CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  KIND                               INTEGER                           NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TMIID )
);

ALTER TABLE TASK_MESSAGE_INSTANCE_T VOLATILE;

CREATE INDEX TMI_TI_K ON TASK_MESSAGE_INSTANCE_T
(   
  TKIID, KIND
);

CREATE INDEX TMI_TMTID ON TASK_MESSAGE_INSTANCE_T
(   
  TMTID
);

CREATE INDEX TMI_CCID ON TASK_MESSAGE_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_AUDIT_LOG_T
(
  ALID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  AUDIT_EVENT                        INTEGER                           NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  ESIID                              CHAR(16)            FOR BIT DATA           ,
  ESTID                              CHAR(16)            FOR BIT DATA           ,
  TOP_TKIID                          CHAR(16)            FOR BIT DATA           ,
  FOLLOW_ON_TKIID                    CHAR(16)            FOR BIT DATA           ,
  PARENT_TKIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_CONTEXT_ID                  CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  WI_REASON                          INTEGER                                    ,
  NAME                               VARCHAR(254)                               ,
  NAMESPACE                          VARCHAR(254)                               ,
  VALID_FROM_UTC                     TIMESTAMP                                  ,
  EVENT_TIME_UTC                     TIMESTAMP                                  ,
  PARENT_TASK_NAME                   VARCHAR(254)                               ,
  PARENT_TASK_NAMESPACE              VARCHAR(254)                               ,
  TASK_KIND                          INTEGER                                    ,
  TASK_STATE                         INTEGER                                    ,
  FAULT_TYPE_NAME                    VARCHAR(220)                               ,
  FAULT_NAMESPACE                    VARCHAR(220)                               ,
  FAULT_NAME                         VARCHAR(220)                               ,
  NEW_USER                           VARCHAR(128)                               ,
  OLD_USER                           VARCHAR(128)                               ,
  PRINCIPAL                          VARCHAR(128)                               ,
  USERS                              CLOB(8192)                                 ,
  DESCRIPTION                        CLOB(8192)                                 ,
  MESSAGE_DATA                       BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ALID )
);

CREATE TABLE IMAIL_T
(
  OBJECT_ID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_STATE                         INTEGER                           NOT NULL ,
  TO_STATE                           INTEGER                           NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  SUBJECT                            VARCHAR(254)                      NOT NULL ,
  URI                                VARCHAR(254)                               ,
  BODY_TEXT                          CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( OBJECT_ID, FROM_STATE, TO_STATE, LOCALE )
);

ALTER TABLE IMAIL_T VOLATILE;

CREATE INDEX IMN_CTX ON IMAIL_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE TASK_HISTORY_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVENT                              INTEGER                           NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_TKIID                       CHAR(16)            FOR BIT DATA           ,
  ESIID                              CHAR(16)            FOR BIT DATA           ,
  REASON                             INTEGER                           NOT NULL ,
  EVENT_TIME                         TIMESTAMP                         NOT NULL ,
  NEXT_TIME                          TIMESTAMP                                  ,
  PRINCIPAL                          VARCHAR(128)                      NOT NULL ,
  WORK_ITEM_KIND                     INTEGER                           NOT NULL ,
  FROM_ID                            VARCHAR(128)                               ,
  TO_ID                              VARCHAR(128)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
);

ALTER TABLE TASK_HISTORY_T VOLATILE;

CREATE INDEX TH_TKIID ON TASK_HISTORY_T
(   
  TKIID
);

CREATE INDEX TH_CTXID ON TASK_HISTORY_T
(   
  CONTAINMENT_CONTEXT_ID
);
-- set schema version to: 620
INSERT INTO SCHEMA_VERSION (SCHEMA_VERSION, DATA_MIGRATION) VALUES( 620, 0 );


-- View: ProcessTemplate
CREATE VIEW PROCESS_TEMPLATE(PTID, NAME, DISPLAY_NAME, VALID_FROM, TARGET_NAMESPACE, APPLICATION_NAME, VERSION, CREATED, STATE, EXECUTION_MODE, DESCRIPTION, CAN_RUN_SYNC, CAN_RUN_INTERRUP, COMP_SPHERE, CONTINUE_ON_ERROR ) AS
 SELECT PROCESS_TEMPLATE_B_T.PTID, PROCESS_TEMPLATE_B_T.NAME, PROCESS_TEMPLATE_B_T.DISPLAY_NAME, PROCESS_TEMPLATE_B_T.VALID_FROM, PROCESS_TEMPLATE_B_T.TARGET_NAMESPACE, PROCESS_TEMPLATE_B_T.APPLICATION_NAME, PROCESS_TEMPLATE_B_T.VERSION, PROCESS_TEMPLATE_B_T.CREATED, PROCESS_TEMPLATE_B_T.STATE, PROCESS_TEMPLATE_B_T.EXECUTION_MODE, PROCESS_TEMPLATE_B_T.DESCRIPTION, PROCESS_TEMPLATE_B_T.CAN_CALL, PROCESS_TEMPLATE_B_T.CAN_INITIATE, PROCESS_TEMPLATE_B_T.COMPENSATION_SPHERE, PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM PROCESS_TEMPLATE_B_T;

-- View: ProcessTemplAttr
CREATE VIEW PROCESS_TEMPL_ATTR(PTID, NAME, VALUE ) AS
 SELECT PROCESS_TEMPLATE_ATTRIBUTE_B_T.PTID, PROCESS_TEMPLATE_ATTRIBUTE_B_T.ATTR_KEY, PROCESS_TEMPLATE_ATTRIBUTE_B_T.VALUE
 FROM PROCESS_TEMPLATE_ATTRIBUTE_B_T;

-- View: ProcessInstance
CREATE VIEW PROCESS_INSTANCE(PTID, PIID, NAME, STATE, CREATED, STARTED, COMPLETED, PARENT_NAME, TOP_LEVEL_NAME, PARENT_PIID, TOP_LEVEL_PIID, STARTER, DESCRIPTION, TEMPLATE_NAME, TEMPLATE_DESCR, RESUMES, CONTINUE_ON_ERROR ) AS
 SELECT PROCESS_INSTANCE_B_T.PTID, PROCESS_INSTANCE_B_T.PIID, PROCESS_INSTANCE_B_T.NAME, PROCESS_INSTANCE_B_T.STATE, PROCESS_INSTANCE_B_T.CREATED, PROCESS_INSTANCE_B_T.STARTED, PROCESS_INSTANCE_B_T.COMPLETED, PROCESS_INSTANCE_B_T.PARENT_NAME, PROCESS_INSTANCE_B_T.TOP_LEVEL_NAME, PROCESS_INSTANCE_B_T.PARENT_PIID, PROCESS_INSTANCE_B_T.TOP_LEVEL_PIID, PROCESS_INSTANCE_B_T.STARTER, PROCESS_INSTANCE_B_T.DESCRIPTION, PROCESS_TEMPLATE_B_T.NAME, PROCESS_TEMPLATE_B_T.DESCRIPTION, PROCESS_INSTANCE_B_T.RESUMES, PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM PROCESS_INSTANCE_B_T, PROCESS_TEMPLATE_B_T
 WHERE PROCESS_INSTANCE_B_T.PTID = PROCESS_TEMPLATE_B_T.PTID;

-- View: ProcessAttribute
CREATE VIEW PROCESS_ATTRIBUTE(PIID, NAME, VALUE, DATA_TYPE ) AS
 SELECT PROCESS_INSTANCE_ATTRIBUTE_T.PIID, PROCESS_INSTANCE_ATTRIBUTE_T.ATTR_KEY, PROCESS_INSTANCE_ATTRIBUTE_T.VALUE, PROCESS_INSTANCE_ATTRIBUTE_T.DATA_TYPE
 FROM PROCESS_INSTANCE_ATTRIBUTE_T;

-- View: Activity
CREATE VIEW ACTIVITY(PIID, AIID, PTID, ATID, SIID, STID, EHIID, ENCLOSING_FEIID, KIND, COMPLETED, ACTIVATED, FIRST_ACTIVATED, STARTED, STATE, STOP_REASON, OWNER, DESCRIPTION, EXPIRES, TEMPLATE_NAME, TEMPLATE_DESCR, BUSINESS_RELEVANCE, SKIP_REQUESTED, CONTINUE_ON_ERROR, INVOKED_INST_ID, INVOKED_INST_TYPE ) AS
 SELECT ACTIVITY_INSTANCE_B_T.PIID, ACTIVITY_INSTANCE_B_T.AIID, ACTIVITY_INSTANCE_B_T.PTID, ACTIVITY_INSTANCE_B_T.ATID, ACTIVITY_INSTANCE_B_T.SIID, ACTIVITY_TEMPLATE_B_T.PARENT_STID, ACTIVITY_INSTANCE_B_T.EHIID, ACTIVITY_INSTANCE_B_T.ENCLOSING_FEIID, ACTIVITY_TEMPLATE_B_T.KIND, ACTIVITY_INSTANCE_B_T.FINISHED, ACTIVITY_INSTANCE_B_T.ACTIVATED, ACTIVITY_INSTANCE_B_T.FIRST_ACTIVATED, ACTIVITY_INSTANCE_B_T.STARTED, ACTIVITY_INSTANCE_B_T.STATE, ACTIVITY_INSTANCE_B_T.STOP_REASON, ACTIVITY_INSTANCE_B_T.OWNER, ACTIVITY_INSTANCE_B_T.DESCRIPTION, ACTIVITY_INSTANCE_B_T.EXPIRES, ACTIVITY_TEMPLATE_B_T.NAME, ACTIVITY_TEMPLATE_B_T.DESCRIPTION, ACTIVITY_TEMPLATE_B_T.BUSINESS_RELEVANCE, ACTIVITY_INSTANCE_B_T.SKIP_REQUESTED, ACTIVITY_INSTANCE_B_T.CONTINUE_ON_ERROR, ACTIVITY_INSTANCE_B_T.INVOKED_INSTANCE_ID, ACTIVITY_INSTANCE_B_T.INVOKED_INSTANCE_TYPE
 FROM ACTIVITY_INSTANCE_B_T, ACTIVITY_TEMPLATE_B_T
 WHERE ACTIVITY_INSTANCE_B_T.ATID = ACTIVITY_TEMPLATE_B_T.ATID;

-- View: ActivityAttribute
CREATE VIEW ACTIVITY_ATTRIBUTE(AIID, NAME, VALUE, DATA_TYPE ) AS
 SELECT ACTIVITY_INSTANCE_ATTR_B_T.AIID, ACTIVITY_INSTANCE_ATTR_B_T.ATTR_KEY, ACTIVITY_INSTANCE_ATTR_B_T.ATTR_VALUE, ACTIVITY_INSTANCE_ATTR_B_T.DATA_TYPE
 FROM ACTIVITY_INSTANCE_ATTR_B_T;

-- View: Event
CREATE VIEW EVENT(EIID, AIID, PIID, EHTID, SIID, NAME ) AS
 SELECT EVENT_INSTANCE_B_T.EIID, EVENT_INSTANCE_B_T.AIID, EVENT_INSTANCE_B_T.PIID, EVENT_INSTANCE_B_T.EHTID, EVENT_INSTANCE_B_T.SIID, SERVICE_TEMPLATE_B_T.NAME
 FROM EVENT_INSTANCE_B_T, SERVICE_TEMPLATE_B_T
 WHERE EVENT_INSTANCE_B_T.STATE = 2 AND EVENT_INSTANCE_B_T.VTID = SERVICE_TEMPLATE_B_T.VTID;

-- View: WorkItem
CREATE VIEW WORK_ITEM(WIID, OWNER_ID, GROUP_NAME, EVERYBODY, OBJECT_TYPE, OBJECT_ID, ASSOC_OBJECT_TYPE, ASSOC_OID, REASON, CREATION_TIME, QIID, KIND ) AS
 SELECT WORK_ITEM_T.WIID, WORK_ITEM_T.OWNER_ID, WORK_ITEM_T.GROUP_NAME, WORK_ITEM_T.EVERYBODY, WORK_ITEM_T.OBJECT_TYPE, WORK_ITEM_T.OBJECT_ID, WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, WORK_ITEM_T.ASSOCIATED_OID, WORK_ITEM_T.REASON, WORK_ITEM_T.CREATION_TIME, WORK_ITEM_T.QIID, WORK_ITEM_T.KIND
 FROM WORK_ITEM_T
 WHERE WORK_ITEM_T.AUTH_INFO = 1
 UNION ALL SELECT WORK_ITEM_T.WIID, WORK_ITEM_T.OWNER_ID, WORK_ITEM_T.GROUP_NAME, WORK_ITEM_T.EVERYBODY, WORK_ITEM_T.OBJECT_TYPE, WORK_ITEM_T.OBJECT_ID, WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, WORK_ITEM_T.ASSOCIATED_OID, WORK_ITEM_T.REASON, WORK_ITEM_T.CREATION_TIME, WORK_ITEM_T.QIID, WORK_ITEM_T.KIND
 FROM WORK_ITEM_T
 WHERE WORK_ITEM_T.AUTH_INFO = 2
 UNION ALL SELECT WORK_ITEM_T.WIID, WORK_ITEM_T.OWNER_ID, WORK_ITEM_T.GROUP_NAME, WORK_ITEM_T.EVERYBODY, WORK_ITEM_T.OBJECT_TYPE, WORK_ITEM_T.OBJECT_ID, WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, WORK_ITEM_T.ASSOCIATED_OID, WORK_ITEM_T.REASON, WORK_ITEM_T.CREATION_TIME, WORK_ITEM_T.QIID, WORK_ITEM_T.KIND
 FROM WORK_ITEM_T
 WHERE WORK_ITEM_T.AUTH_INFO = 3
 UNION ALL SELECT WORK_ITEM_T.WIID, RETRIEVED_USER_T.OWNER_ID, WORK_ITEM_T.GROUP_NAME, WORK_ITEM_T.EVERYBODY, WORK_ITEM_T.OBJECT_TYPE, WORK_ITEM_T.OBJECT_ID, WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, WORK_ITEM_T.ASSOCIATED_OID, WORK_ITEM_T.REASON, WORK_ITEM_T.CREATION_TIME, WORK_ITEM_T.QIID, WORK_ITEM_T.KIND
 FROM WORK_ITEM_T, RETRIEVED_USER_T
 WHERE WORK_ITEM_T.AUTH_INFO = 0 AND WORK_ITEM_T.QIID = RETRIEVED_USER_T.QIID;

-- View: ActivityService
CREATE VIEW ACTIVITY_SERVICE(EIID, AIID, PIID, VTID, PORT_TYPE, NAME_SPACE_URI, OPERATION ) AS
 SELECT EVENT_INSTANCE_B_T.EIID, EVENT_INSTANCE_B_T.AIID, EVENT_INSTANCE_B_T.PIID, EVENT_INSTANCE_B_T.VTID, SERVICE_TEMPLATE_B_T.PORT_TYPE_NAME,URI_TEMPLATE_B_T.URI, SERVICE_TEMPLATE_B_T.OPERATION_NAME
 FROM EVENT_INSTANCE_B_T, SERVICE_TEMPLATE_B_T, URI_TEMPLATE_B_T
 WHERE EVENT_INSTANCE_B_T.STATE = 2 AND EVENT_INSTANCE_B_T.VTID = SERVICE_TEMPLATE_B_T.VTID AND SERVICE_TEMPLATE_B_T.PORT_TYPE_UTID = URI_TEMPLATE_B_T.UTID;

-- View: QueryProperty
CREATE VIEW QUERY_PROPERTY(PIID, VARIABLE_NAME, NAME, NAMESPACE, GENERIC_VALUE, STRING_VALUE, NUMBER_VALUE, DECIMAL_VALUE, TIMESTAMP_VALUE ) AS
 SELECT QUERYABLE_VARIABLE_INSTANCE_T.PIID, QUERYABLE_VARIABLE_INSTANCE_T.VARIABLE_NAME, QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAME, QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAMESPACE, QUERYABLE_VARIABLE_INSTANCE_T.GENERIC_VALUE, QUERYABLE_VARIABLE_INSTANCE_T.STRING_VALUE, QUERYABLE_VARIABLE_INSTANCE_T.NUMBER_VALUE, QUERYABLE_VARIABLE_INSTANCE_T.DECIMAL_VALUE, QUERYABLE_VARIABLE_INSTANCE_T.TIMESTAMP_VALUE
 FROM QUERYABLE_VARIABLE_INSTANCE_T;

-- View: QueryPropTempl
CREATE VIEW QUERY_PROP_TEMPL(PTID, NAME, PROPERTY_NAME, URI, QUERY_TYPE, JAVA_TYPE ) AS
 SELECT QUERYABLE_VARIABLE_TEMPLATE_T.PTID, VARIABLE_TEMPLATE_B_T.NAME, PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_NAME, URI_TEMPLATE_B_T.URI, QUERYABLE_VARIABLE_TEMPLATE_T.QUERY_TYPE, PROPERTY_ALIAS_TEMPLATE_B_T.JAVA_TYPE
 FROM QUERYABLE_VARIABLE_TEMPLATE_T, VARIABLE_TEMPLATE_B_T, PROPERTY_ALIAS_TEMPLATE_B_T, URI_TEMPLATE_B_T
 WHERE QUERYABLE_VARIABLE_TEMPLATE_T.CTID = VARIABLE_TEMPLATE_B_T.CTID AND QUERYABLE_VARIABLE_TEMPLATE_T.PAID = PROPERTY_ALIAS_TEMPLATE_B_T.PAID AND PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_UTID = URI_TEMPLATE_B_T.UTID;

-- View: AuditLog
CREATE VIEW AUDIT_LOG(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, SCOPE_NAME, PROCESS_TEMPL_NAME, PROCESS_INST_NAME, TOP_LEVEL_PI_NAME, TOP_LEVEL_PIID, PARENT_PI_NAME, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, IMPL_NAME, PRINCIPAL, TERMINAL_NAME, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ATID, ADDITIONAL_INFO, OBJECT_META_TYPE ) AS
 SELECT AUDIT_LOG_T.ALID,AUDIT_LOG_T.EVENT_TIME,AUDIT_LOG_T.EVENT_TIME_UTC,AUDIT_LOG_T.AUDIT_EVENT,AUDIT_LOG_T.PTID,AUDIT_LOG_T.PIID,AUDIT_LOG_T.AIID,AUDIT_LOG_T.SIID,AUDIT_LOG_T.VARIABLE_NAME,AUDIT_LOG_T.PROCESS_TEMPL_NAME, AUDIT_LOG_T.PROCESS_INST_NAME,AUDIT_LOG_T.TOP_LEVEL_PI_NAME,AUDIT_LOG_T.TOP_LEVEL_PIID,AUDIT_LOG_T.PARENT_PI_NAME,AUDIT_LOG_T.PARENT_PIID,AUDIT_LOG_T.VALID_FROM,AUDIT_LOG_T.VALID_FROM_UTC, AUDIT_LOG_T.ACTIVITY_NAME,AUDIT_LOG_T.ACTIVITY_KIND,AUDIT_LOG_T.ACTIVITY_STATE,AUDIT_LOG_T.CONTROL_LINK_NAME,AUDIT_LOG_T.IMPL_NAME,AUDIT_LOG_T.PRINCIPAL, AUDIT_LOG_T.TERMINAL_NAME,AUDIT_LOG_T.VARIABLE_DATA,AUDIT_LOG_T.EXCEPTION_TEXT,AUDIT_LOG_T.DESCRIPTION,AUDIT_LOG_T.CORR_SET_INFO,AUDIT_LOG_T.USER_NAME, AUDIT_LOG_T.ATID, AUDIT_LOG_T.ADDITIONAL_INFO, AUDIT_LOG_T.OBJECT_META_TYPE
 FROM AUDIT_LOG_T;

-- View: AuditLogB
CREATE VIEW AUDIT_LOG_B(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, VARIABLE_NAME, PROCESS_TEMPL_NAME, TOP_LEVEL_PIID, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ATID, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, PRINCIPAL, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ADDITIONAL_INFO ) AS
 SELECT AUDIT_LOG_T.ALID,AUDIT_LOG_T.EVENT_TIME,AUDIT_LOG_T.EVENT_TIME_UTC,AUDIT_LOG_T.AUDIT_EVENT,AUDIT_LOG_T.PTID,AUDIT_LOG_T.PIID,AUDIT_LOG_T.AIID,AUDIT_LOG_T.SIID,AUDIT_LOG_T.VARIABLE_NAME,AUDIT_LOG_T.PROCESS_TEMPL_NAME, AUDIT_LOG_T.TOP_LEVEL_PIID,AUDIT_LOG_T.PARENT_PIID,AUDIT_LOG_T.VALID_FROM,AUDIT_LOG_T.VALID_FROM_UTC,AUDIT_LOG_T.ATID, AUDIT_LOG_T.ACTIVITY_NAME,AUDIT_LOG_T.ACTIVITY_KIND,AUDIT_LOG_T.ACTIVITY_STATE,AUDIT_LOG_T.CONTROL_LINK_NAME,AUDIT_LOG_T.PRINCIPAL, AUDIT_LOG_T.VARIABLE_DATA,AUDIT_LOG_T.EXCEPTION_TEXT,AUDIT_LOG_T.DESCRIPTION,AUDIT_LOG_T.CORR_SET_INFO,AUDIT_LOG_T.USER_NAME, AUDIT_LOG_T.ADDITIONAL_INFO
 FROM AUDIT_LOG_T
 WHERE AUDIT_LOG_T.OBJECT_META_TYPE = 1;

-- View: ApplicationComp
CREATE VIEW APPLICATION_COMP(ACOID, BUSINESS_RELEVANCE, NAME, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON ) AS
 SELECT APPLICATION_COMPONENT_T.ACOID, APPLICATION_COMPONENT_T.BUSINESS_RELEVANCE, APPLICATION_COMPONENT_T.NAME, APPLICATION_COMPONENT_T.SUPPORTS_AUTO_CLAIM, APPLICATION_COMPONENT_T.SUPPORTS_CLAIM_SUSPENDED, APPLICATION_COMPONENT_T.SUPPORTS_DELEGATION, APPLICATION_COMPONENT_T.SUPPORTS_SUB_TASK, APPLICATION_COMPONENT_T.SUPPORTS_FOLLOW_ON_TASK
 FROM APPLICATION_COMPONENT_T;

-- View: Task
CREATE VIEW TASK(TKIID, ACTIVATED, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, COMPLETED, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DUE, EXPIRES, FIRST_ACTIVATED, FOLLOW_ON_TKIID, IS_AD_HOC, IS_ESCALATED, IS_INLINE, IS_WAIT_FOR_SUB_TK, KIND, LAST_MODIFIED, LAST_STATE_CHANGE, NAME, NAME_SPACE, ORIGINATOR, OWNER, PARENT_CONTEXT_ID, PRIORITY, STARTED, STARTER, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, HIERARCHY_POSITION, IS_CHILD, SUSPENDED, TKTID, TOP_TKIID, TYPE, RESUMES ) AS
 SELECT TASK_INSTANCE_T.TKIID, TASK_INSTANCE_T.ACTIVATION_TIME, TASK_INSTANCE_T.APPLICATION_DEFAULTS_ID, TASK_INSTANCE_T.APPLICATION_NAME, TASK_INSTANCE_T.BUSINESS_RELEVANCE, TASK_INSTANCE_T.COMPLETION_TIME, TASK_INSTANCE_T.CONTAINMENT_CONTEXT_ID, TASK_INSTANCE_T.CONTEXT_AUTHORIZATION, TASK_INSTANCE_T.DUE_TIME, TASK_INSTANCE_T.EXPIRATION_TIME, TASK_INSTANCE_T.FIRST_ACTIVATION_TIME, TASK_INSTANCE_T.FOLLOW_ON_TKIID, TASK_INSTANCE_T.IS_AD_HOC, TASK_INSTANCE_T.IS_ESCALATED, TASK_INSTANCE_T.IS_INLINE, TASK_INSTANCE_T.IS_WAITING_FOR_SUBTASK, TASK_INSTANCE_T.KIND, TASK_INSTANCE_T.LAST_MODIFICATION_TIME, TASK_INSTANCE_T.LAST_STATE_CHANGE_TIME, TASK_INSTANCE_T.NAME, TASK_INSTANCE_T.NAMESPACE, TASK_INSTANCE_T.ORIGINATOR, TASK_INSTANCE_T.OWNER, TASK_INSTANCE_T.PARENT_CONTEXT_ID, TASK_INSTANCE_T.PRIORITY, TASK_INSTANCE_T.START_TIME, TASK_INSTANCE_T.STARTER, TASK_INSTANCE_T.STATE, TASK_INSTANCE_T.SUPPORTS_AUTO_CLAIM, TASK_INSTANCE_T.SUPPORTS_CLAIM_SUSPENDED, TASK_INSTANCE_T.SUPPORTS_DELEGATION, TASK_INSTANCE_T.SUPPORTS_SUB_TASK, TASK_INSTANCE_T.SUPPORTS_FOLLOW_ON_TASK, TASK_INSTANCE_T.HIERARCHY_POSITION, TASK_INSTANCE_T.IS_CHILD, TASK_INSTANCE_T.IS_SUSPENDED, TASK_INSTANCE_T.TKTID, TASK_INSTANCE_T.TOP_TKIID, TASK_INSTANCE_T.TYPE, TASK_INSTANCE_T.RESUMES
 FROM TASK_INSTANCE_T;

-- View: TaskTempl
CREATE VIEW TASK_TEMPL(TKTID, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DEFINITION_NAME, DEFINITION_NS, IS_AD_HOC, IS_INLINE, KIND, NAME, NAMESPACE, PRIORITY, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, TYPE, VALID_FROM, AUTONOMY ) AS
 SELECT TASK_TEMPLATE_T.TKTID, TASK_TEMPLATE_T.APPLICATION_DEFAULTS_ID, TASK_TEMPLATE_T.APPLICATION_NAME, TASK_TEMPLATE_T.BUSINESS_RELEVANCE, TASK_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, TASK_TEMPLATE_T.CONTEXT_AUTHORIZATION, TASK_TEMPLATE_T.DEFINITION_NAME, TASK_TEMPLATE_T.TARGET_NAMESPACE, TASK_TEMPLATE_T.IS_AD_HOC, TASK_TEMPLATE_T.IS_INLINE, TASK_TEMPLATE_T.KIND, TASK_TEMPLATE_T.NAME, TASK_TEMPLATE_T.NAMESPACE, TASK_TEMPLATE_T.PRIORITY, TASK_TEMPLATE_T.STATE, TASK_TEMPLATE_T.SUPPORTS_AUTO_CLAIM, TASK_TEMPLATE_T.SUPPORTS_CLAIM_SUSPENDED, TASK_TEMPLATE_T.SUPPORTS_DELEGATION, TASK_TEMPLATE_T.SUPPORTS_SUB_TASK, TASK_TEMPLATE_T.SUPPORTS_FOLLOW_ON_TASK, TASK_TEMPLATE_T.TYPE, TASK_TEMPLATE_T.VALID_FROM, TASK_TEMPLATE_T.AUTONOMY
 FROM TASK_TEMPLATE_T;

-- View: Escalation
CREATE VIEW ESCALATION(ESIID, ACTION, ACTIVATION_STATE, ACTIVATION_TIME, ESCALATION_TIME, AT_LEAST_EXP_STATE, ESTID, FIRST_ESIID, INCREASE_PRIORITY, NAME, STATE, TKIID ) AS
 SELECT ESCALATION_INSTANCE_T.ESIID, ESCALATION_INSTANCE_T.ACTION, ESCALATION_INSTANCE_T.ACTIVATION_STATE, ESCALATION_INSTANCE_T.ACTIVATION_TIME, ESCALATION_INSTANCE_T.ESCALATION_TIME, ESCALATION_INSTANCE_T.AT_LEAST_EXPECTED_STATE, ESCALATION_INSTANCE_T.ESTID, ESCALATION_INSTANCE_T.FIRST_ESIID, ESCALATION_INSTANCE_T.INCREASE_PRIORITY, ESCALATION_INSTANCE_T.NAME, ESCALATION_INSTANCE_T.STATE, ESCALATION_INSTANCE_T.TKIID
 FROM ESCALATION_INSTANCE_T;

-- View: EscTempl
CREATE VIEW ESC_TEMPL(ESTID, FIRST_ESTID, PREVIOUS_ESTID, TKTID, CONTAINMENT_CTX_ID, NAME, ACTIVATION_STATE, AT_LEAST_EXP_STATE, INCREASE_PRIORITY, ACTION ) AS
 SELECT ESCALATION_TEMPLATE_T.ESTID, ESCALATION_TEMPLATE_T.FIRST_ESTID, ESCALATION_TEMPLATE_T.PREVIOUS_ESTID, ESCALATION_TEMPLATE_T.TKTID, ESCALATION_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, ESCALATION_TEMPLATE_T.NAME, ESCALATION_TEMPLATE_T.ACTIVATION_STATE, ESCALATION_TEMPLATE_T.AT_LEAST_EXPECTED_STATE, ESCALATION_TEMPLATE_T.INCREASE_PRIORITY, ESCALATION_TEMPLATE_T.ACTION
 FROM ESCALATION_TEMPLATE_T;

-- View: EscTemplDesc
CREATE VIEW ESC_TEMPL_DESC(ESTID, LOCALE, TKTID, DISPLAY_NAME, DESCRIPTION ) AS
 SELECT ESC_TEMPL_LDESC_T.ESTID, ESC_TEMPL_LDESC_T.LOCALE, ESC_TEMPL_LDESC_T.TKTID, ESC_TEMPL_LDESC_T.DISPLAY_NAME, ESC_TEMPL_LDESC_T.DESCRIPTION
 FROM ESC_TEMPL_LDESC_T;

-- View: TaskTemplCProp
CREATE VIEW TASK_TEMPL_CPROP(TKTID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT TASK_TEMPL_CPROP_T.TKTID, TASK_TEMPL_CPROP_T.NAME, TASK_TEMPL_CPROP_T.DATA_TYPE, TASK_TEMPL_CPROP_T.STRING_VALUE
 FROM TASK_TEMPL_CPROP_T;

-- View: EscTemplCProp
CREATE VIEW ESC_TEMPL_CPROP(ESTID, NAME, TKTID, DATA_TYPE, VALUE ) AS
 SELECT ESC_TEMPL_CPROP_T.ESTID, ESC_TEMPL_CPROP_T.NAME, ESC_TEMPL_CPROP_T.TKTID, ESC_TEMPL_CPROP_T.DATA_TYPE, ESC_TEMPL_CPROP_T.STRING_VALUE
 FROM ESC_TEMPL_CPROP_T;

-- View: TaskTemplDesc
CREATE VIEW TASK_TEMPL_DESC(TKTID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT TASK_TEMPL_LDESC_T.TKTID, TASK_TEMPL_LDESC_T.LOCALE, TASK_TEMPL_LDESC_T.DESCRIPTION, TASK_TEMPL_LDESC_T.DISPLAY_NAME
 FROM TASK_TEMPL_LDESC_T;

-- View: TaskCProp
CREATE VIEW TASK_CPROP(TKIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT TASK_INST_CPROP_T.TKIID, TASK_INST_CPROP_T.NAME, TASK_INST_CPROP_T.DATA_TYPE, TASK_INST_CPROP_T.STRING_VALUE
 FROM TASK_INST_CPROP_T;

-- View: TaskDesc
CREATE VIEW TASK_DESC(TKIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT TASK_INST_LDESC_T.TKIID, TASK_INST_LDESC_T.LOCALE, TASK_INST_LDESC_T.DESCRIPTION, TASK_INST_LDESC_T.DISPLAY_NAME
 FROM TASK_INST_LDESC_T;

-- View: EscalationCProp
CREATE VIEW ESCALATION_CPROP(ESIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT ESC_INST_CPROP_T.ESIID, ESC_INST_CPROP_T.NAME, ESC_INST_CPROP_T.DATA_TYPE, ESC_INST_CPROP_T.STRING_VALUE
 FROM ESC_INST_CPROP_T;

-- View: TaskHistory
CREATE VIEW TASK_HISTORY(TKIID, ESIID, PARENT_TKIID, EVENT, REASON, EVENT_TIME, NEXT_TIME, PRINCIPAL, WORK_ITEM_KIND, FROM_ID, TO_ID ) AS
 SELECT TASK_HISTORY_T.TKIID, TASK_HISTORY_T.ESIID, TASK_HISTORY_T.PARENT_TKIID, TASK_HISTORY_T.EVENT, TASK_HISTORY_T.REASON, TASK_HISTORY_T.EVENT_TIME, TASK_HISTORY_T.NEXT_TIME, TASK_HISTORY_T.PRINCIPAL, TASK_HISTORY_T.WORK_ITEM_KIND, TASK_HISTORY_T.FROM_ID, TASK_HISTORY_T.TO_ID
 FROM TASK_HISTORY_T;

-- View: EscalationDesc
CREATE VIEW ESCALATION_DESC(ESIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT ESC_INST_LDESC_T.ESIID, ESC_INST_LDESC_T.LOCALE, ESC_INST_LDESC_T.DESCRIPTION, ESC_INST_LDESC_T.DISPLAY_NAME
 FROM ESC_INST_LDESC_T;

-- View: TaskAuditLog
CREATE VIEW TASK_AUDIT_LOG(ALID, AUDIT_EVENT, CONTAINMENT_CTX_ID, ESIID, ESTID, EVENT_TIME, FAULT_NAME, FAULT_TYPE_NAME, FAULT_NAME_SPACE, FOLLOW_ON_TKIID, NAME, NAMESPACE, NEW_USER, OLD_USER, PARENT_CONTEXT_ID, PARENT_TASK_NAME, PARENT_TASK_NAMESP, PARENT_TKIID, PRINCIPAL, TASK_KIND, TASK_STATE, TKIID, TKTID, TOP_TKIID, VAILD_FROM, WORK_ITEM_REASON, USERS, DESCRIPTION, MESSAGE_DATA ) AS
 SELECT TASK_AUDIT_LOG_T.ALID, TASK_AUDIT_LOG_T.AUDIT_EVENT, TASK_AUDIT_LOG_T.CONTAINMENT_CONTEXT_ID, TASK_AUDIT_LOG_T.ESIID, TASK_AUDIT_LOG_T.ESTID, TASK_AUDIT_LOG_T.EVENT_TIME_UTC, TASK_AUDIT_LOG_T.FAULT_NAME, TASK_AUDIT_LOG_T.FAULT_TYPE_NAME, TASK_AUDIT_LOG_T.FAULT_NAMESPACE, TASK_AUDIT_LOG_T.FOLLOW_ON_TKIID, TASK_AUDIT_LOG_T.NAME, TASK_AUDIT_LOG_T.NAMESPACE, TASK_AUDIT_LOG_T.NEW_USER, TASK_AUDIT_LOG_T.OLD_USER, TASK_AUDIT_LOG_T.PARENT_CONTEXT_ID, TASK_AUDIT_LOG_T.PARENT_TASK_NAME, TASK_AUDIT_LOG_T.PARENT_TASK_NAMESPACE, TASK_AUDIT_LOG_T.PARENT_TKIID, TASK_AUDIT_LOG_T.PRINCIPAL, TASK_AUDIT_LOG_T.TASK_KIND, TASK_AUDIT_LOG_T.TASK_STATE, TASK_AUDIT_LOG_T.TKIID, TASK_AUDIT_LOG_T.TKTID, TASK_AUDIT_LOG_T.TOP_TKIID, TASK_AUDIT_LOG_T.VALID_FROM_UTC, TASK_AUDIT_LOG_T.WI_REASON, TASK_AUDIT_LOG_T.USERS, TASK_AUDIT_LOG_T.DESCRIPTION, TASK_AUDIT_LOG_T.MESSAGE_DATA
 FROM TASK_AUDIT_LOG_T;


-- start import scheduler DDL: createSchemaDB2.ddl


CREATE TABLE "SCHED_TASK" ("TASKID" BIGINT NOT NULL ,
              "VERSION" VARCHAR(5) NOT NULL ,
              "ROW_VERSION" INTEGER NOT NULL ,
              "TASKTYPE" INTEGER NOT NULL ,
              "TASKSUSPENDED" SMALLINT NOT NULL ,
              "CANCELLED" SMALLINT NOT NULL ,
              "NEXTFIRETIME" BIGINT NOT NULL ,
              "STARTBYINTERVAL" VARCHAR(254) ,
              "STARTBYTIME" BIGINT ,
              "VALIDFROMTIME" BIGINT ,
              "VALIDTOTIME" BIGINT ,
              "REPEATINTERVAL" VARCHAR(254) ,
              "MAXREPEATS" INTEGER NOT NULL ,
              "REPEATSLEFT" INTEGER NOT NULL ,
              "TASKINFO" BLOB(102400) LOGGED NOT COMPACT ,
              "NAME" VARCHAR(254) NOT NULL ,
              "AUTOPURGE" INTEGER NOT NULL ,
              "FAILUREACTION" INTEGER ,
              "MAXATTEMPTS" INTEGER ,
              "QOS" INTEGER ,
              "PARTITIONID" INTEGER ,
              "OWNERTOKEN" VARCHAR(200) NOT NULL ,
              "CREATETIME" BIGINT NOT NULL )  ;

ALTER TABLE "SCHED_TASK" ADD PRIMARY KEY ("TASKID");

CREATE INDEX "SCHED_TASK_IDX1" ON "SCHED_TASK" ("TASKID",
              "OWNERTOKEN") ;

CREATE INDEX "SCHED_TASK_IDX2" ON "SCHED_TASK" ("NEXTFIRETIME" ASC,
               "REPEATSLEFT",
               "PARTITIONID") CLUSTER;

CREATE TABLE "SCHED_TREG" ("REGKEY" VARCHAR(254) NOT NULL ,
              "REGVALUE" VARCHAR(254) ) ;

ALTER TABLE "SCHED_TREG" ADD PRIMARY KEY ("REGKEY");

CREATE TABLE "SCHED_LMGR" (LEASENAME VARCHAR(254) NOT NULL,
               LEASEOWNER VARCHAR(254) NOT NULL,
               LEASE_EXPIRE_TIME  BIGINT,
              DISABLED VARCHAR(5));

ALTER TABLE "SCHED_LMGR" ADD PRIMARY KEY ("LEASENAME");

CREATE TABLE "SCHED_LMPR" (LEASENAME VARCHAR(254) NOT NULL,
              NAME VARCHAR(254) NOT NULL,
              VALUE VARCHAR(254) NOT NULL);

CREATE INDEX "SCHED_LMPR_IDX1" ON "SCHED_LMPR" (LEASENAME,
               NAME);

-- end import scheduler DDL: createSchemaDB2.ddl


CONNECT RESET;

