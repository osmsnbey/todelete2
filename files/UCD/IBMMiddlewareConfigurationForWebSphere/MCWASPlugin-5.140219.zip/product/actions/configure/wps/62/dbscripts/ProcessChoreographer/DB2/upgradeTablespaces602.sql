
------------------------------------------------
-- Create 8 K page bufferpool and tablespaces --
------------------------------------------------


CREATE BUFFERPOOL BPEBP8K
  IMMEDIATE SIZE 1000 PAGESIZE 8 K;

CREATE SYSTEM TEMPORARY TABLESPACE BPETEMP8K
  PAGESIZE 8 K MANAGED BY SYSTEM
  USING( '@location@/BPETEMP8K' )
  BUFFERPOOL BPEBP8K;

CREATE TABLESPACE BPETS8K
  PAGESIZE 8 K MANAGED BY SYSTEM
  USING( '@location@/BPETS8K' )
  BUFFERPOOL BPEBP8K;

