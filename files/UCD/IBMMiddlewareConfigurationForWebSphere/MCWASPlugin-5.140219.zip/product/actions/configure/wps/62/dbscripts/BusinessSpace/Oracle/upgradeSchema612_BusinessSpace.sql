-- Licensed Materials - Property of IBM
-- 5724-M24
-- Copyright IBM Corporation 2008, 2009.  All Rights Reserved.
-- US Government Users Restricted Rights - Use, duplication or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- -----------------------------------------------------------------------------
--
-- Script file to perform schema changes for Business Space during
-- migration from 6.1.2 to 6.2
--
-- Customize the following variables before running this script: 
--   @SCHEMA@ = the schema owner, e.g. IBMBUSSP
--   @DBPASS@ = the schema owner password
--   @TSDIR@ = the directory or prefix for tablespace data files, e.g. DEFAULTTS
--
-- Run the script in SQL*Plus.
-- Example:
--    sqlplus system/passw0rd@orcl @upgradeSchema612_BusinessSpace.sql
-- -----------------------------------------------------------------------------

---------------------------------
-- Create, modify, drop tables --
---------------------------------

	DROP TABLE @SCHEMA@.DASHBOARD_DATA_T;

-- No change to the USER_DATA_T table
-- No change to the SPACES table
-- No change to the NLSINFO table

-- Uncomment this statement if Business Space 6.1.2 does not have iFix001 applied.
-- If iFix001 has been applied, this statement will fail, but you can safely
-- ignore the failure.
--	ALTER TABLE @SCHEMA@.PAGE
--		RENAME COLUMN RESTRICTEDD TO RESTRICTED ;

	CREATE INDEX @SCHEMA@.I0000010 ON @SCHEMA@.PAGE ( OWNER ASC )
		TABLESPACE BSPACE;
	CREATE INDEX @SCHEMA@.I0000011 ON @SCHEMA@.PAGE ( SPACEID ASC )
		TABLESPACE BSPACE;

-- No change to the WIDGET table
-- No change to the REGISTERED_WIDGET table
-- No change to the REGISTERED_WIDGET_NLS table
-- No change to the REGISTERED_CATEGORY table
-- No change to the REGISTERED_CATEGORY_NLS table

	ALTER TABLE @SCHEMA@.REGISTERED_ENDPOINT
		  ADD ( TYPE              VARCHAR2(256) );
	ALTER TABLE @SCHEMA@.REGISTERED_ENDPOINT
		  ADD ( NAME              VARCHAR2(256) );
	
	CREATE TABLE @SCHEMA@.REGISTERED_ENDPOINT_NLS (
		  EXTENSION               BLOB ,
		  ID_LOCALE               VARCHAR2(356) NOT NULL ,
		  ENDPOINT_ID_VERSION     VARCHAR2(322) NOT NULL ,
		  LOCALE                  VARCHAR2(32) ,
		  NAME                    VARCHAR2(256) ,
		  DESCRIPTION             VARCHAR2(1024) ,
		  PRIMARY KEY ( ID_LOCALE ) ,
		  FOREIGN KEY ( ENDPOINT_ID_VERSION )
			REFERENCES @SCHEMA@.REGISTERED_ENDPOINT ( ID_VERSION )
			ON DELETE CASCADE
		) TABLESPACE BSPACE
		LOGGING;
	
	CREATE TABLE @SCHEMA@.REGISTERED_WCCM_ENDPOINT (
		  EXTENSION               BLOB ,
		  ID_VERSION              VARCHAR2(322) NOT NULL ,
		  LAST_CHANGE             VARCHAR2(32) NOT NULL ,
		  PRIMARY KEY ( ID_VERSION )
		) TABLESPACE BSPACE
		LOGGING;
	
-- No change to the REGISTRY_FILE table
