"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: workClass.py
"""

class WorkClassReader(ConfigReader):
	
	WORK_CLASS_SUBTYPES = ["Default_HTTP_WC", "Default_IIOP_WC",
						"Default_JMS_WC", "Default_SOAP_WC",
						"Default_default_host_HTTP_WC", "Default_default_host_SOAP_WC"]
	
	def __init__(self, importedIds=[], excludedTypes=[], excludedAttributes=[]):
		self.LOGGER = _Logger("WorkClassReader", MessageManager.RB_WEBSPHERE_WVE)
		self.importedIds = importedIds
		self.objidConfigTypeMap = {}
		self.excludedTypes = excludedTypes
		self.processTypesFirst = []
		self.excludedAttributes = excludedAttributes
		# load the list of attributes which are treated as password fields
		self._updatePasswordAttributes()
	#endDef
	
#
# Default_HTTP_WC(cells/CELL_TEST/applications/WebSphereWSDM.ear/deployments/WebSphereWSDM/workclasses/Default_HTTP_WC|workclass.xml#WorkClass_1267986780915)
#
# Default_HTTP_WC(cells/CELL_TEST/applications/WebSphereWSDM.ear/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
#

	def getWASType(self, id):
		self.LOGGER.traceEnter(id)
		try:
			# AdminConfig.getObjectType is introduced in 7.0
			type = AdminConfig.getObjectType(id)
		except:
			try:
				type = self.objidConfigTypeMap[id]
			except:
				type = id.split("#")[1]
				if (type.startswith('Default')):
					pass
				else:
					type = type.split("_")[0]
				type = type.split(")")[0]
			#endTry
		#endTry
		## work class config types are not recognized as WAS config types, need to 
		## reset the type to the parent config type "WorkClass"
		if (type in self.WORK_CLASS_SUBTYPES):
			type = "WorkClass"
		self.LOGGER.traceExit(type)
		return type
	#endDef
	
	def readConfigDataUsingParentId(self, scopeId, scopeType, configType, excludedTypes=[], excludedAttributes=[]):
		self.excludedAttributes = excludedAttributes
		data = []
		if (len(scopeId) == 0):
			self.LOGGER.error("ERROR: unable to find parent scope: " + scopeId)
			self.LOGGER.error("Cannot read config data.")
			return data
		#endIf

		for objId in AdminConfig.list(configType, scopeId).split(newline):
			self.importedIds = []
			## if anything found, is in scope, and not builtin
			if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId) and (objId.find("builtin") == -1)):
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							match = "yes"
						#endIf
					#endFor
					if (match == "no"):
						self.LOGGER.info("Importing " + objId)
						self.importedIds.append(objId)
						self.objidConfigTypeMap[objId] = configType
						data.append(self.showAll(objId))
					#endIf
				else:
					self.LOGGER.info("Importing " + objId)
					self.importedIds.append(objId)
					self.objidConfigTypeMap[objId] = configType
					data.append(self.showAll(objId))
				#endIf
			#endIf
		#endFor
		return data
	#endDef
#endClass

class WorkClassMediator:
	
	def __init__(self):
		self.LOGGER = _Logger("WorkClassMediator", MessageManager.RB_WEBSPHERE_WVE)
	#endDef		
		
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
	
		data = []
		scopeId = AdminConfig.getid(scope)
		myConfigReader = WorkClassReader()
	
		if (len(scopeId) == 0):
			print "ERROR: unable to find parent scope: " + scope
			print "Cannot read config data."
			return data
				
		print "Importing: scopeId=" + str(scopeId) + ", configType=" + str(configType) + ", excludedTypes=" + str(excludedTypes)
		
		for objId in AdminConfig.list(configType, scopeId).split(newline):
			objId = objId.strip()
			myConfigReader.importedIds = []
			## if anything found and is in scope
			if (len(objId) > 0 and (AdminHelper.isInScope(scopeType, objId))):
				toImport = 1
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							toImport = 0
							break
						#endIf
					#endFor
				#endIf
				
				if toImport:
					print "Importing " + objId
					myConfigReader.importedIds.append(objId)
					if (configType == "WorkClass"):
						# TODO ...
						# ServicePolicy WorkClass example: 
						# Default_HTTP_WC(cells/wve61/applications/connector-sms-ear.ear/deployments/connector-sms-ear-edition1.0/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)

						# RoutingPolicy WorkClass example:
						# Default_HTTP_WC(cells/wve61/applications/connector-sms-ear.ear/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
						dataTemp = myConfigReader.showAll(objId)
						parentPath = objId.split('/workclasses/')[0]
						# print "--## parentPath: %s ##--" % parentPath
						#Default_HTTP_WC(cells/CELL_TEST/xd/systemApps/EventService.ear
						#Default_HTTP_WC(cells/CELL_TEST/applications/ibmasyncrsp.ear/deployments/ibmasyncrsp/workclasses/Default_HTTP_WC|workclass.xml#Default_HTTP_WC)
						#Default_HTTP_WC(cells/CELL_TEST/applications/ibmasyncrsp.ear ##--
						if (parentPath.find('/deployments/') >= 0):
							dataTemp['attrs']['DEPLOYMENT_NAME'] = parentPath.split('/deployments/')[1]
						#endIf

						if (parentPath.find('/applications/') >= 0):
							dataTemp['attrs']['APPLICATION_NAME'] = parentPath.split('/applications/')[1].split('/')[0]
						elif (parentPath.find('/systemApps/') >= 0):
							dataTemp['attrs']['IS_SYSTEM_APP'] = "true"
							dataTemp['attrs']['APPLICATION_NAME'] = parentPath.split('/systemApps/')[1].split('/')[0]
						elif (parentPath.find('/sla/') >= 0):
							dataTemp['attrs']['IS_SERVICE_POLICY_WC'] = "true"
							dataTemp['attrs']['ODRNAME'] = parentPath.split('/sla/')[1]
						elif (parentPath.find('/routing/') >= 0):
							dataTemp['attrs']['IS_ROUTING_POLICY_WC'] = "true"
							dataTemp['attrs']['ODRNAME'] = parentPath.split('/routing/')[1]
						#endIf
						data.append(dataTemp)
					else:
						data.append(myConfigReader.showAll(objId))
		return data
	#endDef
		
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
		scopeid = AdminConfig.getid(scope)
		try:
			xmlProp = XmlProperty(xmlFile)
			xmlPropNode = xmlProp.findRAFWContainerNode(marker)
		except:
		 	print "Warn -- not able to find " + xmlFile
			print "Cannot write WAS config. Returning without doing anything"
		 	return
		#endTry
	
		if (len(scopeid) == 0):
			print "ERROR: unable to find parent scope: " + scopeid
			print "Cannot write WAS config. Returning without doing anything"
			return
		#endIf
		
		myConfigWriter = ConfigWriter()
		myConfigWriter.configReader = WorkClassReader()
		
		for typeName in typeNames:
			## Remove existing WorkClass data for the current scope, excluding those for systemApps
			wrkClassIds = AdminConfig.list(typeName, scopeid).split(newline)
			for wrkClassId in wrkClassIds:
				if ((wrkClassId.find("systemApps") == -1) and (AdminHelper.isInScope(scopeType, wrkClassId))):
					myConfigWriter.remove(wrkClassId, excludedTypes)
				#endIf
			#endFor
		#endFor
		
		for typeName in typeNames:								
			nodeArray = xmlPropNode.getFilteredChildrenArray(typeName)	
			for xmlNode in nodeArray:
				## If XmlNode corresponds to a Application Routing Policy(ARP) or Application Service Policy(ASP) WorkClass element
				if (xmlNode.hasAttr("DEPLOYMENT_NAME") or xmlNode.hasAttr("APPLICATION_NAME")):
					deploymentName = xmlNode.getAttrValue("DEPLOYMENT_NAME")
					applicationName = xmlNode.getAttrValue("APPLICATION_NAME")
					isSystemApp = xmlNode.getAttrValue("IS_SYSTEM_APP")
					wcName = xmlNode.getAttrValue("name")
					wcMatchAction = xmlNode.getAttrValue("matchAction")
					# print "App name: " + applicationName
					
					## If Application contains DEPLOYMENT_NAME and is not a SystemApplication, create Application Service Policy WorkClass
					if ((deploymentName is not None) and (isSystemApp is None)):
						parentId = AdminConfig.getid('/Deployment:' + deploymentName + '/')
						if (len(parentId) > 0):
							print "Info: Creating Application Service Policy " + typeName + " at " + scopeType + " scope"
							myConfigWriter.createWASObject(xmlNode, parentId, excludedTypes)
						else:
							raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WVE, "CRWVE2000E", [deploymentName, typeName]);
						#endIf
					elif (isSystemApp == "true"):
						## If Application is a System Application, obtain config id and only modify the data
						sysAppWCId = self.getWCIdForSystemApp(applicationName, wcName, wcMatchAction, typeName)	
						if (sysAppWCId is not None):
							print "Info: Modifying SystemApp " + typeName + " configuration at " + scopeType + " scope"
							myConfigWriter.modify(sysAppWCId, xmlNode, excludedTypes)
						#endIf
					else:
						## If Application contains only APPLICATION_NAME, create Application Routing Policy WorkClass
						commandOptions = ['-appname ']
						commandOptions.append(applicationName.split('.ear')[0])
						
						commandOptions.append('-wcname')
						commandOptions.append(xmlNode.getAttrValue('name'))
						
						commandOptions.append('-type')
						commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])
						
						commandOptions.append('-actiontype')
						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])
						
						commandOptions.append('-action')
						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1])        				
						
						print "Info: Creating Application Routing Policy " + typeName + " at " + scopeType + " scope"
						id = AdminTask.createRoutingPolicyWorkClass(commandOptions)
						myConfigWriter.modify(id, xmlNode, excludedTypes)
					#endIf
				
				## If XmlNode corresponds to a GenericServerCluster Service Policy(GSP) WorkClass element
				elif (xmlNode.hasAttr("IS_SERVICE_POLICY_WC")):					
					commandOptions = ['-odrname ']
					commandOptions.append(xmlNode.getAttrValue('ODRNAME'))

					commandOptions.append('-odrnode')
					commandOptions.append(scopeid.split('(')[0])
						
					commandOptions.append('-wcname')
					commandOptions.append(xmlNode.getAttrValue('name'))
						
					commandOptions.append('-type')
					commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])

					commandOptions.append('-tcname')
					commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1]) 
						
					commandOptions.append('-vhost')
					commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])
					
					print "Info: Creating GenericServerCluster Service Policy " + typeName + " at " + scopeType + " scope"
					id = AdminTask.createServicePolicyWorkClass(commandOptions)				
					
				## If XmlNode corresponds to a GenericServerCluster Routing Policy(GRP) WorkClass element
				elif (xmlNode.hasAttr("IS_ROUTING_POLICY_WC")):
					commandOptions = ['-odrname ']
					commandOptions.append(xmlNode.getAttrValue('ODRNAME'))

					commandOptions.append('-odrnode')
					commandOptions.append(scopeid.split('(')[0])
						
					commandOptions.append('-wcname')
					commandOptions.append(xmlNode.getAttrValue('name'))
						
					commandOptions.append('-type')
					commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])
						
					commandOptions.append('-actiontype')
					commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1])
						
					commandOptions.append('-action')
					commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[2])

					commandOptions.append('-vhost')
					commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])					
					
					print "Info: Creating GenericServerCluster Routing Policy " + typeName + " at " + scopeType + " scope"
					id = AdminTask.createRoutingPolicyWorkClass(commandOptions)
					myConfigWriter.modify(id, xmlNode, excludedTypes)
				else:
					## If XmlNode corresponds to a WorkClassModule or MatchRules or other child elements of WorkClass
					myConfigWriter.createWASObject(xmlNode, scopeid, excludedTypes)										
				#endIf
			#endFor
		#endFor	
	#endDef
	
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
		scopeId = AdminConfig.getid(scope)
		try:
			xmlProp = XmlProperty(xmlFile)
			xmlPropNode = xmlProp.findRAFWContainerNode(marker)
		except:
			print "Warn -- not able to find " + xmlFile
			print "Cannot write WAS config. Returning without doing anything"
			return
		#endTry
		
		if (len(scopeId) == 0):
			print "ERROR: unable to find parent scope: " + scopeId
        		print "Cannot write WAS config. Returning without doing anything"
	    		return
        	#endIf
        
        	myConfigWriter = ConfigWriter()
	        myConfigValidator = ConfigValidator()
        	myConfigWriter.configReader = WorkClassReader()
        
        	for typeName in typeNames:
        		nodeArray = xmlPropNode.getFilteredChildrenArray(typeName)
	        	for xmlNode in nodeArray:
        			if (not xmlNode.hasAttr("IS_SYSTEM_APP")):
        				## Validate if current node exists in the WAS configuration. If NO, create it.
        				childId = myConfigValidator.validate2(xmlNode, scopeId)
        				if (childId is None):
        					if (xmlNode.hasAttr("DEPLOYMENT_NAME")):
        						deploymentName = xmlNode.getAttrValue("DEPLOYMENT_NAME")
        						parentId = AdminConfig.getid('/Deployment:' + deploymentName + '/')
        						print "Info: Creating Application Service Policy " + typeName + " at " + scopeType + " scope"
        						myConfigWriter.createWASObject(xmlNode, parentId, excludedTypes)
        					elif (xmlNode.hasAttr("APPLICATION_NAME")):
        						applicationName = xmlNode.getAttrValue("APPLICATION_NAME")
        						commandOptions = ['-appname ']
        						commandOptions.append(applicationName.split('.ear')[0])
        						
        						commandOptions.append('-wcname')
        						commandOptions.append(xmlNode.getAttrValue('name'))
        						
        						commandOptions.append('-type')
        						commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])
        						
        						commandOptions.append('-actiontype')
        						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])
        						
        						commandOptions.append('-action')
        						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1])
        						
        						print "Info: Creating Application Routing Policy " + typeName + " at " + scopeType + " scope"
        						id = AdminTask.createRoutingPolicyWorkClass(commandOptions)
        						myConfigWriter.modify(id, xmlNode, excludedTypes)
        					elif (xmlNode.hasAttr("IS_SERVICE_POLICY_WC")):
        						commandOptions = ['-odrname ']
        						commandOptions.append(xmlNode.getAttrValue('ODRNAME'))
        						
        						commandOptions.append('-odrnode')
        						commandOptions.append(scopeId.split('(')[0])
        						
        						commandOptions.append('-wcname')
        						commandOptions.append(xmlNode.getAttrValue('name'))
        						
        						commandOptions.append('-type')
        						commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])
        						
        						commandOptions.append('-tcname')
        						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1])
        						
        						commandOptions.append('-vhost')
        						commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])
        						
        						print "Info: Creating GenericServerCluster Service Policy " + typeName + " at " + scopeType + " scope"
        						id = AdminTask.createServicePolicyWorkClass(commandOptions)        						
        					elif (xmlNode.hasAttr("IS_ROUTING_POLICY_WC")):
								commandOptions = ['-odrname ']
								commandOptions.append(xmlNode.getAttrValue('ODRNAME'))

								commandOptions.append('-odrnode')
								commandOptions.append(scopeId.split('(')[0])
						
								commandOptions.append('-wcname')
								commandOptions.append(xmlNode.getAttrValue('name'))
						
								commandOptions.append('-type')
								commandOptions.append(xmlNode.getAttrValue('type').split('WORKCLASS')[0])
						
								commandOptions.append('-actiontype')
								commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[1])
						
								commandOptions.append('-action')
								commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[2])

								commandOptions.append('-vhost')
								commandOptions.append(xmlNode.getAttrValue('matchAction').split(':')[0])
								
								print "Info: Creating GenericServerCluster Routing Policy " + typeName + " at " + scopeType + " scope"
								id = AdminTask.createRoutingPolicyWorkClass(commandOptions)
								myConfigWriter.modify(id, xmlNode, excludedTypes)
        					else:        						
        						myConfigWriter.createWASObject(xmlNode, scopeId, excludedTypes)
        					#endIf
        				else:
							if (SystemUtils.updateOnAugment()):
								myConfigWriter.modify(childId, xmlNode, excludedTypes)
							else:
								print "Warning: " + typeName + " at " + scopeType + " scope will not be created."
							#endIf
						#endIf
        			else:
        				print "Info: Cannot augment " + typeName + " configuration for systemApp. Run action in 'Execute' mode for modifying systemApps"
        			#endIf
        		#endFor        
        	#endFor
	#endDef
		
	
	"""
		Provides the WAS configuration id for the SystemApp WorkClass in the specified scope, matching with 
		the application name, WorkClass name, matchAction, of the xmlNode supplied. 
		
		@param _appName: Value of APPLICATION_NAME attribute in the xmlNode
		@param _wcNameAttr: Value of WorkClass name attribute in the xmlNode
		@param _wcMatchAction: Value of WorkClass matchAction attribute in the xmlNode
		@param _typeName: Config type of the xmlNode
	                          
		@return: The id of the matching Work class object
	"""
	def getWCIdForSystemApp(self, _appName, _wcNameAttr, _wcMatchAction, _typeName):
		wrkClassNames = AdminConfig.list(_typeName).split(newline)
		if (len(wrkClassNames) > 0):
   			for wrkClassName in wrkClassNames:
			   	name = AdminConfig.showAttribute(wrkClassName, "name")
				action = AdminConfig.showAttribute(wrkClassName, "matchAction")
          			if ((_wcNameAttr == name) and (_wcMatchAction == action) and (wrkClassName.find(_appName) > 0) and (wrkClassName.find('/systemApps/') > 0)):
          				return wrkClassName
				#endIf
			#endFor
			return None
		#endIf
		else:
			return None
	#endDef

	
#endClass

optDict, args = SystemUtils.getopt(sys.argv, 'scope:;scopename:;properties:;mode:')

scope = AdminHelper.buildScope(optDict)
scopeType = optDict['scope']
mode = optDict['mode']
xmlFile = optDict['properties']

thisMediator = WorkClassMediator()
typeNames = ['WorkClass']
excludedTypes = ['DEPLOYMENT_NAME', 'APPLICATION_NAME', 'IS_SYSTEM_APP', 'IS_SERVICE_POLICY_WC', 'IS_ROUTING_POLICY_WC', 'ODRNAME']
marker = 'workClass'

if (mode == MODE_EXECUTE):
	print "Creating Work Classes"
	thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
	AdminHelper.saveAndSyncCell()

elif (mode == MODE_AUGMENT):
    print "Augmenting Work Classes"
    thisMediator.augmentConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
    AdminHelper.saveAndSyncCell()
    
elif (mode == MODE_IMPORT):
	print "Importing Work Classes"
	ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator)

elif (mode == MODE_COMPARE):
	print "Comparing Work Classes in RAFW and WAS"
	ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator)

else:
	print "Unsupported MODE supplied: " + mode
#endIf
