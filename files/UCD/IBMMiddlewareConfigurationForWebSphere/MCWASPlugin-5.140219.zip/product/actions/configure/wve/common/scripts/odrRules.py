"""
    Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

    
    File name: odrRules.py
    This file configures routing rules for ODR cluster/server
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import *

from AdminHelper import AdminHelper

newline = java.lang.System.getProperty("line.separator")

class OdrRulesReader(ConfigReader):
    
    def __init__(self, importedIds=[], excludedTypes = [], excludedAttributes = []):
        self.LOGGER = _Logger("OdrRulesReader", MessageManager.RB_WEBSPHERE_WVE)
        self.importedIds = importedIds
        self.objidConfigTypeMap = {}
        self.excludedTypes = excludedTypes
        self.processTypesFirst = []
        self.excludedAttributes = excludedAttributes
        # load the list of attributes which are treated as password fields
        self._updatePasswordAttributes()
    #endDef
    
    
    ## Override getWASType from ConfigReader, since stripping of #, _, from objId doesn't give a valid configType in this case
    ## id = routing_HTTP_serverRequest(cells/CELL_TEST/clusters/ODR_CLUSTER/rules/routing_HTTP_serverRequest|rules.xml#routing_HTTP_serverRequest)
    ## Since routing_HTTP_serverRequest is not a valid configuration type, set type as Rules used later in AdminConfig.showall(type)
    def getWASType(self, id):
        self.LOGGER.traceEnter(id)
        type = id.split("#")[1]
        if ( (type.find('routing_') != -1) or (type.find('service_') != -1) ):            
            type = 'Rules'
        else:
            type = type.split("_")[0]
            type = type.split(")")[0]
        self.LOGGER.traceExit(type)
        return type
    #endDef
    
    
    def getReferenceKeys(self, id):
        referenceKeys = []
        if (len(id) > 0 and (id.find("builtin") == -1)):
            wasType = self.getWASType(id)
            if ( (id.find ('routing_') == -1) and (id.find ('service_') == -1) ):
                for attribute in AdminConfig.attributes(wasType).split(newline):
                    if (len (attribute) > 0):
                        (key, info) = attribute.split(' ', 1)
                        if (info.endswith('@') or info.endswith('@*')):
                            referenceKeys.append(key)
                        #endIf
                    #endIf
                #endFor
            #endIf
        #endIf
        return referenceKeys
    #endDef
    
    def readConfigDataUsingParentId(self, scopeId, scopeType, configType, excludedTypes = [], excludedAttributes = []):
        self.excludedAttributes = excludedAttributes
        data = []
        if (len(scopeId) == 0):
            self.LOGGER.error("ERROR: unable to find parent scope: " + scopeId)
            self.LOGGER.error("Cannot read config data.")
            return data
        #endIf

        if (scopeType == "cell"):
            excludedTypes = excludedTypes + ["clusters"]
        elif (scopeType == "node"):
            excludedTypes = excludedTypes + ["servers"]
        #endIf

        for objId in AdminConfig.list(configType, scopeId).split(newline):
            self.importedIds = []
            ## if anything found, is in scope, and not builtin
            if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId) and (objId.find("builtin") == -1)):
                ## never show the top level configuration element in references
                if (excludedTypes != []):
                    match = "no"
                    for excludedType in excludedTypes:
                        if (SystemUtils.regexp(excludedType, objId) == 1):
                            match = "yes"
                        #endIf
                    #endFor
                    if (match == "no"):
                        self.LOGGER.info("Importing " + objId)
                        self.importedIds.append(objId)
                        self.objidConfigTypeMap[objId] = configType
                        data.append(self.showAll(objId))
                    #endIf
                else:
                    self.LOGGER.info("Importing " + objId)
                    self.importedIds.append(objId)
                    self.objidConfigTypeMap[objId] = configType
                    data.append(self.showAll(objId))
                #endIf
            #endIf
        #endFor
        return data
    #endDef
#endClass

class OdrRulesMediator:
    
    def __init__(self):
        self.LOGGER = _Logger("OdrRulesMediator", MessageManager.RB_WEBSPHERE_WVE)
    #endDef        
        
    def readConfigData(self, scope, scopeType, configType, excludedTypes):
    
        data = []
        scopeId = AdminConfig.getid(scope)
        myConfigReader = OdrRulesReader()
    
        if (len(scopeId) == 0):
            print "ERROR: unable to find parent scope: " + scope
            print "Cannot read config data."
            return data
                
        print "Importing: scopeId=" + str(scopeId) + ", configType=" + str(configType) + ", excludedTypes=" + str(excludedTypes)
        
        for objId in AdminConfig.list(configType, scopeId).split(newline):
            objId = objId.strip()
            myConfigReader.importedIds = []
            ## if anything found and is in scope
            if (len(objId) > 0 and (AdminHelper.isInScope(scopeType, objId))):
                toImport = 1
                ## never show the top level configuration element in references
                if (excludedTypes != []):
                    match = "no"
                    for excludedType in excludedTypes:
                        if (SystemUtils.regexp(excludedType, objId) == 1):
                            toImport = 0
                            break
                        #endIf
                    #endFor
                #endIf
                
                if toImport:
                    print "Importing " + objId
                    myConfigReader.importedIds.append(objId)
                    data.append(myConfigReader.showAll(objId))
                    parentPath  = objId.split('/rules/')[0]
                    print "--## parentPath: %s ##--" % parentPath
                #endIf
            #endIf
        #endFor
        return data
    #endDef
   
   
    def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
        scopeId = AdminConfig.getid(scope)
        try:
            xmlProp  = XmlProperty(xmlFile)
            xmlPropNode = xmlProp.findRAFWContainerNode(marker)
        except:
             print "Warn -- not able to find " + xmlFile
             print "Cannot write WAS config. Returning without doing anything"
             return
        #endtry
    
        if (len(scopeId) == 0):
            print "ERROR: unable to find parent scope: " + scopeId
            print "Cannot write WAS config. Returning without doing anything"
            return
        #endIf
        
        myConfigWriter = ConfigWriter()
        myConfigWriter.configReader = OdrRulesReader()
        
        for typeName in typeNames:
            myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
            nodeArray = xmlPropNode.getFilteredChildrenArray(typeName)    
            for xmlNode in nodeArray:
                myConfigWriter.createWASObject(xmlNode, scopeId, excludedTypes)
            #endFor
        #endFor    
    #endDef
    
    def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
        scopeId = AdminConfig.getid(scope)
        try:
            xmlProp  = XmlProperty(xmlFile)
            xmlPropNode = xmlProp.findRAFWContainerNode(marker)
        except:
             print "Warn -- not able to find " + xmlFile
             print "Cannot write WAS config. Returning without doing anything"
             return
        #endTry
    
        if (len(scopeId) == 0):
            print "ERROR: unable to find parent scope: " + scopeId
            print "Cannot write WAS config. Returning without doing anything"
            return
        #endIf
        
        myConfigWriter = ConfigWriter()
        myConfigValidator = ConfigValidator()
        myConfigWriter.configReader = OdrRulesReader()
        
        for typeName in typeNames:            
            nodeArray = xmlPropNode.getFilteredChildrenArray(typeName)    
            for xmlNode in nodeArray:
                childId = myConfigValidator.validate2(xmlNode, scopeId)                
                if (childId is None):
                    print "Info: Creating " + typeName + " at " + scopeType + " scope"
                    myConfigWriter.createWASObject(xmlNode, scopeId, excludedTypes)
                else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode)
					else:
						print "Warning: " + typeName + " at " + scopeType + " scope will not be created."
					#endIf
                #endIf
            #endFor
        #endFor    
    #endDef
    
    def isScopeValid (self, _scope):
        scopeid = AdminConfig.getid(_scope)
        serverType = AdminConfig.showAttribute(scopeid, 'serverType')
        if (serverType == "ONDEMAND_ROUTER"):
            return 1
        else:
            print "Provided cluster or server name is not of type on-demand router(ODR)"
            return 0
        #endIf        
    #endDef        
    
#endClass

if ( str(sys.argv).find("scopename") != -1):
	optDict, args = SystemUtils.getopt(sys.argv, 'scope:;scopename:;nodename:;properties:;mode:')
	
	scope = AdminHelper.buildScope( optDict )
	scopeType = optDict['scope']
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	
	thisMediator = OdrRulesMediator()
	typeNames = ['Rules']
	excludedTypes = []
	marker = 'odrRoutingRules'
	
	if(thisMediator.isScopeValid(scope)):
	    if (mode == MODE_EXECUTE):
	        print "Creating ODR Routing Rules in scope: " + scope
	        thisMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
	        AdminHelper.saveAndSyncCell()
	    #endIf
	    
	    elif (mode == MODE_AUGMENT):
	        print "Augmenting ODR Routing Rules in scope: " + scope
	        thisMediator.augmentConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
	        AdminHelper.saveAndSyncCell()
	    #endIf
	    
	    elif (mode == MODE_IMPORT):
	        print "Importing ODR Routing Rules in scope: " + scope
	        ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator) 
	    #endIf
	    
	    elif (mode == MODE_COMPARE):
	        print "Comparing ODR Routing Rules in RAFW and WAS in scope: " + scope
	        ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator)
	    #endIf
	    
	    else:
	        print "Unsupported MODE supplied: " + mode
	#endIf
#endIf