"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: odr.py
"""

import string
import sys
lineSeparator = java.lang.System.getProperty('line.separator')

"""
perlPath = /opt/ibm/cepodr-idev1-01/xodr/websphere/current/appserver/profiles/node01/etc/copy_plugin.pl
ihsHosts = ('cepiweb-idev1-01','cepiweb-idev1-02')
"""
def modifyODR(ihsHosts, odrNodeName, perlPath):
	# ihsHosts = remove "()'" and replace ',' with ';'
	ihsHosts = string.replace(ihsHosts[1:-1], ",", ";")
	print 'ihsHosts=',"'" + ihsHosts + "'"
	print 'odrNodeName=',odrNodeName
	print 'perlPath=', perlPath
	
	odrNode=AdminConfig.getid('/Node:' + odrNodeName + '/')
	proxies = AdminConfig.list('ProxySettings', odrNode).split(lineSeparator)
	for proxy in proxies:
		print 'proxy=',proxy
		print AdminConfig.modify(proxy, [['trustedIntermediaryAddresses', ihsHosts]])
		print 'proxy done'

		print AdminConfig.create('PluginConfigPolicy', proxy, [['pluginConfigChangeScript', perlPath],['pluginGenConfigScope', 'ALL']])	     
		#policy=AdminConfig.list('PluginConfigPolicy', proxy)
		#print 'policy=',policy
		#print AdminConfig.modify(policy, [['pluginConfigChangeScript', perlPath]])
		#print 'mod_1 done'
		#print AdminConfig.modify(policy, [['pluginGenConfigScope', 'ALL']])
		#print 'mod_2 done'
		
		#props = AdminConfig.list('Property', proxy).split(lineSeparator)
		#for prop in props:
		#	name = AdminConfig.showAttribute(prop, 'name')
		#	print 'name',name
		#	if(name == 'http.responseCompression'):
		#		print 'mod',AdminConfig.modify(prop, [['name','http.responseCompression'],['value','true']])
		print AdminConfig.create('Property', proxy, [['name','http.clientInfoFromTrustedIntermediary'],['value','true']])
		print AdminConfig.create('Property', proxy, [['name','http.responseCompression'],['value','true']])
	
	servers = AdminConfig.list('Server', odrNode).split(lineSeparator)
	for server in servers:
		name = AdminConfig.showAttribute(server, 'name')
		print name
		if(name != 'nodeagent'):
			jvms=AdminConfig.list('JavaVirtualMachine', server).split(lineSeparator)
			for jvm in jvms:
				genargs = AdminConfig.showAttribute(jvm, 'genericJvmArguments')
				genargs = string.join([genargs, '-DODR_RulesOverAffinity=true'], ' ')
				print 'args', genargs
				print AdminConfig.modify(jvm, [['genericJvmArguments', genargs]])
	
	AdminConfig.save()
	

optDict, args = SystemUtils.getopt( sys.argv, 'scope:;ihs:;path:;hostname:;properties:;nodename:;scopename:;mode:;cellProperties:;command:;celltype:;cellname:;path:')

ihs = optDict['ihs']
node = optDict['nodename']
path = optDict['path']


modifyODR(ihs, node, path)




			      
