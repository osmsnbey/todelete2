"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: WAS51MQJMSConnFactories.py
	
	This script is to create MQ jms conneciton factories in a given scope.
	This uses a type that only exists in WAS51 and previous.  
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f WAS51MQJMSConnFactories.py 
		-scope <scope>: specify the scope of the jms connection factories to be created
		-scopename <scope name>: specify the scope name of the jms connection to be created 
		-properties <jms properties file>: specify the name of the jms properties 
			file to be used for the creation
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

WAS51JMSProvidersLogger = _Logger("WAS51JMSProviders", MessageManager.RB_WEBSPHERE_WAS)

def createConfig(scope, scopeType, xmlFile, marker):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeid = AdminConfig.getid( scope )
	typeName = "JMSProvider"
	#createConfigType(scopeid, scopeType, xmlProp, typeName)
	createConfig(scope, scopeType, propFile, [typeName])	
#endDef

#not used now
def createConfigType(scopeid, scopeType, xmlProp, typeName):
	
	myConfigWriter = ConfigWriter();
	myConfigWriter.removeExistingConfig(scopeType, typeName, scopeid)
	#print "removed existing config"
	WAS51JMSProvidersLogger.log("CRWWA5045I")

	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	##print "retrieved filteredNodeArray by type "+typeName
	WAS51JMSProvidersLogger.log("CRWWA2088I",[typeName])
	for xmlNode in nodeArray:
		
		##print "getting first JMSProvider node"
		WAS51JMSProvidersLogger.log("CRWWA2089I")
		#providerNode = xmlNode.getFilteredChildrenArray("JMSProvider")[0]
		providerNode = xmlNode.getFilteredChildrenArray("builtin")[0]
		##print "got first JMSProviderNode"
		WAS51JMSProvidersLogger.log("CRWWA2090I")
		JMSProviderName = providerNode.getAttrValue("name")
		##print "first JMSProviderNode name is "+JMSProviderName
		WAS51JMSProvidersLogger.log("CRWWA2091I",[JMSProviderName])
		## hard coded for now
		parentId = AdminConfig.getid( scope + 'JMSProvider:' + JMSProviderName + '/' )
	
		myConfigWriter.createWASObject(xmlNode, parentId)
	#endFor
#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'scope:;properties:;nodename:;scopename:;mode:')
	
# get scope
scope = AdminHelper.buildScope(optDict)

propFile = optDict['properties'] 
marker = "WAS51JMSProviders"

mode = optDict['mode']
if (mode == MODE_EXECUTE):

	##print "Creating JMSProviders in scope: " + scope
	WAS51JMSProvidersLogger.log("CRWSE1698I",[scope])
	scopeType=optDict['scope']

	createConfig(scope, scopeType, propFile, marker)
	AdminHelper.saveAndSyncCell()

elif (mode == MODE_IMPORT):
	##print "Importing MQ Conn Factories in scope: " + scope
	WAS51JMSProvidersLogger.log("CRWSE1699I",[scope])
	typeNames = ["JMSProvider"]
	scopeType=optDict['scope']
	ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames)

else:
	##print "Unsupported MODE supplied: " + mode
	WAS51JMSProvidersLogger.log("CRWWA0008W",[mode])
#endIf

