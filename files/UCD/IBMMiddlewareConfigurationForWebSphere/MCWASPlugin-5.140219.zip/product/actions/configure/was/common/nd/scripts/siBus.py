"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: siBus.py
	
	TODO: description
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals

from com.ibm.rational.rafw.wsadmin.websphere.config import WsadminConfig
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter

from ConfigReader import ConfigReader
from ConfigValidator import ConfigValidator
from java.util import ArrayList
from Logger import _Logger
from SystemUtils import SystemUtils

CONTAINER_XML_ID = "sibMQServer"
XML_ID = "MQServer"

class dsMediator:
	
	def __init__(self):
		self._groups_ = {}
		self._users_ = {}
		self.configValidator = ConfigValidator()
	#endDef
		
	def createSIBusResourceObject(self, xmlNode, parentId, excludedNodeNames = ['builtin', 'BUS_NAME']):
		SCRIPT_LOGGER.traceEnter([xmlNode, parentId, excludedNodeNames])
		type = xmlNode.getNodeNameFixed()
		
		# Process SIBAuthSpace separately:
		# Create SIBAuthSpace object with it's attributes and create it's SIBAuthGroup and SIBAuthUser children.
		# We store these object ids in maps self._groups_ and self._users_
		# for referencing later in other children objects.
		if (type == 'SIBAuthSpace'):
			attrs = xmlNode.buildNodeAttrs(excludedNodeNames)
			authSpace = AdminConfig.create(type, parentId, attrs)
			
			# process SIBAuthGroup children
			for xmlChild in xmlNode.getFilteredChildrenArray('SIBAuthGroup'):
				attrs = xmlChild.buildNodeAttrs()
				wasAttrName = xmlChild.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
				group = AdminConfig.create('SIBAuthGroup', authSpace, attrs, wasAttrName)
				identifier = attrs[0][1]
				self._groups_[identifier] = group
			
			# process SIBAuthUser children
			for xmlChild in xmlNode.getFilteredChildrenArray('SIBAuthUser'):
				attrs = xmlChild.buildNodeAttrs()
				wasAttrName = xmlChild.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
				user = AdminConfig.create('SIBAuthUser', authSpace, attrs, wasAttrName)
				identifier = attrs[0][1]
				self._users_[identifier] = user

			# process other children
			for xmlChild in xmlNode.getChildrenArray():
				if (xmlChild.getNodeNameFixed() not in excludedNodeNames):
					self._parentType_ = xmlNode.getNodeNameFixed()
					self.createSIBusResourceObject(xmlChild, authSpace)
		
		# Other than SIBAuthSpace. Here will be processed SIBAuthSpace children as well.
		elif (type not in excludedNodeNames):
			SCRIPT_LOGGER.debug("createSIBusResourceObject: " + type + ", " + parentId)
			attrs = xmlNode.buildNodeAttrs(excludedNodeNames)
			
			# we create here reference to SIBAuthGroup object in SIBAuthSpace child 
			if (xmlNode.getNodeNameFixed() == 'SIBAuthGroup' and self._parentType_ != 'SIBAuthSpace'):
				identifier = attrs[0][1]
				group = self._groups_[identifier]
				AdminConfig.modify(parentId, [['group', [group]]])
				return
			
			# we create here reference to SIBAuthUser object in SIBAuthSpace child
			elif (xmlNode.getNodeNameFixed() == 'SIBAuthUser' and self._parentType_ != 'SIBAuthSpace'):
				identifier = attrs[0][1]
				user = self._users_[identifier]
				AdminConfig.modify(parentId, [['user', [user]]])
				return
				
			elif ( xmlNode.hasAttr(Globals.WAS_KEY_ATTR_NAME) ):
				## case where we need a fourth parameter
				wasAttrName = xmlNode.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
				newId = AdminConfig.create(type, parentId, attrs, wasAttrName)
			else:
				newId = AdminConfig.create(type, parentId, attrs)
				
			if (newId is None or newId == None or newId == "(null)"):
				SCRIPT_LOGGER.error("Error: Unable to create type: " + type + " under parent: " + parentId)
			else:
				SCRIPT_LOGGER.debug("Created object of type: " + type + " under parent: " + parentId + " with id:" + newId)
				for xmlChild in xmlNode.getChildrenArray():
					if (xmlChild.getNodeNameFixed() not in excludedNodeNames):
						self._parentType_ = xmlNode.getNodeNameFixed()
						self.createSIBusResourceObject(xmlChild, newId)
					#endIf
				#endFor
			#endIf
		#endIf
		SCRIPT_LOGGER.traceExit()
	#endDef
	
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames):
		SCRIPT_LOGGER.traceEnter([scope, scopeType, xmlFile, typeNames])
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeid = AdminConfig.getid( scope )
	
		myConfigWriter = ConfigWriter();
		for typeName in typeNames:
			print "Info: Deleting existing " + typeName
			myConfigWriter.removeExistingConfig(scopeType, typeName, scopeid)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
	
			if (typeName == "SIBus"):
				for xmlNode in nodeArray:
					print "Info: Creating " + typeName + " with name " + xmlNode.getAttrValue("name")
					myConfigWriter.createWASObject(xmlNode, scopeid)
				#endFor
			elif (typeName == "SIBMessagingEngine"):
				for xmlNode in nodeArray:
					self._createMessagingEngine(typeName, xmlNode, myConfigWriter, 1)
				#endFor
			else:
				for xmlNode in nodeArray:
					self._createBusResource(typeName, xmlNode, myConfigWriter, 1)
				#endFor
			#endIf
		#endFor
		SCRIPT_LOGGER.traceExit()
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames):
		SCRIPT_LOGGER.traceEnter([scope, scopeType, xmlFile, typeNames])
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)	
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeid = AdminConfig.getid( scope )
	
		myConfigWriter = ConfigWriter();
		for typeName in typeNames:
			
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			if (typeName == "SIBus"):
				for xmlNode in nodeArray:
					childId = self.configValidator.validate2(xmlNode, scopeid)
					if (childId is None):
						print "Info: Creating " + typeName + " with name " + xmlNode.getAttrValue("name")
						myConfigWriter.createWASObject(xmlNode, scopeid)
					else:
						if (SystemUtils.updateOnAugment()):
							myConfigWriter.modify(childId, xmlNode)
						else:
							print "Warning: " + typeName + " will not be created."
						#endIf
					#endIf
				#endFor
			elif (typeName == "SIBMessagingEngine"):
				for xmlNode in nodeArray:
					self._createMessagingEngine(typeName, xmlNode, myConfigWriter, 0)
				#endFor
			elif (typeName == "SIBAuthSpace"):
				if (len(nodeArray) > 0):
					print "Warning: SIBAuthSpace represents a singleton within an SI Bus"
					print "         Augmenting SIBAuthSpace is not supported."
				#endIf
			else:
				for xmlNode in nodeArray:
					self._createBusResource(typeName, xmlNode, myConfigWriter, 0)
				#endFor
			#endIf
		#endFor
		SCRIPT_LOGGER.traceExit()
	#endDef

	def _getUniqueIdAttrName(self, typeName):
		if (typeName == "SIBDestinationMediation"):
			return "mediationName"
		elif (typeName == "SIBMQServerBusMember"):
			return "name"
		elif (typeName == "SIBAuthSpace"):
			return "alias"
		else:
			return "identifier"
	#endDef

	def _createBusResource(self, typeName, xmlNode, myConfigWriter, deleteFirst):
		if (xmlNode.hasAttr("BUS_NAME")):
			SIBusName = xmlNode.getAttrValue("BUS_NAME")
			parentId = AdminConfig.getid( scope + 'SIBus:' + SIBusName + '/' )
			if (len(parentId) > 0):
				if (deleteFirst):
					self.createSIBusResourceObject(xmlNode, parentId)
				else:
					uniqueAttrName = self._getUniqueIdAttrName(typeName)
					childId = self.configValidator.validateUniqueAttr2(xmlNode, parentId, uniqueAttrName)
					if (childId is None):
						print "Info: Creating " + typeName + " with " + uniqueAttrName + " " + xmlNode.getAttrValue(uniqueAttrName)
						self.createSIBusResourceObject(xmlNode, parentId)
					else:
						if (SystemUtils.updateOnAugment()):
							myConfigWriter.modify(childId, xmlNode)
						else:
							print "Warning: " + typeName + " will not be created."
				#endIf
			else:
				print "Error: The parent bus cannot be found for Bus with name '" + SIBusName + "'"
				print "       The " + typeName + " cannot be created without a valid parent Bus"
			#endIf	
		else:
			print "Warning: " + typeName + " xml node is missing attribute 'BUS_NAME'"
			print "         " + typeName + " will not be created."
		#endIf
	#endDef
	
	def _createMessagingEngine(self, typeName, xmlNode, myConfigWriter, deleteFirst):
		parent = xmlNode.getAttrValue("MESSAGE_ENGINE_PARENT")
		SCRIPT_LOGGER.trace("Getting parentId for: " + parent)
		parentId = AdminConfig.getid(parent)
		SCRIPT_LOGGER.trace("ID of parent " + parent + " is: " + parentId)
		if (len(parentId) == 0):
			print "Unable to get ID of MESSAGE_ENGINE_PARENT with name: " + parent
			print "ERROR: Skipping SIBMessagingEngine because parent id cannot be determined"
		else:
			existingConfigIds = AdminConfig.list(typeName, parentId).split(newline)
			if (deleteFirst):
				for existingId in existingConfigIds:
					myConfigWriter.remove(existingId, ['builtin'])
				myConfigWriter.createWASObject(xmlNode, parentId, ['builtin', 'MESSAGE_ENGINE_PARENT'])
			else:
				childId = self.configValidator.validate2(xmlNode, parentId)
				if (childId is None):
					print "Info: Creating " + typeName + " with name " + xmlNode.getAttrValue("name")
					myConfigWriter.createWASObject(xmlNode, parentId, ['builtin', 'MESSAGE_ENGINE_PARENT'])
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode)
					else:
						print "Warning: " + typeName + " will not be created."
			#endIf
		#endIf
	#endDef
	
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
	
		data = []
		scopeId = AdminConfig.getid(scope)
		myConfigReader = ConfigReader()
	
		if (len(scopeId) == 0):
			print "ERROR: unable to find parent scope: " + scope
			print "Cannot read config data."
			return data
		#endIf
		
		print "Importing: scopeId=" + str(scopeId) + ", configType=" + str(configType) + ", excludedTypes=" + str(excludedTypes)
		
		for objId in AdminConfig.list(configType, scopeId).split(newline):
			objId = objId.strip()
			myConfigReader.importedIds = []
			## if anything found, and (is in scope or is MessagingEngine)
			if (len(objId) > 0 and (AdminHelper.isInScope(scopeType, objId) or configType == "SIBMessagingEngine")):
				toImport = 1
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							toImport = 0
							break
						#endIf
					#endFor
				#endIf
				
				if toImport:
					print "Importing " + objId
					myConfigReader.importedIds.append(objId)
					if (configType == "SIBus"):
						data.append(myConfigReader.showAll(objId))
					elif (configType == "SIBMessagingEngine"):
						# SIBMessagingEngine object ID examples:
						#   (cells/cell/nodes/node01/servers/clone1|sib-engines.xml#SIBMessagingEngine_1236073134384)
						#   (cells/cell/clusters/cluster|sib-engines.xml#SIBMessagingEngine_1236174681638)
						dataTemp = myConfigReader.showAll(objId)
						cell = objId.split('/')[1]
						if (objId.split('/')[2] == 'clusters'):
							cluster = objId.split('/')[3].split('|')[0]
							messageEngineParent = "/Cell:" + cell + "/ServerCluster:" + cluster + "/"
						else:
							node = objId.split('/')[3]
							server = objId.split('/')[5].split('|')[0]
							messageEngineParent = "/Cell:" + cell + "/Node:" + node + "/Server:" + server + "/"
						dataTemp['attrs']['MESSAGE_ENGINE_PARENT'] = messageEngineParent
						data.append(dataTemp)
					else:
						dataTemp = myConfigReader.showAll(objId)
						busName  = objId.split('/')[3].split('|')[0]
						dataTemp['attrs']['BUS_NAME'] = busName
						data.append(dataTemp)
				#endIf
			#endIf
		#endFor
		return data
	#endDef
	"""
	Reads the data in WAS into an ArrayList of WsadminConfig objects
	that represent the configuration.
	"""
	def readData(self):
		mqServers = AdminTask.listSIBWMQServers()
		data = ArrayList()
		configReader = ConfigReader()
		newline = java.lang.System.getProperty("line.separator")
		if (len(mqServers) > 0):
			for server in mqServers.split(newline):
				serverName = AdminConfig.showAttribute(server, 'name')
				if (len(server) > 0):
					mqServerConfig = WsadminConfig()
					mqServerConfig.setId(XML_ID)
					mqServerConfig.setAttributes(configReader.convertToMap(AdminTask.showSIBWMQServer('-name ' + serverName)))
					data.add(mqServerConfig)
				#endIf
			#endFor
		#endIf
		return data
	#endDef

	def doImport(self, xmlFile):
		data = self.readData()
		container = WsadminConfig()
		container.setId(Globals.RAFW_XML_PREFIX + CONTAINER_XML_ID)
		container.setChildren(data)
		XmlConfigFileWriter().build(xmlFile, container)
	#endDef
#endClass

SCRIPT_LOGGER = _Logger("siBus", MessageManager.RB_WEBSPHERE_WAS)

if ( str(sys.argv).find("scopename") != -1):
	optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;properties:;nodename:;scopename:;mode:' )

	version= optDict['version']
	# get scope
	scopeType=optDict['scope']
	scope = AdminHelper.buildScope( optDict )

	propFile = optDict['properties'] 

	mode = optDict['mode']
	#typeNames = ['SIBus', 'SIBQueue', 'SIBDestinationAlias', 'SIBTopicSpace', 'SIBDestinationForeign', 'SIBDestinationMediation', 'SIBMessagingEngine', 'SIBAuthSpace']
	## order matters!
	typeNames_60 = ['SIBus', 'SIBQueue', 'SIBDestinationAlias', 'SIBTopicSpace', 'SIBDestinationForeign', 'SIBDestinationMediation', 'SIBMessagingEngine', 'SIBAuthSpace', 'SIBPort', 'SIBWebService'] 
	typeNames_61 = []
	typeNames_61.extend(typeNames_60)
	typeNames_61.append('SIBMQServerBusMember')
	typeNames_70 = []
	typeNames_70.extend(typeNames_61)
	typeNames_70.append('SIBAudit')

	if (version == "60"):
		typeNames = typeNames_60
	elif (version == "61"):
		typeNames = typeNames_61
	elif (version == "70"):
		typeNames = typeNames_70

	excludeTypes = []
	thisMediator = dsMediator()

	# Under SIBus-'SIBForeignBus', 'SIBVirtualMQLink', 'SIBusMemberTarget',
	# Under	SIBMessagingEngine-	'SIBMQLink', 
	marker = "siBus"

	if (mode == MODE_EXECUTE):
		print "Creating SIBus in scope: " + scope
		thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()

	elif (mode == MODE_AUGMENT):
		print "Augmenting SIBus in scope: " + scope
		thisMediator.augmentConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()

	elif (mode == MODE_IMPORT):
		print "Importing SIBus in scope: " + scope
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator )

	elif (mode == MODE_COMPARE):
		print "Comparing SIBus in RAFW and WAS in scope: " + scope
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator )
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf