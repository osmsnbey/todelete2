"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 



	File name: WIMSecurity.py
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
	sys.modules['AdminControl'] = AdminControl
except:
	pass
import AdminConfig
import AdminTask
import AdminControl

import os
from types import *
import java
import com

from java.util.regex import Pattern
from java.lang import String

from ConfigValidator import ConfigValidator
from ConfigWriter import ConfigWriterException
from ConfigWriter import ConfigWriter
from ConfigReaderException import ConfigReaderException
from ConfigFileWriter import GenericConfigFileWriter
from Logger import _Logger
from SystemUtils import SystemUtils
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

LOGGER = _Logger("WIMSecurity", MessageManager.RB_WEBSPHERE_WAS)

##############---------Global constants-------###################
# This section contains global constants used in implementing	#
# all the actions in WIMSecurity.py							 	#
#																#
#################################################################
newline = java.lang.System.getProperty("line.separator")
ATTRS = 'attrs'
ID = 'id'
CHILDREN = 'children'
VALUE = 'value'
NAME = 'name'
REPO_TYPE = 'repositoryType'
#Supported Profile Repository types in WAS
FILE_TYPE = 'FileRepository'
DB_TYPE = 'DatabaseRepository'
LDAP_TYPE = 'LdapRepository'
CUSTOM_TYPE = 'CustomRepository'

WAS_FILE_TYPE = 'File'
WAS_DB_TYPE = 'DB'
WAS_LDAP_TYPE = 'LDAP'
WAS_CUSTOM_TYPE = 'Custom'

SUPPORTED_REPO_TYPES = [FILE_TYPE, DB_TYPE, LDAP_TYPE, CUSTOM_TYPE]
INBUILT_PROFILEREPO_ID = 'InternalFileRepository'
INBUILT_FILEREPO_BASEENTRY = 'o=defaultWIMFileBasedRealm'
INBUILT_DEFAULT_REALM = 'defaultWIMFileBasedRealm'
REALM_NAME = 'realmName'
BASE_ENTRY_NAME = 'name'
NAME_IN_REPO = 'nameInRepository'
LA = 'LA'
FED = 'FED'
CUSTOM_REPO_VERSION = '6.1.0.27'




############## CLASS :: WIMConfigReaderHelper ###################
# This class provides common utility methods that are used to	# 
# process the configuration data of Federated Security			#
#																#
#																#
# THIS CLASS DOESNT MAINTAINS STATE -- CAN BE A SINGLETON or	# 
# can be extended by any single ton or non-singleton class		#
# This class is the super class of all WIMSecurity helper		#
# classes														#
#																#
#################################################################
class WIMConfigReaderHelper:

	##########################################################
	## 
	##########################################################
	def __init__(self):
		self.LOGGER = _Logger("WIMConfigReaderHelper", MessageManager.RB_WEBSPHERE_WAS)
	#endDef
		
	#######################################################################
	## Converts the value to empty string it its None or 'null' as returned
	## by WIM AdminTask command, so that while writing data to RAFW config
	## it will be a blank string "" instead of 'null'
	#######################################################################
	def eValuateNullVal(self, val):
		
		if (val is not None):
			val = val.strip()
		#endIf
		
		if (val == 'null'):
			val = ''
		#endIf
		
		return val
	#endDef
	
	########################################################################
	## This method converts the value of an attribute in the form a = { ...}
	## /a = [..] to a hash map or to a list based on specific value
	########################################################################
	
	def evaluateAttributeValues(self, values):
		
		self.LOGGER.traceEnter([str(values)])
		values = values.strip()
		data = values
		if (values.startswith('[') and values.endswith(']')):
			data = self.convertToList(values)
		elif (values.startswith('{') and values.endswith('}')):
			data = self.convertToDict(values)
		#endIf
		self.LOGGER.traceExit([str(data)])
		
		return data
		#endIf
	#endDef
	
	###########################################################
	## Converts a string in the form [...] into a list
	##########################################################
	def convertToList(self, values):
		
		self.LOGGER.traceEnter([str(values)])
		data = []
		values = values.strip()
		if (values.startswith('[')):
			values = values.split('[')[1]
		#endIf
		if (values.endswith(']')):
			values = values.split(']')[0]
		#endIf
		values = values.strip()
		if(len(values) > 0):
			data = values.split(',')
		#endIf
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef
	
	##########################################################
	## Converts a string in the form {a=1, b=2} into a Dict
	##########################################################
	def convertToDict(self, values):
		
		self.LOGGER.traceEnter([str(values)])
		data = {}
		if (values.startswith('{')):
			values = values.split('{')[1]
		#endIf
		if (values.endswith('}')):
			values = values.split('}')[0]
		#endIf
		values = values.strip()
		if(len(values) > 0):
			for elem in values.split(', '):
				if (len (elem) > 0):
					keyValue = elem.split('=')
					data[keyValue[0].strip()] = keyValue[1].strip()
				#endIf
			#endFor
		#endIf
		
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef
	
	##########################################################
	## Converts a string in the form
	## {a=1, b={q=3###r=34}###c=[2,3,45] } into a Dict
	##########################################################
	def convertNestedStrToDict(self, values):
		
		data = {}
		self.LOGGER.traceEnter([str(values)])
		for elem in values.split('###'):
			if (len (elem) > 0):
				ipos = elem.find('=')
				keyName = elem[0:ipos]
				keyValue = elem[ipos + 1:]
				valueData = self.evaluateAttributeValues(keyValue.strip())
				data[keyName.strip()] = valueData
			#endIf
		#endFor
		
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef

	##########################################################
	## Converts a string in the form
	## {a=1, b={q=3, r=34}, c=[2,3,45] } into a Dict
	## Many AdminTask command out put are in the form of
	## dict of list and dict
	##########################################################
	def convertAdminTaskAttrsToDict(self, values):
		
		self.LOGGER.traceEnter([str(values)])
		data = {}
		oList = []
		if(values is None):
			return data
		#endIf
		values = values.strip()
		if ((not values.startswith('{')) and (not values.endswith('}'))):
			return data
		#endIf
		values = values[1:len(values) - 1]
		values = values.strip()
		valList = list(values)
		ilen = len(valList)
		i = 0
		dictCnt = 0
		listCnt = 0
		while i < ilen:
			if (valList[i] == '{'):
				dictCnt = dictCnt + 1
			elif (valList[i] == '['):
				listCnt = listCnt + 1
			elif (valList[i] == '}'):
				dictCnt = dictCnt - 1
			elif (valList[i] == ']'):
				listCnt = listCnt - 1
			#endIf
			if ((dictCnt == 0 and listCnt == 0) and ((valList[i] == ',') and (i < (ilen - 1)) and (valList[i+1] == ' '))):
				oList.extend('###')
			else:
				oList.append(valList[i])
			#endIf
			i = i + 1
		#endWhile
		values = ''.join(oList)
		data = self.convertNestedStrToDict(values)
		
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef
	
	################################################################
	## This method searches realmMapStr and returns a value of keyName.
	## Sample input arguments:
	## keyName = nameInRepository
	## realmMapStr = {nameInRepository=ou=domain,dc=com, specificRepositoryType=CUSTOM, name=o=apacheLdapBasedRealm, repositoryType=LDAP, host=ldapserver.domain.com, id=ApacheLDAPRepository, port=10389}
	## keyList = ['repositoryType=', 'specificRepositoryType=', 'nameInRepository=', 'id=', 'host=', 'name=', 'port=', '}']]
	#################################################################
	
	def getValuesFromMap(self, keyName, realmMapStr, keyList=[]):
		self.LOGGER.traceEnter([keyName, realmMapStr, (str(keyList))])
		
		index = realmMapStr.find(keyName + '=')
		if (index >= 0):
			val = realmMapStr[index + len(keyName + '='):]
		else:
			return ''

		for key in keyList:
			index = val.find(key)
			if (index >= 0):
				val = val[0:index].strip()
		if(val.endswith(',') or val.endswith('}')):
			val = val[0:len(val) - 1]
			val = self.eValuateNullVal(val)
			
		self.LOGGER.traceExit(val)
		
		return val
	#endDef
	
	################################################################
	## This method forms AdminTask command options from a option map
	## as input
	## Any future additional arguments can be appended here using
	## extraArgs var
	#################################################################
	
	def getAdminTaskCommandOptions(self, cmdMap, extraArgs=''):
		
		self.LOGGER.traceEnter([str(cmdMap), extraArgs])
		
		futureExtraArgs = extraArgs
		cmdOptions = ''
		if(len(cmdMap) > 0):
			cmdOptions = '[ '
			for key in cmdMap.keys():
				cmdOptions = cmdOptions + ' -' + key + ' ' + '\"' + cmdMap[key] + '\"' + ' '
			#endFor
			cmdOptions = cmdOptions + futureExtraArgs + ' ]'
		else:
			cmdOptions = '' + futureExtraArgs
		#endIf
		
		self.LOGGER.traceExit(cmdOptions)
		
		return cmdOptions
	#endDef
	
	################################################################
	## This method forms AdminTask command options from a RAFW data[attrs]
	## node based on the attribute list in attrList
	## Any future additional arguments can be appended here using
	## extraArgs var
	#################################################################
	
	def getCmdOptionsFromRafwConfig(self, attrList, attrMap, childTypeName=None, extraArgs=''):
		
		futureExtraArgs = extraArgs
		cmdOptions = ''
		self.LOGGER.traceEnter([str(attrList), str(attrMap), childTypeName, extraArgs])
		if(len(attrList) > 0 and len(attrMap) > 0):
			for attr in attrList:
				if(attrMap.has_key(attr)):
					atrName = attr
					atrValue = attrMap[atrName]
					if(len(atrValue) > 0):
						cmdOptions = cmdOptions + ' -' + atrName + ' ' + '\"' + atrValue + '\"' + ' '
					#endIf
					del attrMap[atrName]
				#endIf
			#endFor
		#endIf
		if(childTypeName is not None and len(childTypeName) > 0):
			extraAttributes = attrMap.keys()
			if(len(extraAttributes) > 0):
				msg = self.getLocalizedMessage("CRWWA0167W", [str(extraAttributes), childTypeName, scope])
				self.LOGGER.warn(msg)
		
		cmdOptions = cmdOptions + futureExtraArgs
		
		self.LOGGER.traceExit(cmdOptions)
		
		return cmdOptions
	#endDef
	
	def removeItemsSrcListFromTargetList(self, srcList, tgtList):
		
		if(len(srcList) > 0 and len(tgtList) > 0):
			for elem in srcList:
				if (len(tgtList) > 0):
					tgtList.remove(elem)
				#endIf
			#endFor
		#endIf
		
	#endDef
	
	def getLocalizedMessage(self, msgId, parameList=[]):
		return MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, msgId, parameList)
	#endDef
	
	#####################################################################
	## This method obtains the required parameter for AdminTask command
	## from RAFW config. If the attribute or element used for command 
	## option not present in RAFW config throws InvalidXmlException
	#####################################################################
	
	def getWIMCLIRequiredValue(self, attrName, nameValMap, childType):
		
		self.LOGGER.traceEnter([attrName, str(nameValMap), childType])
		
		missingValue = 0
		value = ''
		if (nameValMap.has_key(attrName)):
			value = nameValMap[attrName]
			value = value.strip()
			if(len(value) == 0):
				missingValue = 1
			#endIf
		else:
			missingValue = 1
		#endIf
		if (missingValue == 1):
			msg = self.getLocalizedMessage("CRWWA0165E", [attrName, childType, scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		#endIf
		self.LOGGER.traceExit(value)
		
		return value
	#endDef

	#####################################################################
	## This method obtains the WIM multi-valued parameter for AdminTask 
	## command from RAFW config.
	## Returns the value as a;b;c ..etc or '' if nothing is present in 
	## RAFW config
	#####################################################################
	
	def getWIMMultiValuesByType(self, rafwConfig, childType):
		
		self.LOGGER.traceEnter([str(rafwConfig), childType])
		valueList = []
		removeList = []
		for childData in rafwConfig[CHILDREN]:
			if (childData[ID] == childType):
				removeList.append(childData)
				if(childData[ATTRS].has_key(VALUE)):
					value = childData[ATTRS][VALUE]
					value = value.strip()
					if(len(value) > 0):
						valueList.append(value)
					#endIf
					self.LOGGER.trace("Getting " + childType + " as : " + value)
				else:
					msg = self.getLocalizedMessage("CRWWA0165E", [VALUE, childType, scope])
					self.LOGGER.error(msg)
					raise InvalidXmlConfigException(msg)
				#endIf
			#endIf
		#endFor
		paramVal = ''
		for iVal in valueList:
			paramVal = paramVal + ';' + iVal
		#endFor
		paramVal = paramVal.replace(';', '', 1)
		
		#clean the child elements already processed
		self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
		
		self.LOGGER.traceExit(paramVal)
		
		return paramVal
	#endDef
	
	######################################################################################
	## This method returns true if the installed version is same or higher than
	## the required version passed as input parameter or else it returns false
	## Remember the comparison is done at specific WAS level, for example if 
	## required version is 6.1.0.31, then it will return true if the installed version
	## is 6.1.0.31 or higher, but it will not return true if the installed version is
	## at different level such as 7.0.0.9..etc. Always returns true for installed version
	## greater than or equal to 8
	########################################################################################
	
	def isApplicableForWASVersionLevel(self, requiredVersion):
		
		self.LOGGER.traceEnter(requiredVersion)
		
		retVal = 0
		self.LOGGER.debug('Required WAS Version is ' + requiredVersion)
		if ((requiredVersion is None) or len(requiredVersion) == 0):
			retVal = 0
		else:
			installedVersion = self.getNodeBaseProductVersion()
			inVerList = installedVersion.split('.')
			reqVerList = requiredVersion.split('.')
			inVerLevel = int(inVerList[0])
			reqVerLevel = int(reqVerList[0])
			if(inVerLevel == reqVerLevel):
				retVal = self.isApplicableForWASVersion(requiredVersion)
			#For version 8.0 or higher than taht
			elif(inVerLevel > 8 or inVerLevel == 8):
				retVal = 1
			#endIf
		#endIf
		
		self.LOGGER.traceExit(str(retVal))
		return retVal
	#endDef
	
	def getNodeBaseProductVersion(self):
		
		self.LOGGER.traceEnter()
		cmdOptions = ''
		self.LOGGER.debug('AdminControl.getNode(' + cmdOptions + ')')
		nodeName = AdminControl.getNode()
		cmdOptions = '[-nodeName ' + nodeName + ' ]'
		self.LOGGER.debug('AdminTask.getNodeBaseProductVersion(' + cmdOptions + ')')
		installedVersion = AdminTask.getNodeBaseProductVersion(cmdOptions)
		
		self.LOGGER.traceExit(str(installedVersion))
		
		return installedVersion
	#endDef

	######################################################################################
	## This method returns true if the installed version is same or higher than
	## the required version passed as input parameter or else it returns false
	########################################################################################
		
	def isApplicableForWASVersion(self, requiredVersion):
		
		self.LOGGER.traceEnter(requiredVersion)
		
		retVal = 0
		self.LOGGER.trace('Required WAS Version is ' + requiredVersion)
		if ((requiredVersion is None) or len(requiredVersion) == 0):
			retVal = 0
		else:
			installedVersion = self.getNodeBaseProductVersion()
			self.LOGGER.trace('Installed WAS Version is ' + installedVersion)
			installedVersionList = installedVersion.split('.')
			requiredVersionList = requiredVersion.split('.')
			
			if (len(installedVersionList) > len(requiredVersionList)):
				iCnt = len(installedVersionList) - len(requiredVersionList)
				while iCnt > 0:
					requiredVersionList.append('0')
					iCnt = iCnt - 1
				#endWhile
			elif (len(requiredVersionList) > len(installedVersionList)):
				iCnt = len(requiredVersionList) - len(installedVersionList)
				while iCnt > 0:
					installedVersionList.append('0')
					iCnt = iCnt - 1
				#endWhile
			#endIf
			iDigit = 0
			retVal = 1
			while iDigit < len(requiredVersionList):
				inVer = int(installedVersionList[iDigit])
				reqVer = int(requiredVersionList[iDigit])
				iDigit = iDigit + 1
				if(inVer > reqVer):
					retVal = 1
					break
				elif (inVer < reqVer):
					retVal = 0
					break
				#endIf
			#endWhile
		#endIf
		self.LOGGER.traceExit(str(retVal))
		
		return retVal
	#endDef
	
	def getWASRepositoryListMap(self):
		
		self.LOGGER.traceEnter()
		cmdOptions = ''
		self.LOGGER.debug('AdminTask.listIdMgrRepositories(' + cmdOptions + ')')
		rids = AdminTask.listIdMgrRepositories(cmdOptions)
		repoMap = self.convertAdminTaskAttrsToDict(rids)
		if(len(repoMap) == 0):
			repoMap = {}
		#endIf
		self.LOGGER.traceExit(str(repoMap))
		return repoMap
	#endDef
	
	def isRepositoryExists(self, id):
		repoMap = self.getWASRepositoryListMap()
		if(repoMap.has_key(id)):
			return 1
		#endIf
		
		return 0
#end CLASS




############## CLASS :: RepoConfigHelper ########################################
# This class is used to manage the configuration data of Federated Security		#
# Repository Configuration . This manages generic and custom repository			#
# configs																		#
#																				#
#																				#
#################################################################################
class RepoConfigHelper(WIMConfigReaderHelper):
	
	############################################################################
	## This constructor initializes all the attributes and childType names
	## used define a Repository config object in Federated Security
	############################################################################
	def __init__(self):
		
		self.LOGGER = _Logger("RepoConfigHelper", MessageManager.RB_WEBSPHERE_WAS)
		self.profileRepoType = 'repositories'
		self.repoChildTypes = [ 'baseEntries', 'EntityTypesNotAllowCreate', 'EntityTypesNotAllowUpdate',
						'EntityTypesNotAllowRead', 'EntityTypesNotAllowDelete', 'repositoriesForGroups',
						'loginProperties', 'CustomProperties' ]
		self.repoAttributes = ['id', 'adapterClassName', 'readOnly', 'supportPaging', 'supportSorting', 'supportTransactions',
						'isExtIdUnique', 'supportExternalName', 'supportAsyncMode']

	#######################################################################
	## A private method that reads the repository child element
	#######################################################################
	def getRepoChildData(self, id, inputmap):
		
		self.LOGGER.traceEnter([id, str(inputmap)])
		
		childTypes = self.repoChildTypes
		childElemList = []
		#endDef
		for childType in childTypes:
			if (not childType == 'CustomProperties'):
				if(inputmap.has_key(childType)):
					if(childType == 'baseEntries'):
						realmHelper = WIMConfigManager.getRealmHelper()
						realmDataList = realmHelper.getUniqueBasentryWithRealmForRepository(id)
						if(len(realmDataList) > 0):
							for realmData in realmDataList:
								baseEntry = realmData[BASE_ENTRY_NAME]
								if (not id == INBUILT_PROFILEREPO_ID and not baseEntry == INBUILT_FILEREPO_BASEENTRY):
									child = {}
									child[ID] = childType
									child[ATTRS] = {}
									child[CHILDREN] = []
									child[ATTRS][NAME] = realmData[BASE_ENTRY_NAME]
									child[ATTRS][NAME_IN_REPO] = realmData[NAME_IN_REPO]
									childElemList.append(child)
								#endIf
							#endFor
						else:
							child = {}
							child[ID] = childType
							child[ATTRS] = {}
							child[CHILDREN] = []
							child[ATTRS][NAME] = ''
							child[ATTRS]['nameInRepository'] = ''
							childElemList.append(child)
						#endIf
					else:
						for val in inputmap[childType]:
							child = {}
							child[ID] = childType
							child[ATTRS] = {}
							child[CHILDREN] = []
							child[ATTRS][VALUE] = self.eValuateNullVal(val)
							childElemList.append(child)
						#endFor
					#endIf
					
					del inputmap[childType]
				#endIf
			else:
				if (inputmap.has_key(childType)):
					customProp = inputmap[childType]
					for keyName in customProp.keys():
						child = {}
						child[ID] = childType
						child[ATTRS] = {}
						child[CHILDREN] = []
						child[ATTRS][NAME] = keyName
						child[ATTRS][VALUE] = self.eValuateNullVal(customProp[keyName])
						childElemList.append(child)
					#endFor
					del inputmap[childType]
				#endIf
			#endIf
		#endFor
		self.LOGGER.traceExit([str(childElemList)])
		
		return childElemList
	
	#endDef
	
	###########################################################################
	## Private method that update the repository Custom prop children elements
	###########################################################################
	
	def updateRepositoryChildDataCustomProp(self, repoId, rafwConfig, wasConfig, childType):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig), childType ])
		removeList = []
		if (childType == 'CustomProperties'):
			#Delete the existing data if any
			for childWASData in wasConfig[CHILDREN]:
				if (childWASData[ID] == childType):
					if(childWASData[ATTRS].has_key(NAME)):
						self.LOGGER.trace("Deleting the property : " + childWASData[ATTRS][NAME] + " for type " + childType + " of repository with id : " + repoId)
						cmdMap = {}
						cmdMap[ID] = repoId
						cmdMap[NAME] = childWASData[ATTRS][NAME]
						cmdMap[VALUE] = ''
						cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
						self.LOGGER.debug('AdminTask.setIdMgrCustomProperty(' + cmdOptions + ')')
						AdminTask.setIdMgrCustomProperty(cmdOptions)
					#endIf
				#endIf
			#endFor
			
			#Create custom property data if any
			for childData in rafwConfig[CHILDREN]:
				if (childData[ID] == childType):
					removeList.append(childData)
					if(childData[ATTRS].has_key(NAME)):
						if(childData[ATTRS].has_key(VALUE)):
							propVal = childData[ATTRS][VALUE]
						else:
							propVal = ''
						#endIf
						if(len(propVal) > 0):
							self.LOGGER.trace("Creating the property : " + childData[ATTRS][NAME] + " for type " + childType + " of repository with id : " + repoId)
							cmdMap = {}
							cmdMap[ID] = repoId
							cmdMap[NAME] = childData[ATTRS][NAME]
							cmdMap[VALUE] = propVal
							cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
							self.LOGGER.debug('AdminTask.setIdMgrCustomProperty(' + cmdOptions + ')')
							AdminTask.setIdMgrCustomProperty(cmdOptions)
						else:
							self.LOGGER.trace("Skipping the creation of empty value property : " + childData[ATTRS][NAME] + " for type " + childType + " of repository with id : " + repoId)
						#endIf
					else:
						msg = self.getLocalizedMessage("CRWWA0165E", [NAME, childType, scope])
						self.LOGGER.error(msg)
						raise InvalidXmlConfigException(msg)
					#endIf
				#endIf
			#endFor
			#clean the child elements already processed
			self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
			
			self.LOGGER.traceExit()
		#endIf
		
	#endDef
	
	#######################################################################
	## Updates the repository child data
	#######################################################################
	
	def updateRepositoryChildData(self, repoId, rafwConfig, childType):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), childType ])
		
		paramVal = ''
		#Delete the exsting data if any
		self.LOGGER.trace("Deleting existing data for " + childType + " of repository with id : " + repoId)
		cmdMap = {}
		cmdMap[ID] = repoId
		cmdMap[childType] = paramVal
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.updateIdMgrRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrRepository(cmdOptions)
		
		paramVal = self.getWIMMultiValuesByType(rafwConfig, childType)
		
		#Recreate the data if paramVal is not empty
		if(len(paramVal) > 0):
			self.LOGGER.trace("Adding new data : " + paramVal + " for " + childType + " for repository with id : " + repoId)
			cmdMap = {}
			cmdMap[ID] = repoId
			cmdMap[childType] = paramVal
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.updateIdMgrRepository(' + cmdOptions + ')')
			AdminTask.updateIdMgrRepository(cmdOptions)
		else:
			self.LOGGER.trace("No data found for " + childType + " for repository with id : " + repoId)
		
		self.LOGGER.traceExit()
	#endDef
	
	############################################################################
	## This method deletes the base entries that are existing in realms for that
	## repository but not added by execute mode
	###########################################################################
	
	def deleteExistingRealmDataForRepo(self, repoId, rafwConfig, addedBEntryListMap):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(addedBEntryListMap) ])
		
		realmHelper = WIMConfigManager.getRealmHelper()
		realmDataList = realmHelper.getUniqueBasentryWithRealmForRepository(repoId)
		#RealmHelper.deleteAllRepoBaseEntriesFromRealms(repoId)
		if(len(realmDataList) > 0):
			for realmData in realmDataList:
				baseEntryName = realmData[BASE_ENTRY_NAME]
				if(not addedBEntryListMap.has_key(baseEntryName) and not repoId == INBUILT_PROFILEREPO_ID):
					cmdMap = {}
					cmdMap[ID] = repoId
					cmdMap[NAME] = baseEntryName
					cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
					self.LOGGER.debug('AdminTask.deleteIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
					print('AdminTask.deleteIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
					AdminTask.deleteIdMgrRepositoryBaseEntry(cmdOptions)
				#endIf
			#endFor
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
	##################################################################
	## This method checks if a specific base entry that we get from an
	## associated realm exists in repository base entry list or not
	##################################################################
	
	def isBaseEntryExistInRepository(self, repoId, bEntName):
		
		self.LOGGER.traceEnter([repoId, bEntName ])
		
		name = bEntName.replace(' ', '')
		retVal = 0
		nameToSearch = name + '='
		cmdMap = {}
		cmdMap[ID] = repoId
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrRepositoryBaseEntries(' + cmdOptions + ')')
		repoBaseEntry = AdminTask.listIdMgrRepositoryBaseEntries(cmdOptions)
		repoBaseEntry = repoBaseEntry.replace(' ', '')
		retVal = repoBaseEntry.find(nameToSearch)
		if(retVal is None or retVal == -1):
			retVal = 0
		else:
			retVal = 1
		#endIf
		self.LOGGER.traceExit(str(retVal))
		
		return retVal
	
	#endDef
	##########################################################################
	## This method updates the base entries specified in RAF config
	##########################################################################
	
	def updateIdMgrRepositoryBaseEntries(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig)])
		childType = 'baseEntries'
		removeList = []
		addedBEntryListMap = {}
		addedFlag = 0
		for configNode in rafwConfig[CHILDREN]:
			if(configNode[ID] == 'baseEntries'):
				removeList.append(configNode)
				name = self.getWIMCLIRequiredValue(NAME, configNode[ATTRS], childType)
				addedBEntryListMap[name] = 1
				addedFlag = 1
				cmdMap = {}
				cmdMap[ID] = repoId
				cmdMap[NAME] = name
				if (configNode[ATTRS].has_key('nameInRepository') and
					len(configNode[ATTRS]['nameInRepository']) > 0):
					cmdMap['nameInRepository'] = configNode[ATTRS]['nameInRepository']
				#endIf
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				try:
					if(not self.isBaseEntryExistInRepository(repoId, name)):
						self.LOGGER.debug('AdminTask.addIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
						#print('AdminTask.addIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
						AdminTask.addIdMgrRepositoryBaseEntry(cmdOptions)
					else:
						self.LOGGER.debug('AdminTask.updateIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
						#self.LOGGER.warn(sys.exc_info()[1])
						#print('AdminTask.updateIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
						AdminTask.updateIdMgrRepositoryBaseEntry(cmdOptions)
					#endIf
				except:
					#The following code will be removed once we have listIdMgrRepositoryBaseEntries
					#is in right format. It will most likely not be executed until and unless
					#WIM config content data is not in standard format such as c=us, o = ibm ..etc
					self.LOGGER.trace(sys.exc_info()[1])
					self.LOGGER.debug('AdminTask.updateIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
					#print('AdminTask.updateIdMgrRepositoryBaseEntry(' + cmdOptions + ')')
					AdminTask.updateIdMgrRepositoryBaseEntry(cmdOptions)
				#endTry
				
				#Adds base entry to the default realm
				realmHelper = WIMConfigManager.getRealmHelper()
				realmHelper.addIdMgrRealmBaseEntry(INBUILT_DEFAULT_REALM, name)
			#endIf
		#endFor
		
		#If something is added delete existing realms for the repository
		if(addedFlag):
			self.deleteExistingRealmDataForRepo(repoId, rafwConfig, addedBEntryListMap)
		else:
			if(not repoId == INBUILT_PROFILEREPO_ID):
				msg = self.getLocalizedMessage("CRWWA0174E", [repoId, scope])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException(msg)
			#endIf
		#endIf
		self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
		
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates the WAS repository type child elements and their attributes
	#######################################################################				 
	
	def updateRepositoryChildrenData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig)])
		childTypes = self.repoChildTypes
		removeList = []
		for childType in childTypes:
			if (not childType == 'CustomProperties'):
				if(not childType == 'baseEntries'):
					self.updateRepositoryChildData(repoId, rafwConfig, childType)
				#endIf
			else:
				self.updateRepositoryChildDataCustomProp(repoId, rafwConfig, wasConfig, childType)
			#endIf
		#endFor
		
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates the repository base type content using exsting rafwConfig data
	## and existing wasConfig data
	####################################################################### 
	
	def updateIdMgrRepositoryData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig)])
		repoAttrList = self.repoAttributes
		if(self.isApplicableForWASVersion('7.0.0.7')):
			repoAttrList.append('supportChangeLog')
		#endIf
		
		attrOptions = self.getCmdOptionsFromRafwConfig(repoAttrList, rafwConfig[ATTRS])
		cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
		self.LOGGER.debug('AdminTask.updateIdMgrRepository(' + cmdOptions + ')')
		#print('AdminTask.updateIdMgrRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrRepository(cmdOptions)
		self.LOGGER.traceExit()
	#endDef
	#######################################################################
	## Updates the custom repository data
	## This method reads the existing was config which is passed to
	## the subsequent updates methods for updating specific data based on
	## existing was config data
	#######################################################################
	def updateIdMgrCustomRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig)])
		
		wasConfig = self.readRepositoryConfigData(repoId)
		self.updateIdMgrRepositoryData(repoId, rafwConfig, wasConfig)
		self.updateIdMgrRepositoryBaseEntries(repoId, rafwConfig, wasConfig)
		
		self.LOGGER.traceExit()
		
	#endDef
	
	
	##########################################################
	## Reads the repository config from WAS
	##########################################################
	def readRepositoryConfigData(self, id):
		
		self.LOGGER.traceEnter([id])
		
		cmdMap = {}
		cmdMap['id'] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrRepository(' + cmdOptions + ')')
		repositoryMap = AdminTask.getIdMgrRepository(cmdOptions)
		repositoryMap = self.convertAdminTaskAttrsToDict(repositoryMap)
		children = self.getRepoChildData(id, repositoryMap)
	
		parent = {}
		parent[ID] = CUSTOM_TYPE
		parent[ATTRS] = {}
		parent[CHILDREN] = children
		
		for keyName in repositoryMap.keys():
			parent[ATTRS][keyName] = self.eValuateNullVal(repositoryMap[keyName])
		#endFor
		#parent[ATTRS][REPO_TYPE] = CUSTOM_TYPE
		
		self.LOGGER.traceExit(str(parent))
		
		return parent
	#endDef
	#######################################################################
	## Creates a custom repository
	#######################################################################
	def createIdMgrCustomRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig)])
		
		adapterClassName = self.getWIMCLIRequiredValue('adapterClassName', rafwConfig[ATTRS], currentConfigType)
		cmdMap = {}
		cmdMap[ID] = repoId
		cmdMap['adapterClassName'] = adapterClassName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.createIdMgrCustomRepository (' + cmdOptions + ')')
		#print('AdminTask.createIdMgrCustomRepository (' + cmdOptions + ')')
		AdminTask.createIdMgrCustomRepository (cmdOptions)
		
		#Then update the registry
		self.updateIdMgrCustomRepository(repoId, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## This method creates a new repository config or updates the same based
	## on the repository config in WAS
	####################################################################### 
	
	def createRepositoryConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		repoId = rafwConfig[ATTRS][ID]
		notSupported = 1
		if(rafwConfig[ID] == CUSTOM_TYPE):
			if(self.isApplicableForWASVersion(CUSTOM_REPO_VERSION)):
				notSupported = 0
				if(self.isRepositoryExists(repoId)):
					#print "updateIdMgrCustomRepository: updating the registry with id " + repoId
					self.updateIdMgrCustomRepository(repoId, rafwConfig)
				else:
					#print "createIdMgrCustomRepository : creating the registry with id " + repoId
					self.createIdMgrCustomRepository(repoId, rafwConfig)
			#endIf
		#endIf
		if(notSupported):
			currentProdVersion = self.getNodeBaseProductVersion()
			msg = self.getLocalizedMessage("CRWWA0172W", [repoType, scope, currentProdVersion])
			self.LOGGER.warn(msg)
		#endIf
		self.LOGGER.traceExit()
	#endDef




#end class



############## CLASS :: FileRepoConfigHelper ################
# This class is used to manage the configuration data of	#
# Federated Security File Repository						#
#															#
#															#
#############################################################
class FileRepoConfigHelper(RepoConfigHelper):

	##############################################################
	## This constructor File repository specific attribute names
	##############################################################
	def __init__(self):
		RepoConfigHelper.__init__(self)
		self.LOGGER = _Logger("FileRepoConfigHelper", MessageManager.RB_WEBSPHERE_WAS)
		self.repoFileChildAttributes = ['baseDirectory', 'fileName', 'saltLength', 'messageDigestAlgorithm',
										'caseSensitive']

	#######################################################################
	## This method delegated the call to Repository getChildata to get the 
	## children of a File repository
	#######################################################################
	def getFileChildData(self, id, inputmap):
		
		self.LOGGER.traceEnter([id, str(inputmap)])
		
		childElemList = self.getRepoChildData(id, inputmap)
		
		self.LOGGER.traceExit(str(childElemList))
		
		return childElemList
	#endDef
	
	##############################################################
	## This method reads the File Repository config data from WAS
	##############################################################
	def readRepositoryConfigData(self, id):
		
		self.LOGGER.traceEnter([id])
		
		excludeAttributes = ['adapterClassName']
		parent = RepoConfigHelper.readRepositoryConfigData(self, id)
		parent[ID] = FILE_TYPE
		
		if(id == INBUILT_PROFILEREPO_ID):
			parent[ID] = 'builtin'
			for exAttr in excludeAttributes:
				if(parent[ATTRS].has_key(exAttr)):
					del parent[ATTRS][exAttr]
				#endIf
			#endFor
		#endIf
		self.LOGGER.traceExit(str(parent))
		
		return parent
	#endDef
	#######################################################################
	## This method updates the existing file repository data
	#######################################################################
	def updateIdMgrFileRepositoryData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig)])
		
		# First update repository data
		self.updateIdMgrRepositoryData(repoId, rafwConfig, wasConfig)
		self.updateRepositoryChildrenData(repoId, rafwConfig, wasConfig)
		
		# Now update file repository data
		repoAttrList = self.repoFileChildAttributes
		attrOptions = self.getCmdOptionsFromRafwConfig(repoAttrList, rafwConfig[ATTRS], 'repositories')
		cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
		self.LOGGER.debug('AdminTask.updateIdMgrFileRepository(' + cmdOptions + ')')
		#print('AdminTask.updateIdMgrFileRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrFileRepository(cmdOptions)
		
		self.LOGGER.traceExit()
	#endDef
		
		
	#######################################################################
	## Updates the File Repository data
	#######################################################################
	def updateIdMgrFileRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig)])
		
		wasConfig = self.readRepositoryConfigData(repoId)
		self.updateIdMgrFileRepositoryData(repoId, rafwConfig, wasConfig)
		self.updateIdMgrRepositoryBaseEntries(repoId, rafwConfig, wasConfig)
		
		self.LOGGER.traceExit()
	#endDef
	#######################################################################
	## Creates a new File repository in WAS
	#######################################################################
	def createIdMgrFileRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig)])
		
		messageDigestAlgorithm = self.getWIMCLIRequiredValue('messageDigestAlgorithm', rafwConfig[ATTRS], currentConfigType)
		cmdMap = {}
		cmdMap[ID] = repoId
		cmdMap['messageDigestAlgorithm'] = messageDigestAlgorithm
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.createIdMgrFileRepository(' + cmdOptions + ')')
		#print('AdminTask.createIdMgrFileRepository(' + cmdOptions + ')')
		AdminTask.createIdMgrFileRepository(cmdOptions)
		
		#Then update the registry
		self.updateIdMgrFileRepository(repoId, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	##this method creates or updates a existing file repository
	####################################################################### 
	
	def createRepositoryConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		repoId = rafwConfig[ATTRS][ID]
		if(self.isRepositoryExists(repoId) or repoId == INBUILT_PROFILEREPO_ID):
			#print "updateIdMgrFileRepository : updating the registry with id " + repoId
			self.updateIdMgrFileRepository(repoId, rafwConfig)
		else:
			#print "createIdMgrFileRepository : creating the registry with id " + repoId
			self.createIdMgrFileRepository(repoId, rafwConfig)
		#endIf
		self.LOGGER.traceExit()
	#endDef


############## CLASS :: DBRepoConfigHelper ###############
# This class is used to manage the configuration data of #
# Federated Security DB repository						 #
#														 #
#														 #
##########################################################
class DBRepoConfigHelper(RepoConfigHelper):

	##########################################################
	## This constructor initializes the DB repository specific
	## attributes
	##########################################################
	def __init__(self):
		RepoConfigHelper.__init__(self)
		self.LOGGER = _Logger("DBRepoConfigHelper", MessageManager.RB_WEBSPHERE_WAS)
		self.repoDBChildAttributes = ['dataSourceName', 'databaseType', 'dbURL', 'dbAdminId', 'dbAdminPassword',
									'JDBCDriverClass', 'entityRetrievalLimit', 'saltLength', 'encryptionKey']
 
	#######################################################################
	## Updates the DB repository specific data
	#######################################################################
	
	def updateIdMgrDBRepositoryData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig), str(wasConfig)])
		
		# first update repository data
		self.updateIdMgrRepositoryData(repoId, rafwConfig, wasConfig)
		
		# then update ldap repository data
		repoAttrList = self.repoDBChildAttributes
		
		attrOptions = self.getCmdOptionsFromRafwConfig(repoAttrList, rafwConfig[ATTRS], 'repositories')
		cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
		self.LOGGER.debug('AdminTask.updateIdMgrDBRepository(' + cmdOptions + ')')
		#print('AdminTask.updateIdMgrDBRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrDBRepository(cmdOptions)
		
		self.LOGGER.traceExit()
	#endDef
		
		
	#######################################################################
	## Updates the DB repository specific data
	#######################################################################
	
	def updateIdMgrDBRepository(self, repoId, rafwConfig):
		
		wasConfig = self.readRepositoryConfigData(repoId)
		self.updateIdMgrDBRepositoryData(repoId, rafwConfig, wasConfig)
		self.updateIdMgrRepositoryBaseEntries(repoId, rafwConfig, wasConfig)
		
	#endDef
	#######################################################################
	## Creates a new DB repository config data in WAS
	#######################################################################
	
	def createIdMgrDBRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([repoId, str(rafwConfig)])
		cmdMap = {}
		cmdMap[ID] = repoId
		cmdMap['dataSourceName'] = self.getWIMCLIRequiredValue('dataSourceName', rafwConfig[ATTRS], currentConfigType)
		cmdMap['databaseType'] = self.getWIMCLIRequiredValue('databaseType', rafwConfig[ATTRS], currentConfigType)
		cmdMap['dbURL'] = self.getWIMCLIRequiredValue('dbURL', rafwConfig[ATTRS], currentConfigType)
		if(rafwConfig[ATTRS].has_key('dbAdminId')):
			cmdMap['dbAdminId'] = rafwConfig[ATTRS]['dbAdminId']
		else:
			cmdMap['dbAdminId'] = ''
		#endIf
		if(rafwConfig[ATTRS].has_key('dbAdminPassword')):
			cmdMap['dbAdminPassword'] = rafwConfig[ATTRS]['dbAdminPassword']
		else:
			cmdMap['dbAdminPassword'] = ''
		#endIf
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		
		self.LOGGER.debug('AdminTask.createIdMgrDBRepository(' + cmdOptions + ')')
		#print('AdminTask.createIdMgrDBRepository(' + cmdOptions + ')')
		AdminTask.createIdMgrDBRepository(cmdOptions)
		
		#Then update the registry
		self.updateIdMgrDBRepository(repoId, rafwConfig)
		self.LOGGER.traceExit()
		
	#endDef
	
	#######################################################################
	## This method creates or updates a DB repository config data in WAS
	####################################################################### 
	
	def createRepositoryConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		repoId = rafwConfig[ATTRS][ID]
		if(self.isRepositoryExists(repoId)):
			print "updateIdMgrDBRepository : updating the registry with id " + repoId
			self.updateIdMgrDBRepository(repoId, rafwConfig)
		else:
			print "createIdMgrDBRepository : creating the registry with id " + repoId
			self.createIdMgrDBRepository(repoId, rafwConfig)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
	##########################################################
	## This method reads the DB repository specific data
	##########################################################
	def readRepositoryConfigData(self, id):
		
		parent = RepoConfigHelper.readRepositoryConfigData(self, id)
		parent[ID] = DB_TYPE
		
		return parent
	#endDef
	




############## CLASS :: LdapRepoConfigHelper ################
# This class is used to manage the configuration data of	#
# LDAP repository in Federated Security						#
#															#
#															#
#############################################################
class LdapRepoConfigHelper(RepoConfigHelper):

	#####################################################################
	## This constructor initializes all the attributes and child types	#
	## of LDAP repository config schema									# 
	#####################################################################
	def __init__(self):
		RepoConfigHelper.__init__(self)
		self.LOGGER = _Logger("RepoConfigHelper", MessageManager.RB_WEBSPHERE_WAS)
		self.repoLdapChildTypes = ['ldapServerConfiguration', 'ldapEntityTypes', 'groupConfiguration',
									'attributeConfiguration', 'contextPool', 'cacheConfiguration']
		self.repoLdapChildAttributes = ['ldapServerType', 'certificateMapMode', 'certificateFilter',
										'translateRDN']
		self.repoLdapEntityTypeChildTypes = ['rdnAttributes', 'objectClasses', 'objectClassesForCreate', 'searchBases']
		self.ldapTypeAttributeMap = {}
		self.ldapTypeAttributeMap['ldapServerConfiguration'] = ['searchTimeLimit', 'searchCountLimit', 'searchPageSize',
						'sslConfiguration', 'returnToPrimaryServer', 'primaryServerQueryTimeInterval']
		self.ldapTypeAttributeMap['attributesCache'] = ['enabled', 'cacheSize', 'cacheTimeOut', 'attributeSizeLimit',
														 'serverTTLAttribute', 'cacheDistPolicy']
		self.ldapTypeAttributeMap['searchResultsCache'] = ['enabled', 'cacheSize', 'cacheTimeOut', 'searchResultSizeLimit',
															'cacheDistPolicy']
		self.ldapTypeAttributeMap['contextPool'] = ['enabled', 'initPoolSize', 'maxPoolSize', 'prefPoolSize',
													'poolTimeOut', 'poolWaitTime']
		self.ldapTypeAttributeMap['ldapServers'] = ['bindDN', 'bindPassword', 'authentication', 'referal',
													'derefAliases', 'sslEnabled', 'connectionPool', 'connectTimeout']
		
	def getServerList(self, id, inputmap):

		self.LOGGER.traceEnter([str(id), str(inputmap)])
		childElemList = []
		data = {}
		data[ID] = 'connections'
		data[ATTRS] = {}
		data[ATTRS]['host'] = self.eValuateNullVal(inputmap['host'])
		del inputmap['host']
		data[ATTRS]['port'] = self.eValuateNullVal(inputmap['port'])
		del inputmap['port']
		data[CHILDREN] = []
		childElemList.append(data)
		
		#fix for 6.1 as it doesnt like id's with spaces in them.
		cmdOptions = '[-id "' + id + '" -primary_host ' + data[ATTRS]['host'] + ' ]' 
		self.LOGGER.debug('AdminTask.listIdMgrLDAPBackupServers(' + cmdOptions + ')')
		outStr = AdminTask.listIdMgrLDAPBackupServers(cmdOptions)
		
		if(len(outStr) > 0):
			outStrList = outStr.split(newline)
			for backuServerMap in outStrList:
				backuServerMap = self.convertToDict(backuServerMap)
				data = {}
				data[ID] = 'connections'
				data[ATTRS] = {}
				keys = backuServerMap.keys()
				data[ATTRS]['host'] = self.eValuateNullVal(keys[0])
				data[ATTRS]['port'] = self.eValuateNullVal(backuServerMap[keys[0]])
				data[CHILDREN] = []
				childElemList.append(data)
			#endFor
		
		#endIf
		if (inputmap.has_key('environmentProperties')):
			customProp = inputmap['environmentProperties']
			for keyName in customProp.keys():
				data = {}
				data[ID] = 'environmentProperties'
				data[ATTRS] = {}
				data[CHILDREN] = []
				data[ATTRS][NAME] = keyName
				data[ATTRS][VALUE] = self.eValuateNullVal(customProp[keyName])
				childElemList.append(child)
			#endFor
			del inputmap['environmentProperties']
			#endIf
		
		self.LOGGER.traceExit([str(childElemList)])
		
		return childElemList
	#endDef
		
	############################################################
	## This method reads all the server configured for a LDAP
	## repository instance from WAS config
	############################################################
	def getLdapServers(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		
		removeList = ['id', 'ldapServerType', 'certificateMapMode', 'certificateFilter', 'sslConfiguration']
		serverElems = []
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrLDAPServers(' + cmdOptions + ')')
		outStr = AdminTask.listIdMgrLDAPServers(cmdOptions)
		if(len(outStr) > 0):
			PrimaryServIdList = outStr.split(newline)
			for PrimaryServ in PrimaryServIdList:
				ldapServerData = {}
				ldapServerData[ID] = 'ldapServers'
				ldapServerData[CHILDREN] = []
				ldapServerData[ATTRS] = {}
				cmdMap = {}
				cmdMap[ID] = id
				cmdMap['host'] = PrimaryServ
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				self.LOGGER.debug('AdminTask.getIdMgrLDAPServer(' + cmdOptions + ')')
				servMap = AdminTask.getIdMgrLDAPServer(cmdOptions)
				servMap = self.convertAdminTaskAttrsToDict(servMap)
				ldapServerData[CHILDREN] = self.getServerList(id, servMap)
				for elemKey in removeList:
					if(servMap.has_key(elemKey)):
						del servMap[elemKey]
					#endIf
				#endFor
				for keyName in servMap.keys():
					ldapServerData[ATTRS][keyName] = self.eValuateNullVal(servMap[keyName])
				#endFor
				serverElems.append(ldapServerData)
			#endFor
		#endIf
		
		self.LOGGER.traceExit(str(serverElems))
		
		return serverElems
	#endDef
		
		
 
	
	#######################################################################
	## Reads LAP repository server configuration attributes and also server 
	## elements
	#######################################################################
	def getLdapServerConfigurationData(self, id, inputmap):
		
		self.LOGGER.traceEnter([str(id), str(inputmap)])
		
		sConfigAttr = self.ldapTypeAttributeMap['ldapServerConfiguration']
		data = {}
		data[ID] = 'ldapServerConfiguration'
		data[ATTRS] = {}
		data[CHILDREN] = []
		
		for attrName in sConfigAttr:
			if (inputmap.has_key(attrName)):
				data[ATTRS][attrName] = self.eValuateNullVal(inputmap[attrName])
				del inputmap[attrName]
			#endIf
		#endFor
		data[CHILDREN] = self.getLdapServers(id)
		if (len(data[ATTRS]) == 0 and len(data[CHILDREN]) == 0):
			data = {}
		#endIf
		
		self.LOGGER.traceExit(str(data))
		return data
	#endDef
	
	#################################################################################
	## Reads LDAP repository EntityTypes RDN attributes from WAS config
	################################################################################
	def getIdMgrLDAPEntityTypeRDNAttr(self, id, eType):
		
		self.LOGGER.traceEnter([str(id), str(eType)])
		rdnList = []
		cmdMap = {}
		cmdMap[ID] = id
		cmdMap['entityTypeName'] = eType
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrLDAPEntityTypeRDNAttr(' + cmdOptions + ')')
		outStr = AdminTask.getIdMgrLDAPEntityTypeRDNAttr(cmdOptions)
		if (len(outStr) > 0):
			entityRDNMap = self.convertToDict(outStr)
			for key in entityRDNMap.keys():
				data = {}
				data[ID] = 'rdnAttributes'
				data[ATTRS] = {}
				data[CHILDREN] = []
				data[ATTRS][NAME] = key
				data[ATTRS]['objectClass'] = self.eValuateNullVal(entityRDNMap[key])
				rdnList.append(data)
			#endFor
		#endFor
		self.LOGGER.traceExit(str(rdnList))
		return rdnList
	#endDef
 
	#################################################################################
	## Reads LDAP repository EntityType data from WAS config
	#################################################################################
	def getIdMgrLDAPEntityTypes(self, id, eType):
		
		self.LOGGER.traceEnter([str(id), str(eType)])
		cmdMap = {}
		cmdMap[ID] = id
		cmdMap['name'] = eType
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrLDAPEntityType(' + cmdOptions + ')')
		outStr = AdminTask.getIdMgrLDAPEntityType(cmdOptions)
		entityMap = self.convertAdminTaskAttrsToDict(outStr)
		parent = {}
		parent[ID] = 'ldapEntityTypes'
		parent[ATTRS] = {}
		parent[CHILDREN] = []
		
		parent[ATTRS][NAME] = eType
		parent[ATTRS]['searchFilter'] = self.eValuateNullVal(entityMap['searchFilter'])
		parent[CHILDREN] = self.getIdMgrLDAPEntityTypeRDNAttr(id, eType)
		elementList = ['objectClasses', 'objectClassesForCreate', 'searchBases']
		for element in elementList:
			if(entityMap.has_key(element)):
				valueList = entityMap[element]
				for val in valueList:
					child = {}
					child[ID] = element
					child[ATTRS] = {}
					child[CHILDREN] = []
					child[ATTRS][VALUE] = self.eValuateNullVal(val)
					parent[CHILDREN].append(child)
				#endFor
			#endIf
		#endFor
		
		self.LOGGER.traceExit(str(parent))
		return parent
	#endDef
		
	#################################################################################
	## Reads LDAP repository all EntityTypes data from WAS config
	################################################################################
	 
	def getLdapEntityTypesConfigurationData(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		
		entityTypeElems = []
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrLDAPEntityTypes(' + cmdOptions + ')')
		outStr = AdminTask.listIdMgrLDAPEntityTypes(cmdOptions)
		if (len(outStr) > 0):
			enityTypes = outStr.split(newline)
			for enityType in enityTypes:
				eTypeData = self.getIdMgrLDAPEntityTypes(id, enityType)
				entityTypeElems.append(eTypeData)
			#endFor
		#endIf
		self.LOGGER.traceExit(str(entityTypeElems))
		return entityTypeElems
	#endIf
	
	#################################################################################
	## Reads LDAP repository all Cache Configuration data from WAS config
	################################################################################
	def getLdapCacheConfiguration(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		data = {}
		data[ID] = 'cacheConfiguration'
		data[ATTRS] = {}
		data[CHILDREN] = []
		
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrLDAPAttrCache(' + cmdOptions + ')')
		attrCache = AdminTask.getIdMgrLDAPAttrCache(cmdOptions)
		if ((attrCache is not None) and len(attrCache) > 0):
			attrCache = self.convertAdminTaskAttrsToDict(attrCache)
			attrCacheData = {}
			attrCacheData[ID] = 'attributesCache'
			attrCacheData[ATTRS] = {}
			attrCacheData[CHILDREN] = []
			for keyName in attrCache.keys():
				attrCacheData[ATTRS][keyName] = self.eValuateNullVal(attrCache[keyName])
			#endFor
			
			## Set default value for cachesDiskOffLoad
			if (not attrCache.has_key('cachesDiskOffLoad')):
				attrCacheData[ATTRS]['cachesDiskOffLoad'] = 'false'
			#endIf
			if(len(attrCacheData[ATTRS]) > 0):
				data[CHILDREN].append(attrCacheData)
		#endIf
		self.LOGGER.debug('AdminTask.getIdMgrLDAPSearchResultCache(' + cmdOptions + ')')
		searchCache = AdminTask.getIdMgrLDAPSearchResultCache(cmdOptions)
		if ((searchCache is not None) and len(searchCache) > 0):
			searchCache = self.convertAdminTaskAttrsToDict(searchCache)
			searchCacheData = {}
			searchCacheData[ID] = 'searchResultsCache'
			searchCacheData[ATTRS] = {}
			searchCacheData[CHILDREN] = []
			for keyName in searchCache.keys():
				searchCacheData[ATTRS][keyName] = self.eValuateNullVal(searchCache[keyName])
			#endFor
			if (not searchCache.has_key('cachesDiskOffLoad')):
				searchCacheData[ATTRS]['cachesDiskOffLoad'] = 'false'
			#endIf
			if(len(searchCacheData[ATTRS]) > 0):
				data[CHILDREN].append(searchCacheData)
		#endIf
		if(len(data[CHILDREN]) == 0):
			data = {}
		#endIf
		
		self.LOGGER.traceExit(str(data))
		return data
	#endDef
	
	#######################################################################
	## Reads LDAP context pool data from
	#######################################################################
	def getLdapContextPoolData(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		data = {}
	
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrLDAPContextPool(' + cmdOptions + ')')
		contextPool = AdminTask.getIdMgrLDAPContextPool(cmdOptions)
	 
		if ((contextPool is not None) and len(contextPool) > 0):
			contextPool = self.convertAdminTaskAttrsToDict(contextPool)
			contextPoolData = {}
			contextPoolData[ID] = 'contextPool'
			contextPoolData[ATTRS] = {}
			contextPoolData[CHILDREN] = []
			for keyName in contextPool.keys():
				contextPoolData[ATTRS][keyName] = self.eValuateNullVal(contextPool[keyName])
			#endFor
			
			if(len(contextPoolData[ATTRS]) > 0):
				data = contextPoolData
			#endIf
		#endIf
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef

	#######################################################################
	## Reads LDAP attribute configuration data from 
	#######################################################################
	def getLdapAttrData(self, id, typeName):
		
		self.LOGGER.traceEnter([str(id), str(typeName)])
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		children = []
		if(typeName == 'attributes'):
			try:
				self.LOGGER.debug('AdminTask.listIdMgrLDAPAttrs(' + cmdOptions + ')')
				attrOut = AdminTask.listIdMgrLDAPAttrs(cmdOptions)
			except:
				self.LOGGER.info('AdminTask.listIdMgrLDAPAttrs(' + cmdOptions + ') is not applicable for object ' + id + ". Continuing execution.")
				attrOut = None
		elif (typeName == 'externalIdAttributes'):
			try:
				self.LOGGER.debug('AdminTask.listIdMgrLDAPExternalIdAttrs(' + cmdOptions + ')')
				attrOut = AdminTask.listIdMgrLDAPExternalIdAttrs(cmdOptions)
			except:
				self.LOGGER.info('AdminTask.listIdMgrLDAPExternalIdAttrs(' + cmdOptions + ') is not applicable for object ' + id + ". Continuing execution.")
				attrOut = None
		elif (typeName == 'propertiesNotSupported'):
			try:
				self.LOGGER.debug('AdminTask.listIdMgrLDAPAttrsNotSupported(' + cmdOptions + ')')
				attrOut = AdminTask.listIdMgrLDAPAttrsNotSupported (cmdOptions)
			except:
				self.LOGGER.info('AdminTask.listIdMgrLDAPAttrsNotSupported(' + cmdOptions + ') is not applicable for object ' + id + ". Continuing execution.")
				attrOut = None
		else:
			self.LOGGER.traceExit([str(children)])
			return children
		#endIf
		
		if((attrOut is None) or len(attrOut) == 0):
			self.LOGGER.traceExit([str(children)])
			return children
		#endIf
		attrList = attrOut.split(newline)
	 
		for attrDataMap in attrList:
			attrDataMap = self.convertAdminTaskAttrsToDict(attrDataMap)
			attrData = {}
			attrData[ID] = typeName
			attrData[CHILDREN] = []
			attrData[ATTRS] = {}
			
			if(attrDataMap.has_key('id')):
				del attrDataMap['id']
			
			#endIf
			entTypeKey = None
			if(attrDataMap.has_key('entityTypesList')):
				entTypeKey = 'entityTypesList'
			elif (attrDataMap.has_key('entityTypes')):
				entTypeKey = 'entityTypes'
			#endIf
			if(entTypeKey is not None):
				for entType in attrDataMap[entTypeKey]:
					eData = {}
					eData[ID] = 'entityTypes'
					eData[ATTRS] = {}
					eData[CHILDREN] = []
					eData[ATTRS][VALUE] = self.eValuateNullVal(entType)
					attrData[CHILDREN].append(eData)
				#endFor
				if(entTypeKey == 'entityTypesList'):
					del attrDataMap['entityTypesList']
				#endIf
				del attrDataMap['entityTypes']
			#endIf
			
			for keyName in attrDataMap.keys():
				if(typeName == 'propertiesNotSupported' and keyName == 'propertyName'):
					attrData[ATTRS][NAME] = self.eValuateNullVal(attrDataMap[keyName])
				else:
					attrData[ATTRS][keyName] = self.eValuateNullVal(attrDataMap[keyName])
			#endFor
			children.append(attrData)
		#endFor
		
		self.LOGGER.traceExit([str(children)])
		
		return children
	#endDef
				
		
	#######################################################################
	## Reads LDAP attribute configuration
	####################################################################### 
	def getLdapAttributeConfigurationData(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		attrChildConfigTypes = ['externalIdAttributes', 'attributes', 'propertiesNotSupported']
		parent = {}
		parent[ID] = 'attributeConfiguration'
		parent[ATTRS] = {}
		parent[CHILDREN] = []
		if(not self.isApplicableForWASVersion("7.0.0.9")):
			parent = {}
			return parent
		#endIf
		for typeName in attrChildConfigTypes:
			elems = self.getLdapAttrData(id, typeName)
			for elem in elems:
				parent[CHILDREN].append(elem)
			#endFor
		#endFor
		if(len(parent[CHILDREN]) == 0):
			parent = {}
		#endIf
		self.LOGGER.traceExit([str(parent)])
		
		return parent
	#endDef
	
	#######################################################################
	## Reads LDAP Group configuration data
	####################################################################### 
	
	def getLdapGroupConfiguration(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		parent = {}
		parent[ID] = 'groupConfiguration'
		parent[CHILDREN] = []
		parent[ATTRS] = {}
		self.LOGGER.debug('AdminTask.getIdMgrLDAPGroupConfig(' + cmdOptions + ')')
		groupDataMap = AdminTask.getIdMgrLDAPGroupConfig(cmdOptions)
		groupDataMap = self.convertAdminTaskAttrsToDict(groupDataMap)
		
		if(groupDataMap.has_key('updateGroupMembership')):
			parent[ATTRS] = {}
			parent[ATTRS]['updateGroupMembership'] = self.eValuateNullVal(groupDataMap['updateGroupMembership'])
		#endIf
		if(groupDataMap.has_key(NAME)):
			child = {}
			child[ID] = 'membershipAttribute'
			child[ATTRS] = {}
			child[CHILDREN] = []
			child[ATTRS][NAME] = self.eValuateNullVal(groupDataMap[NAME])
			if(groupDataMap.has_key('scope')):
				child[ATTRS]['scope'] = self.eValuateNullVal(groupDataMap['scope'])
			#endIf
			if(not len(child[ATTRS]) == 0):
				parent[CHILDREN].append(child)
			#endIf
		#endIf
		
		# add memberAttributes if available
		self.LOGGER.debug('AdminTask.getIdMgrLDAPGroupMemberAttrs(' + cmdOptions + ')')
		attrOut = AdminTask.getIdMgrLDAPGroupMemberAttrs(cmdOptions)
		if((attrOut is not None) and len(attrOut) > 0):
			attrList = attrOut.split(newline)
			for attrDataMap in attrList:
				attrDataMap = self.convertAdminTaskAttrsToDict(attrDataMap)
				child = {}
				child[ID] = 'memberAttributes'
				child[ATTRS] = {}
				child[CHILDREN] = []
				for keyName in attrDataMap.keys():
					child[ATTRS][keyName] = self.eValuateNullVal(attrDataMap[keyName])
				#endFor
				if(not len(child[ATTRS]) == 0):
					parent[CHILDREN].append(child)
				#endIf
			#endFor
		#endIf
		# add dynamicMemberAttributes if available
		self.LOGGER.debug('AdminTask.getIdMgrLDAPGroupDynamicMemberAttrs(' + cmdOptions + ')')
		attrOut = AdminTask.getIdMgrLDAPGroupDynamicMemberAttrs(cmdOptions)
		if((attrOut is not None) and len(attrOut) > 0):
			attrList = attrOut.split(newline)
			for attrDataMap in attrList:
				attrDataMap = self.convertAdminTaskAttrsToDict(attrDataMap)
				child = {}
				child[ID] = 'dynamicMemberAttributes'
				child[ATTRS] = {}
				child[CHILDREN] = []
				for keyName in attrDataMap.keys():
					child[ATTRS][keyName] = self.eValuateNullVal(attrDataMap[keyName])
				#endFor
				if(not len(child[ATTRS]) == 0):
					parent[CHILDREN].append(child)
				#endIf
			#endFor
		#endIf
		
		if(len(parent[CHILDREN]) == 0 and len(parent[ATTRS]) == 0):
			parent = {}
		#endIf
		
		self.LOGGER.traceExit([str(parent)])
		
		return parent
	#endDef
			
	#######################################################################
	## Reads LDAP repository config child elements
	#######################################################################	
	def getLdapChildData(self, id, inputmap):
		
		self.LOGGER.traceEnter([str(id), str(inputmap)])
		
		childTypes = self.repoLdapChildTypes
		childElemList = self.getRepoChildData(id, inputmap)
		if(childElemList is None):
			childElemList = []
		#endIf
		
		for typeName in childTypes:
			if(typeName == 'ldapServerConfiguration'):
				data = self.getLdapServerConfigurationData(id, inputmap)
				if(not len(data) == 0):
					childElemList.append(data)
				#endIf
			elif(typeName == 'ldapEntityTypes'):
				eTypeList = self.getLdapEntityTypesConfigurationData(id)
				if(not len(eTypeList) == 0):
					for data in eTypeList:
						childElemList.append(data)
					#endFor
				#endIf
			elif(typeName == 'cacheConfiguration'):
				data = self.getLdapCacheConfiguration(id)
				if(not len(data) == 0):
					childElemList.append(data)
				#endIf
			elif(typeName == 'contextPool'):
				data = self.getLdapContextPoolData(id)
				if(not len(data) == 0):
					childElemList.append(data)
				#endIf
			elif(typeName == 'attributeConfiguration'):
				data = self.getLdapAttributeConfigurationData(id)
				if(not len(data) == 0):
					childElemList.append(data)
				#endIf
			elif(typeName == 'groupConfiguration'):
				data = self.getLdapGroupConfiguration(id)
				if(not len(data) == 0):
					childElemList.append(data)
				#endIf
			#endIf
		#endFor
	 
		self.LOGGER.traceExit([str(childElemList)])
		
		return childElemList
	#endDef
	
	#######################################################################
	## ReadsLDAP repository config data
	#######################################################################	
	def readRepositoryConfigData(self, id):
		
		self.LOGGER.traceEnter([str(id)])
		cmdMap = {}
		cmdMap[ID] = id
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrRepository(' + cmdOptions + ')')
		repositoryMap = AdminTask.getIdMgrRepository(cmdOptions)
		repositoryMap = self.convertAdminTaskAttrsToDict(repositoryMap)
		children = self.getLdapChildData(id, repositoryMap)
		
		parent = {}
		parent[ID] = LDAP_TYPE
		parent[ATTRS] = {}
		parent[CHILDREN] = children
		
		for keyName in repositoryMap.keys():
			parent[ATTRS][keyName] = self.eValuateNullVal(repositoryMap[keyName])
		#endFor
		
		self.LOGGER.traceExit([str(parent)])
		return parent
	#endDef
	
	
	def updateNonRDNTypesForEntityTypes(self, repoId, rafwConfig, entityTypeName, childType):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(entityTypeName), str(childType)])
		
		paramVal = self.getWIMMultiValuesByType(rafwConfig, childType)
		#Recreate the data if paramVal is not empty
		if(len(paramVal) > 0):
			self.LOGGER.trace("Adding new data : " + paramVal + " for " + childType + " for repository with id : " + repoId)
			cmdMap = {}
			cmdMap[ID] = repoId
			cmdMap[NAME] = entityTypeName
			cmdMap[childType] = paramVal
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.updateIdMgrLDAPEntityType(' + cmdOptions + ')')
			#print('AdminTask.updateIdMgrLDAPEntityType(' + cmdOptions + ')')
			AdminTask.updateIdMgrLDAPEntityType(cmdOptions)
		else:
			self.LOGGER.trace("No data found for " + childType + " for repository with id : " + repoId)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
	def updateRDNTypesForEntityTypes(self, repoId, rafwConfig, entityTypeName, childType):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(entityTypeName), str(childType)])
		valueList = []
		removeList = []
		for childData in rafwConfig[CHILDREN]:
			if (childData[ID] == childType):
				removeList.append(childData)
				nameValue = self.getWIMCLIRequiredValue(NAME, childData[ATTRS], childType)
				cmdMap = {}
				cmdMap[ID] = repoId
				cmdMap[NAME] = nameValue
				cmdMap['entityTypeName'] = entityTypeName
				
				cmdOptions = '[ -id ' + repoId + ' -name ' + nameValue + ' -entityTypeName ' + entityTypeName
				if(childData[ATTRS].has_key('objectClass')):
					cmdMap['objectClass'] = childData[ATTRS]['objectClass']
				#endIf
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				self.LOGGER.debug('AdminTask.addIdMgrLDAPEntityTypeRDNAttr(' + cmdOptions + ')')
				#print('AdminTask.addIdMgrLDAPEntityTypeRDNAttr(' + cmdOptions + ')')
				AdminTask.addIdMgrLDAPEntityTypeRDNAttr(cmdOptions)
			#endIf
		#endFor
		
		#clean the child elements already processed
		self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
		self.LOGGER.traceExit()
	#endDef
	
	
	def updateLdapEntityTypeChildData(self, repoId, rafwConfig, entityTypeName):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(entityTypeName)])
		
		for childType in self.repoLdapEntityTypeChildTypes:
			if(not childType == 'rdnAttributes'):
				self.updateNonRDNTypesForEntityTypes(repoId, rafwConfig, entityTypeName, childType)
			else:
				self.updateRDNTypesForEntityTypes(repoId, rafwConfig, entityTypeName, childType)
			#endIf
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	def deleteLdapEntityTypes(self, repoId, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(wasConfig)])
		childTypeName = 'ldapEntityTypes'
		
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				entityTypeName = childNode[ATTRS]['name']
				cmdMap = {}
				cmdMap[ID] = repoId
				cmdMap[NAME] = entityTypeName
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				self.LOGGER.debug('AdminTask.deleteIdMgrLDAPEntityType(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrLDAPEntityType(' + cmdOptions + ')')
				AdminTask.deleteIdMgrLDAPEntityType(cmdOptions)
			#endIf
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
 
	def updateLdapEntityTypesConfigurationData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		childTypeName = 'ldapEntityTypes'
		#sConfigAttr = self.ldapTypeAttributeMap[childTypeName]
		self.deleteLdapEntityTypes(repoId, wasConfig)
		removeList = []
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				removeList.append(childNode)
				entityTypeName = childNode[ATTRS]['name']
				if(len(entityTypeName) > 0):
					cmdMap = {}
					cmdMap[ID] = repoId
					cmdMap[NAME] = entityTypeName
					if(childNode[ATTRS].has_key('searchFilter') and len(childNode[ATTRS]['searchFilter']) > 0):
						cmdMap['searchFilter'] = childNode[ATTRS]['searchFilter']
					#endIf
					paramVal = self.getWIMMultiValuesByType(childNode, 'objectClasses')
					if(len(paramVal) > 0):
						cmdMap['objectClasses'] = paramVal
					else:
						msg = self.getLocalizedMessage("CRWWA0165E", ['objectClasses', childTypeName, scope])
						self.LOGGER.error(msg)
						raise InvalidXmlConfigException(msg)
					#endIf
					cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
					self.LOGGER.debug('AdminTask.addIdMgrLDAPEntityType(' + cmdOptions + ')')
					#print('AdminTask.addIdMgrLDAPEntityType(' + cmdOptions + ')')
					AdminTask.addIdMgrLDAPEntityType(cmdOptions)
					self.updateLdapEntityTypeChildData(repoId, childNode, entityTypeName)
				else:
					msg = self.getLocalizedMessage("CRWWA0165E", [NAME, childTypeName, scope])
					self.LOGGER.error(msg)
					raise InvalidXmlConfigException(msg)
				#endIf
			#endIf
		#endFor
		self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
		self.LOGGER.traceExit()
	#wnd DEF

 
	
	#######################################################################
	## Creates LDAP server data in WAS config
	#######################################################################	
	def createServer(self, repoId, connNode, primaryHost=''):
		
		self.LOGGER.traceEnter([str(repoId), str(connNode), str(primaryHost)])
		cmdMap = {}
		cmdMap[ID] = repoId
		if(connNode[ATTRS].has_key('host') and len(connNode[ATTRS]['host']) > 0):
			cmdMap['host'] = connNode[ATTRS]['host']
		else:
			msg = self.getLocalizedMessage("CRWWA0165E", ['host', serverType, scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		
		if(connNode[ATTRS].has_key('port') and len(connNode[ATTRS]['port']) > 0):
			cmdMap['port'] = connNode[ATTRS]['port']
		#endIf
		
		if(len(primaryHost) > 0):
			cmdMap['primary_host'] = primaryHost
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.addIdMgrLDAPBackupServer(' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPBackupServer(' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPBackupServer(cmdOptions)
		else:
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.addIdMgrLDAPServer(' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPServer(' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPServer(cmdOptions)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
	def updateLdapServerData(self, repoId, rafwLdapSvrConfig, wasLdapSvrConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwLdapSvrConfig), str(wasLdapSvrConfig)])
		typeName = 'ldapServerConfiguration'
		serverType = 'ldapServers'
		connType = 'connections'
		
		removeList = []
		connNode = {}
		if(len(wasLdapSvrConfig) > 0):
			for serverNode in wasLdapSvrConfig[CHILDREN]:
				if(serverNode[ID] == serverType):
					if(len(serverNode[CHILDREN]) > 0):
						connNode = serverNode[CHILDREN][0]
						cmdMap = {}
						cmdMap[ID] = repoId
						cmdMap['host'] = connNode[ATTRS]['host']
						cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
						self.LOGGER.debug('AdminTask.deleteIdMgrLDAPServer(' + cmdOptions + ')')
						#print('AdminTask.deleteIdMgrLDAPServer(' + cmdOptions + ')')
						AdminTask.deleteIdMgrLDAPServer(cmdOptions)
					#endIf
				#endIf
			#endFor
		#endFor
		connNode = {}
		if(len(rafwLdapSvrConfig) > 0):
			for serverNode in rafwLdapSvrConfig[CHILDREN]:
				if(serverNode[ID] == serverType):
					removeList.append(serverNode)
					connNode = serverNode[CHILDREN][0]
					self.createServer(repoId, connNode, '')
					primaryHost = connNode[ATTRS]['host']
					backUpCnt = 1
					while backUpCnt < len(serverNode[CHILDREN]):
						self.createServer(repoId, serverNode[CHILDREN][backUpCnt], primaryHost)
						backUpCnt = backUpCnt + 1
					#endWhile
					servAttrList = self.ldapTypeAttributeMap[serverType]
					attrOptions = self.getCmdOptionsFromRafwConfig(servAttrList, serverNode[ATTRS], serverType)
					cmdOptions = '[ -id ' + repoId + ' -host ' + primaryHost + attrOptions + ' ]'
					self.LOGGER.debug('AdminTask.updateIdMgrLDAPServer(' + cmdOptions + ')')
					#print('AdminTask.updateIdMgrLDAPServer(' + cmdOptions + ')')
					AdminTask.updateIdMgrLDAPServer(cmdOptions)
				#endIf
			#endFor
		#endIf
		#clean the child elements already processed
		self.removeItemsSrcListFromTargetList(removeList, rafwLdapSvrConfig[CHILDREN])
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates LDAP server configuration in WAS config
	#######################################################################
	def updateLdapServerConfigurationData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		
		childTypeName = 'ldapServerConfiguration'
		sConfigAttr = self.ldapTypeAttributeMap[childTypeName]
		
		removeList = []
		ldapServerCfgNode = {}
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapServerCfgNode = childNode
				removeList.append(childNode)
				break
			#endIf
		#endFor
		attrOptions = self.getCmdOptionsFromRafwConfig(sConfigAttr, ldapServerCfgNode[ATTRS], childTypeName)
		cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
		self.LOGGER.debug('AdminTask.updateIdMgrLDAPRepository(' + cmdOptions + ')')
		#print('AdminTask.updateIdMgrLDAPRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrLDAPRepository(cmdOptions)
					
		wasLdapServerConfig = {}
		childNode = {}
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				wasLdapServerConfig = childNode
				break
			#endIf
		#endFor
		self.updateLdapServerData(repoId, ldapServerCfgNode, wasLdapServerConfig)
		
		#clean the child elements already processed
		self.removeItemsSrcListFromTargetList(removeList, rafwConfig[CHILDREN])
		self.LOGGER.traceExit()
	#endDef
	#######################################################################
	## Updates LDAP repository cache configuration
	#######################################################################
	def updateLdapCacheConfiguration(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		
		childTypeName = 'cacheConfiguration'
		
		ldapAttrCfgNode = {}
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		if(len(ldapAttrCfgNode) > 0):
			for node in ldapAttrCfgNode[CHILDREN]:
				if(node[ID] == 'attributesCache'):
					attrList = self.ldapTypeAttributeMap['attributesCache']
					attrOptions = self.getCmdOptionsFromRafwConfig(attrList, node[ATTRS], 'attributesCache')
					cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
					self.LOGGER.debug('AdminTask.setIdMgrLDAPAttrCache(' + cmdOptions + ')')
					#print('AdminTask.setIdMgrLDAPAttrCache(' + cmdOptions + ')')
					AdminTask.setIdMgrLDAPAttrCache(cmdOptions)
				elif(node[ID] == 'searchResultsCache'):
					attrList = self.ldapTypeAttributeMap['searchResultsCache']
					attrOptions = self.getCmdOptionsFromRafwConfig(attrList, node[ATTRS], 'searchResultsCache')
					cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
					self.LOGGER.debug('AdminTask.setIdMgrLDAPSearchResultCache(' + cmdOptions + ')')
					#print('AdminTask.setIdMgrLDAPSearchResultCache(' + cmdOptions + ')')
					AdminTask.setIdMgrLDAPSearchResultCache(cmdOptions)
				else:
					msg = self.getLocalizedMessage("CRWWA0168W", [str(node[ID]), childTypeName, scope])
					self.LOGGER.warn(msg)
				#endIf
			#endFor
		#endIf
		self.LOGGER.traceExit()
	 
	#endDef
	
	#######################################################################
	## Updates LDAP server context pool data
	#######################################################################
	
	def updateLDAPContextPool(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		
		childTypeName = 'contextPool'
		
		ldapAttrCfgNode = {}
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		if(len(ldapAttrCfgNode) > 0):
			attrList = self.ldapTypeAttributeMap['contextPool']
			attrOptions = self.getCmdOptionsFromRafwConfig(attrList, ldapAttrCfgNode[ATTRS], childTypeName)
			cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
			self.LOGGER.debug('AdminTask.setIdMgrLDAPContextPool(' + cmdOptions + ')')
			#print('AdminTask.setIdMgrLDAPContextPool(' + cmdOptions + ')')
			AdminTask.setIdMgrLDAPContextPool(cmdOptions)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	#######################################################################
	## Convert the values to list or dict based on the input data structure
	#######################################################################
	def updatePropertyNotSupportedNode(self, repoId, propNotSupportedList , wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(propNotSupportedList), str(wasConfig)])
		childTypeName = 'attributeConfiguration'
		ldapAttrCfgNode = {}
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		wasPropConfigList = []
		if(len(ldapAttrCfgNode) > 0):
			for node in ldapAttrCfgNode[CHILDREN]:
				if(node[ID] == 'propertiesNotSupported'):
					wasPropConfigList.append(node)
				#endIf
			#endFor
		#endIf
		#Delete the existing props in WAS configuration
		if(len(wasPropConfigList) > 0):
			for propCfgNode in wasPropConfigList:
				propName = propCfgNode[ATTRS][NAME]
				cmdMap = {}
				cmdMap[ID] = repoId
				cmdMap['propertyName'] = propName
				paramVal = self.getWIMMultiValuesByType(propCfgNode, 'entityTypes')
				if(len(paramVal) > 0):
					cmdMap['entityTypes'] = paramVal
				#endIf
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				
				self.LOGGER.debug('AdminTask.deleteIdMgrLDAPAttrNotSupported(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrLDAPAttrNotSupported(' + cmdOptions + ')')
				AdminTask.deleteIdMgrLDAPAttrNotSupported(cmdOptions)
			#endFor
		#endIf
		
		#Create the new list
		for propNotSupported in propNotSupportedList:
			propName = self.getWIMCLIRequiredValue(NAME, propNotSupported[ATTRS], 'propertiesNotSupported')
			cmdMap = {}
			cmdMap[ID] = repoId
			cmdMap['propertyName'] = propName
			paramVal = self.getWIMMultiValuesByType(propNotSupported, 'entityTypes')
			if(len(paramVal) > 0):
				cmdMap['entityTypes'] = paramVal
			#endIf
			## For unsupported attributes add entityTypes=PersonAccount as extraArgs
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap, '-entityTypes PersonAccount')
			
			self.LOGGER.debug('AdminTask.addIdMgrLDAPAttrNotSupported (' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPAttrNotSupported (' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPAttrNotSupported (cmdOptions)
		#endFor
	 
		self.LOGGER.traceExit()
	#endDef
	
	def updateLDAPExternalIdAttr(self, repoId, attrNodeList , wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(attrNodeList), str(wasConfig)])
		childTypeName = 'attributeConfiguration'
		ldapAttrCfgNode = {}
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		wasPropConfigList = []
		if(len(ldapAttrCfgNode) > 0):
			for node in ldapAttrCfgNode[CHILDREN]:
				if(node[ID] == 'externalIdAttributes'):
					wasPropConfigList.append(node)
				#endIf
			#endFor
		#endIf
		#Delete the existin props in WAS configuration
		if(len(wasPropConfigList) > 0):
			for propCfgNode in wasPropConfigList:
				propName = propCfgNode[ATTRS][NAME]
				cmdMap = {}
				cmdMap[ID] = repoId
				cmdMap['name'] = propName
				paramVal = self.getWIMMultiValuesByType(propCfgNode, 'entityTypes')
				if(len(paramVal) > 0):
					cmdMap['entityTypes'] = paramVal
				#endIf
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				
				self.LOGGER.debug('AdminTask.deleteIdMgrLDAPExternalIdAttr(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrLDAPExternalIdAttr(' + cmdOptions + ')')
				AdminTask.deleteIdMgrLDAPExternalIdAttr(cmdOptions)
			#endFor
		#endIf
		
		#Create the new list
		atrNameList = ['syntax', 'wimGenerate']
		for attrNode in attrNodeList:
			propName = self.getWIMCLIRequiredValue(NAME, attrNode[ATTRS], 'externalIdAttributes')
			cmdMap = {}
			cmdMap[ID] = repoId
			cmdMap['name'] = propName
			for atrName in atrNameList:
				if(attrNode[ATTRS].has_key(atrName) and len(attrNode[ATTRS][atrName]) > 0):
					cmdMap[atrName] = attrNode[ATTRS][atrName]
				#endIf
			#endFor
			paramVal = self.getWIMMultiValuesByType(attrNode, 'entityTypes')
			if(len(paramVal) > 0):
				cmdMap['entityTypes'] = paramVal
			#endIf
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			
			self.LOGGER.debug('AdminTask.addIdMgrLDAPExternalIdAttr (' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPExternalIdAttr (' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPExternalIdAttr(cmdOptions)
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	def updateLDAPAttributes(self, repoId, attrNodeList , wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(attrNodeList), str(wasConfig)])
		childTypeName = 'attributeConfiguration'
		ldapAttrCfgNode = {}
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		wasPropConfigList = []
		if(len(ldapAttrCfgNode) > 0):
			for node in ldapAttrCfgNode[CHILDREN]:
				if(node[ID] == 'attributes'):
					wasPropConfigList.append(node)
				#endIf
			#endFor
		#endIf
		#Delete the existing props in WAS configuration
		if(len(wasPropConfigList) > 0):
			for propCfgNode in wasPropConfigList:
				propName = propCfgNode[ATTRS][NAME]
				cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' '
				paramVal = self.getWIMMultiValuesByType(propCfgNode, 'entityTypes')
				if(len(paramVal) > 0):
					cmdOptions = cmdOptions + ' -entityTypes ' + paramVal + ' '
				#endIf
				cmdOptions = cmdOptions + ' ]'
				
				self.LOGGER.debug('AdminTask.deleteIdMgrLDAPAttr(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrLDAPAttr(' + cmdOptions + ')')
				AdminTask.deleteIdMgrLDAPAttr(cmdOptions)
			#endFor
		#endIf
		
		#Create the new list
		atrNameList = ['syntax', 'defaultValue', 'propertyName', 'defaultAttribute']
		for attrNode in attrNodeList:
			propName = self.getWIMCLIRequiredValue(NAME, attrNode[ATTRS], 'attributes')
			cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' '
			for atrName in atrNameList:
				if(attrNode[ATTRS].has_key(atrName) and len(attrNode[ATTRS][atrName]) > 0):
					if(atrName == 'defaultAttribute'):
						cmdOptions = cmdOptions + ' -defaultAttr ' + attrNode[ATTRS][atrName]
					else:
						cmdOptions = cmdOptions + ' -' + atrName + ' ' + attrNode[ATTRS][atrName]
					#endIf
				#endIf
			#endFor
			paramVal = self.getWIMMultiValuesByType(attrNode, 'entityTypes')
			if(len(paramVal) > 0):
				cmdOptions = cmdOptions + ' -entityTypes ' + paramVal + ' '
			else:
				# If paramVal is empty, set entityTypes to PersonAccount
				cmdOptions = cmdOptions + ' -entityTypes PersonAccount'
			#endIf
			
			cmdOptions = cmdOptions + ' ]'
			
			self.LOGGER.debug('AdminTask.addIdMgrLDAPAttr (' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPAttr (' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPAttr(cmdOptions)
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates LDAP Attribute configuration
	#######################################################################
	
	def updateLDAPAttributeConfiguration(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		childTypeName = 'attributeConfiguration'
		
		ldapAttrCfgNode = {}
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapAttrCfgNode = childNode
				break
			#endIf
		#endFor
		externalAttrNode = []
		attrNode = []
		propertyNotSupportedNode = []
		if(len(ldapAttrCfgNode) > 0):
			for node in ldapAttrCfgNode[CHILDREN]:
				if(node[ID] == 'externalIdAttributes'):
					externalAttrNode.append(node)
				elif(node[ID] == 'attributes'):
					attrNode.append(node)
				elif(node[ID] == 'propertiesNotSupported'):
					propertyNotSupportedNode.append(node)
				else:
					msg = self.getLocalizedMessage("CRWWA0168W", [str(node[ID]), childTypeName, scope])
					self.LOGGER.warn(msg)
		#endIf
		self.updatePropertyNotSupportedNode(repoId, propertyNotSupportedNode, wasConfig)
		self.updateLDAPAttributes(repoId, attrNode, wasConfig)
		self.updateLDAPExternalIdAttr(repoId, externalAttrNode, wasConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def updateMemberAttributes(self, repoId, memberAttributes):
		
		self.LOGGER.traceEnter([str(repoId), str(memberAttributes)])
		#Create the new list
		atrNameList = ['objectClass', 'scope', 'dummyMember']
		for attrNode in memberAttributes:
			propName = self.getWIMCLIRequiredValue(NAME, attrNode[ATTRS], 'memberAttributes')
			del attrNode[ATTRS][NAME]
			cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' '
			for atrName in atrNameList:
				if(attrNode[ATTRS].has_key(atrName) and len(attrNode[ATTRS][atrName]) > 0):
					cmdOptions = cmdOptions + ' -' + atrName + ' ' + attrNode[ATTRS][atrName] + ' '
				#endIf
			#endFor
			cmdOptions = cmdOptions + ' ]'
			
			self.LOGGER.debug('AdminTask.addIdMgrLDAPGroupMemberAttr (' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPGroupMemberAttr (' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPGroupMemberAttr(cmdOptions)
		#endFor
		self.LOGGER.traceExit()
	#endDef

	def updateDynamicMemberAttributes(self, repoId, dynamicMemberAttributes):
		
		self.LOGGER.traceEnter([str(repoId), str(dynamicMemberAttributes)])
		#Create the new list
		for attrNode in dynamicMemberAttributes:
			propName = self.getWIMCLIRequiredValue(NAME, attrNode[ATTRS], 'dynamicMemberAttributes')
			if(attrNode[ATTRS].has_key('objectClass') and len(attrNode[ATTRS]['objectClass']) > 0):
				cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' -objectClass ' + attrNode[ATTRS]['objectClass'] + ' ]'
			else:
				cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' ]'
				
			self.LOGGER.debug('AdminTask.addIdMgrLDAPGroupDynamicMemberAttr (' + cmdOptions + ')')
			#print('AdminTask.addIdMgrLDAPGroupDynamicMemberAttr (' + cmdOptions + ')')
			AdminTask.addIdMgrLDAPGroupDynamicMemberAttr(cmdOptions)
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates LDAP group configuration data
	#######################################################################
	
	def updateLDAPGroupConfiguration(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		childTypeName = 'groupConfiguration'
		
		#delete the existing group configuration
		for childNode in wasConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				cmdOptions = '[ -id ' + repoId + ' ]'
				self.LOGGER.debug('AdminTask.deleteIdMgrLDAPGroupConfig(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrLDAPGroupConfig(' + cmdOptions + ')')
				AdminTask.deleteIdMgrLDAPGroupConfig(cmdOptions)
			#endIf
		#endFor
		ldapGroupCfgNode = {}
		for childNode in rafwConfig[CHILDREN]:
			if(childNode[ID] == childTypeName):
				ldapGroupCfgNode = childNode
				break
			#endIf
		#endFor
		
		externalAttrNode = []
		memberAttributes = []
		dynamicMemberAttributes = []
		updateGroupMembership = 'false'
		if(len(ldapGroupCfgNode) > 0):
			if(ldapGroupCfgNode[ATTRS].has_key('updateGroupMembership') 
				and len(ldapGroupCfgNode[ATTRS]['updateGroupMembership']) > 0):
				updateGroupMembership = ldapGroupCfgNode[ATTRS]['updateGroupMembership']
				
			for node in ldapGroupCfgNode[CHILDREN]:
				if(node[ID] == 'membershipAttribute'):
					propName = self.getWIMCLIRequiredValue(NAME, node[ATTRS], 'membershipAttribute')
					cmdOptions = '[ -id ' + repoId + ' -name ' + propName + ' ' + ' -updateGroupMembership ' + updateGroupMembership
					if(node[ATTRS].has_key('scope') and len(node[ATTRS]['scope']) > 0):
						cmdOptions = cmdOptions + ' -scope ' + node[ATTRS]['scope']
					#endIf
					cmdOptions = cmdOptions + ' ]'
					self.LOGGER.debug('AdminTask.setIdMgrLDAPGroupConfig(' + cmdOptions + ')')
					#print('AdminTask.setIdMgrLDAPGroupConfig(' + cmdOptions + ')')
					AdminTask.setIdMgrLDAPGroupConfig(cmdOptions)
				elif(node[ID] == 'memberAttributes'):
					memberAttributes.append(node)
				elif(node[ID] == 'dynamicMemberAttributes'):
					dynamicMemberAttributes.append(node)
				else:
					msg = self.getLocalizedMessage("CRWWA0168W", [str(node[ID]), childTypeName, scope])
					self.LOGGER.warn(msg)
		#endIf
		self.updateMemberAttributes(repoId, memberAttributes)
		self.updateDynamicMemberAttributes(repoId, dynamicMemberAttributes)
		
		self.LOGGER.traceExit()

	#endDef
	
	
	#######################################################################
	## Updates LDAP repository config child elements
	#######################################################################
	
	
	def updateIdMgrLDAPRepositoryChildrenData(self, repoId, rafwConfig, wasConfig):
		
		self.updateRepositoryChildrenData(repoId, rafwConfig, wasConfig)
		
		childTypes = self.repoLdapChildTypes
		self.updateLdapServerConfigurationData(repoId, rafwConfig, wasConfig)
		for childType in childTypes:
			if (childType == 'ldapServerConfiguration'):
				alreadyDone = 1
			elif(childType == 'ldapEntityTypes'):
				self.updateLdapEntityTypesConfigurationData(repoId, rafwConfig, wasConfig)
			elif(childType == 'cacheConfiguration'):
				self.updateLdapCacheConfiguration(repoId, rafwConfig, wasConfig)
			elif(childType == 'contextPool'):
				self.updateLDAPContextPool(repoId, rafwConfig, wasConfig)
			elif(childType == 'attributeConfiguration'):
				if(self.isApplicableForWASVersion('7.0.0.9')):
					self.updateLDAPAttributeConfiguration(repoId, rafwConfig, wasConfig)
				#endIf
			elif(childType == 'groupConfiguration'):
				self.updateLDAPGroupConfiguration(repoId, rafwConfig, wasConfig)
			#endIf
			else:
				msg = self.getLocalizedMessage("CRWWA0168W", [childType, 'repositories', scope])
				self.LOGGER.warn(msg)
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Updates LDAP repository config data
	#######################################################################
	def updateIdMgrLDAPRepositoryData(self, repoId, rafwConfig, wasConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig), str(wasConfig)])
		# first update repository data
		self.updateIdMgrRepositoryData(repoId, rafwConfig, wasConfig)
		
		# then update ldap repository data
		repoAttrList = self.repoLdapChildAttributes
		
		attrOptions = self.getCmdOptionsFromRafwConfig(repoAttrList, rafwConfig[ATTRS], 'repositories')
		cmdOptions = '[ -id ' + repoId + ' ' + attrOptions + ' ]'
		self.LOGGER.debug('AdminTask.updateIdMgrLDAPRepository(' + cmdOptions + ')')
		#print('AdminTask.updateIdMgrLDAPRepository(' + cmdOptions + ')')
		AdminTask.updateIdMgrLDAPRepository(cmdOptions)
		
		self.LOGGER.traceExit()
	#endDef
		
		
	#######################################################################
	## Updates LDAP repository config data
	#######################################################################
	def updateIdMgrLDAPRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig)])
		
		wasConfig = self.readRepositoryConfigData(repoId)
		self.updateIdMgrLDAPRepositoryData(repoId, rafwConfig, wasConfig)
		self.updateIdMgrLDAPRepositoryChildrenData(repoId, rafwConfig, wasConfig)
		self.updateIdMgrRepositoryBaseEntries(repoId, rafwConfig, wasConfig)
		self.LOGGER.traceExit()
	#endDef
	#######################################################################
	## Creates new LDAP repository config data
	#######################################################################
	def createIdMgrLDAPRepository(self, repoId, rafwConfig):
		
		self.LOGGER.traceEnter([str(repoId), str(rafwConfig)])
		ldapServerType = self.getWIMCLIRequiredValue('ldapServerType', rafwConfig[ATTRS], currentConfigType)
		cmdOptions = '[ -id ' + repoId + ' -ldapServerType ' + ldapServerType + ' -default ' + 'true' + ' ]'
		self.LOGGER.debug('AdminTask.createIdMgrLDAPRepository(' + cmdOptions + ')')
		#print('AdminTask.createIdMgrLDAPRepository(' + cmdOptions + ')')
		AdminTask.createIdMgrLDAPRepository(cmdOptions)
		
		#Then update the registry
		self.updateIdMgrLDAPRepository(repoId, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	#######################################################################
	## Creates or updates LDAP repository config based on existence of the same
	## in WAS config
	####################################################################### 
	
	def createRepositoryConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		repoId = rafwConfig[ATTRS][ID]
		if(self.isRepositoryExists(repoId)):
			print "updateIdMgrLDAPRepository : updating the registry with id " + repoId
			self.updateIdMgrLDAPRepository(repoId, rafwConfig)
		else:
			print "createIdMgrLDAPRepository : creating the registry with id " + repoId
			self.createIdMgrLDAPRepository(repoId, rafwConfig)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
#end CLASS

############## CLASS :: SupportedEntityTypesHelper #######
# This class is used to manage the Federated Security	#
# Supported entity types data							#
#														#
#														#
##########################################################
class SupportedEntityTypesHelper(WIMConfigReaderHelper):

	def __init__(self):
		self.LOGGER = _Logger("SupportedEntityTypesHelper", MessageManager.RB_WEBSPHERE_WAS)
	#endDef
	
	##########################################################
	## Returns the list of supported entity types available in
	## WAS configuration
	##########################################################
	def listIdMgrSupportedEntityTypes(self):
		
		self.LOGGER.traceEnter()
		returnList = []
		cmdMap = {}
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrSupportedEntityTypes(' + cmdOptions + ')')
		#print('AdminTask.listIdMgrSupportedEntityTypes(' + cmdOptions + ')')
		outPutStr = AdminTask.listIdMgrSupportedEntityTypes(cmdOptions)
		if(len(outPutStr) > 0):
			returnList = outPutStr.split(newline)
		#endIf
		
		self.LOGGER.traceExit([str(returnList)])
		
		return returnList
	#endDef
	
	def isEntityTypeExists(self, entityTypeName):
		
		self.LOGGER.traceEnter([str(entityTypeName)])
		
		entTypeList = self.listIdMgrSupportedEntityTypes()
		found = 0
		for ent in entTypeList:
			if(ent == entityTypeName):
				found = 1
				break
			#endIf
		#endFor
		self.LOGGER.traceExit([str(found)])
		return found
	#endDef
	
	def deleteIdMgrSupportedEntityType(self, entityTypeName):
		
		self.LOGGER.traceEnter([str(entityTypeName)])
		if(self.isEntityTypeExists(entityTypeName)):
			cmdMap = {}
			cmdMap[NAME] = entityTypeName
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.deleteIdMgrSupportedEntityType(' + cmdOptions + ')')
			#print('AdminTask.deleteIdMgrSupportedEntityType(' + cmdOptions + ')')
			AdminTask.deleteIdMgrSupportedEntityType(cmdOptions)
		#endIf
	#endDef
	
	def deleteIdMgrAllsSupportedEntityTypes(self):
		
		self.LOGGER.traceEnter()
		
		entTypeList = self.listIdMgrSupportedEntityTypes()
		for ent in entTypeList:
			self.deleteIdMgrSupportedEntityType(ent)
		#endFor
		self.LOGGER.traceExit()
	#endDef
			
	def getIdMgrSupportedEntityType(self, entityTypeName):
		
		self.LOGGER.traceEnter([str(entityTypeName)])
		
		keyList = ['rdnProperties=', 'defaultParent=', 'name=', '}']
		cmdMap = {}
		cmdMap[NAME] = entityTypeName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrSupportedEntityType(' + cmdOptions + ')')
		#print('AdminTask.getIdMgrSupportedEntityType(' + cmdOptions + ')')
		outPutStr = AdminTask.getIdMgrSupportedEntityType(cmdOptions)
		returnOutMap = {}
		if(len(outPutStr) > 0):
			outPutMap = self.convertAdminTaskAttrsToDict(outPutStr)
			defaultParent = self.getValuesFromMap('defaultParent', outPutStr, keyList)
			returnOutMap[NAME] = outPutMap[NAME]
			returnOutMap['defaultParent'] = defaultParent
			returnOutMap['rdnProperties'] = outPutMap['rdnProperties']
		#endIf
		self.LOGGER.traceExit([str(returnOutMap)])
		
		return returnOutMap
	#endDef
	
	def readSupportedEntityTypeData(self, entityTypeName):
		
		self.LOGGER.traceEnter([str(entityTypeName)])
		
		inputMap = self.getIdMgrSupportedEntityType(entityTypeName)
		data = {}
		if(len(inputMap) > 0):
			data[ID] = 'supportedEntityTypes'
			data[ATTRS] = {}
			data[ATTRS][NAME] = self.eValuateNullVal(inputMap[NAME])
			data[ATTRS]['defaultParent'] = self.eValuateNullVal(inputMap['defaultParent'])
			data[CHILDREN] = []
			for rdns in inputMap['rdnProperties']:
				cdata = {}
				cdata[ID] = 'rdnProperties'
				cdata[CHILDREN] = []
				cdata[ATTRS] = {}
				cdata[ATTRS][VALUE] = self.eValuateNullVal(rdns)
				data[CHILDREN].append(cdata)
			#endFor
		#endIf
		
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef
	
	#######################################################################
	## Reads supported entity type configuration in WAS config
	####################################################################### 
	
	def readSupportedEntiTypesConfiguration(self):
		
		self.LOGGER.traceEnter()
		
		entTypeDataList = []
		entTypeNameList = self.listIdMgrSupportedEntityTypes()
		for entTypeName in entTypeNameList:
			entTypeData = self.readSupportedEntityTypeData(entTypeName)
			entTypeDataList.append(entTypeData)
		#endFor
		self.LOGGER.traceExit([str(entTypeDataList)])
		
		return entTypeDataList
	#endDef				
 
	#######################################################################
	## Creates Supported Entity type in WAS config
	####################################################################### 
	
	def createSupportedEntityTypesConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		cmdMap = {}
		cmdMap[NAME] = self.getWIMCLIRequiredValue(NAME, rafwConfig[ATTRS], currentConfigType)
		cmdMap['defaultParent'] = self.getWIMCLIRequiredValue('defaultParent', rafwConfig[ATTRS], currentConfigType)
		cmdMap['rdnProperties'] = self.getWIMMultiValuesByType(rafwConfig, 'rdnProperties')
		if(len(cmdMap['rdnProperties']) == 0):
			msg = self.getLocalizedMessage("CRWWA0165E", [VALUE, 'rdnProperties', scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		#endIf
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.createIdMgrSupportedEntityType(' + cmdOptions + ')')
		#print('AdminTask.createIdMgrSupportedEntityType(' + cmdOptions + ')')
		AdminTask.createIdMgrSupportedEntityType(cmdOptions)
		
		self.LOGGER.traceExit()
		
	#endDef
	

############## CLASS :: RealmHelper #############################
# This class is used to manage the realm configuration data of	#
# Federated Security											#
#																#
#################################################################

class RealmHelper(WIMConfigReaderHelper):
	 
	def __init__(self):
		self.LOGGER = _Logger("RealmHelper", MessageManager.RB_WEBSPHERE_WAS)
	#endDef
	
	
	#####################################################################
	## Retruns realm and associated repository repository map with all	#
	## base entries defined for the respective repository				#
	#####################################################################
	
	def getRealmRepoMap(self, realmMapStr, realmName):
		
		self.LOGGER.traceEnter([str(realmMapStr), str(realmName)])
		
		keyList = ['repositoryType=', 'specificRepositoryType=', 'nameInRepository=',
					'id=', 'host=', 'name=', 'port=', '}']
		
		data = {}
		data[REALM_NAME] = self.eValuateNullVal(realmName)
		name = self.getValuesFromMap('name', realmMapStr, keyList)
		data[BASE_ENTRY_NAME] = self.eValuateNullVal(name)
		nameInRepository = self.getValuesFromMap('nameInRepository', realmMapStr, keyList)
		data[NAME_IN_REPO] = self.eValuateNullVal(nameInRepository)
		id = self.getValuesFromMap('id', realmMapStr, keyList)
		data[ID] = self.eValuateNullVal(id)
		
		self.LOGGER.traceExit([str(data)])
		
		return data
	#endDef
	
	def getIdMgrRelams(self):
		
		self.LOGGER.traceEnter()
		
		cmdMap = {}
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrRealms(' + cmdOptions + ')')
		#print('AdminTask.listIdMgrRealms(' + cmdOptions + ')')
		outPutStr = AdminTask.listIdMgrRealms(cmdOptions)
		realmList = outPutStr.split(newline)
		if(len(realmList) == 0):
			realmList = []
		#endIf
		
		self.LOGGER.traceExit([str(realmList)])
		
		return realmList
	#endDef
	
	def getRepositoryBaseEntriesForRealms(self):
		
		self.LOGGER.traceEnter()
		
		realmList = self.getIdMgrRelams()
		realmMapList = []
		for realm in realmList:
			data = {}
			data[ID] = self.eValuateNullVal(realm)
			data[ATTRS] = {}
			data[CHILDREN] = []
			cmdMap = {}
			cmdMap['name'] = realm
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.getIdMgrRepositoriesForRealm(' + cmdOptions + ')')
			#print('AdminTask.getIdMgrRepositoriesForRealm(' + cmdOptions + ')')
			outPutStr = AdminTask.getIdMgrRepositoriesForRealm(cmdOptions)
			repoRealmList = outPutStr.split(newline)
			for repoRealmStr in repoRealmList:
				realmMap = self.getRealmRepoMap(repoRealmStr, realm)
				data[CHILDREN].append(realmMap)
			#endFor
			realmMapList.append(data)
		#endFor
		
		self.LOGGER.traceExit([str(realmMapList)])
		
		return realmMapList
	#endDef
	
	#################################################################
	## Returns unique base entries of a repository available across
	## all available realms
	#################################################################
	
	def getUniqueBasentryWithRealmForRepository(self, repoId):
		
		self.LOGGER.traceEnter([str(repoId)])
		
		baseEntryList = []
		checkMap = {}
		realmDataList = self.getBasentryWithRealmForRepository(repoId)
		for realmData in realmDataList:
			baseEntry = realmData[BASE_ENTRY_NAME]
			if(not checkMap.has_key(baseEntry)):
				checkMap[baseEntry] = 1
				baseEntryList.append(realmData)
			#endIf
		#endFor
		
		self.LOGGER.traceExit([str(baseEntryList)])
		
		return baseEntryList
	#endDef
	
	#################################################################
	## Returns base entries of a repository available across
	## all available realms
	#################################################################
	
	def getBasentryWithRealmForRepository(self, repoId):
		
		self.LOGGER.traceEnter([str(repoId)])
		
		baseEntryList = []
		realmNodeList = self.getRepositoryBaseEntriesForRealms()
		for realmNode in realmNodeList:
			for rmNode in realmNode[CHILDREN]:
				if(rmNode[ID] == repoId):
					baseEntryList.append(rmNode)
				#endIf
			#endFor
		#endFor
		
		self.LOGGER.traceExit([str(baseEntryList)])
		
		return baseEntryList
	#endDef
	
	
	def getIdMgrDefaultRealm(self):
		
		self.LOGGER.traceEnter()
		
		cmdMap = {}
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrDefaultRealm(' + cmdOptions + ')')
		#print('AdminTask.getIdMgrDefaultRealm(' + cmdOptions + ')')
		realmName = AdminTask.getIdMgrDefaultRealm(cmdOptions)
		realmName = self.eValuateNullVal(realmName)
		
		self.LOGGER.traceExit([str(realmName)])
		
		return realmName
	#endDef
	
	def listIdMgrRealms(self):
		
		self.LOGGER.traceEnter()
		
		cmdMap = {}
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrRealms(' + cmdOptions + ')')
		#print('AdminTask.getIdMgrDefaultRealm(' + cmdOptions + ')')
		realmNameList = AdminTask.listIdMgrRealms(cmdOptions)
		realmNameList = realmNameList.split(newline)
		
		self.LOGGER.traceExit([str(realmNameList)])
		
		return realmNameList
	#endDef
	
	def listIdMgrRealmURAttrMappings(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		URAttrListChildList = []
		if(self.isApplicableForWASVersionLevel('7.0.0.11') or self.isApplicableForWASVersionLevel('6.1.0.31')):
			cmdMap = {}
			cmdMap[NAME] = realmName
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.listIdMgrRealmURAttrMappings(' + cmdOptions + ')')
			#print('AdminTask.listIdMgrRealmURAttrMappings(' + cmdOptions + ')')
			URAttrList = AdminTask.listIdMgrRealmURAttrMappings(cmdOptions)
			#URAttrList = '{userDisplayName={propertyForInput=principalName, propertyForOutput=principalName},userSecurityName={propertyForInput=principalName, propertyForOutput=principalName},uniqueUserId={propertyForInput=uniqueName, propertyForOutput=uniqueName},uniqueGroupId={propertyForInput=uniqueName, propertyForOutput=uniqueName},groupSecurityName={propertyForInput=cn, propertyForOutput=cn},groupDisplayName={propertyForInput=cn, propertyForOutput=cn}}'
			if(len(URAttrList) > 0):
				URAttrList = self.convertAdminTaskAttrsToDict(URAttrList)
			else:
				URAttrList = {}
			#endIf
			
			for attrName in URAttrList.keys():
				propertyMap = URAttrList[attrName]
				propertyForInput = propertyMap['propertyForInput']
				propertyForOutput = propertyMap['propertyForOutput']
				data = {}
				data[ID] = self.eValuateNullVal(attrName) + 'Mapping'
				data[ATTRS] = {}
				data[CHILDREN] = []
				data[ATTRS]['propertyForInput'] = self.eValuateNullVal(propertyForInput)
				data[ATTRS]['propertyForOutput'] = self.eValuateNullVal(propertyForOutput)
				
				URAttrListChildList.append(data)
			#endFor
		#endIf
		
		self.LOGGER.traceExit([str(URAttrListChildList)])
		
		return URAttrListChildList
	#endDef
	
	
	def listIdMgrRealmBaseEntries(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrRealmBaseEntries(' + cmdOptions + ')')
		#print('AdminTask.listIdMgrRealmBaseEntries(' + cmdOptions + ')')
		baseEntryList = AdminTask.listIdMgrRealmBaseEntries(cmdOptions)
		baseEntryList = baseEntryList.split(newline)
		
		self.LOGGER.traceExit([str(baseEntryList)])
			 
		return baseEntryList
	#endDef
	
	
	def listIdMgrRealmBaseEntriesData(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		baseEntryChildList = []
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.listIdMgrRealmBaseEntries(' + cmdOptions + ')')
		#print('AdminTask.listIdMgrRealmBaseEntries(' + cmdOptions + ')')
		baseEntryList = AdminTask.listIdMgrRealmBaseEntries(cmdOptions)
		baseEntryList = self.listIdMgrRealmBaseEntries(realmName)
		for baseEntry in baseEntryList:
			baseEntry = baseEntry.strip()
			data = {}
			data[ID] = 'participatingBaseEntries'
			data[ATTRS] = {}
			data[CHILDREN] = []
			data[ATTRS][NAME] = self.eValuateNullVal(baseEntry)
			baseEntryChildList.append(data)
		#endFor
		
		self.LOGGER.traceExit([str(baseEntryChildList)])
		
		return baseEntryChildList
	#endDef
	
	def getRealmChildren(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		childrenList = []
		childrenList = childrenList + self.listIdMgrRealmBaseEntriesData(realmName)
		childrenList = childrenList + self.listIdMgrRealmURAttrMappings(realmName)
		
		self.LOGGER.traceExit([str(childrenList)])
		
		return childrenList
	#endDef
		
		
	def getRealmAttributes(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		realmAttrs = {}
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.getIdMgrRealm(' + cmdOptions + ')')
		#print('AdminTask.getIdMgrRealm(' + cmdOptions + ')')
		realmAttrs = AdminTask.getIdMgrRealm(cmdOptions)
		if(len(realmAttrs) > 0):
			realmAttrs = self.convertAdminTaskAttrsToDict(realmAttrs)
		else:
			realmAttrs = {}
		#endIf
		defaultRealmName = self.getIdMgrDefaultRealm()
		defaultRealmName = defaultRealmName.strip()
		if(defaultRealmName == realmName):
			realmAttrs['isDefaultRealm'] = 'true'
		else:
			realmAttrs['isDefaultRealm'] = 'false'
		#endIf
		if(not realmAttrs.has_key(NAME)):
			realmAttrs[NAME] = self.eValuateNullVal(realmName)
		#endIf
		
		if(self.isTrustedInBoundRealm(realmName)):
			realmAttrs['inboundTrustedAuthenticationRealm'] = 'true'
		elif (self.isApplicableForWASVersion('7.0.0.0')):
			realmAttrs['inboundTrustedAuthenticationRealm'] = 'false'
		#endIf
		
		self.LOGGER.traceExit([str(realmAttrs)])
		
		return realmAttrs
	#endDef
	
	
	def isBaseEntryExistsInRealm(self, realmName, baseEntry):
		
		self.LOGGER.traceEnter([str(realmName), str(baseEntry)])
		
		found = 0
		baseEntryList = self.listIdMgrRealmBaseEntries(realmName)
		baseEntry = baseEntry.strip()
		for entry in baseEntryList:
			entry = entry.strip()
			if(baseEntry == entry):
				found = 1
				break
			#endIf
		#endFor
		
		self.LOGGER.traceExit([str(found)])
		
		return found
	#endDef
	
	def isRealmExists(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		found = 0
		realmList = self.listIdMgrRealms()
		for realm in realmList:
			realm = realm.strip()
			if(realm == realmName):
				found = 1
				break
			#endIf
		#endFor
		
		self.LOGGER.traceExit([str(found)])
		
		return found
	#endDef
	
	def isTrustedInBoundRealm(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		trustedFlag = 0
		if (self.isApplicableForWASVersion('7.0.0.0')):
			cmdMap = {}
			cmdMap['communicationType'] = 'inbound'
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.listTrustedRealms(' + cmdOptions + ')')
			#print('AdminTask.listTrustedRealms(' + cmdOptions + ')')
			realmList = AdminTask.listTrustedRealms(cmdOptions)
			realmList = realmList.split(newline)
			if(len(realmList) > 0):
				for realm in realmList:
					if(realm == realmName):
						trustedFlag = 1
						break;
					#endIf
				#endFor
			#endIf
		#endIf
		
		self.LOGGER.traceExit([str(trustedFlag)])
		
		return trustedFlag
	#endDef
	
	
	def deleteAllRepoBaseEntriesFromRealms(self, repoId):
		
		self.LOGGER.traceEnter([str(repoId)])
		
		realmDataList = self.getBasentryWithRealmForRepository(repoId)
		for realmData in realmDataList:
			baseEntry = realmData[BASE_ENTRY_NAME]
			realmName = realmData[REALM_NAME]
			self.deleteIdMgrRealmBaseEntry(realmName, baseEntry)
		#endFor
		
		self.LOGGER.traceExit()
		
	#endDef
	
	def addIdMgrRealmBaseEntry(self, realmName, baseEntryName):
		
		self.LOGGER.traceEnter([str(realmName), str(baseEntryName)])
		
		if(not self.isBaseEntryExistsInRealm(realmName, baseEntryName)):
			cmdMap = {}
			cmdMap['name'] = realmName
			cmdMap['baseEntry'] = baseEntryName
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.addIdMgrRealmBaseEntry(' + cmdOptions + ')')
			#print('AdminTask.addIdMgrRealmBaseEntry(' + cmdOptions + ')')
			AdminTask.addIdMgrRealmBaseEntry(cmdOptions)
		#endIf
		self.LOGGER.traceExit()
	#endDef
	
	def deleteIdMgrRealmBaseEntry(self, realmName, baseEntryName):
		
		self.LOGGER.traceEnter([str(realmName), str(baseEntryName)])
		
		if(self.isBaseEntryExistsInRealm(realmName, baseEntryName)):
			cmdMap = {}
			cmdMap['name'] = realmName
			cmdMap['baseEntry'] = baseEntryName
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.deleteIdMgrRealmBaseEntry(' + cmdOptions + ')')
			#print('AdminTask.deleteIdMgrRealmBaseEntry(' + cmdOptions + ')')
			AdminTask.deleteIdMgrRealmBaseEntry(cmdOptions)
		#endIf
		
		self.LOGGER.traceExit()
		
	#endDef
	
	def deleteIdMgrRealm(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		if(not realmName == INBUILT_DEFAULT_REALM):
			defaultRealm = self.getIdMgrDefaultRealm()
			if(defaultRealm == realmName):
				self.setIdMgrDefaultRealm(INBUILT_DEFAULT_REALM)
			cmdMap = {}
			cmdMap['name'] = realmName
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.deleteIdMgrRealm(' + cmdOptions + ')')
			#print('AdminTask.deleteIdMgrRealm(' + cmdOptions + ')')
			AdminTask.deleteIdMgrRealm(cmdOptions)
		#endIf
		self.LOGGER.traceExit()
	#endDef

	def removeTrustedRealms(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		if (self.isApplicableForWASVersion('7.0.0.0')):
			if(self.isTrustedInBoundRealm(realmName)):
				cmdMap = {}
				cmdMap['communicationType'] = 'inbound'
				cmdMap['realmList'] = realmName
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				self.LOGGER.debug('AdminTask.removeTrustedRealms(' + cmdOptions + ')')
				#print('AdminTask.removeTrustedRealms(' + cmdOptions + ')')
				AdminTask.removeTrustedRealms(cmdOptions)
			#endIf
		#endIf
		
		self.LOGGER.traceExit()
		
	#endDef
	
	def addTrustedRealms(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		if (self.isApplicableForWASVersion('7.0.0.0')):
			if(not self.isTrustedInBoundRealm(realmName)):
				cmdMap = {}
				cmdMap['communicationType'] = 'inbound'
				cmdMap['realmList'] = realmName
				cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
				self.LOGGER.debug('AdminTask.addTrustedRealms(' + cmdOptions + ')')
				#print('AdminTask.addTrustedRealms(' + cmdOptions + ')')
				AdminTask.addTrustedRealms(cmdOptions)
			#endIf
		#endIf
		
		self.LOGGER.traceExit()
		
	#endDef
	
	def setIdMgrDefaultRealm(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.setIdMgrDefaultRealm(' + cmdOptions + ')')
		#print('AdminTask.setIdMgrDefaultRealm(' + cmdOptions + ')')
		AdminTask.setIdMgrDefaultRealm(cmdOptions)
		
		self.LOGGER.traceExit()
		
	#endDef

	def updateRealmBaseEntryData(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		baseEntryNodeList = []
		for configNode in rafwConfig[CHILDREN]:
			if(configNode[ID] == 'participatingBaseEntries'):
				baseEntryNodeList.append(configNode)
			#endIf
		#endFor
		if(len(baseEntryNodeList) == 0):
			msg = self.getLocalizedMessage("CRWWA0176E", [realmName, scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		#endIf
		retainMap = {}
		for baseEntryNode in baseEntryNodeList:
			baseEntryName = self.getWIMCLIRequiredValue('name', baseEntryNode[ATTRS], 'participatingBaseEntries')
			baseEntryName = baseEntryName.strip()
			retainMap[baseEntryName] = 1
			self.addIdMgrRealmBaseEntry(realmName, baseEntryName)
			rafwConfig[CHILDREN].remove(baseEntryNode)
		#endFor
		
		#delete remaining Base Entries
		existingList = self.listIdMgrRealmBaseEntries(realmName)
		for bEntry in existingList:
			bEntry = bEntry.strip()
			if(not retainMap.has_key(bEntry)):
				self.deleteIdMgrRealmBaseEntry(realmName, bEntry)
			#endIf
		#endFor
		self.LOGGER.traceExit()
		
	#endDef
	def setIdMgrRealmURAttrMapping(self, realmName, attrName, propInput, propOutput):
		
		self.LOGGER.traceEnter([str(realmName), str(attrName), str(propInput), str(propOutput)])
		
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdMap['URAttrName'] = attrName
		cmdMap['propertyForInput'] = propInput
		cmdMap['propertyForOutput'] = propOutput
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.setIdMgrRealmURAttrMapping (' + cmdOptions + ')')
		#print('AdminTask.setIdMgrRealmURAttrMapping (' + cmdOptions + ')')
		AdminTask.setIdMgrRealmURAttrMapping (cmdOptions)
		self.LOGGER.traceExit()
	#endDef
		
	
	def updateRealmURAttrMappingsData(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		realmURAttributeList = ['uniqueUserIdMapping', 'userSecurityNameMapping', 'userDisplayNameMapping',
								'uniqueGroupIdMapping', 'groupSecurityNameMapping', 'groupDisplayNameMapping']
		realmURAttributeNodeList = []
		if(self.isApplicableForWASVersionLevel('7.0.0.11') or self.isApplicableForWASVersionLevel('6.1.0.31')):
			for attrName in realmURAttributeList:
				for configNode in rafwConfig[CHILDREN]:
					if(configNode[ID] == attrName):
						realmURAttributeNodeList.append(configNode)
					#endIf
				#endFor
			#endFor
			
			for attrNode in realmURAttributeNodeList:
				urAttrName = attrNode[ID].replace('Mapping', '')
				propertyForInput = self.getWIMCLIRequiredValue('propertyForInput', attrNode[ATTRS], attrNode[ID])
				propertyForOutput = self.getWIMCLIRequiredValue('propertyForOutput', attrNode[ATTRS], attrNode[ID])
				self.setIdMgrRealmURAttrMapping(realmName, urAttrName, propertyForInput, propertyForOutput)
				rafwConfig[CHILDREN].remove(attrNode)
			#endFor
		#endIf
		self.LOGGER.traceExit()
	#endDef
			 
	def updateRealmChildrenData(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		self.updateRealmBaseEntryData(realmName, rafwConfig)
		self.updateRealmURAttrMappingsData(realmName, rafwConfig)
		
		if(len(rafwConfig[CHILDREN]) > 0):
			unrecognisedList = []
			for node in rafwConfig[CHILDREN]:
				unrecognisedList.append(node[ID])
			#endFor
			msg = self.getLocalizedMessage("CRWWA0167W", [str(unrecognisedList), 'realms', scope])
			self.LOGGER.warn(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef
				
	def updateRealmAttrubtes(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		realmAttrs = rafwConfig[ATTRS]
		
		#name is already processed
		del realmAttrs[NAME]
		
		if(realmAttrs.has_key('isDefaultRealm')):
			if(realmAttrs['isDefaultRealm'] == 'true'):
				self.setIdMgrDefaultRealm(realmName)
			#endIf
			del realmAttrs['isDefaultRealm']
		#endIf
		if(realmAttrs.has_key('inboundTrustedAuthenticationRealm')):
			if(realmAttrs['inboundTrustedAuthenticationRealm'] == 'true'):
				self.addTrustedRealms(realmName)
			else:
				self.removeTrustedRealms(realmName)
			#endIf
			del realmAttrs['inboundTrustedAuthenticationRealm']
		else:
			self.removeTrustedRealms(realmName)
		#endIf
		
		realmAttrList = ['allowOperationIfReposDown', 'delimiter', 'securityUse']
		
		cmdMap = {}
		cmdMap[NAME] = realmName
		for atrName in realmAttrList:
			if(realmAttrs.has_key(atrName)):
				cmdMap[atrName] = realmAttrs[atrName]
				del realmAttrs[atrName]
			#endIf
		#endFor
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.updateIdMgrRealm(' + cmdOptions + ')')
		repositoryMap = AdminTask.updateIdMgrRealm(cmdOptions)
		
		unrecognisedList = []
		for key in realmAttrs.keys():
			unrecognisedList.append(key)
		#endFor
		if(len(unrecognisedList) > 0):
			msg = self.getLocalizedMessage("CRWWA0167W", [str(unrecognisedList), 'realms', scope])
			self.LOGGER.warn(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef		
		
	def updateIdMgrRealm(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		self.updateRealmAttrubtes(realmName, rafwConfig)
		self.updateRealmChildrenData(realmName, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	#endDef
	#######################################################################
	## Convert the values to list or dict based on the input data structure
	#######################################################################
	def createIdMgrRealm(self, realmName, rafwConfig):
		
		self.LOGGER.traceEnter([str(realmName), str(rafwConfig)])
		
		cmdMap = {}
		cmdMap[NAME] = realmName
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.createIdMgrRealm(' + cmdOptions + ')')
		#print('AdminTask.createIdMgrRealm(' + cmdOptions + ')')
		AdminTask.createIdMgrRealm(cmdOptions)
		
		#Then update the realm
		self.updateIdMgrRealm(realmName, rafwConfig)
		
		self.LOGGER.traceExit()
		
	#endDef
	
	#######################################################################
	## Convert the values to list or dict based on the input data structure
	####################################################################### 
	
	def createRealmConfigData(self, rafwConfig):
		
		self.LOGGER.traceEnter([str(rafwConfig)])
		
		realmName = rafwConfig[ATTRS][NAME]
		if(self.isRealmExists(realmName) or realmName == INBUILT_DEFAULT_REALM):
			print "updateIdMgrRealm : updating the realm with name " + realmName
			self.updateIdMgrRealm(realmName, rafwConfig)
		else:
			print "createIdMgrRealm : creating the realm with name " + realmName
			self.createIdMgrRealm(realmName, rafwConfig)
		#endIf
		
		self.LOGGER.traceExit()
		
	#endDef
	
	def readRealmData(self, realmName):
		
		self.LOGGER.traceEnter([str(realmName)])
		
		realmData = {}
		realmData[ID] = 'realms'
		realmData[CHILDREN] = self.getRealmChildren(realmName)
		realmData[ATTRS] = self.getRealmAttributes(realmName)
		
		if(realmName == INBUILT_DEFAULT_REALM):
			realmData[ID] = 'builtin'
			if(realmData[ATTRS].has_key(NAME)):
				del realmData[ATTRS][NAME]
			#endIf
		#endIf
		
		self.LOGGER.traceExit([str(realmData)])
		
		return realmData
	#endDef
	
	def readRealmConfiguration(self):
		
		self.LOGGER.traceEnter()
		
		realmDataList = []
		realmNameList = self.listIdMgrRealms()
		for realmName in realmNameList:
			realmData = self.readRealmData(realmName)
			realmDataList.append(realmData)
		#endFor
		
		self.LOGGER.traceExit([str(realmDataList)])
		
		return realmDataList
	#endDef
		
		
		
		
############## CLASS :: _WIMConfigManager #######################
# This class is used to manage the configuration data of		#
# Federated Security											#
# This class is the virtual interface to WIM config interfaces	#
#																#
# THIS CLASS DOESNT MAINTAINS STATE -- IS USED AS SINGLETON		#
#																#
#################################################################
class _WIMConfigManager(WIMConfigReaderHelper):

	##################################################################
	## This constructor is used to initialize config helper references
	##################################################################
	def __init__(self):
		self.LOGGER = _Logger("_WIMConfigManager", MessageManager.RB_WEBSPHERE_WAS)
		self.repoHelper = None
		self.fileRepoHelper = None
		self.ldapRepoHelper = None
		self.dbRepoHelper = None
		self.realmHelper = None
		self.entityTypeHelper = None
		
	#endDef
	
	##########################################################
	## Validates the repository types supported by WIM
	##########################################################
	
	def isValidRepoType(self, repoType):
		
		self.LOGGER.traceEnter([str(repoType)])
		
		retVal = 0
		if(repoType is None or len(repoType) == 0):
			retVal = 0
		else:
			for rType in SUPPORTED_REPO_TYPES:
				if(rType == repoType):
					retVal = 1
					break
				#endIf
			#endFor
		#endIf
		self.LOGGER.traceExit([str(retVal)])
		
		return retVal
	#endDef
	
	##########################################################
	## Validates RAFW supported entity types config data
	##########################################################
	
	def validateSupportedentiTypesData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		attrName = None
		for rafwConfig in rafwConfigs:
			if(not rafwConfig[ATTRS].has_key(NAME) or len(rafwConfig[ATTRS][NAME]) == 0):
				attrName = NAME
			elif (not rafwConfig[ATTRS].has_key('defaultParent') or len(rafwConfig[ATTRS]['defaultParent']) == 0):
				attrName = 'defaultParent'
			#endIf
			
			if(attrName is not None):
				msg = self.getLocalizedMessage("CRWWA0165E", [attrName, currentConfigType, scope])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException
			if(len(rafwConfig[CHILDREN]) == 0):
				msg = self.getLocalizedMessage("CRWWA0180E", [rafwConfig[NAME], scope])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException
			#endIf
			attrName = None
		#endFor
		self.LOGGER.traceExit()
	#endDef
		
		
	##########################################################
	## Validates RAFW repository config data
	##########################################################
	def validateRepositoryData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		
		isValidrepoIdFlag = 0
		for rafwConfig in rafwConfigs:
			if (rafwConfig[ATTRS].has_key(ID)):
				repoType = rafwConfig[ATTRS][ID]
				if(len(repoType) == 0):
					isValidrepoIdFlag = 0
				else:
					isValidrepoIdFlag = 1
				#endIf	
			else:
				isValidrepoIdFlag = 0
			#endIf
			
			if(isValidrepoIdFlag == 0):
				msg = self.getLocalizedMessage("CRWWA0165E", [scope, ID, currentConfigType])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException(msg)
			#endIf
			
		#endFor
		self.LOGGER.traceExit()
		
	#endDef
	
	##########################################################
	## Validates realm data in RAFW config
	##########################################################
	
	def validateRealmData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		isValid = 0
		defaultRealmCount = 0
		isvalidDefaultRealm = 1
		for rafwConfig in rafwConfigs:
			relmName = self.getWIMCLIRequiredValue('name', rafwConfig[ATTRS], currentConfigType)
			isValid = 1
			if (rafwConfig[ATTRS].has_key('isDefaultRealm')):
				if(rafwConfig[ATTRS]['isDefaultRealm'] == 'true'):
					defaultRealmCount = defaultRealmCount + 1
				#endIf
			#endIf
		#endFor
		if (isValid == 0):
			msg = self.getLocalizedMessage("CRWWA0165E", [scope, ID, currentConfigType])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		#endIf
		if(mode == MODE_AUGMENT):
			if(defaultRealmCount > 1):
				isvalidDefaultRealm = 0
			#endIf
		elif (not defaultRealmCount == 1):
			realmHelper = self.getRealmHelper()
			defaultRealm = realmHelper.getIdMgrDefaultRealm()
			if(defaultRealmCount == 0 and defaultRealm == INBUILT_DEFAULT_REALM):
				isvalidDefaultRealm = 1
			else:
				isvalidDefaultRealm = 0
			#endIf
		#endIf
		if (isvalidDefaultRealm == 0):
			msg = self.getLocalizedMessage("CRWWA0177E", [scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef
		
	def getRealmHelper(self):
		
		if(self.realmHelper == None):
			self.realmHelper = RealmHelper()
		#endIf
		
		return self.realmHelper
	#endDef
	
	def getSupportedEntityTypeHelper(self):
		
		if(self.entityTypeHelper == None):
			self.entityTypeHelper = SupportedEntityTypesHelper()
		#endIf
		
		return self.entityTypeHelper
	#endDef

	def getRepositoryHelper(self, id, repoType):
		
		retRepoHelper = None
	 
		if(repoType == FILE_TYPE or repoType == WAS_FILE_TYPE):
			if(self.fileRepoHelper == None):
				self.fileRepoHelper = FileRepoConfigHelper()
			#endDef
			retRepoHelper = self.fileRepoHelper
		elif(repoType == LDAP_TYPE or repoType == WAS_LDAP_TYPE):
			if(self.ldapRepoHelper == None):
				self.ldapRepoHelper = LdapRepoConfigHelper()
			#endDef
			retRepoHelper = self.ldapRepoHelper
		elif(repoType == CUSTOM_TYPE or repoType == WAS_CUSTOM_TYPE):
			if(self.repoHelper == None):
				self.repoHelper = RepoConfigHelper()
			#endDef
			retRepoHelper = self.repoHelper
			#supported in 6.1.0.27 make sure u change accordingly
		elif(repoType == DB_TYPE or repoType == WAS_DB_TYPE):
			if(self.dbRepoHelper == None):
				self.dbRepoHelper = DBRepoConfigHelper()
			#endDef
			retRepoHelper = self.dbRepoHelper
		else:
			msg = self.getLocalizedMessage('CRWWA0164E', [id, repoType, scope])
			self.LOGGER.error(msg)
			raise ConfigReaderException(msg)
		#endIf
		
		return retRepoHelper
	#endDef
	
	##########################################################
	## This method deletes list of WIM repository configs from
	## WAS config
	##########################################################
		
	def deleteIdMgrRepositories(self, repoIdList=[]):
		
		self.LOGGER.traceEnter([str(repoIdList)])
		
		for repoId in repoIdList:
			if(not repoId == INBUILT_PROFILEREPO_ID):
				realmHelper = self.getRealmHelper()
				realmHelper.deleteAllRepoBaseEntriesFromRealms(repoId)
				cmdOptions = '[ -id ' + repoId + ' ]'
				self.LOGGER.debug('AdminTask.deleteIdMgrRepository(' + cmdOptions + ')')
				#print('AdminTask.deleteIdMgrRepository(' + cmdOptions + ')')
				AdminTask.deleteIdMgrRepository(cmdOptions)
			#endIf
		#endFor
		self.LOGGER.traceExit()
	#endDef
	
	def deleteIdMgrRealms(self, realmNameList=[]):
		
		self.LOGGER.traceEnter([str(realmNameList)])
		
		for realmName in realmNameList:
			if(not realmName == INBUILT_DEFAULT_REALM):
				realmHelper = self.getRealmHelper()
				realmHelper.deleteIdMgrRealm(realmName)
			#endIf
		#endFor
		self.LOGGER.traceExit()
		
	#endDef
	
	########################################################################
	## Reads Supported Entity Types Data from WAS config using helper class
	########################################################################
	
	def readSupportedEntityTypesConfigurationData(self):
		
		self.LOGGER.traceEnter()
		
		typeHelperObj = self.getSupportedEntityTypeHelper()
		entityTypeDataList = []
		
		entityTypeData = typeHelperObj.readSupportedEntiTypesConfiguration()
		if(len(entityTypeData) > 0):
			entityTypeDataList = entityTypeData
		#endIf
		self.LOGGER.traceExit([str(entityTypeDataList)])
		
		return entityTypeDataList
	#endDef
	
	###################################################################
	## Creates supported sneity types in WAS config using helper class
	###################################################################
	
	def createSupportedEntityTypesConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		entityTypeList = []
		# should be called before the below for loop
		self.validateSupportedentiTypesData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			entityTypeName = rafwConfig[ATTRS][NAME]
			typeHelperObject = self.getSupportedEntityTypeHelper()
			typeHelperObject.createSupportedEntityTypesConfigData(rafwConfig)
			entityTypeList.append(entityTypeName)
		#endFor
		self.LOGGER.traceExit()
		
	#endDef
	
	#################################################################################
	## Augments supported entity types config data in WAS config using helper class
	#################################################################################
	
	def augmentSupportedentiTypesConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		entityTypeConfigList = []
		# should be called before the below for loop
		self.validateSupportedentiTypesData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			entityTypeName = rafwConfig[ATTRS][NAME]
			typeHelperObject = self.getSupportedEntityTypeHelper()
			if(not typeHelperObject.isEntityTypeExists(entityTypeName)):
				entityTypeConfigList.append(rafwConfig)
			else:
				msg = self.getLocalizedMessage("CRWWA0175W", [currentConfigType, entityTypeName, scope])
				self.LOGGER.warn(msg)
			#endIf
		#endFor
		self.createSupportedEntityTypesConfigData(entityTypeConfigList)
		
		self.LOGGER.traceExit()
		
	#endDef
	
	##########################################################
	## Reads realm data from WAS config using helper class
	##########################################################
	
	def readRealmConfigurationData(self):
		
		self.LOGGER.traceEnter()
		
		realmDataList = []
		realmHelper = self.getRealmHelper()
		realmData = realmHelper.readRealmConfiguration()
		if(len(realmData) > 0):
			realmDataList = realmData
		#endIf
		self.LOGGER.traceExit([str(realmDataList)])
		
		return realmDataList
	#endDef
	
	###################################################################
	## Creates realm data in WAS config using helper class
	###################################################################
	
	def createRealmConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		realmIdList = []
		# should be called before the below for loop
		self.validateRealmData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			realmName = rafwConfig[ATTRS][NAME]
			realmHelper = self.getRealmHelper()
			realmHelper.createRealmConfigData(rafwConfig)
			realmIdList.append(realmName)
		#endFor
		self.LOGGER.traceExit()
		
	#endDef
	
	######################################################################
	## Augments realm data in WAS config using helper class
	#####################################################################
	
	def augmentRealmConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		realmConfigList = []
		# should be called before the below for loop
		self.validateRealmData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			realmName = rafwConfig[ATTRS][NAME]
			realmHelper = self.getRealmHelper()
			if(not realmHelper.isRealmExists(realmName)):
				realmConfigList.append(rafwConfig)
			else:
				msg = self.getLocalizedMessage("CRWWA0175W", [currentConfigType, realmName, scope])
				self.LOGGER.warn(msg)
			#endIf
		#endFor
		if(len(realmConfigList) > 0):
			self.createRealmConfigData(realmConfigList)
		#endIf
	#endDef
	
	#################################################################
	## Reads repository config data from WAS using helper classes
	#################################################################
	
	def readRepositoryConfigData(self, scope):
		
		self.LOGGER.traceEnter([''])
		repoData = []
		repoMap = self.getWASRepositoryListMap()
		rids = repoMap.keys()
		if(len(rids) > 0):
			self.LOGGER.log("CRWWA0162I", [rids, scope])
			data = []
			for id in rids:
				repoTypeMap = repoMap[id]
				repoType = repoTypeMap[REPO_TYPE]
				repoHelper = self.getRepositoryHelper(id, repoType)
				if(repoType == WAS_CUSTOM_TYPE and not self.isApplicableForWASVersion('6.1.0.27')):
					currentProdVersion = self.getNodeBaseProductVersion()
					msg = self.getLocalizedMessage("CRWWA0172W", [repoType, scope, currentProdVersion])
					self.LOGGER.warn(msg)
				else:
					data = repoHelper.readRepositoryConfigData(id)
					if(len(data) > 0):
						repoData.append(data)
					#endIf
				#endIf
			#endFor
		else:
			self.LOGGER.log("CRWWA0163I", scope)
		#endIf
		self.LOGGER.traceExit([str(repoData)])
		
		return repoData
	#endDef
	
	######################################################################
	## Creates repository config in WAS using helper classes
	#######################################################################
	
	def createRepositoryConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		repoIdList = []
		# should be called before the below for loop
		self.validateRepositoryData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			repoHelper = self.getRepositoryHelper(rafwConfig[ATTRS][ID], rafwConfig[ID])
			repoId = repoHelper.createRepositoryConfigData(rafwConfig)
			repoIdList.append(repoId)
		#endFor
		msg = self.getLocalizedMessage("CRWWA0173I", [str(repoIdList), scope])
		self.LOGGER.log(msg)
		
		self.LOGGER.traceExit()
		
	#endDef
	
	######################################################################
	## Augments repository config in WAS using helper classes
	#######################################################################
	
	def augmentRepositoryConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		repoConfigList = []
		# should be called before the below for loop
		self.validateRepositoryData(rafwConfigs)
		for rafwConfig in rafwConfigs:
			repoId = rafwConfig[ATTRS][ID]
			if(not self.isRepositoryExists(repoId)):
				repoConfigList.append(rafwConfig)
			else:
				msg = self.getLocalizedMessage("CRWWA0175W", [currentConfigType, repoId, scope])
				self.LOGGER.warn(msg)
			#endIf
		#endFor
		self.createRepositoryConfigData(repoConfigList)
		
		self.LOGGER.traceExit()
	#endDef
	##########################################################
	## Reads property extension repository config from WAS
	##########################################################
	
	def readLAConfigData(self):
		
		self.LOGGER.traceEnter([''])
		
		repoData = []
		excludedAttrList = ['id', 'adapterClassName']
		try:
			cmdMap = {}
			cmdMap['id'] = LA
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.getIdMgrRepository(' + cmdOptions + ')')
			repos = AdminTask.listIdMgrRepositories()
			if str(repos).find("LA") !=-1:
				repositoryMap = AdminTask.getIdMgrRepository(cmdOptions)
				repositoryMap = self.convertAdminTaskAttrsToDict(repositoryMap)
				parent = {}
				parent[ID] = 'propertyExtensionRepository'
				parent[ATTRS] = repositoryMap
				parent[CHILDREN] = []
				repoData.append(parent)
				for keyName in excludedAttrList:
					if(parent[ATTRS].has_key(keyName)):
						del parent[ATTRS][keyName]
					#endIf
				#endFor
			#endIf
		except:
			#self.LOGGER.warn(sys.exc_info(0))
			pass

		self.LOGGER.traceExit([str(repoData)])
		
		return repoData
	#endDef
	
	##################################################################################
	## Creates property extension repository config in WAS
	#################################################################################
	
	def createLAConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		repoIdList = []
		optionalParamList = ['dataSourceName', 'databaseType', '']
		rafwConfig = rafwConfigs[0]
		cmdMap = {}
		cmdMap['dbURL'] = self.getWIMCLIRequiredValue('dbURL', rafwConfig[ATTRS], currentConfigType)
		del rafwConfig[ATTRS]['dbURL']
		cmdMap['entityRetrievalLimit'] = self.getWIMCLIRequiredValue('entityRetrievalLimit', rafwConfig[ATTRS], currentConfigType)
		del rafwConfig[ATTRS]['entityRetrievalLimit']
		cmdMap['JDBCDriverClass'] = self.getWIMCLIRequiredValue('JDBCDriverClass', rafwConfig[ATTRS], currentConfigType)
		del rafwConfig[ATTRS]['JDBCDriverClass']
		
		if(rafwConfig[ATTRS].has_key('dbAdminPassword')):
			cmdMap['dbAdminPassword'] = rafwConfig[ATTRS]['dbAdminPassword']
			del rafwConfig[ATTRS]['dbAdminPassword']
		else:
			cmdMap['dbAdminPassword'] = ''
		#endIf
		
		if(rafwConfig[ATTRS].has_key('dbAdminId')):
			cmdMap['dbAdminId'] = rafwConfig[ATTRS]['dbAdminId']
			del rafwConfig[ATTRS]['dbAdminId']
		else:
			cmdMap['dbAdminId'] = ''
		#endIf
		if(rafwConfig[ATTRS].has_key('dataSourceName') and len(rafwConfig[ATTRS]['dataSourceName']) > 0):
			cmdMap['dataSourceName'] = rafwConfig[ATTRS]['dataSourceName']
			del rafwConfig[ATTRS]['dataSourceName']
		#endIf
		
		if(rafwConfig[ATTRS].has_key('databaseType') and len(rafwConfig[ATTRS]['databaseType']) > 0):
			cmdMap['databaseType'] = rafwConfig[ATTRS]['databaseType']
			del rafwConfig[ATTRS]['databaseType']
		#endIf
		if (len(rafwConfig[ATTRS]) > 0):
			msg = self.getLocalizedMessage("CRWWA0167W", [str(rafwConfig[ATTRS].keys()), currentConfigType, scope])
			self.LOGGER.warn(msg)
		#endIf
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.setIdMgrPropertyExtensionRepository(' + cmdOptions + ')')
		repositoryMap = AdminTask.setIdMgrPropertyExtensionRepository(cmdOptions)
		
		self.LOGGER.traceExit()
		
	#endDef
	
	##########################################################
	## Reads Entry Mapping Repository config from WAS
	##########################################################
	
	def readFEDConfigData(self):
		
		self.LOGGER.traceEnter()
		
		repoData = []
		excludedAttrList = ['id', 'adapterClassName']
		try:
			cmdMap = {}
			cmdMap['id'] = FED
			cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
			self.LOGGER.debug('AdminTask.getIdMgrRepository(' + cmdOptions + ')')			
			if str(repos).find("FED") !=-1:
				repositoryMap = AdminTask.getIdMgrRepository(cmdOptions)
				repositoryMap = self.convertAdminTaskAttrsToDict(repositoryMap)
				parent = {}
				parent[ID] = 'entryMappingRepository'
				parent[ATTRS] = repositoryMap
				parent[CHILDREN] = []
				repoData.append(parent)
				for keyName in excludedAttrList:
					if(parent[ATTRS].has_key(keyName)):
						del parent[ATTRS][keyName]
					#endIf
				#endFor
			#endIf
		except:
			#self.LOGGER.warn(sys.exc_info(0))
			pass

		self.LOGGER.traceExit([str(repoData)])
		
		return repoData
	#endDef
	
	##########################################################
	## Creates Entry Mapping Repository config in WAS
	##########################################################
	
	def createFEDConfigData(self, rafwConfigs):
		
		self.LOGGER.traceEnter([str(rafwConfigs)])
		
		repoIdList = []
		optionalParamList = ['dataSourceName', 'databaseType', '']
		rafwConfig = rafwConfigs[0]
		cmdMap = {}
		cmdMap['dbURL'] = self.getWIMCLIRequiredValue('dbURL', rafwConfig[ATTRS], currentConfigType)
		del rafwConfig[ATTRS]['dbURL']
		cmdMap['JDBCDriverClass'] = self.getWIMCLIRequiredValue('JDBCDriverClass', rafwConfig[ATTRS], currentConfigType)
		del rafwConfig[ATTRS]['JDBCDriverClass']
		
		if(rafwConfig[ATTRS].has_key('dbAdminPassword')):
			cmdMap['dbAdminPassword'] = rafwConfig[ATTRS]['dbAdminPassword']
			del rafwConfig[ATTRS]['dbAdminPassword']
		else:
			cmdMap['dbAdminPassword'] = ''
		#endIf
		
		if(rafwConfig[ATTRS].has_key('dbAdminId')):
			cmdMap['dbAdminId'] = rafwConfig[ATTRS]['dbAdminId']
			del rafwConfig[ATTRS]['dbAdminId']
		else:
			cmdMap['dbAdminId'] = ''
		#endIf
		if(rafwConfig[ATTRS].has_key('dataSourceName') and len(rafwConfig[ATTRS]['dataSourceName']) > 0):
			cmdMap['dataSourceName'] = rafwConfig[ATTRS]['dataSourceName']
			del rafwConfig[ATTRS]['dataSourceName']
		#endIf
		
		if(rafwConfig[ATTRS].has_key('databaseType') and len(rafwConfig[ATTRS]['databaseType']) > 0):
			cmdMap['databaseType'] = rafwConfig[ATTRS]['databaseType']
			del rafwConfig[ATTRS]['databaseType']
		#endIf
		if (len(rafwConfig[ATTRS]) > 0):
			msg = self.getLocalizedMessage("CRWWA0167W", [str(rafwConfig[ATTRS].keys()), currentConfigType, scope])
			self.LOGGER.warn(msg)
		#endIf
		cmdOptions = self.getAdminTaskCommandOptions(cmdMap)
		self.LOGGER.debug('AdminTask.setIdMgrEntryMappingRepository(' + cmdOptions + ')')
		repositoryMap = AdminTask.setIdMgrEntryMappingRepository(cmdOptions)
		
		self.LOGGER.traceExit()
		
	#endDef		
	
#end CLASS
			 
		
############## CLASS :: WIMConfigMediator ###################
# This class is used to execute actions for supported modes	#
#															#
# THIS CLASS DOESNT MAINTAINS STATE -- IS A SINGLETON		#
#															#
#############################################################

class WIMConfigMediator(WIMConfigReaderHelper):
	

	def __init__(self , xmlFile, currentConfigType, scope):
		self.xmlFile = xmlFile
		self.currentConfigType = currentConfigType
		self.scope = scope
		self.LOGGER = _Logger("WIMConfigMediator", MessageManager.RB_WEBSPHERE_WAS)
	
	def setBuiltInNodeValues(self, attrName, attrValue, nodeAttrMap, typeName):

		self.LOGGER.traceEnter([str(attrName), str(attrValue), str(nodeAttrMap), str(typeName)])
		
		if(nodeAttrMap.has_key(attrName)):
			msg = self.getLocalizedMessage("CRWWA0170W", [nodeAttrMap[attrName], attrName, typeName, scope])
			self.LOGGER.warn(msg)
		#endIf
		msg = self.getLocalizedMessage("CRWWA0171I", [attrValue, attrName, typeName, scope])
		self.LOGGER.log(msg)
		nodeAttrMap[attrName] = attrValue
		
		self.LOGGER.traceExit()
		 
	#endDef
	def isRepoExistInRAFWConfig(self, rafwConfigs, rId):
		
		
		repoFound = 0
		for rafwConfig in rafwConfigs:
			if(rafwConfig[ATTRS][ID] == rId):
				repoFound = 1
			#endIf
		#endFor
		return repoFound
	#endDef
	
	def isRealmExistInRAFWConfig(self, rafwConfigs, realmName):
		repoFound = 0
		for rafwConfig in rafwConfigs:
			if(rafwConfig[ATTRS][NAME] == realmName):
				repoFound = 1
			#endIf
		#endFor
		return repoFound
	#endDef
	
	def getRAFWWIMSupportedEntityTypesConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = None
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(markerTypes['supportedEntityTypes'])
		xmlConfigReader = XMLConfigReader()
		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(self.currentConfigType)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef 
	def getRAFWWIMRepositoriesConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = []
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(markerTypes['repositories'])
		xmlConfigReader = XMLConfigReader()
		# get rafwConfig
		for rType in SUPPORTED_REPO_TYPES:
			filteredNodes = xmlProp.getFilteredNodeArray(rType)
			if (filteredNodes is not None):
				rafwConfig = rafwConfig + xmlConfigReader.readXmlConfig(filteredNodes)
			#endIf
		#endFor
		
		builtInFilteredNodes = xmlProp.getFilteredNodeArray("builtin")
		inbuiltFileconfig = xmlConfigReader.readXmlConfig(builtInFilteredNodes)
		if(len(inbuiltFileconfig) > 0):
			if(len(inbuiltFileconfig) > 1):
				msg = self.getLocalizedMessage("CRWWA0169E", [typeName, scope])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException(msg)
			#endIf
			
			buildInBode = inbuiltFileconfig[0]
			
			if(not mode == MODE_COMPARE):
				buildInBode[ID] = FILE_TYPE
				self.setBuiltInNodeValues('adapterClassName', 'com.ibm.ws.wim.adapter.file.was.FileAdapter' , 
				buildInBode[ATTRS],self.currentConfigType)
				self.setBuiltInNodeValues(ID, INBUILT_PROFILEREPO_ID , buildInBode[ATTRS], self.currentConfigType)
			#endIf
			
			rafwConfig = rafwConfig + inbuiltFileconfig
		#endIf
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef 
	
	def getRAFWWIMLAConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = None
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(markerTypes['propertyExtensionRepository'])
		xmlConfigReader = XMLConfigReader()
		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(self.currentConfigType)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		if(len(rafwConfig) > 1):
			msg = self.getLocalizedMessage("CRWWA0178E", [markerTypes[''], scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)			
		elif(len(rafwConfig) == 1):
			if(mode == MODE_COMPARE):
				configNode = rafwConfig[0]
				if(configNode[ATTRS].has_key(ID) and configNode[ATTRS][ID] == LA):
					del configNode[ATTRS][ID]
				#endIf
				if(configNode[ATTRS].has_key('adapterClassName') and 
					configNode[ATTRS]['adapterClassName'] == 'com.ibm.ws.wim.lookaside.LookasideAdapter'):
					del configNode[ATTRS][ID]
				#endIf
			#endIf
		#endIf
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef
	def getRAFWWIMFEDConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = None
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(markerTypes['entryMappingRepository'])
		xmlConfigReader = XMLConfigReader()
		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(self.currentConfigType)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		if(len(rafwConfig) > 1):
			msg = self.getLocalizedMessage("CRWWA0178E", [markerTypes['entryMappingRepository'], scope])
			self.LOGGER.error(msg)
			raise InvalidXmlConfigException(msg)			
		elif(len(rafwConfig) == 1):
			if(mode == MODE_COMPARE):
				configNode = rafwConfig[0]
				if(configNode[ATTRS].has_key(ID) and configNode[ATTRS][ID] == FED):
					del configNode[ATTRS][ID]
				#endIf
				if(configNode[ATTRS].has_key('adapterClassName') and 
					configNode[ATTRS]['adapterClassName'] == 'com.ibm.ws.wim.federation.FederationAdapter'):
					del configNode[ATTRS][ID]
				#endIf
			#endIf
		#endIf
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef
	def getRAFWWIMRealmsConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = None
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(markerTypes['realms'])
		xmlConfigReader = XMLConfigReader()
		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(self.currentConfigType)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		builtInFilteredNodes = xmlProp.getFilteredNodeArray("builtin")
		inbuiltFileconfig = xmlConfigReader.readXmlConfig(builtInFilteredNodes)
		if(len(inbuiltFileconfig) > 0):
			if(len(inbuiltFileconfig) > 1):
				msg = self.getLocalizedMessage("CRWWA0169E", [typeName, scope])
				self.LOGGER.error(msg)
				raise InvalidXmlConfigException(msg)
			#endIf
			
			buildInBode = inbuiltFileconfig[0]
			
			if(not mode == MODE_COMPARE):
				buildInBode[ID] = self.currentConfigType
				self.setBuiltInNodeValues(NAME, INBUILT_DEFAULT_REALM, buildInBode[ATTRS], self.currentConfigType)
			#endIf
			rafwConfig = rafwConfig + inbuiltFileconfig
		#endIf
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef 
	def getRAFWWIMConfig(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfig = None
		if (self.currentConfigType == "repositories"):
			rafwConfig = self.getRAFWWIMRepositoriesConfig()
		elif (self.currentConfigType == "realms"):
			rafwConfig = self.getRAFWWIMRealmsConfig()
		elif (self.currentConfigType == "propertyExtensionRepository"):
			rafwConfig = self.getRAFWWIMLAConfig()
		elif (self.currentConfigType == "entryMappingRepository"):
			rafwConfig = self.getRAFWWIMFEDConfig()
		elif (self.currentConfigType == "supportedEntityTypes"):
			rafwConfig = self.getRAFWWIMSupportedEntityTypesConfig()
		else:
			rafwConfig = None
	
	
		self.LOGGER.traceExit([str(rafwConfig)])
		
		return rafwConfig
	#endDef

	def executeFederatedSecuritySupportedEntityTypes(self):
		
		self.LOGGER.traceEnter()
		
		removeRepoList = []
		rafwConfigs = self.getRAFWWIMSupportedEntityTypesConfig()
		typeHelperObject = WIMConfigManager.getSupportedEntityTypeHelper()
		typeHelperObject.deleteIdMgrAllsSupportedEntityTypes()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.createSupportedEntityTypesConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['supportedEntityTypes'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef
	def executeFederatedSecurityRepositories(self):
		
		self.LOGGER.traceEnter()
		
		removeRepoList = []
		rafwConfigs = self.getRAFWWIMRepositoriesConfig()
		wasRepoMap = self.getWASRepositoryListMap()
		wasRepoList = wasRepoMap.keys()
		for rId in wasRepoList:
			if(not self.isRepoExistInRAFWConfig(rafwConfigs, rId)):
				removeRepoList.append(rId)
			#endIf
		#endFor
		WIMConfigManager.deleteIdMgrRepositories(removeRepoList)
		if(len(rafwConfigs) > 0):
			WIMConfigManager.createRepositoryConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['repositories'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
	#endDef
		
	def executeFederatedSecurityLA(self):
		
		self.LOGGER.traceEnter()
		
		removeRepoList = []
		rafwConfigs = self.getRAFWWIMLAConfig()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.createLAConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['propertyExtensionRepository'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef
	
	
	def executeFederatedSecurityFED(self):
		
		self.LOGGER.traceEnter()
		
		removeRepoList = []
		rafwConfigs = self.getRAFWWIMFEDConfig()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.createFEDConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['entryMappingRepository'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef
	
		
	def executeFederatedSecurityRealms(self):
		
		self.LOGGER.traceEnter()
		
		removeRealmList = []
		rafwConfigs = self.getRAFWWIMRealmsConfig()
		realmHelper = WIMConfigManager.getRealmHelper()
		wasRealmList = realmHelper.listIdMgrRealms()
		for realmName in wasRealmList:
			if(not self.isRealmExistInRAFWConfig(rafwConfigs, realmName)):
				removeRealmList.append(realmName)
			#endIf
		#endFor
		WIMConfigManager.deleteIdMgrRealms(removeRealmList)
		if(len(rafwConfigs) > 0):
			WIMConfigManager.createRealmConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['realms'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
	#endDef
 
	def augmentFederatedSecuritySupportedEntityTypes(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfigs = self.getRAFWWIMSupportedEntityTypesConfig()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.augmentSupportedentiTypesConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['supportedEntityTypes'], scope])
			self.LOGGER.error(msg)
		#endIf
		self.LOGGER.traceExit()
		
	#endDef 
		
	def augmentFederatedSecurityRepositories(self):
		
		self.LOGGER.traceEnter()
	 
		rafwConfigs = self.getRAFWWIMRepositoriesConfig()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.augmentRepositoryConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['repositories'], scope])
			self.LOGGER.error(msg)
		#endIf
		
		self.LOGGER.traceExit()
	#endDef
		
	def augmentFederatedSecurityRealms(self):
		
		self.LOGGER.traceEnter()
		
		rafwConfigs = self.getRAFWWIMRealmsConfig()
		if(len(rafwConfigs) > 0):
			WIMConfigManager.augmentRealmConfigData(rafwConfigs)
		else:
			msg = self.getLocalizedMessage("CRWWA0179E", [markerTypes['realms'], scope])
			self.LOGGER.error(msg)
		#endIf
		
		self.LOGGER.traceExit()
	#endDef
 
	def importFederatedSecuritySupportedentityTypes(self):		
		self.LOGGER.traceEnter()
		
		data = WIMConfigManager.readSupportedEntityTypesConfigurationData()
		GenericConfigFileWriter.processBasicFile(self.xmlFile, data, markerTypes['supportedEntityTypes'])
		
		self.LOGGER.traceExit([str(data)])
	#endDef
	 
	def importFederatedSecurityRepositories(self):		
		self.LOGGER.traceEnter()
		data = WIMConfigManager.readRepositoryConfigData(self.scope)
		GenericConfigFileWriter.processBasicFile(self.xmlFile, data, markerTypes['repositories'])
		
		self.LOGGER.traceExit([str(data)])
	#endDef
	 
	def importFederatedSecurityLA(self):		
		self.LOGGER.traceEnter()
		data = WIMConfigManager.readLAConfigData()
		GenericConfigFileWriter.processBasicFile(self.xmlFile, data, markerTypes['propertyExtensionRepository'])
		
		self.LOGGER.traceExit([str(data)])
	#endDef
	def importFederatedSecurityFED(self):		
		self.LOGGER.traceEnter()
		data = WIMConfigManager.readFEDConfigData()
		GenericConfigFileWriter.processBasicFile(self.xmlFile, data, markerTypes['entryMappingRepository'])
		
		self.LOGGER.traceExit([str(data)])
	#endDef
	 
	def importFederatedSecurityRealms(self):
		self.LOGGER.traceEnter()
		data = WIMConfigManager.readRealmConfigurationData()
		GenericConfigFileWriter.processBasicFile(self.xmlFile, data, markerTypes['realms'])
		
		self.LOGGER.traceExit([str(data)])
	#endDef
	
	def compareFederatedSecurityRealms(self):
		self.LOGGER.traceEnter()
		
		rafwConfig = self.getRAFWWIMRealmsConfig()
		wasConfig = WIMConfigManager.readRealmConfigurationData()
		ConfigComparor.compare(markerTypes['realms'], wasConfig, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def compareFederatedSecurityRepositories(self):
		self.LOGGER.traceEnter()
		
		rafwConfig = self.getRAFWWIMRepositoriesConfig()
		wasConfig = WIMConfigManager.readRepositoryConfigData()
		ConfigComparor.compare(markerTypes['repositories'], wasConfig, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def compareFederatedSecuritySupportedentityTypes(self):
		self.LOGGER.traceEnter()
		
		rafwConfig = self.getRAFWWIMSupportedEntityTypesConfig()
		wasConfig = WIMConfigManager.readSupportedEntityTypesConfigurationData()
		ConfigComparor.compare(markerTypes['supportedEntityTypes'], wasConfig, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def compareFederatedSecurityFED(self):
		self.LOGGER.traceEnter()
		
		rafwConfig = self.getRAFWWIMFEDConfig()
		wasConfig = WIMConfigManager.readFEDConfigData()
		ConfigComparor.compare(markerTypes['entryMappingRepository'], wasConfig, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def compareFederatedSecurityLA(self):
		self.LOGGER.traceEnter()
		
		rafwConfig = self.getRAFWWIMLAConfig()
		wasConfig = WIMConfigManager.readLAConfigData()
		ConfigComparor.compare(markerTypes['propertyExtensionRepository'], wasConfig, rafwConfig)
		
		self.LOGGER.traceExit()
	#endDef
	
	def importAll(self):
		self.LOGGER.traceEnter()
		
		self.importFederatedSecurityRepositories()
		self.importFederatedSecurityRealms()
		self.importFederatedSecuritySupportedentityTypes()
		self.importFederatedSecurityFED()
		self.importFederatedSecurityLA()
		
		self.LOGGER.traceExit()
	#endDef
	
	def executeAll(self):
		self.LOGGER.traceEnter()
		
		self.executeFederatedSecurityRepositories()
		self.executeFederatedSecurityRealms()
		self.executeFederatedSecuritySupportedEntityTypes()
		self.executeFederatedSecurityFED()
		self.executeFederatedSecurityLA()
		
		self.LOGGER.traceExit()
	#endDef
	
	def augmentAll(self):
		self.LOGGER.traceEnter()
		
		self.augmentFederatedSecurityRepositories()
		self.augmentFederatedSecurityRealms()
		self.augmentFederatedSecuritySupportedEntityTypes()	
		
		self.LOGGER.traceExit()
	#endDef
	
	def compareAll(self):
		self.LOGGER.traceEnter()
		
		self.compareFederatedSecurityRepositories()
		self.compareFederatedSecurityRealms()
		self.compareFederatedSecuritySupportedentityTypes()
		self.compareFederatedSecurityFED()
		self.compareFederatedSecurityLA()
		
		self.LOGGER.traceExit()
	#endDef
	
	def importFederatedSecurity(self):		
		self.LOGGER.traceEnter()
		
		if(self.currentConfigType == 'repositories'):
			self.importFederatedSecurityRepositories()
		elif(self.currentConfigType == 'realms'):
			self.importFederatedSecurityRealms()
		elif(self.currentConfigType == 'propertyExtensionRepository'):
			self.importFederatedSecurityLA()
		elif(self.currentConfigType == 'entryMappingRepository'):
			self.importFederatedSecurityFED()
		elif(self.currentConfigType == 'supportedEntityTypes'):
			self.importFederatedSecuritySupportedentityTypes()
		elif(self.currentConfigType == 'ALL'):
			self.importAll()
		#endIf
		
		self.LOGGER.traceExit()
	#endDef
	
	
	
	def executeFederatedSecurity(self):
		self.LOGGER.traceEnter()
		
		if (self.currentConfigType == 'repositories'):
			self.executeFederatedSecurityRepositories()
		elif (self.currentConfigType == 'realms'):
			self.executeFederatedSecurityRealms()
		elif (self.currentConfigType == 'propertyExtensionRepository'):
			self.executeFederatedSecurityLA()
		elif (self.currentConfigType == 'entryMappingRepository'):
			self.executeFederatedSecurityFED()
		elif (self.currentConfigType == 'supportedEntityTypes'):
			self.executeFederatedSecuritySupportedEntityTypes()
		elif(self.currentConfigType == 'ALL'):
			self.executeAll()
		#endIf
		
		AdminHelper.saveAndSyncCell()
		self.LOGGER.traceExit()
	#endDef
	
	def augmentFederatedSecurity(self):		
		self.LOGGER.traceEnter()
		
		if(self.currentConfigType == 'repositories'):
			self.augmentFederatedSecurityRepositories()
		elif (self.currentConfigType == 'realms'):
			self.augmentFederatedSecurityRealms()
		elif (self.currentConfigType == 'supportedEntityTypes'):
			self.augmentFederatedSecuritySupportedEntityTypes()
		elif(self.currentConfigType == 'ALL'):
			self.augmentAll()
		#endIf
		
		AdminHelper.saveAndSyncCell()
		
		self.LOGGER.traceExit()		
	#endDef

	def compareFederatedSecurity(self):		
		self.LOGGER.traceEnter()
		
		# get wasConfig
		if(self.currentConfigType == 'repositories'):
			self.compareFederatedSecurityRepositories()
		elif(self.currentConfigType == 'realms'):
			self.compareFederatedSecurityRealms()
		elif(self.currentConfigType == 'propertyExtensionRepository'):
			self.compareFederatedSecurityLA()
		elif(self.currentConfigType == 'entryMappingRepository'):
			self.compareFederatedSecurityFED()
		elif(self.currentConfigType == 'supportedEntityTypes'):
			self.compareFederatedSecuritySupportedentityTypes()
		elif(self.currentConfigType == 'ALL'):
			self.compareAll()
		#endIf
		
		self.LOGGER.traceExit()	
	#endDef


 
##################################################################################
##
## Main
##
##################################################################################
global version, scopeName, scopeType, scope, mode, xmlFile, configType, configTypes, currentConfigType, nodeName
configTypes = ['FederatedProfileRepositories', 'FederatedSupportedEntityTypes', 'FederatedPropertyExtensionRepository',
				'FederatedEntryMappingRepository', 'FederatedExternalRealms']

markerTypes = { 'repositories' : 'FederatedProfileRepositories',
				'realms' : 'FederatedExternalRealms',
			    'supportedEntityTypes' : 'FederatedSupportedEntityTypes',
			    'propertyExtensionRepository' : 'FederatedPropertyExtensionRepository',
			    'entryMappingRepository' : 'FederatedEntryMappingRepository',
			   }
WIMConfigManager = _WIMConfigManager()
if ( str(sys.argv).find("scopename") != -1):
	# parse the options into optDict
	optDict, args = SystemUtils.getopt(sys.argv, 'version:;scope:;scopename:;properties:;mode:;config_type:')
	
	version = optDict['version']
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	scope = AdminHelper.buildScope(optDict)
	mode = optDict['mode']
	xmlFile = optDict['properties']
	configType = optDict['config_type']

	if(configType == 'FederatedProfileRepositories'):
		currentConfigType = "repositories"
		marker = configType
	elif(configType == 'FederatedExternalRealms'):
		currentConfigType = 'realms'
		marker = configType
	elif(configType == 'FederatedPropertyExtensionRepository'):
		currentConfigType = 'propertyExtensionRepository'
		marker = configType
	elif(configType == 'FederatedEntryMappingRepository'):
		currentConfigType = 'entryMappingRepository'
		marker = configType
	elif(configType == 'FederatedSupportedEntityTypes'):
		currentConfigType = 'supportedEntityTypes'
		marker = configType
	elif (configType == 'ALL'):
		currentConfigType = 'ALL'
		marker = 'ALL'
	#endIf

	try:
		WIMConfigManager = _WIMConfigManager()
		thisMediator = WIMConfigMediator(xmlFile, currentConfigType, scope)
		
		if (mode == MODE_EXECUTE):
			LOGGER.info("Configuring Federated Security in scope: " + scope)
			thisMediator.executeFederatedSecurity()
		
		elif (mode == MODE_AUGMENT):
			LOGGER.info("Augmenting Federated Security in scope: " + scope)
			thisMediator.augmentFederatedSecurity()
			
		elif (mode == MODE_IMPORT):
			LOGGER.info("Importing Federated Security in scope: " + scope)
			thisMediator.importFederatedSecurity()
			
		elif (mode == MODE_COMPARE):
			LOGGER.info("Comparing Federated Security settings in scope: " + scope)
			thisMediator.compareFederatedSecurity()
		else:
			print "Unsupported MODE supplied: " + mode
	except:
		LOGGER.log('CRWWA0181E', str(sys.exc_info()[0]))
		LOGGER.trace("Details are: " + str(sys.exc_info()[0]) + ":" + str(sys.exc_info()[1]))
		raise
	#endTry
#endIf
