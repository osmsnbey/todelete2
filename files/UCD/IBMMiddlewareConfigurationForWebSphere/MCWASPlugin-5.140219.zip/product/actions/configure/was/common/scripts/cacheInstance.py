"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 


	File name: cacheInstances.py

	This script is to manage cache instances.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f cacheInstances.py
		-scope <scope>: specify the scope of the objects to be created
		-properties <xml file>: specify the relevant configuration data
		-nodename <node name>: specify the node name of the objects to be created 
		-scopename <scope name>: specify the scope name of the objects to be created 
		-mode <import|execute|compare>: What mode the script will run as
		-scriptName: cacheInstances.py
"""

import sys

from ConfigValidator import ConfigValidator
from ConfigReaderException import ConfigReaderException
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager


class dsMediator:
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		self.myConfigWriter = ConfigWriter();	
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			SCRIPT_LOGGER.debug("processing configType: " + typeName)
			self.myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				SCRIPT_LOGGER.debug("processing data from xmlFile: " + str(xmlNode))
				try:
					parentId = AdminHelper.findProviderId(xmlNode, scope, "CacheProvider", "name")
				except ConfigReaderException:
					## the provider could not be found, create it and try again
					SCRIPT_LOGGER.debug("unable to find cache provider using node: " + str(xmlNode))
					SCRIPT_LOGGER.debug("the cache provider will be created under parent scope: " + str(scope))
					parentId = self._createProvider(xmlNode, scopeId, typeName)
				self.myConfigWriter.createWASObject(xmlNode, parentId)
			#endFor
		#endFor
	#endDef

	"""
	Creates a provider under the supplied scope of the mentioned type.
	"""
	def _createProvider(self, xmlNode, scopeId, configType):
		providerNodes = xmlNode.getFilteredChildrenArray("CacheProvider")
		if ( len(providerNodes) > 0 and providerNodes[0] != None):
			providerNode = providerNodes[0]
			if (providerNode.hasAttr("name")):
				providerName = providerNode.getAttrValue("name")
				##print "log: Creating 'CacheProvider' with name '" + providerName + "'"
				SCRIPT_LOGGER.log("CRWWA1000I",[providerName])
				type = providerNode.getNodeNameFixed()
				attrs = providerNode.buildNodeAttrsAsJyString()
				SCRIPT_LOGGER.debug("AdminConfig.create('"+type+"','"+scopeId+"',"+ attrs +")")
				newId = AdminConfig.create(type, scopeId, attrs)
				if (newId is None or len(newId) == 0):
					msg = ("Unable to create type: " + type + " under parent: " + scopeId 
						+ " for xmlNode: " + str(providerNode))
					SCRIPT_LOGGER.error(msg)
					raise ConfigWriterException(msg)
				#endIf
				##print  "Created config object " + type + ": " + newId
				SCRIPT_LOGGER.log("CRWWA3001I",[type,newId])
				return newId
			else:
				msg = "Attribute 'name' is required on xmlNodes of type 'CacheProvider'"
				raise InvalidXmlConfigException(msg)
			#endIf
		else:
			msg = "XML node 'CacheProvider' does not exist as a child of " + configType
			raise InvalidXmlConfigException(msg)
		#endIf
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames, configValidator):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		self.myConfigWriter = ConfigWriter();	
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			SCRIPT_LOGGER.debug("processing configType: " + typeName)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				SCRIPT_LOGGER.debug("processing data from xmlFile: " + str(xmlNode))
				try:
					parentId = AdminHelper.findProviderId(xmlNode, scope, "CacheProvider", "name")
				except ConfigReaderException:
					## the provider could not be found, create it and try again
					SCRIPT_LOGGER.debug("unable to find cache provider using node: " + str(xmlNode))
					SCRIPT_LOGGER.debug("the cache provider will be created under parent scope: " + str(scope))
					## parent doesn't exist, therefore, child doesn't exist
					parentId = self._createProvider(xmlNode, scopeId, typeName)
				#endTry
				childId = configValidator.validateUniqueJndiName2(xmlNode, parentId)
				if (childId is None):
					##print "log: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					SCRIPT_LOGGER.log("CRWWA2108I",[typeName, xmlNode.getAttrValue("jndiName")])
					self.myConfigWriter.createWASObject(xmlNode, parentId)
				else:
					if (SystemUtils.updateOnAugment()):
						self.myConfigWriter.modify(childId, xmlNode)
					else:
						##print "Warning: " + typeName + " will not be created."
						SCRIPT_LOGGER.log("CRWWA2107W",[typeName])
					#endIf
				#endIf
			#endFor
		#endFor
	#endDef
	
	def readConfigData(self, scope, scopeType, typeName, excludeTypes):
		myConfigReader = ConfigReader()
		data = myConfigReader.readConfigData(scope, scopeType, typeName, excludeTypes)
		## filter out most attributes of JMSProvider since it won't be written when we createConfig
		myConfigReader.stripElement(data, "provider", "CacheProvider", ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		return data
	#endDef
	
#endClass

SCRIPT_LOGGER = _Logger("cacheInstance", MessageManager.RB_WEBSPHERE_WAS)

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )

# get scope
scope = AdminHelper.buildScope( optDict )

propFile = optDict['properties'] 
scopeType=optDict['scope']
excludeTypes = ['builtin']

mode = optDict['mode']
#typeNames = ["CacheInstance","ObjectCacheInstance","ServletCacheInstance"]
typeNames = ["ObjectCacheInstance","ServletCacheInstance"]
marker = "cacheInstance"
thisMediator = dsMediator()
if (mode == MODE_EXECUTE):

	##print "Creating Cache Instances in scope: " + scope
	SCRIPT_LOGGER.log("CRWWA4000I",[scope])
	thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
	
	AdminHelper.saveAndSyncCell()
	
elif (mode == MODE_AUGMENT):
	##print "Augmenting Cache Instances in scope: " + scope
	SCRIPT_LOGGER.log("CRWWA2109I",[scope])
	thisMediator.augmentConfig(scope, scopeType, propFile, marker, typeNames, ConfigValidator())
	AdminHelper.saveAndSyncCell()
	
elif (mode == MODE_IMPORT):
	##print "Importing Cache Instances in scope: " + scope
	SCRIPT_LOGGER.log("CRWWA1006I",[scope])
	ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator)

elif (mode == MODE_COMPARE):
	##print "Comparing Cache Instances in RAFW and WAS in scope: " + scope
	SCRIPT_LOGGER.log("CRWWA4002I",[scope])
	ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator)

else:
	##print "Unsupported MODE supplied: " + mode
	SCRIPT_LOGGER.log("CRWWA0008W",[mode])
#endIf
