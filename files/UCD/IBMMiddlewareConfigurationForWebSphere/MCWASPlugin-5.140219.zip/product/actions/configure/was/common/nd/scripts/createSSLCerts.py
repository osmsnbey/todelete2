"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createSSLCerts.py
	
	This script is to create SSL certs in the cell
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f createSSLCerts.py 
		-properties <xml file describing SSL certs and keystores> 
"""


import sys

#---------
#  Creates the keystore identified by xmlNode, then creates
#  all certs within a keystore that exist as children of xmlNode
#---------
def createKeystore (xmlNode) :

	#--------------------------------------------------------------
	# set up globals
	#--------------------------------------------------------------
	global AdminTask
	keystoreName = xmlNode.getAttrValue("keyStoreName")
	keystoreScope = ""
	if (xmlNode.hasAttr("scopeName")):
		keystoreScope = xmlNode.getAttrValue("scopeName")
	#endIf

	print "Creating Keystore: " + keystoreName
	## create key store
	AdminTask.createKeyStore(xmlNode.buildNodeAttrsList())

	## create Self Signed Certificate
	certs = xmlNode.getFilteredChildrenArray('SelfSignedCert') 
	
	for xmlCert in certs:
		certName = xmlCert.getAttrValue("certificateAlias")
		print "Creating Self Signed Cert: " + certName
		attrsList = xmlCert.buildNodeAttrsList()

		AdminTask.createSelfSignedCertificate(attrsList)
	#endFor


#endDef

#---------
#  Creates the SSL configuration given by xmlSSLConfig
#---------
def createSSLConfig(xmlSSLConfig):

	sslConfigName = xmlSSLConfig.getAttrValue("alias")
	print "Creating SSL Configuration: " + sslConfigName
	attrsList = xmlSSLConfig.buildNodeAttrsList()
	AdminTask.createSSLConfig(attrsList)
#endDef

## Adds an attribute name/value to the supplied attrsList
def addAttr(attrsList, attrName, attrValue):
	attrsList.append(attrName)
	attrsList.append(attrValue)
	return attrsList
#endDef

#---------
#  Deletes the SSL configuration given by xmlSSLConfig
#---------
def deleteSSLConfig(xmlSSLConfig):
	sslConfigName = xmlSSLConfig.getAttrValue("alias")

	## list SSLConfigs, 
	existingConfigs = AdminTask.listSSLConfigs().split( newline )
	## alias: WebContainerSSL managementScope: (cell):fdc_qa_network
	for existingConfig in existingConfigs:
		existingConfig = existingConfig.split(' ')[1]
		## if this one exists delete it
		if (existingConfig == sslConfigName):
			print "Deleting SSL Configuration: " + sslConfigName
			AdminTask.deleteSSLConfig(['-alias', sslConfigName])
		#endIf
	#endFor
#endDef

#---------
#  Deletes all certs within a keystore identified by xmlNode, 
#  then deletes the keystore
#---------
def deleteKeystore (xmlNode):

	#--------------------------------------------------------------
	# set up globals
	#--------------------------------------------------------------
	global AdminTask
	keystoreName = xmlNode.getAttrValue("keyStoreName")
	
	keystoreScope = ""
	if (xmlNode.hasAttr("scopeName")):
		keystoreScope = xmlNode.getAttrValue("scopeName")
	#endIf

	## list keystores, 
	## if scope is set, search within scope
	if (len(keystoreScope) > 0):
		existingKeyStores = AdminTask.listKeyStores(['-scopeName', keystoreScope]).split( newline )
	else:
		existingKeyStores = AdminTask.listKeyStores().split( newline )
	#endIf

	for existingKeyStore in existingKeyStores:
		existingKeyStore = existingKeyStore.split('(', 1)[0]
		## if this one exists delete it
		if (existingKeyStore == keystoreName):

			## delete certs first
			## personal certs
			pcArgs = []
			pcArgs.append('-keyStoreName')
			pcArgs.append(keystoreName)
			print pcArgs
			addKeystoreScope(pcArgs, keystoreScope)
			
			certs = AdminTask.listPersonalCertificates(pcArgs).split( newline )

			for cert in certs:
				for certAttr in cert.split('] ['):
					if (certAttr.split(' ', 1)[0] == "alias"):
						certName = certAttr.split(' ', 1)[1]
						print "Deleting Self Signed Cert: " + certName
						delArgs = []
						delArgs.append('-keyStoreName')
						delArgs.append(keystoreName)
						delArgs.append('-certificateAlias')
						if (re.compile("^\[").search(certName)):
							 certName = certName[1:len(certName)-1]
						delArgs.append(certName)
						addKeystoreScope(delArgs, keystoreScope)
						AdminTask.deleteCertificate(delArgs)
					#endIf
				#endFor
			#endFor

			## signer certs
			certs = AdminTask.listSignerCertificates(pcArgs).split( newline )
	
			for cert in certs:
				for certAttr in cert.split('] ['):
					if (certAttr.split(' ', 1)[0] == "alias"):
						certName = certAttr.split(' ', 1)[1]
						print "Deleting Signer Cert: " + certName
						delArgs = []
						delArgs.append('-keyStoreName')
						delArgs.append(keystoreName)
						delArgs.append('-certificateAlias')
						if (re.compile("^\[").search(certName)):
							 certName = certName[1:len(certName)-1]
						delArgs.append(certName)
						addKeystoreScope(delArgs, keystoreScope)
						AdminTask.deleteSignerCertificate(delArgs)
					#endIf
				#endFor
			#endFor

			## Delete keystore last, as it is used by everything else
			print "Deleting Keystore: " + keystoreName
			args = []
			args.append('-keyStoreName')
			args.append(keystoreName)
			addScopeName(args, keystoreScope)
			AdminTask.deleteKeyStore(args)
		#endIf
	#endFor

#endDef

def addScopeName(args, keystoreScope):
	if (len(keystoreScope) > 0):
		args.append('-scopeName')
		args.append(keystoreScope)
	#endIf
#endDef

def addKeystoreScope(args, keystoreScope):
	if (len(keystoreScope) > 0):
		args.append('-keyStoreScope')
		args.append(keystoreScope)
	#endIf
#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:' )

# parse the properties into props

xmlProp = ConfigFileReader.openXmlConfig(optDict['properties'])

## Delete everything first
## Delete SSL Configuration
sslConfigs = xmlProp.getFilteredNodeArray('SSLConfig') 
	
for xmlSSLConfig in sslConfigs:
	# do work
	deleteSSLConfig(xmlSSLConfig)
#endFor

nodeArray = xmlProp.getFilteredNodeArray('KeyStore' ) 
for xmlNode in nodeArray:
	## delete store
	deleteKeystore(xmlNode)

	print "Saving Config after removing existing keystore..."
	AdminConfig.save( )

	## Create store
	createKeystore(xmlNode)

	print "Saving Config after creating keystore..."
	AdminConfig.save( )

#endFor

## Create SSL Configuration
sslConfigs = xmlProp.getFilteredNodeArray('SSLConfig') 
	
for xmlSSLConfig in sslConfigs:
	# do work
	createSSLConfig(xmlSSLConfig)
#endFor
	
AdminHelper.saveAndSyncCell()
