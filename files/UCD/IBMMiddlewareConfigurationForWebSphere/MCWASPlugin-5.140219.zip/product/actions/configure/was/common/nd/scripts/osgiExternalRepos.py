"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: osgiExternalRepos.py
	
	Description: Manages external OSGi repositories in WAS
"""

from com.ibm.rational.rafw.wsadmin.websphere.config import WsadminConfig,\
	LegacyWsadminConfigHelper
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter
from com.ibm.rational.rafw.wsadmin.websphere.config.compare import ConfigCompareTools
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import sys
import java
import Globals

from java.lang import Integer
from java.util import ArrayList
from SystemUtils import SystemUtils
from Logger import _Logger
from ConfigReader import ConfigReader

CONTAINER_XML_ID = "OSGi_ExternalRepositories"
XML_ID = "ExternalRepository"

class OSGIExternalRepos:
	def __init__(self):
		self.LOGGER = _Logger("osgiExternalRepos", MessageManager.RB_WEBSPHERE_WAS)	
	#endDef

	def doExecute(self, xmlFile ):
		self.doModify(xmlFile, 0)
	#endDef

	def doAugment(self, xmlFile ):
		self.doModify(xmlFile, 1)
	#endDef
	
	def doModify(self, xmlFile, isAugment ):
		# parse the XML data 
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(CONTAINER_XML_ID)
		
		xmlConfigReader = XMLConfigReader()
		filteredNodes = xmlProp.getFilteredNodeArray(XML_ID)
		newConfig = xmlConfigReader.readXmlWsadminConfig(filteredNodes)
		existingConfig = self.readData()
	
		compareTools = ConfigCompareTools("name")	
		toUpdate = compareTools.findIntersection(newConfig, existingConfig)
		toAdd = compareTools.findComplementInA(newConfig, existingConfig)
		toRemove = compareTools.findComplementInA(existingConfig, newConfig)
		
		for update in toUpdate:
			# do work
			if (not isAugment or SystemUtils.updateOnAugment()):
				self.LOGGER.log("CRWWA9701I", update.getAttributes().get("name"))
				AdminTask.modifyExternalBundleRepository(self.buildXmlTaskInput(update.getAttributes()))
			else:
				self.LOGGER.log("CRWWA9700W", [update.getId(), "name", update.getAttributes().get("name")])
			#endIf
		#endFor
		
		for add in toAdd:
			self.LOGGER.log("CRWWA9702I", add.getAttributes().get("name"))
			# do work
			AdminTask.addExternalBundleRepository(buildXmlTaskInput(add.getAttributes()))
		#endFor

		if (not isAugment):	
			for remove in toRemove:
				# do work
				self.LOGGER.log("CRWWA9703I", remove.getAttributes().get("name"))
				AdminTask.removeExternalBundleRepository("-name " + remove.getAttributes().get("name"))
			#endFor
		#endIf
	#endDef

	"""
	Turns the attributes HashMap into a jython list of AdminTask input
	The returned list can be used in an AdminTask command.

	This could be shared with other scripts at some point as needed.
	"""
	def buildXmlTaskInput(self, attributes):
		retVal = []
		for name in attributes.keySet():
			val = attributes.get(name);
			retVal.append("-" + name)
			retVal.append(val)
		#endFor
		return retVal
	#endDef

	"""
	Reads the data in WAS into an ArrayList of WsadminConfig objects
	that represent the configuration.
	"""
	def readData(self):
		repos = AdminTask.listExternalBundleRepositories()
		data = ArrayList()
		configReader = ConfigReader()
		newline = java.lang.System.getProperty("line.separator")
		for repo in repos.split(newline):
			if (len(repo) > 0):
				repoConfig = WsadminConfig()
				repoConfig.setId(XML_ID)
				repoConfig.setAttributes(configReader.convertToMap(AdminTask.showExternalBundleRepository('-name ' + repo)))
				data.add(repoConfig)
			#endIf
		#endFor
		return data
	#endDef

	def doImport(self, xmlFile):
		data = self.readData()
		container = WsadminConfig()
		container.setId(Globals.RAFW_XML_PREFIX + CONTAINER_XML_ID)
		container.setChildren(data)
		XmlConfigFileWriter().build(xmlFile, container)
	#endDef

	def doCompare(self, xmlFile):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(CONTAINER_XML_ID)
		
		## this is a list of WsadminConfig objects
		configData = self.readData()
		wasConfig = LegacyWsadminConfigHelper.convertToLegacy(configData)

		# get rafwConfig
		xmlConfigReader = XMLConfigReader()
		filteredNodes = xmlProp.getFilteredNodeArray(XML_ID)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)

		ConfigComparor.compare(CONTAINER_XML_ID, wasConfig, rafwConfig)
		
	#endDef

	def perform(self):
		if (wasVersion >= 70):
			if (wasVersion == 70):
				# check to see if aries is enabled in this profile
				dmgrNode = AdminControl.getNode()
				ariesVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.AriesFeaturePackProductShortName]')
				if (ariesVersion is None or len(ariesVersion) == 0):
					self.LOGGER.log("CRWWA9708I")
					return
				#endIf
			#endIf
			xmlFile = optDict['properties'] 
			mode = optDict['mode']
			if (mode == MODE_EXECUTE):
				self.LOGGER.log("CRWWA9704I")
				self.doExecute(xmlFile)
				AdminHelper.saveAndSyncCell()
			elif (mode == MODE_AUGMENT):
				self.LOGGER.log("CRWWA9705I")
				self.doAugment(xmlFile)
				AdminHelper.saveAndSyncCell()
			elif (mode == MODE_IMPORT):
				self.LOGGER.log("CRWWA9706I")
				self.doImport(xmlFile)
			elif (mode == MODE_COMPARE):
				self.LOGGER.log("CRWWA9707I")
				self.doCompare(xmlFile)
			else:
				self.LOGGER.log("CRWWA0008W", [mode])
			#endIf
		else:
			self.LOGGER.log("CRWWA9709W")
		#endIf
	#endDef
#endClass


#Main
if ( str(sys.argv).find("scopename") != -1):
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:;scopename:;scope:;version:' )

	wasVersion = Integer.valueOf(optDict['version']) 
	thismediator = OSGIExternalRepos()
	thismediator.perform()
#endIf
