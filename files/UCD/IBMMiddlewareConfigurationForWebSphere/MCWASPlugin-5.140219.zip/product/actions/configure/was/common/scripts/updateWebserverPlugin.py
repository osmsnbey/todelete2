"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateWebserverPlugin.py
	
	This script is to update the web server plugin properties of an application server or server members of a cluster.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f updateWebserverPlugin.py 
		-version <WAS version>: specify the WAS version of the server
		-scope <scope: node/cluster>: specify the scope either as node or cluster
		-scopename <server/cluster name>: specify the name of the server or cluster 
		-nodename <node name>: in case of node, we need to specify the server name
		-properties <server template properties file>: 
			specify the xml files for defining the properties of the server
"""


import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
updateWebserverPluginLogger = _Logger("updateWebserverPlugin", MessageManager.RB_WEBSPHERE_WAS)


# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;scopename:;nodename:;properties:' )

scope = optDict['scope']
scopeName = optDict['scopename']

cellName = AdminControl.getCell()

# parse the properties into props

serviceType='WebserverPluginSettings'
propFile = optDict['properties']
xmlProp = ConfigFileReader.openXmlConfig(propFile)
nodelist = xmlProp.getFilteredNodeList(serviceType) 
nodearr = xmlProp.xmlReadNodeLevel( nodelist )

webserverPluginSettings = ['Role','ConnectTimeout','ServerIOTimeout','MaxConnections','ExtendedHandshake','WaitForContinue']
propertySettings = ['name','value','description']

try:
	properties = nodearr[0][serviceType]
except:
	raise "\nupdateWebserverPlugin.py: Warn -- Can not find the web server plugin properties from the server template file " + propFile 
#endtry
		
if scope == "node":

	nodeName = optDict['nodename']
	# Check if it is a valid node
	node = AdminConfig.getid( '/Cell:' + cellName + '/Node:' + nodeName + '/' )

	if node == "":
		raise "\nupdateORBService: Error -- Invalid node name: " + nodeName 
	#endIf

	# Check if a server by this name already existing on the node
	server = AdminConfig.getid("/Cell:" + cellName + "/Node:" + nodeName + "/Server:" + scopeName + "/")

	if server == "":
		raise "\nupdateWebserverPlugin.py: Error -- Server " + scopeName + " does not exist on node " + nodeName
	#endIf

	#print "Updating " + scopeName + " on node " + nodeName
	updateWebserverPluginLogger.log("CRWWA5043I",[scopeName,nodeName])
	WasConfig.updateContainerService(properties, server, serviceType, webserverPluginSettings, propertySettings)
	
elif ( scope == 'cluster' ):

	cluster = AdminConfig.getid("/Cell:" + cellName + "/ServerCluster:" + scopeName + "/")
	if cluster == "":
		raise "\nupdateWebserverPlugin.py: Error -- Invalid cluster name: " + scopeName 
	#endIf	

	memberlist = AdminConfig.showAttribute(cluster, "members" )
	members = memberlist[1:len(memberlist)-1]
	for member in members.split():
		nodeName = AdminConfig.showAttribute(member, "nodeName" )
		serverName = AdminConfig.showAttribute(member, "memberName" )
		server = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
		
		#print "Updating " + serverName + " on node " + nodeName
		updateWebserverPluginLogger.log("CRWWA5044I",[serverName,nodeName])
		WasConfig.updateContainerService(properties, server, serviceType, webserverPluginSettings, propertySettings)
		
	#endFor

else:
	raise "\nupdateWebserverPlugin.py: %s is invalid. Exiting!" % (scope)
#endIf
	
AdminHelper.saveAndSyncCell()

