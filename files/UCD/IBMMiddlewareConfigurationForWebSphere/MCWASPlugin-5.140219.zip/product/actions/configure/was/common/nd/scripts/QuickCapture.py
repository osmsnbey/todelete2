'''
Created on Jul 26, 2013

@author: bakeley
'''


import java
from java.io import File
from java.util import HashMap
from java.util import ArrayList
from java.util import Date
from com.ibm.rational.rafw.wsadmin.websphere.config import *
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import *
from com.ibm.rational.rafw.wsadmin.websphere.config.compare import *
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from com.ibm.rational.rafw.framework.util import Files
from com.ibm.rational.rafw.shared.util import PropertiesUtil

from Logger import _Logger
from ConfigReader import ConfigReader
from ConfigComparor import ConfigComparor
from ServerConfigMediator import ServerConfigMediator
#import AdminConfig
#import AdminControl
#global AdminTask,AdminConfig

import sys
import Globals
sys.modules['AdminConfig'] = AdminConfig
sys.modules['AdminControl'] = AdminControl
#sys.modules['AdminTask'] = AdminTask

#Append scripts to sys.path
importedFiles =  Globals.getInstallRoot() + "/product/actions/configure/was/common/nd/scripts"
importedFiles2 =  Globals.getInstallRoot() + "/product/actions/configure/was/common/scripts"
importedFiles3 =  Globals.getInstallRoot() + "/product/lib/jython/wsadmin_lib"
importedFiles4 =  Globals.getInstallRoot() + "/product/actions/configure/wve/common/nd/cluster/scripts/"
importedFiles5 =  Globals.getInstallRoot() + "/product/actions/configure/wve/common/scripts/"
sys.path.append(importedFiles)
sys.path.append(importedFiles2)
sys.path.append(importedFiles3)
sys.path.append(importedFiles4)
sys.path.append(importedFiles5)

from dyncluster import DynClusterMediator
from odrRules import OdrRulesMediator
from dynclusterTemplate import DynClusterTemplate
from manageWebServer import ManageWebServer
from osgiExternalRepos import OSGIExternalRepos
from osgiInternalRepos import OSGIInternalRepos
from fileRegistryGroups import FileRegistryGroups
from fileRegistryUsers import FileRegistryUsers
from siBus import dsMediator as siBusMediator
from JMSActivationSpec import dsMediator as jmsActivSpecMediator
from WIMSecurity import WIMConfigMediator
from consoleMembers import ConsoleMemberMediator
from siBuses import Bus,BusMember,MsgEngine,Mediation,Destination,ForeignBus,BootstrapMember,Security
from resourceEnvironmentEntries import resEnvEntriesReader

logger = _Logger("QuickCapture", MessageManager.RB_WEBSPHERE_WAS)

newline = java.lang.System.getProperty("line.separator")

class QuickCapture:
	
	def __init__(self, scopelist):
		self.LOGGER = _Logger("QuickCapture", MessageManager.RB_WEBSPHERE_WAS)	
		self.scopelist = scopelist.split(',')
		self.actionscopes = None
		self.scopeWasTypes = None
	#endDef
	
	def convertDictToMap(self, d):
		data = HashMap()
		for key in d.keys():
			data.put(key,d[key])
		return data
	#endDef
	
	def getScopeName(self, scope):
		scopePath = scope.split('/')
		scopeName = scopePath[len(scopePath)-1]
		return scopeName
	#endDef
	
	def getScopeType(self, scope):
		scopePath = scope.split('/')
		scopeType = scopePath[len(scopePath)-2]
		if scopeType.endswith('s'):
			scopeType = scopeType[0:len(scopeType)-1]
		return scopeType.capitalize()
	#endDef
	
	def getActionScopes(self):
		if self.actionscopes==None:
			self.actionscopes = []
			for scope in self.scopelist:
				#if we narrowed down the possible scope to process earlier, then "" will be the first scope
				if scope== "":
					continue
				#Check if windows added \: to the path while saving to props file, if so strip it out.
				if scope.find("\:"):
					scope = scope.replace("\:",":")
				#endif
				aScope = ActionScope()
				aScope.setPath(scope)
				aScope.setName(self.getScopeName(scope))
				aScope.setType(self.getScopeType(scope))
				self.actionscopes.append(aScope)
				scopeProps = PropertiesUtil()
				try:
					scopeProps.load(str(scope) + "/scope.properties")
					aScope.setSubType(scopeProps.getProperty("SCOPE_DATA_TYPE"))
				except Exception, e:
					print str(e)
					logger.error("Exception" + str(e))
			#endFor
		#endIf
		return self.actionscopes
	#endDef
	
	def getScopeWasTypes(self):
		if self.scopeWasTypes == None:
			self.scopeWasTypes = []
			for scope in self.getActionScopes():
				scopeId = AdminConfig.getid(scope.getWASName())
				self.scopeWasTypes.append(scopeId[scopeId.find("(")+1:scopeId.find("|")])
			#endFor
			allsrvrs = AdminTask.listServers().split(newline)
			for srvr in allsrvrs:
				srvrScopeId = srvr[srvr.find("(")+1:srvr.find("|")]
				nodeScopeId = srvrScopeId[0:srvrScopeId.find("/servers")]
				if srvrScopeId not in self.scopeWasTypes:
					self.scopeWasTypes.append(srvrScopeId)
				if nodeScopeId not in self.scopeWasTypes:
					self.scopeWasTypes.append(nodeScopeId)
		#endIf
		return self.scopeWasTypes
	#endDef
	
	def writeConfigs(self, scope, configs, parentNode, outputFile):
		writer = XmlConfigFileWriter()
		parentConfig = None
		if len(configs)>0:
			if parentNode != None:
				parentConfig = WsadminConfig()
				parentConfig.setId(parentNode)
				for config in configs:
					parentConfig.addChild(config)
				#endFor
			#endIf
		#endIf 
		if parentConfig != None:
			writer.write(scope, parentConfig, outputFile)
		else:
			writer.write(scope, configs, outputFile)
	#endDef
	
	def buildWsadminConfig(self, configDict, excludedTypes, excludedAttrs):
		config = WsadminConfig()
		configId = configDict['id']
		if (configId not in excludedTypes):
			config.setId(configId)
			for attr in configDict['attrs'].keys():
				if (attr not in excludedAttrs):
					config.setAttribute(attr, configDict['attrs'][attr])
				#endIf
			for childDict in configDict['children']:
				config.addChild(self.buildWsadminConfig(childDict, excludedTypes, excludedAttrs))
		#endIf
		return config
	#endDef
	
	def objectInScope(self,wasObj,scopeId,useContainsCheck):
		#if scopeId is null, lets not process this config type.
		if scopeId == "" or wasObj == "":
			return 0; #return false
		#endIF
		scopeStr = scopeId[scopeId.find("(")+1:scopeId.find("|")]
		if (useContainsCheck == 'y'):			
			isInScope=((wasObj.find(scopeStr) > -1))
		else:
			pipe=wasObj.find("|")
			#need this weird rfind cause of jdbc providers that have (xa)(scope|blah)
			objscope = wasObj[wasObj.rfind("(",0,pipe) +1:pipe]
			isInScope=(objscope == scopeStr)
		#endIF
		return isInScope
	#endDef
	
	def getFileForWasObj(self, wasObj):
		wasobjstr = str(wasObj)
		lindex = wasobjstr.find("|")+1
		rindex = wasobjstr.find("#")
		scopeStr = wasobjstr[lindex:rindex]
		return scopeStr
	#endDef
	
	def capture(self, wasData, excludedTypes, excludedAttrs, wasType, useContainsCheck='n'):
		reader = ConfigReader([],excludedTypes,excludedAttrs)
		configs = {}
		for wasObj in wasData.split(newline):
			if wasObj!=None and len(wasObj)>0:
				for scope in self.getActionScopes():
					if None == configs.get(scope, None):
						configs[scope] = ArrayList()
					#endIf
					scopeId = AdminConfig.getid(scope.getWASName())
					inScopeCheck = self.objectInScope(wasObj,scopeId, useContainsCheck)
					#we dont want to include built-in types for jdbc...historical reasons...
					if wasType == 'JDBCProvider':
						inScopeCheck = (self.objectInScope(wasObj,scopeId, useContainsCheck) and (wasObj.find("builtin") == -1))
					elif wasType == "DataSource":
						#this is how datasources manages excluded types...trace JDBCDataSources.py to find out.
						for exclType in excludedTypes:
							if (SystemUtils.regexp(exclType, wasObj) == 1):
								inScopeCheck = 0
								break
							#endIf
						#endFor
					#endIF
					if inScopeCheck:
						configDict = reader.showAll(wasObj)
						if wasType == 'J2CActivationSpec':
							configDict = self.mapResourceAdapterToActivSpec(wasObj, configDict, scope)
						#endIf
						config = qc.buildWsadminConfig(configDict, excludedTypes, excludedAttrs)
						configs[scope].add(config)
					elif self.getFileForWasObj(wasObj) == "coregroup.xml" and scope.getType()=="Cell":
						configDict = reader.showAll(wasObj)
						config = qc.buildWsadminConfig(configDict, excludedTypes, excludedAttrs)
						configs[scope].add(config)
					#endIf
				#endFor
			#endIf
		#endFor
		return configs
	#endDef
	
	def mapResourceAdapterToActivSpec(self, wasObj, activSpec, scope):
		scopeId = AdminConfig.getid(scope.getWASName())
		resourceAdapters = AdminConfig.list("J2CResourceAdapter", scopeId).split(newline)
		found=0
		for resourceAdapter in resourceAdapters:
			if (len(resourceAdapter) > 0):
				for objId in AdminConfig.list('J2CActivationSpec', resourceAdapter).split(newline):
					objId = objId.strip()
					if wasObj == objId: 
						resourceAdapterNode = {}
						resourceAdapterNode['id'] = 'J2CResourceAdapter'
						resourceAdapterNode['attrs'] = {}
						resourceAdapterNode['attrs'][Globals.RAFW_TYPE] = 'parentName'
						resourceAdapterNode['attrs']['name'] = AdminConfig.showAttribute(resourceAdapter, 'name')
						resourceAdapterNode['children'] = []
						activSpec['children'].append(resourceAdapterNode)
						found = 1
					#endIf
					if found:
						break
					#endIf
				#endFor
			#endIf
			if found:
				break
		#endFor
		return activSpec
	#endDef
	
	def captureServer(self, scope, ignoreDifferences):
		messageRecorder = MessageRecorder();
		configMediator = ServerConfigMediator(messageRecorder,"ALL",version)
		configMediator.setIgnoreConfigDifferences(ignoreDifferences)
		
		serverIds = []
		scopeType = str(scope.getType()).lower()
		if scope.getType()=="Cluster" or scope.getType()=="Cell":
			serverIds = configMediator.findServersInScope(scope.getName(), scopeType, None)
		else:
			serverIds = [AdminConfig.getid(scope.getWASName())]
		#endIf
			
		return configMediator.readAllConfigTypes(serverIds, scopeType, 1, None)
	#endDef
	
	def getTimeDifference(self, startTime, endTime):
		totalMillis = endTime - startTime
		deltaSecs = totalMillis / 1000 % 60
		deltaMins = totalMillis / 1000 / 60 % 60
		deltaHours = totalMillis / 1000 /60/60%60
		
		return  str(deltaHours) + " hours " + str(deltaMins) + " minutes " + str(deltaSecs) + " seconds"
	#endDef
	
	def processSibXmlTypes(self, config_type, marker, xmlFile):
		#scopeStr = scopeId[scopeId.find("(")+1:scopeId.find("|")]
		marker = marker[marker.find("_")+1 : ]
		if (config_type == "SIBus"):
			thisMediator = Bus()
		elif (config_type == "SIBusMember"):
			thisMediator = BusMember()
		elif (config_type == "SIBMessagingEngine"):
			thisMediator = MsgEngine()
		elif (config_type == "SIBMediation"):
			thisMediator = Mediation()
		elif (config_type == "SIBDestination"):
			thisMediator = Destination()
		elif (config_type == "SIBForeignBus"):
			thisMediator = ForeignBus()
		elif (config_type == "SIBBootstrapMember"):
			thisMediator = BootstrapMember()
		elif (config_type == "SIBSecurity"):
			thisMediator = Security()
		#endIf
		
		thisMediator.importConfig(xmlFile, marker, config_type)
	#endDef
	
	def prepXmlDataFile(self, rafhome, filename, scope):
		xmlTmpl = rafhome + "/product/templates/xml/" + str(filename);
		xmlTgt = scope.getPath() + "/" + str(filename)
		fileTrgt = File(xmlTgt)
		#print "filetrgt.isFile(): " + str(fileTrgt.isFile()) + ", file: " + fileTrgt.getAbsolutePath()
		if not fileTrgt.isFile():
			#print "******** copying file " + str(xmlTmpl) + " to " + str(xmlTgt)
			Files.copyFileContents(xmlTmpl, xmlTgt)
	#endDef
#endClass

optDict, args = SystemUtils.getopt( sys.argv, 'scopelist:;mode:;version:;rafhome:' )

scopeListProps = PropertiesUtil()
scopeList = ""
try:
	scopeListProps.load(str(optDict['scopelist']))
	# list of fully qualified paths within the user tree separated by comma
	scopelist = scopeListProps.getProperty("SCOPE_LIST")
except Exception, e:
	print str(e)
	logger.error("Exception" + str(e))
#endTry

rafhome = optDict['rafhome']

# import, compare
mode = optDict['mode']
isImportMode = (mode == 'import')
isCompareMode = (mode == 'compare')

# 61,70,80,85
#cast the version from a string to an int...so it gets compared correctly later on.
version = int(optDict['version'])

qc = QuickCapture(scopelist)

if mode=='compare':
	diff={}
	for scope in qc.getActionScopes():
		diff[scope] = []

typeMap = DataTypeMap()
actionScopes = qc.getActionScopes()
cellScope = None
clusterServerIds = {}

for mapping in typeMap.getMappings():
	wasType = mapping.getType()
	if version < mapping.getVersion():
		print "ConfigType " + wasType + " is not in WebSphere Application Server v" + str(version)
		continue
	#endIF
	startTime = Date().getTime()

	excludedTypes = []
	if mapping.getExcludedTypes() != None and mapping.getExcludedTypes() != '':
		excludedTypes = mapping.getExcludedTypes().split(',')
	#endIf
	
	excludedAttrs = []
	if mapping.getExcludedAttributes() != None:
		excludedAttrs = mapping.getExcludedAttributes().split(',')
	#endIf
	
	file = ""
	if mapping.getFile() != None:
		file = mapping.getFile()
	#endIf

	if isImportMode:
		scopesProcessed = ArrayList()
		#Lets try to copy the xml file from the templates if it doesnt already exist..this is what normal action
		#do before they even get into jython.
		for scope in actionScopes:
			if cellScope == None and scope.getType() == "Cell":
				cellScope = scope
			if not scopesProcessed.contains(scope):
				qc.prepXmlDataFile(rafhome, file, scope)
			#endIf
		#endFor

		if (file == "osgi.xml" and wasType == "ExternalRepository"):
			#check to see if we support osgi...in 70 its only available in a feature pack
			if (version == 70):
				# check to see if aries is enabled in this profile
				dmgrNode = AdminControl.getNode()
				ariesVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.AriesFeaturePackProductShortName]')
				if (ariesVersion is None or len(ariesVersion) == 0):
					logger.log("CRWWA9708I")
					continue
				#endIf
			#endIf
			#actionScopes[0] is cell...
			if (not cellScope == None):
				config = OSGIExternalRepos()
				config.doImport(file)
		elif (file == "osgi.xml" and wasType == "InternalRepository"):
			#check to see if we support osgi...in 70 its only available in a feature pack
			if (version == 70):
				# check to see if aries is enabled in this profile
				dmgrNode = AdminControl.getNode()
				ariesVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.AriesFeaturePackProductShortName]')
				if (ariesVersion is None or len(ariesVersion) == 0):
					logger.log("CRWWA9708I")
					continue
				#endIf
			#endIf
			if not cellScope == None:
				config = OSGIInternalRepos()
				config.doImport(file)
		elif (file == "fileRegistry.xml" and wasType == "Group"):
			optDict = {'scope': 'cell'}
			if ((not cellScope == None) and WasConfig.isWimEnabled(optDict)):
				config = FileRegistryGroups()
				config.readFileRegistryGroups(file, "fileRegistryGroups")
		elif (file == "fileRegistry.xml" and wasType == "User"):
			optDict = {'scope': 'cell'}
			if ((not cellScope == None) and WasConfig.isWimEnabled(optDict)):
				config = FileRegistryUsers()
				config.readFileRegistryUsers(file, "fileRegistryUsers")
		elif (file == "SIBus.xml" and wasType == "MQServer"):
			if (not cellScope == None):
				config = siBusMediator()
				config.doImport(file)
		elif (file == "sib.xml"):
			#this stuff really only exists at the cell scope
			if (not cellScope == None):
				qc.processSibXmlTypes(wasType, mapping.getParentNode(), file)
		elif (file == "wimconfig.xml"):
			if (not cellScope == None):
				config = WIMConfigMediator(file, wasType, scope.getWASName())
				config.importFederatedSecurity()
		elif (file == "consoleMembers.xml"):
			if (not cellScope == None):
				config = ConsoleMemberMediator()
				config.importConsole(file, "consoleMembers", wasType.split(','))
		elif wasType == "WebServer":
			if (not cellScope == None):
				mws = ManageWebServer("import")
				mws.processWebServers(file, wasType)
		elif file =='serverTemplate.xml':
			for scope in actionScopes:
				if scope.getSubType() == "DYNAMIC_WAS":
					dynClusterMediator = DynClusterTemplate("import")
					scopeType =scope.getType().lower()
					scopeName = scope.getName()
					if not clusterServerIds.has_key(scopeName):
						clusterServerIds[scopeName] = dynClusterMediator.findServersInScope(scopeName, scopeType, None)
					xmlFile = scope.getPath() + "/" + file
					dynClusterMediator.processServer(clusterServerIds[scopeName], xmlFile, wasType, wasType, scopeType)
		elif file == 'rules.xml':
			for scope in actionScopes:
				if scope.getSubType() == "ODR":
					thisMediator = OdrRulesMediator()
					scopeType =scope.getType().lower()
					scopeName = scope.getName()
					xmlFile = scope.getPath() + "/" + file
					optDict = {'scope': 'cluster', 'scopename':scopeName}
					wasscope = AdminHelper.buildScope( optDict )
					ConfigMediator.importConfig(wasscope, scopeType, xmlFile, "odrRoutingRules", [wasType], excludedTypes, thisMediator) 
		elif file == 'dyncluster.xml':
			for scope in actionScopes:
				if scope.getSubType() == "DYNAMIC_WAS":
					thisMediator = DynClusterMediator("import", scope.getWASName(), wasType)
					scopeType =scope.getType().lower()
					xmlFile = scope.getPath() + "/" + file
					clusterIds = thisMediator.findClustersInScope(scope.getName(), scopeType)
					thisMediator.processServer(clusterIds, xmlFile, "dynamicCluster", scopeType)
		elif wasType == 'ResourceEnvEntry':
			for scope in actionScopes:
				scopeType =scope.getType().lower()
				scopeName = scope.getWASName()
				xmlFile = scope.getPath() + "/" + file
				myReader = resEnvEntriesReader()
				ConfigMediator.importConfig(scopeName, scopeType, xmlFile, 'resourceEnvironmentEntries', [wasType], excludedTypes , myReader)
		else:
			if (wasType == "SERVER.errorStreamRedirect" or wasType == "SERVER.outputStreamRedirect"):
				wasType = "StreamRedirect"
			#endIf
			types = wasType.split(',')
			configs = {}
			for wasType in types:
				useContainsCheck='n'
				#we need this cause...well...it wont capture the right things without it...so sad
				if (file == 'operationalPolicies.xml' or file == 'sib.xml'):
					useContainsCheck='y'
				tmpConfig = qc.capture(AdminConfig.list(wasType),excludedTypes,excludedAttrs, wasType, useContainsCheck)
				if len(configs) == 0:
					configs.update(tmpConfig)
				else:
					for key in tmpConfig.keys():
						if len(tmpConfig[key]) > 0:
							configs[key].addAll(tmpConfig[key])
			for scope in configs.keys():
				scopesProcessed.add(scope);
				try:
					#CRWWA4020I Importing {0}s at {1} Scope
					logger.log("CRWWA4020I", [wasType,scope.getWASName()])
					qc.writeConfigs(scope,configs[scope],mapping.getParentNode(),mapping.getFile())
				except Exception, e:
					print str(e)
					logger.error("Exception" + str(e))
				#endTry
			#endFor
		#endIf
		
		endTime = Date().getTime()
		print "Import of Config Type '" + mapping.getType() + "' took " + qc.getTimeDifference(startTime, endTime)
	elif isCompareMode:
		localFile = scope.getPath() + "/" + mapping.getFile()
		if File(localFile).exists():
			#CRWWA4021I Comparing {0}s at {1} Scope
			logger.log("CRWWA4021I", [wasType,scope.getWASName()])
			
			local = WsadminConfigXmlBuilder.readResourceFile(localFile)
			
			remote = qc.capture(AdminConfig.list(wasType),excludedTypes,excludedAttrs, wasType)
			
			for scope in qc.getActionScopes():
				
				compare = Compare()
				if remote.has_key(scope):
					result = compare.computeComparison(wasType, local, remote[scope])
					if result.differencesFound():
						diff[scope].append(result)
					#endIf
				#endIf
			#endFor
		#endIf
	#endIf
#endFor

startTime = Date().getTime()
for scope in actionScopes:
	if scope.getType()=="Server" or scope.getType()=="Cluster":#  or scope.getType()=="Cell":
		if isImportMode:
			configs = qc.captureServer(scope, 1)
			try:
				qc.writeConfigs(scope, configs, None, "server.xml")
			except Exception, e:
				logger.error("Exception" + str(e))
		elif isCompareMode:
			localFile = scope.getPath() + "/server.xml"
			if File(localFile).exists():
				local = WsadminConfigXmlBuilder.readFile(localFile)
				remote = qc.captureServer(scope, 1)
				compare = Compare()
				result = compare.computeComparison(wasType, local, remote)
				if result.differencesFound():
					diff[scope].append(result)
				#endIf
			#endIf
		#endIf
	#endIf
#endFor
endTime = Date().getTime()
print "Import of Server Config took " + qc.getTimeDifference(startTime, endTime)

differences = 0
if isCompareMode:
	for scope in diff.keys():
		for difference in diff[scope]:
			print "Found a difference for " + scope.getName()
			differences = differences + 1
			# we have all the POJOs here, so lets display out to stdout
			# or we could do something else cool like write to a file or run some actions
			displayProps = CompareDisplayProperties()
			displayProps.setSummaryMessage(MessageManager.getExceptionMessage(
					MessageManager.RB_WEBSPHERE_WAS, "CRWWA1503I", difference.getParent().getId()))
	
			display = CompareDisplay(displayProps)
			writer = StringWriter()
			display.displayComparison(difference, writer)
			print writer.toString()
		#endFor
	#endFor
	if differences < 1:
		logger.log("CRWWA1504I", [scope.getName()])
#endIf
