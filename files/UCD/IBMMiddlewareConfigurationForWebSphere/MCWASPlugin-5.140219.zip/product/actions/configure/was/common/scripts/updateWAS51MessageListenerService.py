"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateWAS51MessageListenerService.py
	
	This script is to update the message listener service properties of an application server or server members of a cluster.
"""


import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

updateWAS51MessageListenerServiceLogger = _Logger("updateWAS51MessageListenerService", MessageManager.RB_WEBSPHERE_WAS)


# function to modify listener ports
def modifyListenerPorts(nodeHash, server, serverName, nodeName):

	mls = AdminConfig.list('MessageListenerService', server)
	lports = AdminConfig.showAttribute(mls, 'listenerPorts')
	cleanLports = lports[1:len(lports)-1]
	for lport in cleanLports.split( ):
		##print "Removing " + lport
		updateWAS51MessageListenerServiceLogger.log("CRWWA2054I",[lport])
		
		AdminConfig.remove(lport)

	for child in nodeHash['MessageListenerService']['children']:
		# Modify ThreadPool Settings
		# There should only be one of these.
		if ( child.has_key('threadPool') ):
			##print "Modifying ThreadPool Settings for  " + mls
			updateWAS51MessageListenerServiceLogger.log("CRWWA2056I",[mls])
			AdminConfig.modify(mls, [['threadPool', [['inactivityTimeout', child['threadPool']['inactivityTimeout']], 
				['isGrowable',  child['threadPool']['isGrowable']],
				['maximumSize', child['threadPool']['maximumSize']], 
				['minimumSize', child['threadPool']['minimumSize']]]]])

		# modify the Listener Ports 
		elif ( child.has_key('ListenerPort') ):
			##print "Creating ListenerPort " + child['ListenerPort']['name']
			updateWAS51MessageListenerServiceLogger.log("CRWWA2057I",[child['ListenerPort']['name']])
			new = AdminConfig.create('ListenerPort', mls, 
				[['name', child['ListenerPort']['name']], 
				['destinationJNDIName', child['ListenerPort']['destinationJNDIName']], 
				['description', child['ListenerPort']['description']], 
				['connectionFactoryJNDIName', child['ListenerPort']['connectionFactoryJNDIName']],
				['maxMessages', child['ListenerPort']['maxMessages']],
				['maxRetries', child['ListenerPort']['maxRetries']],
				['maxSessions', child['ListenerPort']['maxSessions']]])

			print AdminConfig.create('StateManageable', new, [['initialState', 'START']])
		#endIf
#endDef
		
# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;scopename:;nodename:;properties:;mode:' )

scope = optDict['scope']
scopeName = optDict['scopename']
nodeName = optDict['nodename']

cellName = AdminControl.getCell()

# parse the properties into props

xmlProp  = ConfigFileReader.openXmlConfig( optDict['properties'] )
nodelist = xmlProp.getFilteredNodeList('MessageListenerService' ) 
nodearr = xmlProp.xmlReadNodeLevel( nodelist )

for nodeHash in nodearr:
	
	if (scope == "server") or (scope == "node"):
	
		# Check if it is a valid node
		node = AdminConfig.getid( '/Cell:' + cellName + '/Node:' + nodeName + '/' )
	
		if node == "":
			raise "\nupdateWAS51MessageListenerService.py: Error -- Invalid node name: " + scopeName 
		#endIf
	
		# Check if a server by this name already existing on the node
		serverName = optDict['scopename']
		server = AdminConfig.getid("/Cell:" + cellName + "/Node:" + nodeName + "/Server:" + serverName + "/")
	
		if server == "":
			raise "\nupdateWAS51MessageListenerService.py: Error -- Server " + serverName + " does not exist on node " + nodeName
		#endIf
		##print "Updating " + serverName + " on node " + nodeName
		updateWAS51MessageListenerServiceLogger.log("CRWWA2058I",[serverName,nodeName])	
		modifyListenerPorts(nodeHash, server, serverName, nodeName)
		
	
	elif (scope == "cluster") or (scope == "cell"):
		cluster = AdminConfig.getid("/Cell:" + cellName + "/ServerCluster:" + scopeName + "/")
		if cluster == "":
			raise "\nupdateWAS51MessageListenerService.py: Error -- Invalid cluster name: " + scopeName 
		#endIf	
	
		memberlist = AdminConfig.showAttribute(cluster, "members" )
		members = memberlist[1:len(memberlist)-1]
		for member in members.split():
			nodeName = AdminConfig.showAttribute(member, "nodeName" )
			serverName = AdminConfig.showAttribute(member, "memberName" )
			server = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
			
			##print "Updating " + serverName + " on node " + nodeName	
			updateWAS51MessageListenerServiceLogger.log("CRWWA2058I",[serverName,nodeName])
			modifyListenerPorts(nodeHash, server, serverName, nodeName)
			
		#endFor
	
	
	else:
		raise ("\nupdateWAS51MessageListenerService.py: %s is invalid. Exiting!" % (scope))
	
	#endIf

			
#endFor
	
AdminHelper.saveAndSyncCell()
