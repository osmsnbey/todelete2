"""
        Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 


        File name: configureDatabase.py

        Use this helper class to execute commands on remote server that is not described in RAFW environment as a node.
        It also provides methods for getting the remote server OS name, or user home directory.
"""

from com.ibm.rational.rafw.framework.connect import ExecutionEnvironment
from com.ibm.rational.rafw.framework.connect import ConnectionSettings
from com.ibm.rational.rafw.framework.transfer import TransferHelperFactory
from com.ibm.rational.rafw.framework.transfer import FileTransferDataProvider
from java.util import HashMap
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

"""
	Constructor arguments:
		hostname - remote server
		user - OS username
		password - OS password
		workingDir - if not specified user home directory will be used
"""
class RemoteHelper:
	
	def __init__(self, hostname, user, password, workingDir=None):
		self.LOGGER = _Logger("RemoteHelper", MessageManager.RB_WEBSPHERE_BPM)
		
		self.connection = ConnectionSettings()
		self.connection.setUsername(user)
		self.connection.setPassword(password)
		self.connection.setHostname(hostname)
		
		if workingDir is None:
			workingDir = self.getUserHomeDir() + "/RemoteHelper"
        
		nodeProps = HashMap()
		nodeProps.put("REMOTE_RAFW_HOME", workingDir)
		self.connection.setNodeProps(nodeProps)
	#endDef
	
	"""
		Executes command on remote server.
		This will transfer files required by the command and then execute the command.
		Arguments:
			command - command to be executed
			dirToTransfer - absolute path to the dir to be transfered. If not provided nothing will be transfered.
	"""
	def runCommand(self, command, dirToTransfer = None):
		try:	
			executionEnvironment = ExecutionEnvironment()
			remoteAccess = executionEnvironment.beginSession2(self.connection)
	
			# transfer files
			if dirToTransfer is not None:
				transferHelper = TransferHelperFactory.createTransferHelper(executionEnvironment)
				dataProvider = FileTransferDataProvider.createDataProvider(dirToTransfer)
				dataProvider.includeDirectory("/")
				# force transfer file by file without zipping because remote system
				# may not have java for unzipping
				transferHelper.setNumFilesBeforeArchive(100)
				transferHelper.transferFiles(dataProvider, "ConfigureDatabase_transfer_id")
	
			returnCode = executionEnvironment.runRemoteProcess(command)
			executionEnvironment.endSession()
	
			if returnCode != 0:
				raise "Command failed to execute: " + str(command) + "\nReturn code is: " + str(returnCode)
	
		except Exception, e:
			self.LOGGER.error("RXA exception: " + str(e))
			executionEnvironment.endSession()
			raise "RXA exception: " + str(e)
	#endDef
	
	"""
		Returns user home directory on the remote server.
	"""
	def getUserHomeDir(self):
		try:
			executionEnvironment = ExecutionEnvironment()
			remoteAccess = executionEnvironment.beginSession2(self.connection)
			workingDir = remoteAccess.getCurrentDirectory()
			executionEnvironment.endSession()
			return workingDir
		except Exception, e:
			self.LOGGER.error("RXA exception: " + str(e))
			executionEnvironment.endSession()
			raise "RXA exception: " + str(e)
	#endDef
	
	"""
		Returns remote server OS information.
		Arguments:
			key - OS param name. See list below.
		
		Available OS params:
			PLATFORM (AixPPC64, AixPPC32, LinuxPPC64...)
			OS_TYPE (64bit, 32bit)
			SCRIPT_EXT ('.sh', '.bat')
			OS (aix, linux...)
			CLASSPATH_SEPERATOR (':', ';')
	"""
	def getOsParam(self, key):
		try:
			executionEnvironment = ExecutionEnvironment()
			executionEnvironment.beginSession2(self.connection)
			value = executionEnvironment.getOsSettings().get(key)
			executionEnvironment.endSession()
			return value
		except Exception, e:
			self.LOGGER.error("RXA exception: " + str(e))
			executionEnvironment.endSession()
			raise "RXA exception: " + str(e)
	#endDef
#endClass