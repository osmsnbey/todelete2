--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.3
--   Last update: 07/07/17 03:28:04
--------------------------------------------------------------------------------
--
-- SQL snippet for Observer java based UDF
-- for Oracle 9i and Oracle 10g
--
--------------------------------------------------------------------------------
--
-- Note:
--
-- Before you can use this SQL file to switch to the Java based Observer
-- functions, you must ensure that you have installed the utility jar
-- $WAS_HOME/lib/bpcodbutil.jar using the setupEventCollector tool or by
-- using the following command:
--
-- 1) On your database server, change to the directory where the jar file
--    bpcodbutil.jar is located:
--    - IF your database is on the same server as the application server,
--      change to the lib subdirectory of the install_root directory.
--    - If your database is not on the same machine as your application server,
--      copy it per FTP and then change to the directory where you copied it to
--
-- 2) Run the Oracle loadjava utility to install the jar file bpcodbutil.jar,
--    by entering the following command:
--
--      $ORACLE_HOME/bin/loadjava -user <user>/<password>@<database> -resolve bpcodbutil.jar
--
--------------------------------------------------------------------------------
-- Following variables needs to be changed for customization and
-- before running this script:
--
--   @SCHEMA@ = Schema Qualifier
--------------------------------------------------------------------------------


-- OBSVR_FUNCTION_BEGIN INTERVALIN
CREATE OR REPLACE FUNCTION @SCHEMA@.INTERVALIN(INTERVALUNIT NUMBER, TS1 TIMESTAMP, TS2 TIMESTAMP)
  RETURN NUMBER
  AS LANGUAGE JAVA
  NAME 'com.ibm.bpe.observer.dbutil.TimestampUtil.intervalinUTC(int, java.sql.Timestamp, java.sql.Timestamp) return Integer';
/
-- OBSVR_FUNCTION_END INTERVALIN

-- OBSVR_FUNCTION_BEGIN OBSVR_JAR_ACTIVE
CREATE OR REPLACE FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE RETURN NUMBER IS
BEGIN
  RETURN 1;
END OBSVR_JAR_ACTIVE;
/
-- OBSVR_FUNCTION_END OBSVR_JAR_ACTIVE
