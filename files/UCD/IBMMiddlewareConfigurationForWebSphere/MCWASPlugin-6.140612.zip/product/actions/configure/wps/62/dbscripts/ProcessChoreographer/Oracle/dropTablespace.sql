--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to drop tablespaces for Oracle 9i and Oracle 10g
-- Start this script with SQL*Plus.
-- example: sqlplus scott/tiger@mydb @dropTablespace.sql


----------------------
-- Drop tablespaces --
----------------------

DROP TABLESPACE AUDITLOG INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE INSTANCE INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE STAFFQRY INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE TEMPLATE INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE WORKITEM INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE LOBTS INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;

DROP TABLESPACE INDEXTS INCLUDING CONTENTS AND DATAFILES CASCADE CONSTRAINTS;



-- start import scheduler DDL: dropTablespaceOracle.ddl

DROP TABLESPACE SCHEDTS INCLUDING CONTENTS;
-- end import scheduler DDL: dropTablespaceOracle.ddl

QUIT
