#!/bin/sh
#
# BEGIN COPYRIGHT
# *************************************************************************
# Licensed Materials - Property of IBM 
# 5724-L01, 5655-N53, 5724-I82, 5655-R15
# (C) Copyright IBM Corporation 2006. All rights reserved. 
# US Government Users Restricted Rights - Use, duplication, or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
# *************************************************************************
# END COPYRIGHT
#------------------------------------------------------------------------------
# Description:   executes the db2cmd configCommonDB.sh scripts to create
# the CommonDB database
# Return Codes:  0 for success, non zero for failed
#
# Usage: 
#      configCommonDB.sh   [createDB]
# Parameters:
#      createDB    - specify whether or not  to create a new db 
# 
# Example:
#      configCommonDB.sh  createDB   //create a new db
#      configCommonDB.sh             // use an existing db
#------------------------------------------------------------------------------
#-----------------------------------------
# Ask user for the database userid
#-----------------------------------------
get_userid() {
   while true; do
      if [ -n "$USER_NAME" ]; then
         USER_NAME=$USER_NAME
         break
      else
         echo         
		 echo "Enter DB2 user id ( user is required ): "
         read USER_NAME
         continue
      fi
   done
}


#-----------------------------------------
# Ask user for the database password
#-----------------------------------------
get_password() {
   while true; do
      if [ -n "$user_password" ]; then
          user_password=$user_password
          break
      else
          echo
	      trap 'stty echo;' 0 1 2 3 15
	      echo "Enter DB2 password( password is required ): "
	      stty -echo
	      read user_password
	      stty echo
          continue
      fi
   done
}


CURRENT_DIR=`dirname $0`
if [ "$CURRENT_DIR" = "." ] ; then
   CURRENT_DIR=`pwd`
fi

DB_CREATE=$1

################################
#  DB_NAME will be replaced 
################################
DB_NAME=#DB_NAME#

################################
#  DB_USER will be replaced 
################################
USER_NAME=#DB_USER#


#call the following subroutine to get the db2 userid
get_userid

# call db2cmd env to execute command.
$CURRENT_DIR/createDBTables.sh  $USER_NAME $DB_NAME $DB_CREATE 
			