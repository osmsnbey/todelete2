-- --------------------------------------------
-- Licensed Materials - Property of IBM
--
-- 5724-R31, 5655-S30
--
-- (C) Copyright IBM Corp. 2008 All Rights Reserved.
--
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
-- ---------------------------------------------

--
--  Create temporary tables, copy the original data into them and drop the original tables
--      This is just to make sure all of the indexes on the original table are gone.
--

CREATE TABLE w_temp_uri (
    id INTEGER NOT NULL, 
    uri VARCHAR(254) NOT NULL, 
    namespace_id INTEGER NOT NULL )  
 IN USERSPACE1; 

INSERT INTO w_temp_uri SELECT * FROM w_uri;
DROP TABLE w_uri;

CREATE TABLE w_temp_statement (
    id INTEGER NOT NULL, 
    version_from INTEGER NOT NULL, 
    version_to INTEGER NOT NULL, 
    subj_id INTEGER NOT NULL, 
    pred_id INTEGER NOT NULL, 
    obj_id INTEGER NOT NULL, 
    obj_typ_cd INTEGER NOT NULL,
    partition_id INTEGER NOT NULL)  
 IN USERSPACE1; 


INSERT INTO w_temp_statement SELECT * FROM w_statement;
DROP TABLE w_statement;

--
-- Recreate the tables with the new indexes
--

CREATE TABLE w_uri (
    id INTEGER NOT NULL, 
    uri VARCHAR(254) NOT NULL, 
    namespace_id INTEGER NOT NULL )  
 IN USERSPACE1; 

ALTER TABLE w_uri ADD PRIMARY KEY (id);

CREATE UNIQUE INDEX idx_uri ON w_uri (uri ASC);
CREATE UNIQUE INDEX idx_uri_by_ns ON w_uri (namespace_id, id);

ALTER TABLE w_uri 
	ADD CONSTRAINT w_uri_fk_namesp FOREIGN KEY
		(namespace_id)
	REFERENCES w_namespace
		(id)
	ON DELETE NO ACTION
	ON UPDATE NO ACTION
	ENFORCED
	ENABLE QUERY OPTIMIZATION;

CREATE TABLE w_statement (
    id INTEGER NOT NULL, 
    version_from INTEGER NOT NULL, 
    version_to INTEGER NOT NULL, 
    subj_id INTEGER NOT NULL, 
    pred_id INTEGER NOT NULL, 
    obj_id INTEGER NOT NULL, 
    obj_typ_cd INTEGER NOT NULL,
    partition_id INTEGER NOT NULL)  
 IN USERSPACE1; 

ALTER TABLE w_statement ADD PRIMARY KEY (id);

CREATE INDEX idx_smt_by_sbj ON w_statement (subj_id, version_from, version_to);
CREATE INDEX idx_smt_by_fvr ON w_statement (version_from);
CREATE INDEX idx_sbj_by_prp ON w_statement (pred_id, obj_id);
CREATE INDEX idx_smt_by_val ON w_statement (obj_id, subj_id);
CREATE INDEX idx_val_by_prp ON w_statement (subj_id, pred_id);

--
--  Copy the data from the temporary tables back into the original tables and drop the temporary tables
--

INSERT INTO W_STATEMENT SELECT * FROM W_TEMP_STATEMENT;
DROP TABLE W_TEMP_STATEMENT;

INSERT INTO W_URI SELECT * FROM W_TEMP_URI;
DROP TABLE W_TEMP_URI;

