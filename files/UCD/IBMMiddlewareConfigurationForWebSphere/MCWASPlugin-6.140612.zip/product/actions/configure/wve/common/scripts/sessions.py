"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: sessions.py
"""

import string
import sys
lineSeparator = java.lang.System.getProperty('line.separator')

"""
	Find the 'target' property in the middleware descriptors for the current cell
"""
def findMDValue(descs, target):
	for desc in descs:
		line = string.strip(desc)
		if(line != ''):
			pair = line.split('=', 1)
			if(pair[0] == target):
				return pair[1]

"""
	Modify the middleware property 'name' to 'value'
"""
def modifyProperty(name, value):
	AdminTask.modifyMiddlewareDescriptorProperty ('[-name application_server -version default -propName ' + name + ' -propValue ' + value + ']')
		
"""
	Update cookies with 'cellName', and ensure that other properties are correct
"""
def addCell(isODR, cellName):
	descs=AdminTask.showMiddlewareDescriptorInformation ('[-name application_server]').split('\n')
	cellName = string.upper(cellName)
	cookies = findMDValue(descs, 'sessionAffinityDescriptor:cookieNames')
	altCloneIdSep = findMDValue(descs, 'sessionAffinityDescriptor:altCloneIdSeparator')

	tmp = cookies[1:-1]
	tmp = tmp.split(',')
	tmp.append(cellName)
	
	cookies = string.join(tmp, ',')
	print cookies
	altCloneIdSep = '[-]'
	
	modifyProperty('sessionAffinityDescriptor:cookieNames', cookies)
	modifyProperty('sessionAffinityDescriptor:altCloneIdSeparator',altCloneIdSep)
	
	if(isODR == 1):
		modifyProperty('sessionAffinityDescriptor:learnCloneIds', 'true')
		modifyProperty('sessionAffinityDescriptor:affinityMode', 'passive')
	AdminConfig.save()

"""
	Modify the LTPA session timeout
"""			
def modifyLTPATimeout(cellName, value):
	sec  = AdminConfig.getid('/Cell:' + cellName + '/Security:/')
	ltpa = AdminConfig.list('LTPA', sec)
	AdminConfig.modify(ltpa, [['timeout', int(value)]])
	AdminConfig.save()
	

"""
	Modify the session manager cookie settings
"""
def modifySessionManager(value):
	cellName = AdminControl.getCell()
	cellName = string.upper(cellName)
	nodes = AdminConfig.list('Node').split(lineSeparator)
  	for node in nodes:
    		nodeName = AdminConfig.showAttribute(node, "name" )
    		serverEntries = AdminConfig.list( "ServerEntry" , node).split(lineSeparator)    
    		for serverEntry in serverEntries:
      			serverName = AdminConfig.showAttribute(serverEntry, "serverName" )
      			if serverName != 'dmgr' and serverName != 'nodeagent':
				server = AdminConfig.getid('/Node:' + nodeName + '/Server:' + serverName +'/')
				wc =  AdminConfig.list('WebContainer', server)
				sm = AdminConfig.list('SessionManager', wc)			
				AdminConfig.modify(sm, [['enableCookies', 'true']])
				cookie = AdminConfig.list('Cookie', sm)
				AdminConfig.modify(cookie, [['name', cellName]])				
				tp = AdminConfig.list('TuningParams', sm)
				AdminConfig.modify(tp, [['invalidationTimeout', int(value)]])
	AdminConfig.save()


optDict, args = SystemUtils.getopt( sys.argv, 'scope:;nodename:;scopename:;mode:;cellProperties:;command:;celltype:;cellname:;value:' )

command = optDict['command']

if (command == 'middleware'):
	isODR = int(optDict['celltype'])
	cellname = optDict['cellname']
	addCell(isODR, cellname)
elif (command == 'ltpa'):
	cellname = optDict['cellname']
        value = optDict['value']
	modifyLTPATimeout(cellname, value)
elif (command == 'sessionmgr'):
        value = optDict['value']	
	modifySessionManager(value)

