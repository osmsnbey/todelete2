"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: serviceClass.py
"""

class ServiceClassReader(ConfigReader):
	
	def __init__(self, importedIds=[], excludedTypes = [], excludedAttributes = []):
		self.LOGGER = _Logger("ServiceClassReader", MessageManager.RB_WEBSPHERE_WVE)
		self.importedIds = importedIds
		self.objidConfigTypeMap = {}
		self.excludedTypes = excludedTypes
		self.processTypesFirst = []
		self.excludedAttributes = excludedAttributes
		# load the list of attributes which are treated as password fields
		self._updatePasswordAttributes()
	#endDef

	def checkWasAttrs( self, wasAttrs ):
		newList = []
		for attr in wasAttrs:
			if ( len(attr) > 0 ):
				newList.append( attr )
			#endIf
		#endFor
		return newList
	#endDef

	##########################################################
	## Reads all data from WAS with the supplied id, then processes all attributes
	## that contain WAS ids into children. 
	##
	## Returns a dict with the following keys
	## id -- the type of the WAS config element referred to by the supplied id
	## attrs -- the attributes of the id, with all attributes referring to WAS ids removed
	## children 
	## An array of similar dicts, referring to each child referenced by this configuration
	## (each child contain the same:) 
	## ---id 
	## ---attrs
	## ---children
	##########################################################
	def showAll(self, id):
		self.LOGGER.traceEnter(id)
		if (str(id).split("#")[1].find(" ") >= 0):
			print "WARNING: ignored key = " + str(id)
			self.LOGGER.traceExit(str(None))
			return None
		#endIf
		# print "reading AllConfigData under: " + id
		# self.importedIds.append(id)
		subAttrs = self.show(id)
		children = []
		configElements = []
		if (subAttrs != None):
			configElements = self.removeChildIdsToProcess(id, subAttrs)
		
			## process reference ids
			for childKey in configElements.referenceIds.keys():
				childIds = configElements.referenceIds[childKey]
				for childId in childIds:
					if (childId not in self.importedIds):
						child = {}
						child['id'] = self.getWASType(childId)
						child['children'] = []
						childAttrs = self.show(childId)
						## remove all fields containing object ids
						print "--## Working on %s::%s ##--" % (childId, childAttrs)
						self.removeChildIdsToProcess(childId, childAttrs)
						child['attrs'] = childAttrs
						child['attrs'][WAS_KEY_ATTR_NAME] = childKey
						child['attrs'][RAFW_TYPE] = RAFW_TYPE_REFERENCE
						children.append(child)
					#endIf
				#endFor
			#endFor

			## process higher priority children first
			for childKey in configElements.highPriorityIds.keys():
				childIds = configElements.highPriorityIds[childKey]
				for childId in childIds:
					child = self.processId(childId)
					if (child != None and child['id'] not in self.excludedTypes):
						child['attrs'][WAS_KEY_ATTR_NAME] = childKey
						children.append(child)
					#endIf
				#endFor
			#endFor

			if (len(subAttrs.keys()) > 0):
				## process regular priority children second
				#for childKey in childIds['none'].keys():
				for childKey in configElements.lowPriorityIds.keys():
					childIds = configElements.lowPriorityIds[childKey]
					for childId in childIds:
						child = self.processId(childId)
						if (child != None and child['id'] not in self.excludedTypes):
							print "--## Working on childKey: %s SubAttrs: %s ##--" % (childKey,subAttrs)
							child['attrs']['WASKey'] = childKey
							if (child['id'] != "builtin"):
								children.append(child)
						#endIf
					#endFor
				#endIf
			#endFor

		#endIf
		data = {}
		data['id'] = self.getWASType(id)
		data['attrs'] = subAttrs
		data['children'] = children
		self.LOGGER.traceExit(data)
		return data
	#endDef

	##########################################################
	##  Extends AdminConfig.show to display the values as a Dict
	## @param objId: the object id to show 
	##########################################################
	def show(self, objId):
		self.LOGGER.traceEnter(objId)
		try:
			wasAttrs = AdminConfig.show(objId).split(newline)
			wasAttrs = self.checkWasAttrs( wasAttrs )
			returnDict = self.convertAdminConfigAttrsToDict(objId, wasAttrs)
			self.LOGGER.traceExit(returnDict)
			return returnDict
		except:	
			self.LOGGER.error("unable to show: " + objId)
			self.LOGGER.error(" Details are: " + str(sys.exc_info()[0]) + ":" + str(sys.exc_info()[1]))
			if (objId.find(':') != -1):
				print "Trying again without :"
				newObjId = objId.split(':', 1)[1]
				try:
					wasAttrs = AdminConfig.show(newObjId).split(newline)
					returnDict = self.convertAdminConfigAttrsToDict(newObjId, wasAttrs)
					self.LOGGER.traceExit(returnDict)
					return returnDict
				except:	
					print "ERROR: unable to show: " + newObjId
				#endTry
			#endIf
			returnDict = None
			self.LOGGER.traceExit(returnDict)
			return returnDict
		#endTry
	#endDef

	##########################################################
	## Determines which attributes contained in the supplied id are defined
	## to contain references to other WebSphere ids.  
	##
	## Reference ids are WebSphere ids that exist outside the parent-child
	## hierarchy.  As such, they must be handled differently than ids which are children
	## of a given WebSphere configuration element.  
	##
	## @param id: The parent object whose attributes should be consulted
	## @return: a list of attribute names that are defined to contain references to 
	##          non-sibling WebSphere configuration elements
	## 
	##########################################################
	def getReferenceKeys(self, id):
		referenceKeys = []
		if (len(id) > 0 and (id.find("builtin") == -1)):
			wasType = self.getWASType(id)
			if ( wasType != "DiscretionaryGoal" ):
				for attribute in AdminConfig.attributes(wasType).split(newline):
						print "-## %s of %s ##--" % (attribute,wasType)
						(key, info) = attribute.split(' ', 1)
						if (info.endswith('@')):
							referenceKeys.append(key)
						#endIf
				#endFor
			#endIf
		#endIf
		return referenceKeys
	#endDef
	
	##########################################################
	## Parse an id string to find the type in the order
	## Garbage#JDBCProvider_Garbage
	##
	## @return: The above example would return JDBCProvider
	##
	##########################################################
	def getWASType(self, id):
		self.LOGGER.traceEnter(id)
		type = id.split("#")[1]
		type = type.split("_")[0]
		type = type.split(")")[0]
		self.LOGGER.traceExit(type)

		allTypes = AdminConfig.types().split(newline)

		if (type not in allTypes):
			type = "ServiceClass"
		#endIf
		return type
	#endDef
	
#endClass

class ServiceClassMediator:
	
	def __init__(self):
		self.LOGGER = _Logger("ServiceClassMediator", MessageManager.RB_WEBSPHERE_WVE)
	#endDef		
		
	##########################################################
	## 
	## Reads WAS configuration data under the supplied scope for 
	## the requested configuration type.
	##
	## This method is not called recursively like the showAll method
	## This method resets the importedIds variable
	##
	## @param scope: The parent scope of the configuration to read
	## @param scopeType: cell/node/cluster/server - used to filter out 
	##                   elements not in the correct scope 
	## @param configType: The data type to read - ex: JDBCProvider - this is generally the 
	##                    xml:id in the WAS configuration files 
	## @param excludedTypes: The types to exclude. ex: ['JAASAuthData', ...] 
	## @param excludedAttributes: The attributes to exclude or replace their values.
	##                            To exclude: ['Security.wsPasswordEncryptions', ...]
	##                            To replace: ['LDAPUserRegistry.serverPassword=value', ...]
	##
	##########################################################
	def readConfigData_old(self, scope, scopeType, configType, excludedTypes = [], excludedAttributes = []):
		self.LOGGER.traceEnter([scope, scopeType, configType, excludedTypes, excludedAttributes])
		scopeId = AdminConfig.getid(scope)
		print "Scope ID is: %s" % scopeId
		returnVal = self.readConfigDataUsingParentId(scopeId, scopeType, configType, excludedTypes, excludedAttributes)
		self.LOGGER.traceExit(returnVal)
		return returnVal
	#endDef

	def readConfigData(self, scope, scopeType, configType, excludedTypes):
	
		data = []
		scopeId = AdminConfig.getid(scope)
		myConfigReader = ServiceClassReader()
	
		for objId in AdminConfig.list(configType, scopeId).split(newline):
			self.importedIds = []
			## if anything found, is in scope, and not builtin
			if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId) and (objId.find("builtin") == -1)):
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							match = "yes"
						#endIf
					#endFor
					if (match == "no"):
						self.LOGGER.info("Importing " + objId)
						self.importedIds.append(objId)
						data.append(self.showAll(objId))
					#endIf
				else:
					self.LOGGER.info("Importing " + objId)
					self.importedIds.append(objId)
					data.append(myConfigReader.showAll(objId))
				#endIf
			#endIf
		#endFor
		return data
		#print "Scope ID is: %s" % scopeId
		#returnVal = myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, configType, excludedTypes, excludedAttributes)
		#self.LOGGER.traceExit(returnVal)
		#return returnVal
	#endDef
	
#endClass

optDict, args = SystemUtils.getopt(sys.argv, 'scope:;scopename:;properties:;mode:')

scope = AdminHelper.buildScope( optDict )
scopeType = optDict['scope']
mode = optDict['mode']
xmlFile  = optDict['properties']

thisMediator = ServiceClassMediator()
typeNames = ['ServiceClass']
#excludedTypes = ['Default'] 
excludedTypes = []
marker = "servicePolicy"

if (mode == MODE_EXECUTE):
	print "Creating Service Classes"
	ConfigMediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes)
	AdminHelper.saveAndSyncCell()
	
elif (mode == MODE_IMPORT):
	print "Importing Service Classes"
	ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator)

elif (mode == MODE_COMPARE):
	print "Comparing Service Classes in RAFW and WAS"
	ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames, excludedTypes, thisMediator)

elif (mode == MODE_AUGMENT):
	print "Augmenting Service Classes"
	scopeId = AdminConfig.getid(scope)	
	ConfigMediator.augmentConfigUsingParentId(scopeId, scopeType, xmlFile, marker, typeNames, excludedTypes)
	AdminHelper.saveAndSyncCell()
	
else:
	print "Unsupported MODE supplied: " + mode
#endIf
