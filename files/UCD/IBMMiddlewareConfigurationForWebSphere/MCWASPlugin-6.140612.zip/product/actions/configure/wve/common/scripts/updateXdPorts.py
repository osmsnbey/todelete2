"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateXdPorts.py
"""

#from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from AdminHelper import *

import AdminConfig
import AdminTask

"""
CLASS :: _XdConfig
Encapsulates useful utilities used for WebSphere XD    
specific configuration                                
"""
class _XdConfig:
	
	def __init__(self):
		self.LOGGER = _Logger("_XdConfig", MessageManager.RB_WEBSPHERE_WVE)
	#endDef

	def updateServerPorts(self, wasVersion, nodeName, serverName, serverNumber=1, transportInc=0, transportStartPort=0, serverTemplate='default'):
		self.LOGGER.traceEnter([wasVersion, nodeName, serverName, serverNumber, transportInc, transportStartPort])
		
		print "serverTemplate = " + serverTemplate
		
		if serverTemplate == 'default':
			endPointNames = ['OVERLAY_TCP_LISTENER_ADDRESS',
							'OVERLAY_UDP_LISTENER_ADDRESS',
							'XDAGENT_PORT']
		else:
			endPointNames = []
		
		serverNumber = int(serverNumber)
		transportInc = int(transportInc)
		transportStartPort = int(transportStartPort)
		
		# Now we're going to adjust the tcp transports if TRANSPORT_STARTING_POINT was defined
		if (transportStartPort > 0):			
			myPort = ((serverNumber-1) * transportInc) + transportStartPort
			for sEPoint in endPointNames:
				sAttrs = '[-nodeName ' + nodeName + ' -endPointName ' + sEPoint + ' -port ' + str(myPort) + ' -modifyShared]'
				print "--## Setting %10s:%40s == %5s ##--" % (serverName, sEPoint, str(myPort))
				AdminTask.modifyServerPort(serverName, sAttrs)
				myPort = myPort+1
			#endFor
		#endif
		self.LOGGER.traceExit()
	#endDef
	
	def getGratestWasPort(self, nodeName, serverName):
		xdPorts = ['OVERLAY_TCP_LISTENER_ADDRESS',
				'OVERLAY_UDP_LISTENER_ADDRESS',
				'XDAGENT_PORT']
		
		port = 0
		for portEntry in AdminTask.listServerPorts(serverName,'[-nodeName ' + nodeName + ']').split(newline):
			# portEntry == [[WC_adminhost_secure [[[host *] [node dmgr] [server dmgr] [port 17001] ]]] ]
			portName = portEntry[2:].split(" [[[")[0]
			if portName in xdPorts:
				continue
			
			portNum = int(portEntry.split('[port ')[1].split(']')[0])
			if portNum > port:
				port = portNum
		print "The greatest WAS port number: " + str(port)
		return port
	#endDef
	
#endDef


optDict, args = SystemUtils.getopt( sys.argv, 'mode:;wasVersion:;nodeName:;serverName:;serverTemplate:;transportStartPort:;action:' )
mode = optDict['mode']
action = optDict['action']
wasVersion = optDict['wasVersion']
nodeName = optDict['nodeName']
serverName = optDict['serverName']
serverTemplate = optDict['serverTemplate']
transportStartPort = optDict['transportStartPort']

## define global singletons
XdConfig = _XdConfig()

if (mode == MODE_EXECUTE):
	if action == 'updateports':
		transportStartPort = XdConfig.getGratestWasPort(nodeName, serverName) + 1
		XdConfig.updateServerPorts(wasVersion, nodeName, serverName, 1, 0, transportStartPort, serverTemplate)
		AdminHelper.saveAndSyncCell()
	else:
		raise "Unsupported action supplied: " + str(action)
else:
	raise "Unsupported MODE supplied: " + mode
#endIf