"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: WAS51MQJMSConnFactories.py
	
	This script is to create MQ jms conneciton factories in a given scope.
	This uses a type that only exists in WAS51 and previous.  
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f WAS51MQJMSConnFactories.py 
		-scope <scope>: specify the scope of the jms connection factories to be created
		-scopename <scope name>: specify the scope name of the jms connection to be created 
		-properties <jms properties file>: specify the name of the jms properties 
			file to be used for the creation
"""

from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

WAS51MQJMSConnFactoriesLogger = _Logger("WAS51MQJMSConnFactories", MessageManager.RB_WEBSPHERE_WAS)

def createConfig(scope, scopeType, xmlFile, marker):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeid = AdminConfig.getid( scope )
	typeName = "MQQueueConnectionFactory"
	createConfigType(scopeid, scopeType, xmlProp, typeName)
	
#endDef

def createConfigType(scopeid, scopeType, xmlProp, typeName):
	
	myConfigWriter = ConfigWriter();
	myConfigWriter.removeExistingConfig(scopeType, typeName, scopeid)

	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	for xmlNode in nodeArray:
		
		providerNode = xmlNode.getFilteredChildrenArray("builtin")[0]
		JMSProviderName = providerNode.getAttrValue("name")
		## hard coded for now
		parentId = AdminConfig.getid( scope + 'JMSProvider:' + JMSProviderName + '/' )
	
		myConfigWriter.createWASObject(xmlNode, parentId)
	#endFor
#endDef

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'scope:;properties:;nodename:;scopename:;mode:')
	
# get scope
scope = AdminHelper.buildScope(optDict)

propFile = optDict['properties'] 

mode = optDict['mode']
marker = "WAS51MQJMSConnFactories"
if (mode == MODE_EXECUTE):

	##print "Creating MQ conn factories in scope: " + scope
	WAS51MQJMSConnFactoriesLogger.log("CRWWA2094I",[scope])
	scopeType=optDict['scope']

	createConfig(scope, scopeType, propFile, marker)
	AdminHelper.saveAndSyncCell()

elif (mode == MODE_IMPORT):
	##print "Importing MQ Conn Factories in scope: " + scope
	WAS51MQJMSConnFactoriesLogger.log("CRWWA2095I",[scope])
	typeNames = ["MQQueueConnectionFactory"]
	scopeType=optDict['scope']
	ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames)

else:
	##print "Unsupported MODE supplied: " + mode
	WAS51MQJMSConnFactoriesLogger.log("CRWWA0008W",[mode])
#endIf

