"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: osgiInternalRepos.py
	
	Description: Manages internal OSGi repositories in WAS
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import *

from com.ibm.rational.rafw.wsadmin.websphere.config import WsadminConfig,\
	LegacyWsadminConfigHelper
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter
from com.ibm.rational.rafw.wsadmin.websphere.config.compare import ConfigCompareTools

import Globals

from java.lang import Integer
from java.util import ArrayList
from java.io import File
from XmlProperty import InvalidXmlConfigException

CONTAINER_XML_ID = "OSGi_InternalRepositories"
XML_ID = "InternalRepository"
## the attribute name that identifies each instance of the top level xml nodes.
UNIQUE_XML_IDENTIFIER = "symbolicName"

## the path relative to SCOPE_HOME where the bundles are stored, including path separators on both sides
BUNDLE_REPO_REL_PATH="/bundleRepository/"
class OSGIInternalRepos:
	def __init__(self, scopehome):
		self.LOGGER = _Logger("osgiInternalRepos", MessageManager.RB_WEBSPHERE_WAS)
		self.scopeHome = scopehome	
	#endDef
	
	def doExecute(self, xmlFile ):
		self.doModify(xmlFile, 0)
	#endDef

	def doAugment(self, xmlFile ):
		self.doModify(xmlFile, 1)
	#endDef
		
	def doModify(self, xmlFile, isAugment ):
		# parse the XML data 
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(CONTAINER_XML_ID)
		
		xmlConfigReader = XMLConfigReader()
		filteredNodes = xmlProp.getFilteredNodeArray(XML_ID)
		newConfig = xmlConfigReader.readXmlWsadminConfig(filteredNodes)
		existingConfig = self.readData()
		uniqueKeys = ArrayList()
		uniqueKeys.add(UNIQUE_XML_IDENTIFIER)
		uniqueKeys.add("version")
		compareTools = ConfigCompareTools(uniqueKeys)	
		toUpdate = compareTools.findIntersection(newConfig, existingConfig)
		toAdd = compareTools.findComplementInA(newConfig, existingConfig)
		toRemove = compareTools.findComplementInA(existingConfig, newConfig)
		
		for update in toUpdate:
			# do work
			self.LOGGER.log("CRWWA9710I", [update.getAttributes().get(UNIQUE_XML_IDENTIFIER), update.getAttributes().get("version")])
		#endFor
		
		for add in toAdd:
			self.LOGGER.log("CRWWA9711I", [add.getAttributes().get(UNIQUE_XML_IDENTIFIER), add.getAttributes().get("version")])
			# add the new bundle
			filePath = self._getFilePath(self.scopeHome + BUNDLE_REPO_REL_PATH, 
								add.getAttributes().get(UNIQUE_XML_IDENTIFIER), 
								add.getAttributes().get('version'))
			params = []
			params.append('-file')
			params.append(filePath)
			AdminTask.addLocalRepositoryBundle(params)
		#endFor

		if (not isAugment):	
			for remove in toRemove:
				# do work
				self.LOGGER.log("CRWWA9712I", [remove.getAttributes().get(UNIQUE_XML_IDENTIFIER), remove.getAttributes().get("version")])
				params = []
				params.append('-symbolicName')
				params.append(remove.getAttributes().get('symbolicName'))
				params.append('-version')
				params.append(remove.getAttributes().get('version'))
				AdminTask.removeLocalRepositoryBundle(params)
			#endFor
		#endIf
	#endDef

	def _getFilePath(self, relPath, symbolicName, version):
		fileName = symbolicName + "_" + version
		absJar = File(relPath + fileName + ".jar")
		absCba = File(relPath + fileName + ".cba")
		if (absJar.exists()):
			return absJar.getAbsolutePath()
		elif(absCba.exists()):
			return absCba.getAbsolutePath();
		else:
			raise InvalidXmlConfigException(MessageManager.getExceptionMessage(
						MessageManager.RB_WEBSPHERE_WAS, "CRWWA9718E", [relPath + fileName]))
		#endIf
	#endDef

	"""
	Reads the data in WAS into an ArrayList of WsadminConfig objects
	that represent the configuration.
	"""
	def readData(self):
		repos = AdminTask.listLocalRepositoryBundles()
		data = ArrayList()
		configReader = ConfigReader()
		newline = java.lang.System.getProperty("line.separator")
		for repo in repos.split(newline):
			if (len(repo) > 0):
				(symbolicName, version) = repo.split(';')
				repoConfig = WsadminConfig()
				repoConfig.setId(XML_ID)
				repoConfig.setAttribute("symbolicName", symbolicName)
				repoConfig.setAttribute("version", version)
				data.add(repoConfig)
			#endIf
		#endFor
		return data
	#endDef

	def doImport(self,xmlFile):
		data = self.readData()
		container = WsadminConfig()
		container.setId(Globals.RAFW_XML_PREFIX + CONTAINER_XML_ID)
		container.setChildren(data)
		XmlConfigFileWriter().build(xmlFile, container)
	#endDef

	def doCompare(self, xmlFile):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(CONTAINER_XML_ID)
		
		## this is a list of WsadminConfig objects
		configData = self.readData()
		wasConfig = LegacyWsadminConfigHelper.convertToLegacy(configData)

		# get rafwConfig
		xmlConfigReader = XMLConfigReader()
		filteredNodes = xmlProp.getFilteredNodeArray(XML_ID)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		
		## must compare ignoring file

		ConfigComparor.compare(CONTAINER_XML_ID, wasConfig, rafwConfig)
		
	#endDef

	def perform(self, optDict, save="1"):
		wasVersion = Integer.valueOf(optDict['version']) 
		if (wasVersion >= 70):
			if (wasVersion == 70):
				# check to see if aries is enabled in this profile
				dmgrNode = AdminControl.getNode()
				ariesVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.AriesFeaturePackProductShortName]')
				if (ariesVersion is None or len(ariesVersion) == 0):
					self.LOGGER.log("CRWWA9708I")
					return
				#endIf
			#endIf
			xmlFile = optDict['properties'] 
			mode = optDict['mode']
			if (mode == MODE_EXECUTE):
				self.LOGGER.log("CRWWA9713I")
				self.doExecute(xmlFile)
				if (save is not None):
					AdminHelper.saveAndSyncCell()
			elif (mode == MODE_AUGMENT):
				self.LOGGER.log("CRWWA9714I")
				self.doAugment(xmlFile)
				if (save is not None):
					AdminHelper.saveAndSyncCell()
			elif (mode == MODE_IMPORT):
				self.LOGGER.log("CRWWA9715I")
				self.doImport(xmlFile)
			elif (mode == MODE_COMPARE):
				self.LOGGER.log("CRWWA9716I")
				self.doCompare(xmlFile)
			else:
				self.LOGGER.log("CRWWA0008W", [mode])
			#endIf
		else:
			self.LOGGER.log("CRWWA9709W")
		#endIf
	#endDef
#endClass

def export(optDict=None):
	#wasProfHome = optDict['wasProfHome'] 
	thismediator = OSGIInternalRepos(optDict['scopeHome'])
	thismediator.perform(optDict, None)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:;scopename:;scope:;version:;scopeHome:;wasProfHome:' )

	#wasProfHome = optDict['wasProfHome'] 
	#wasVersion = Integer.valueOf(optDict['version']) 
	thismediator = OSGIInternalRepos(optDict['scopeHome'])
	thismediator.perform(optDict)
#endIf
