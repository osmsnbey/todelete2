"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: createWP61Cluster.py
	
	TODO: description
"""


import sys
from java.util import Properties
from java.io import FileInputStream


def createCluster ( clusterName, nodes, namePrefix, serversPerNode, weight, primaryNode, transportStartPort, transportInc, wasVersion ):

        #--------------------------------------------------------------
        # set up globals
        #--------------------------------------------------------------
        global AdminConfig
        global AdminControl
        global AdminApp

        #---------------------------------------------------------
        # We assume that there is only one cell, and we are on it
        #---------------------------------------------------------
        cellname = AdminControl.getCell( )
        cell = AdminConfig.getid("/Cell:"+cellname+"/" )

        #---------------------------------------------------------
        # Construct the attribute list to be used in creating a ServerCluster
        # attribute.
        #---------------------------------------------------------

        name_attr = ["name", clusterName]
        desc_attr = ["description", clusterName+" cluster"]
        pref_attr = ["preferLocal", "true"]
        statem_attr = ["stateManagement", [["initialState", "STOP"]]]
        attrs = [name_attr, desc_attr, pref_attr, statem_attr]

        #---------------------------------------------------------
        # Create the server cluster by converting WebSphere_Portal to a cluster
        #---------------------------------------------------------

        cluster = AdminConfig.getid("/Cell:"+cellname+"/ServerCluster:"+clusterName )
        if (len(cluster) == 0):
                print "cluster: creating the ServerCluster "+clusterName
                primary_server = AdminConfig.getid("/Cell:"+cellname+"/Node:"+primaryNode+"/Server:WebSphere_Portal" )
                if (len(primary_server) > 0):
                    cluster = AdminConfig.convertToCluster(primary_server, clusterName )
                else:
                    raise( "Error: Unable to locate primary server to convert to cluster"
                        + ".  Using primary node '" + str(primaryNode) + "'"
                        + ".  Using primary server 'WebSphere_Portal'")
                #endIf
        else:
                print "cluster: SrverCluster "+clusterName+" already exists..."

        #endIf 

        #---------------------------------------------------------
        # For each node, create the required number of servers
        #---------------------------------------------------------
        cloneNum = 1
        for nodeName in nodes.split(","):
                node = AdminConfig.getid("/Node:"+nodeName+"/" )
                # stop servers we don't need
                print "Stopping WebSphere_Portal"
                AdminHelper.stopServer('WebSphere_Portal', nodeName )
                print "Stopping server1"
                AdminHelper.stopServer('server1', nodeName )
                i = 1  #forStart
                portIndex = 1  #forStart
                while ( i <= serversPerNode ):  #forTest
                       serverName = namePrefix + str(cloneNum)
                       name_attr = ["memberName", serverName]
                       weight_attr = ["weight", weight]
                       uniquePorts_attr = ["genUniquePorts", "false"]
                       attrs = [name_attr, weight_attr, uniquePorts_attr]
                       serverid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/" )
                       if (len(serverid) == 0):
                            print "cluster: creating server "+serverName+" on node "+nodeName
                            if (i > 1):
                                 server = AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [['+nodeName+' '+serverName+' "" "" true true]]]') 
                            else:
                                 server = AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [['+nodeName+' '+serverName+' "" "" false true]]]') 
                            serverid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/" )
                            nodeid = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/" )
                            # Now we're going to adjust the tcp transports of TRANSPORT_STARTING_POINT was defined
                            WasConfig.updateServerPorts(wasVersion, nodeName, serverName, portIndex, transportInc, transportStartPort)
                            jvm = AdminConfig.list("JavaVirtualMachine", serverid )
                       else:
                            print "cluster: ClusterMember "+serverName+" already exists..."
							#No need to update ports if the server is already existing
                            #print "cluster: ClusterMember "+serverName+" updating ports..."
                            #WasConfig.updateServerPorts(wasVersion, nodeName, serverName, portIndex, transportInc, transportStartPort)
                            jvm = AdminConfig.list("JavaVirtualMachine", serverid )
                       #endIf

                       i += 1  #forNext
                       portIndex += 1  #forNext
                       cloneNum += 1  #forNext
                #endWhile  (#endFor)

        #endFor 

        #---------------------------------------------------------
        # save changes
        #
        #---------------------------------------------------------

        print "cluster: saving config changes."
        AdminConfig.save( )

        #---------------------------------------------------------
        # Ask the ClusterMgr to refresh its list of clusters
        #
        #---------------------------------------------------------

        clusterMgr = AdminControl.completeObjectName("type=ClusterMgr,cell="+cellname+",*" )
        if (len(clusterMgr) == 0):
                print "cluster: Error -- clusterMgr MBean not found for cell "+cellname
                return 
        #endIf 
        AdminControl.invoke(clusterMgr, "retrieveClusters" )

        # Syncronize the nodes
        AdminHelper.syncNodes( nodes )

        #---------------------------------------------------------
        # Ask the Cluster MBean to start the cluster
        #
        #---------------------------------------------------------

#        cluster = AdminControl.completeObjectName("type=Cluster,name="+clusterName+",*" )
#        print "cluster: Invoking start for cluster "+clusterName
#        AdminControl.invoke(cluster, "start" )

#endDef #Read properties file.

def cleanUp ( nodes ):
        global AdminControl
        global AdminConfig
        cellName = AdminControl.getCell( )

        for nodeName in nodes.split(","):
            wpid = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:WebSphere_Portal/" )
            # remove servers we don't need
            if (len(wpid) != 0):
                 print "Removing "+wpid
                 AdminConfig.remove(wpid )
            # IN WP6.1, If the node is not the Primary Node, then the server name is WebSphere_Portal_NodeName
            wpid = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:WebSphere_Portal_"+nodeName+"/" )
            if (len(wpid) != 0):
                 print "Removing "+wpid
                 AdminConfig.remove(wpid )

            server1id = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:server1/" )
            if (len(server1id) != 0):
                 print "Removing "+server1id
                 AdminConfig.remove(server1id )
        #endFor 
        AdminConfig.save( )
#endDef 

def getHostName ( nodeid ):
        global AdminConfig
        hostAttr = AdminConfig.show(nodeid, "hostName" )
        attr = hostAttr[1:len(hostAttr)-1]
        attr=attr.split()
        return attr[1]
#endDef 

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:;cellProperties:' )

propFile=optDict['properties']
cellFile=optDict['cellProperties']

cellProps = SystemUtils.getPropertyDict(cellFile)
properties = SystemUtils.getPropertyDict(propFile)

clusterName = str(properties["CLUSTER_NAME"])
nodes = str(properties["NODES"])
#endIf
transportStartPort = 0
if (properties.has_key("TRANSPORT_STARTING_POINT")):
	if (len(properties["TRANSPORT_STARTING_POINT"]) > 0):
		transportStartPort = int(properties["TRANSPORT_STARTING_POINT"])
	#endif
#endif
transportInc = 0
if (properties.has_key("TRANSPORT_NODE_INCREMENTOR")):
	if (len(properties["TRANSPORT_NODE_INCREMENTOR"]) > 0):
		transportInc = int(properties["TRANSPORT_NODE_INCREMENTOR"])
#endif
# remove quotes from nodes property
prefix = str(properties["PREFIX"])
perNode = int(properties["PERNODE"])
weight = 1
if (properties.has_key("WEIGHT")):
	if (len(properties["WEIGHT"]) > 0):
		weight = int(properties["WEIGHT"])
#endif
		
wasVersion = cellProps["WAS_VERSION"]
primaryNode = properties["PRIMARY_NODE"]

createCluster(clusterName, nodes, prefix, perNode, weight, primaryNode, transportStartPort, transportInc, wasVersion )
cleanUp(nodes )

AdminHelper.saveAndSyncCell()
