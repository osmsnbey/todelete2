"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 


	
	File name: Security.py
	
	This script is to manage was security settings.
	It is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f Security.py
		-scope <scope: cell>
		-scopename <server/cluster name>
		-properties <server xml file>
		-mode <import|execute|compare>
		-config_type <sub config element name>
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from AdminHelper import AdminHelper
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigFileWriter import GenericConfigFileWriter

LOGGER = _Logger("Security", MessageManager.RB_WEBSPHERE_WAS)


def importSecurity(scopeId, scopeType, typeName, excludedTypes, excludedAttributes, marker, xmlFile):
	LOGGER.info("Processing config type: " + typeName)
	myConfigReader = ConfigReader()
	data = []
	print "Gathering data for: " + typeName
	data.extend(myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, typeName, excludedTypes, excludedAttributes))
	#endFor
	# write XML file
	GenericConfigFileWriter.processBasicFile(xmlFile, data, marker)
#endDef

#def importSecurity(scopeId, scopeType, typeName, excludedTypes, excludedAttributes, marker):
#	importSecurity(scopeId, scopeType, typeName, excludedTypes, excludedAttributes, marker, xmlFile)
#endDef

##------------------------------------------------------------------------------
##	 scope								   = /Cell:cell/
##	 scopeType							   = cell
##	 AdminConfig.getid(scope + "Security:/") = (cells/cell|security.xml#Security_1)
##	 scopeId = AdminConfig.getid(scope)	  = cell(cells/cell|cell.xml#Cell_1)
##------------------------------------------------------------------------------
def compareSecurity(scopeId, scopeType, configType, xmlFile, excludedTypes, excludedAttributes, marker):
	# get wasConfig
	myConfigReader = ConfigReader()
	wasConfig = []
	print "Gathering data for: " + typeName
	wasConfig.extend(myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, typeName, excludedTypes, excludedAttributes))
	
	# get rafwConfig
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	
	xmlConfigReader = XMLConfigReader()
	rafwConfig = []
	filteredNodes = xmlProp.getFilteredNodeArray(typeName)
	rafwConfig.extend(xmlConfigReader.readXmlConfig(filteredNodes))
	ConfigComparor.compare(configType, wasConfig, rafwConfig)
#endDef

def executeSecurity(scopeType, xmlFile, typeName, scopeId, excludedTypes, excludedAttributes, marker, save="1"):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	
	LOGGER.info("Processing group: " + typeName)
	
	myConfigWriter = ConfigWriter()

	LOGGER.info("Processing config type: " + typeName)
	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	typeScopeId = AdminConfig.list(typeName, scopeId).split(newline)[0]
	for xmlNode in nodeArray:
		myConfigWriter.modify(typeScopeId, xmlNode, [])
	#endFor
	if save is not None:
		AdminHelper.saveAndSyncCell( )
#endDef

def augmentSecurity(scopeType, xmlFile, typeNames, scopeId, excludedTypes, marker):

	try:
		xmlProp  = XmlProperty(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		myConfigValidator = ConfigValidator()
	except:
		raise "Not able to find or parse " + xmlFile
	#endtry
	
	myConfigWriter = ConfigWriter()
	parentId = AdminConfig.list(typeName, scopeId).split(newline)[0]
	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	newXmlProp = nodeArray[0]
	nodeArray = newXmlProp.getFilteredChildrenArray("JAASConfigurationEntry")
	uniqueAttrName = "alias"
	for xmlNode in nodeArray:
		childId = myConfigValidator.validateUniqueAttr2(xmlNode,parentId,uniqueAttrName)
		if (childId is None):
			myConfigWriter.createWASObject(xmlNode, parentId)
		else:
			if (SystemUtils.updateOnAugment()):
				myConfigWriter.modify(childId, xmlNode)
			#endIf
		#endIf
	#endFor
	AdminHelper.saveAndSyncCell( )
#endDef

def export(optDict=None):
	global newline
	newline = java.lang.System.getProperty("line.separator")
	version = optDict['version']
	
	# Used for ALL config type
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg']
	
	scopeName = optDict['scopename']
	scope = optDict['wasscopetype']
	
	securityId = AdminConfig.getid(scope + "Security:/")
	
	marker = optDict['marker']
	if (marker == "applicationLoginConfiguration"):
		scopeId = AdminConfig.showAttribute(securityId, 'applicationLoginConfig')
		LOGGER.debug("Managing configuration for JAAS Application Logins under id '" + scopeId + "'")
		if (len(scopeId) == 0):
			raise ConfigWriterException("Attribute 'applicationLoginConfig' is undefined in Security configuration: " + securityId);
		#endIf
	else:
		scopeId= AdminConfig.showAttribute(securityId, 'systemLoginConfig')
		LOGGER.debug("Managing configuration for JAAS System Logins under id '" + scopeId + "'")
		if (len(scopeId) == 0):
			raise ConfigWriterException("Attribute 'systemLoginConfig' is undefined in Security configuration: " + securityId);
		#endIf
	#endIf

	mode = optDict['mode']
	xmlFile  = optDict['properties']
	typeName = optDict['type']
	scopeType = optDict['scope']
	excludedTypes=optDict['excludedtypes']
	excludedAttributes=optDict['excludedattrs']

	executeSecurity(scopeType, xmlFile,typeName, scopeId, excludedTypes, excludedAttributes, marker, None)
	
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	##################################################################################
	##
	## Main
	##
	##################################################################################
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;logintype:;scopename:;properties:;mode:;config_type:' )
	
	
	version = optDict['version']
	
	# Used for ALL config type
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg']
	
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	loginType = optDict['logintype']
	scope = AdminHelper.buildScope( optDict )
	
	cell = AdminConfig.list("Cell").split(newline)[0]
	cellName = AdminConfig.showAttribute(cell, "name")
	
	securityId = AdminConfig.getid(scope + "Security:/")
	
	if (loginType == "application"):
		# scopeId='(cells/'+cellName+'|security.xml#JAASConfiguration_1)'
		scopeId = AdminConfig.showAttribute(securityId, 'applicationLoginConfig')
		LOGGER.debug("Managing configuration for JAAS Application Logins under id '" + scopeId + "'")
		if (len(scopeId) == 0):
			raise ConfigWriterException("Attribute 'applicationLoginConfig' is undefined in Security configuration: " + securityId);
		#endIf
		marker="applicationLoginConfiguration"
	else:
		# scopeId='(cells/'+cellName+'|security.xml#JAASConfiguration_2)'
		scopeId= AdminConfig.showAttribute(securityId, 'systemLoginConfig')
		LOGGER.debug("Managing configuration for JAAS System Logins under id '" + scopeId + "'")
		if (len(scopeId) == 0):
			raise ConfigWriterException("Attribute 'systemLoginConfig' is undefined in Security configuration: " + securityId);
		#endIf
		marker="systemLoginConfiguration"
	#endIf
	
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	typeName = "JAASConfiguration"
	excludedTypes=[]
	excludedAttributes=[]
	
	if (mode == MODE_EXECUTE):
		LOGGER.info("Configuring "+loginType+" login security in scope: " + scope)
		executeSecurity(scopeType, xmlFile,typeName, scopeId, excludedTypes, excludedAttributes, marker)
	
	elif (mode == MODE_IMPORT):
		LOGGER.info("Importing "+loginType+" login security in scope: " + scope)
		importSecurity(scopeId, scopeType, typeName, excludedTypes, excludedAttributes, marker, xmlFile)
		
	elif (mode == MODE_COMPARE):
		LOGGER.info("Comparing "+loginType+" login security in scope: " + scope)
		compareSecurity(scopeId, scopeType, typeName, xmlFile, excludedTypes, excludedAttributes, marker)
	
	elif (mode == MODE_AUGMENT):
		LOGGER.info("Augmenting "+loginType+" login security in scope: " + scope)
		augmentSecurity(scopeType, xmlFile, typeName, scopeId, excludedTypes, marker)
		
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf