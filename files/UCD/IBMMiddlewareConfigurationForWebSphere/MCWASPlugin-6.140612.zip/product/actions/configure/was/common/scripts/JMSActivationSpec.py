"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: JMSDestinations.py
	
	This script is to manage jms destinations, including GenericJMSDestination, MQQueue, and MQTopic in a given scope.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f JMSDestinations.py 
		-scope <scope>: specify the scope of the jms destination factories to be created
		-scopename <scope name>: specify the scope name of the jms destination to be created 
		-properties <jms properties file>: specify the name of the jms properties file 
			to be used for the creation
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals

from com.ibm.rational.rafw.wsadmin.websphere.config import WsadminConfig
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from com.ibm.rational.rafw.wsadmin.websphere.config.xml import XmlConfigFileWriter

from ConfigReader import ConfigReader
from ConfigWriter import ConfigWriter
from ConfigFileReader import ConfigFileReader
from ConfigValidator import ConfigValidator
from java.util import ArrayList
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigFileWriter import GenericConfigFileWriter
from AdminHelper import AdminHelper

newline = java.lang.System.getProperty("line.separator")

class dsMediator:
	
	def createJ2CWASObject(self, xmlNode, parentId, excludedNodeNames = ['builtin']):
		type = xmlNode.getNodeNameFixed()
		if (xmlNode.hasAttr(Globals.RAFW_TYPE) and xmlNode.getAttrValue(Globals.RAFW_TYPE) == Globals.RAFW_TYPE_REFERENCE):
			##print "References will not be created for xmlNode: " + type
			logger.log("CRWWA1126I",[type])
			return
		#endIf
		if (type not in excludedNodeNames):
			print "createJ2CWASObject: " + type + ", " + parentId
	
			# we need to get the activationSpec Id from the config to be able to
			# create the Activation Specs
	 		for xmlChild in xmlNode.getChildrenArray():
	 			if(xmlChild.getNodeNameFixed() == "ActivationSpec"):
					activationSpecId=AdminConfig.list("ActivationSpec", parentId).split(newline)[0]
					## set it back on the xml node
					xmlNode.setAttrValue("activationSpec", activationSpecId)
				#endIf
			#endFor
			
			attrs = xmlNode.buildNodeAttrsAsJyString(excludedNodeNames)
			if ( xmlNode.hasAttr(Globals.WAS_KEY_ATTR_NAME) ):
				## case where we need a fourth parameter
				wasAttrName = xmlNode.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
				logger.trace("Creating type " + str(type) + " with wasAttrName " + str(wasAttrName) + " and attrs " + str(attrs))
				newId = AdminConfig.create(type, parentId, attrs, wasAttrName)
			else:
				logger.trace("Creating type " + str(type) + " with attrs " + str(attrs))
				newId = AdminConfig.create(type, parentId, attrs)
			#endIf
			if (newId == None):
				##print "Error: Unable to create type: " + type + " under parent: " + parentId
				logger.log("CRWWA1127E",[type,parentId])
			else:
				#Child J2EEResourceProperty objects are created by default, remove them or duplicates
				#will be created
				if( type == "J2CActivationSpec"):
					##print "Unsetting attribute resourceProperties for config id " + str(newId) + " to avoid duplicates"
					logger.log("CRWWA1128I",[str(newId)])
					AdminConfig.modify(newId, "[[resourceProperties '']]")
				#endIf
				for xmlChild in xmlNode.getChildrenArray():
					if (xmlChild.getNodeNameFixed() not in excludedNodeNames):
						self.createJ2CWASObject(xmlChild, newId)
					#endIf
				#endFor
			#endIf
		#endIf
		return newId
	#endDef

	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			self.createConfigType(scopeId, scopeType, xmlProp, typeName)
		#endFor
		
	#endDef
	
	def createConfigType(self, scopeId, scopeType, xmlProp, typeName):
		myConfigWriter = ConfigWriter()
		myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
		
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			parentId = self.getParentId(scope, xmlNode)
			excludedNodeNames = ['builtin', 'J2CResourceAdapter']
			self.createJ2CWASObject(xmlNode, parentId, excludedNodeNames)
		#endFor
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeId = AdminConfig.getid( scope )
		myConfigWriter = ConfigWriter();	
		configValidator = ConfigValidator()
		for typeName in typeNames:
			nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				excludedNodeNames = ['builtin', 'J2CResourceAdapter']
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					parentId = self.getParentId(scope, xmlNode)
					##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					logger.log("CRWWA1129I",[typeName,xmlNode.getAttrValue("jndiName")])
					self.createJ2CWASObject(xmlNode, parentId, excludedNodeNames)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode, excludedNodeNames)
					else:
						##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
						logger.log("CRWWA1130W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endFor
		#endFor
	#endDef
	
	def getParentId(self, scope, xmlNode):
		resourceAdapter = xmlNode.getXmlNode().getElementsByTagName("J2CResourceAdapter").item(0)
		if resourceAdapter is None:
			parentName = 'SIB JMS Resource Adapter'
			
			##print "WARNING"
			logger.log("CRWWA1131W")
			##print "No Resource Adapter specified for this Activation Specification object: " + str(xmlNode.getAttrValue('name'))
			logger.log("CRWWA1132W",[str(xmlNode.getAttrValue('name'))])
			##print "Using default: " + parentName
			logger.log("CRWWA1133I",[parentName])
		else:
			parentName = resourceAdapter.getAttribute('name')
			
		#TODO: refactor to use AdminHelper.findProviderId
		parentId = AdminHelper.findProviderIdByName(scope, 'J2CResourceAdapter', parentName)[0]
		return parentId
	#endDef
	
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
		data = []
		scopeId = AdminConfig.getid(scope)
		myConfigReader = ConfigReader()
	
		if (len(scopeId) == 0):
			#print "ERROR: unable to find parent scope: " + scope
			logger.log("CRWWA1135E",[scope])
			#print "Cannot read config data."
			logger.log("CRWWA1136E")
			return data
		
		resourceAdapters = AdminConfig.list("J2CResourceAdapter", scopeId).split(newline)
		for resourceAdapter in resourceAdapters:		
			if (len(resourceAdapter) > 0):
				for objId in AdminConfig.list(configType, resourceAdapter).split(newline):
					objId = objId.strip()
					myConfigReader.importedIds = []
					## if anything found and is in scope
					if (len(objId) > 0 and (AdminHelper.isInScope(scopeType, objId))):
						toImport = 1
						## never show the top level configuration element in references
						if (excludedTypes != []):
							match = "no"
							for excludedType in excludedTypes:
								if (SystemUtils.regexp(excludedType, objId) == 1):
									toImport = 0
									break
								#endIf
							#endFor
						#endIf
						
						if toImport:
							#print "Importing " + objId
							logger.log("CRWWA1136I",[objId])
							myConfigReader.importedIds.append(objId)
							if (configType == "J2CActivationSpec"):
								dataTemp = myConfigReader.showAll(objId)
								resourceAdapterNode = {}
								resourceAdapterNode['id'] = 'J2CResourceAdapter'
								resourceAdapterNode['attrs'] = {}
								resourceAdapterNode['attrs'][Globals.RAFW_TYPE] = 'parentName'
								resourceAdapterNode['attrs']['name'] = AdminConfig.showAttribute(resourceAdapter, 'name')
								resourceAdapterNode['children'] = []
								dataTemp['children'].append(resourceAdapterNode)
								data.append(dataTemp)
							else:
								data.append(myConfigReader.showAll(objId))
							#endIf
						#endIf
					#endIf
				#endFor
			#endIf
		#endFor
		return data
	#endDef

#endClass

def export(optDict=None):
	global scope
	thisMediator = dsMediator()
	# get scope
	scope = optDict['wasscopetype']
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	marker = optDict['marker']
	
	mode = optDict['mode']
	typeNames = [optDict['type']]
	thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
#enddef

logger = _Logger("JMSActivationSpec", MessageManager.RB_WEBSPHERE_WAS)

if ( str(sys.argv).find("scopename") != -1):
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )
	
	thisMediator = dsMediator()
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	marker = "JMSActivationSpec"
	
	mode = optDict['mode']
	typeNames = ["J2CActivationSpec"]
	if (mode == MODE_EXECUTE):
		##print "Creating JMS Activation Specifications in scope: " + scope
		logger.log("CRWWA1134I",[scope])
		thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		#print "Augmenting JMS Activation Specifications in scope: " + scope
		logger.log("CRWWA2103I",[scope])
		thisMediator.augmentConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_IMPORT):
		##print "Importing JMS Activation Specifications in scope: " + scope
		logger.log("CRWWA2104I",[scope])
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, ['J2CResourceAdapter'], thisMediator )
	
	elif (mode == MODE_COMPARE):
		##print "Comparing JMS Activation Specifications in RAFW and WAS in scope: " + scope
		logger.log("CRWWA2105I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, ['J2CResourceAdapter'], thisMediator )
	else:
		##print "Unsupported MODE supplied: " + mode
		logger.log("CRWWA2011I",[mode])
	#endIf
#endIf