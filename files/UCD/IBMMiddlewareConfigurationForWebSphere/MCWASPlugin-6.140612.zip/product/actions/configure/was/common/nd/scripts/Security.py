"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: Security.py
	
	This script is to manage was security settings.
	It is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f Security.py
		-scope <scope: cell>
		-scopename <server/cluster name>
		-properties <server xml file>
		-mode <import|execute|compare>
		-config_type <sub config element name>
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigValidator import ConfigValidator
from ConfigWriter import MissingReferenceIdHandler

LOGGER = _Logger("Security", MessageManager.RB_WEBSPHERE_WAS)

class SecurityConfigWriter(ConfigWriter):
	"""
	SSLConfig requires an composite key that is both the alias and the management scope reference id
	This class extends ConfigWriter to provide support for this scenario.
	"""
	
	def __init__(self):
		ConfigWriter.__init__(self)
		self.LOGGER = _Logger("SecurityConfigWriter", MessageManager.RB_WEBSPHERE_WAS)
		# a cache of previously discovered mgmt scope ids
		self.mgmtScopeIds = {}
	#endDef
	
	def computeXmlKey(self, xmlNode):
		self.LOGGER.traceEnter(xmlNode)
		key = ConfigWriter.computeXmlKey(self, xmlNode)
		## SSLConfig has to be handled differently because its key is the 
		## composite of alias and a child managementScope reference
		
		if (xmlNode.getNodeNameFixed() == "SSLConfig"):
			mgmtScopeNodes = xmlNode.getFilteredChildrenArray("ManagementScope")
			if (len(mgmtScopeNodes) == 1):
				mgmtScopeNode = mgmtScopeNodes[0]
				mgKey = ConfigWriter.computeXmlKey(self, mgmtScopeNode)
				self.LOGGER.debug("Adding extra info to composite key: " + str(mgKey))
				key = key + "." + mgKey
				## need error handling/logging
			else:
				self.LOGGER.debug("For XML node type SSLConfig there was not 1 ManagmentScope child. Found: " + str(mgmtScopeNodes))
				self.LOGGER.log("CRWWA0123I", [key])
			#endIf
		#endIf
		self.LOGGER.traceExit(key)
		return key
	#endDef
	
	def computeWasKey(self, obj):
		self.LOGGER.traceEnter(obj)
		key = ConfigWriter.computeWasKey(self, obj)
		wasType = self.configReader.getWASType(obj)
		if (wasType == "SSLConfig" and self.configReader.hasAttr(obj, "managementScope")):
			## SSLConfig has to be handled differently because its key is the 
			## composite of alias and a child managementScope reference
			mgScopeId = AdminConfig.showAttribute(obj, "managementScope")
			## if managementScope attribute isn't set we cannot use it with the key (and neither can WAS)
			if (mgScopeId != None and len(mgScopeId) > 0):
				mgKey = ConfigWriter.computeWasKey(self, mgScopeId)
				key = key + "." + mgKey
			else:
				# SSLConfig object does not have a value for the managementScope attribute: 
				# the key used to compare this object against XML configuration will be {1}
				self.LOGGER.log("CRWWA0122W", [obj, key])
			#endIf
		#endIf
		self.LOGGER.traceExit(key)
		return key
	#endDef
	
	def getReferenceId(self, xmlNode, scopeId = None):
		self.LOGGER.traceEnter(xmlNode)
		type = xmlNode.getNodeNameFixed()
		referenceId = None
		if (self.initialScopeId is not None):
			if (type == "KeyStore"):
				mgmtScopeId = self._getMgmtScopeId(xmlNode, ["SecureSocketLayer", "SSLConfig"])
				referenceId = self._findByMgmtScope(xmlNode, mgmtScopeId)
			elif (type == "SSLConfig"):
				mgmtScopeId = self._getMgmtScopeId(xmlNode, ["SSLConfigGroup"])
				referenceId = self._findByMgmtScope(xmlNode, mgmtScopeId)
			#endIf
		#endIf
		if (referenceId is None):
			## couldn't find it or didn't want to, use default logic
			referenceId = ConfigWriter.getReferenceId(self, xmlNode)

		#endIf
		self.LOGGER.traceExit(referenceId)
		return referenceId
	#endDef
	
	def handleReferenceSearchError(self, xmlNode, wasKey, parentId):
		wasType = xmlNode.getNodeNameFixed() 
		## nodes of type TrustManager and KeyManager are not unique by name 
		## and name is the only key they go by (and management scopes don't have to match, so we cannot
		## filter by the management scope either
		if (wasType == "TrustManager" or wasType == "KeyManager"):
			## the default logic failed, log what we find and display an error, if we just choose one, we'll break the cell security
			discoveredIds = self.configReader.findObjectIds(xmlNode)
			#self.LOGGER.log("CRWWA0124W", [wasType, discoveredIds, str(xmlNode)])
			raise Exception(MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0124W", [wasType, discoveredIds, str(xmlNode)]))
			#return 1
		#endIf
		ConfigWriter.handleReferenceSearchError(self, xmlNode, wasKey, parentId)
	#endDef
	
	def _getMgmtScopeId(self, xmlNode, pathToNode):
		"""
		Returns the management scope object id which is related to this xmlNode 
		by a parent hierarchy relationship
		
		xmlNode is the xml node we are looking for a reference id on.
		pathToNode is a list of types in the hierarchy toward the management scope 
		xml node in question
		
		For example, from KeyStore you go up 1 parent to SecureSocketLayer and up 
		another parent to SSLConfig 
		From SSLConfig you can find the ManagementScope that we are looking for.  
		
		If the path specified does not lead to the correct parent types or a ManagementScope 
		node doesn't exist in the DOM tree at that path or if the management scope id cannot 
		be retrieved from WAS config, this method returns None
		"""
		self.LOGGER.traceEnter([xmlNode, pathToNode])
		containerNode = None
		childNode = xmlNode
		for type in pathToNode:
			self.LOGGER.trace("Looking for parent of type:" + type)
			node = childNode.getParent()
			if (node is not None and node.getNodeNameFixed() == type):
				self.LOGGER.trace("Found parent of type:" + type)
				containerNode = node
				childNode = node
			else:
				self.LOGGER.trace("Unable to find parent of type:" + type)
				self.LOGGER.trace("Reference objects will be located independently of management scope.")
				## we didn't find the node at the path we expected, no mgmt scope id will be returned
				containerNode = None
			#endIf
		#endFor
		## if we could find the containerNode at the supplied path, we can continue
		if (containerNode is not None):
			mgmtScopeNodes = containerNode.getFilteredChildrenArray("ManagementScope")
			if (len(mgmtScopeNodes) == 1):
				mgmtScopeNode = mgmtScopeNodes[0]
				mgmtScopeKey = self.computeXmlKey(mgmtScopeNode)
				if (self.mgmtScopeIds.has_key(mgmtScopeKey)):
					mgmtScopeId = self.mgmtScopeIds[mgmtScopeKey]
					self.LOGGER.traceExit(mgmtScopeId)
					return mgmtScopeId
				else:
					xmlMgmtScopeIds = self.configReader.findObjectIds(mgmtScopeNode, self.initialScopeId)
					if (len(xmlMgmtScopeIds) == 1):
						# if we found more than 1, we cannot continue
						mgmtScopeId = xmlMgmtScopeIds[0]
						self.LOGGER.debug("Discovered ManagementScope id for key: " + mgmtScopeKey + " with id: " + mgmtScopeId)
						## cache the id
						self.mgmtScopeIds[mgmtScopeKey] = mgmtScopeId
						self.LOGGER.traceExit(mgmtScopeId)
						return mgmtScopeId
					else:
						self.LOGGER.trace("one unique ManagementScope id could not be found in configuration.  " 
										+ "Looking for: " + str(mgmtScopeNode) + " under sope: " + self.initialScopeId)
						self.LOGGER.trace("Found: " + str(xmlMgmtScopeIds))
					#endIf
				#endIf
			else:
				self.LOGGER.trace("Top level object does not have one XML child of type: ManagementScope")
			#endIf
		#endIf
		self.LOGGER.traceExit(None)
		return None
	#endDef
							
	def _findByMgmtScope(self, xmlNode, mgmtScopeId):
		"""
		Some config types are not unique by the values of their key attributes alone.  
		The manaagement scope also plays a role in finding reference object ids in these cases.
		
		This method locates object ids in the WAS config which match attributes
		in the supplied xmlNode.  For each discovered id, this method identifies the managementScope
		id which matches the mgmtScopeId supplied.  
		
		If a match on both the supplied xml attributes and the associated management scope id
		is found, the discovered object id is returned.  
		
		This method returns None if no match can be found.
		"""
		self.LOGGER.traceEnter([xmlNode, mgmtScopeId])
		## KeyStore and SSLConfig can be unique to ManagementScopes
		## find the KeyStores under Security, 
		## if we find more than 1, pair them by management scope
		if (mgmtScopeId is not None):
			discoveredIds = self.configReader.findObjectIds(xmlNode, self.initialScopeId)
			if (len(discoveredIds) > 1):
				self.LOGGER.debug("Found more than 1 match for xmlNode: " + str(xmlNode))
				self.LOGGER.debug("   found the following matches: " + str(discoveredIds))
				for dId in discoveredIds:
					if (self.configReader.hasAttr(dId, "managementScope")):
						mgmtScope = AdminConfig.showAttribute(dId, "managementScope")
						self.LOGGER.debug("managementScope id is:" + str(mgmtScope) 
										+ " for object: " + str(dId))
						if (mgmtScopeId == mgmtScope):
							self.LOGGER.traceExit(dId)
							return dId
						#endIf
					#endIf
				#endFor
			elif (len(discoveredIds) == 1):
				referenceId = discoveredIds[0]
				self.LOGGER.traceExit(referenceId)
				return referenceId
			#endIf
		#endIf
		self.LOGGER.traceExit(None)
		return None
	#endDef
#endClass

class SecurityReferenceHandler(MissingReferenceIdHandler):
	"""
		Defines a handler which is used to resolve cases where a 
		reference id cannot be found.
	
		When the reference id is not found, the method:
		handleMissingReferenceId(xmlNode) is called.  This method can return the 
		object id that should be used for the reference or return None to indicate 
		that the default behavior should be used.
		
		@see: ConfigWriter._updateWASReferenceByKey()
	"""
	
	def __init__(self, securityId):
		self.securityId = securityId
	#endDef
	
	"""
	Can return None to indicate that the reference cannot be created - 
	this results in a unified exception/Error in the ConfigWriter
	"""	
	def handleMissingReferenceId(self, xmlNode):
		type = xmlNode.getNodeNameFixed()
		if (type == "ManagementScope"):
			print "Info: Creating reference object: " + type + " under parent: " + self.securityId
			attrs = xmlNode.buildNodeAttrsAsJyString([])
			LOGGER.debug("AdminConfig.create('"+type+"','"+ self.securityId+"',"+ attrs + "')")
			newId = AdminConfig.create(type, self.securityId, attrs)
			if (newId == None or len(newId) == 0):
				print "Error: Unable to create type: " + type + " under parent: " + self.securityId
				## in case it was "", make it None so the rest of calling method can handle correctly
				newId = None
			#endIf
			return newId
		#endIf
		return None
	#endDef
#endClass

#	security_item = AdminConfig.list("Security" )
#	LTPA = AdminConfig.list("LTPA" )
#	SSO = AdminConfig.list("SingleSignon" )
#	userRegistry = AdminConfig.list("UserRegistry" )
#	ldapUserRegistryId = AdminConfig.list("LDAPUserRegistry" )
#	cusUserRegistry = AdminConfig.list("CustomUserRegistry" )
#	SSL = AdminConfig.list("SSLConfig" )
#	cryptoHardwareToken = AdminConfig.list("CryptoHardwareToken" )
#	ldapSearchFilter = AdminConfig.list("LDAPSearchFilter" )


"""
     scope                                   = /Cell:cell/
     scopeType                               = cell
     AdminConfig.getid(scope + "Security:/") = (cells/cell|security.xml#Security_1)
     scopeId = AdminConfig.getid(scope)      = cell(cells/cell|cell.xml#Cell_1)
"""
def importSecurity():
	global scope, scopeType, configType, xmlFile

	if (configType == "ALL"):
		for configType_ in configTypes:
			_evaluteParams_(configType_)
			_import_()
	else:
		_evaluteParams_(configType)
		_import_()
	#endIf
		
#endDef

def _import_():
	global scopeType, xmlFile, typeNames, scopeId, excludedAttributes, currentConfigType 
	data = _readConfigData_(1)

	# write XML file
	GenericConfigFileWriter.processBasicFile(xmlFile, data, currentConfigType)
#def

"""
	Read the configuration data.
	
	if the configType contains SECURITY. then the config id will be 
	updated from the WAS type to the configType
	if includeDotsInConfigType is true then the config id will be the
	full configType (SECURITY.foo) else the config id will be
	updated to be the last portion after the dots (foo)
"""
def _readConfigData_(includeDotsInConfigType):
	LOGGER.info("Processing config type: " + currentConfigType)
	myConfigReader = ConfigReader()
	data = []
	for typeName in typeNames:
		print "Gathering data for: " + typeName
		
		# SECURITY is used to denote that the configuration type is accessible 
		# as an attribute of the global security configuration
		if (typeName.find('SECURITY.') >= 0):
			## save original config type for later usage in writing the xml
			rafwTypeName = typeName
			typeName = typeName.split('.')[1]
			objId = AdminConfig.showAttribute(scopeId, typeName)
			configData = myConfigReader.showAll(objId)
			if (includeDotsInConfigType):
				configData['id'] = rafwTypeName
			else:
				configData['id'] = typeName
			#endIf
			data.append(configData)
		else:
			myConfigReader.setExcludedAttributes(excludedAttributes)
			data.extend(myConfigReader.readConfigDataUsingParentId(scopeId, scopeType, typeName))
		#endIf
		if (typeName == "Security"):
			## strip out the extra attributes on reference types under Security
			myConfigReader.stripElement(data, "activeUserRegistry", None,
						[Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
			myConfigReader.stripElement(data, "activeAuthMechanism", "LTPA", 
						[Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
			myConfigReader.stripElement(data, "defaultSSLSettings", "SSLConfig", 
						["alias", Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		#endIf
	#endFor
	return data
#endDef

"""
     scope                                   = /Cell:cell/
     scopeType                               = cell
     AdminConfig.getid(scope + "Security:/") = (cells/cell|security.xml#Security_1)
     scopeId = AdminConfig.getid(scope)      = cell(cells/cell|cell.xml#Cell_1)
"""
def compareSecurity():
	global scope, scopeType, configType, xmlFile
	
	if (configType == "ALL"):
		for configType_ in configTypes:
			_evaluteParams_(configType_)
			_compare_()
		#endFor
	else:
		_evaluteParams_(configType)
		_compare_()
	#endIf
#endDef

def _compare_():
	global scope, scopeType, configType, xmlFile
		
	# get wasConfig
	wasConfig = _readConfigData_(0)
	
	# get rafwConfig
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(currentConfigType)
	xmlConfigReader = XMLConfigReader()
	rafwConfig = []
	for typeName in typeNames:
		filteredNodes = xmlProp.getFilteredNodeArray(typeName)
		rafwConfig.extend(xmlConfigReader.readXmlConfig(filteredNodes))
	#endFor
	ConfigComparor.compare(configType, wasConfig, rafwConfig)
#endDef

def executeSecurity(save = "1", optDict = None):
	global scope, scopeType, xmlFile, xmlProp, ltpa, localOSUserRegistry, ldapUserRegistry, customUserRegistry, xmlPropParent

	xmlPropParent = ConfigFileReader.openXmlConfig(xmlFile)
	
#	security_item = AdminConfig.list("Security" )
	
#	SSO = AdminConfig.list("SingleSignon" )
#	SSL = AdminConfig.list("SSLConfig" )
#	cryptoHardwareToken = AdminConfig.list("CryptoHardwareToken" )
#	ldapSearchFilter = AdminConfig.list("LDAPSearchFilter" )
	
	ltpa = AdminConfig.list("LTPA")
	localOSUserRegistry = AdminConfig.list("LocalOSUserRegistry")
	ldapUserRegistry = AdminConfig.list("LDAPUserRegistry")
	customUserRegistry = AdminConfig.list("CustomUserRegistry")
	
	if (configType == "ALL"):
		for configType_ in configTypes:
			_evaluteParams_(configType_)
			_execute_()
	else:
		if save is None:
			_evalParamsQuickExport(configType, optDict)
		else:
			_evaluteParams_(configType)
		#endIf
		_execute_()
	#endIf
	
	# save config and Syncronize the Cell
	if (save is not None):
		AdminHelper.saveAndSyncCell( )
	
#endDef

def _execute_():
	global scopeType, xmlPropParent, typeNames, scopeId, excludedAttributes
	
	xmlProp = xmlPropParent.findRAFWContainerNode(currentConfigType)
	
	LOGGER.info("Processing group: " + currentConfigType)
	
	myConfigWriter = SecurityConfigWriter()
	
	# set custom reference id handler
	serverId = AdminConfig.getid(scope + "Security:/")
	myConfigWriter.setMissingReferenceIdHander(SecurityReferenceHandler(serverId))
	
	processedXmlNodes = []
	processedSecurityNodeByParent = {}

	for typeName in typeNames:
		LOGGER.info("Processing config type: " + typeName + " under group " + currentConfigType)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		if (typeName == 'SSLConfig'):
			## SSLConfig objects have to be created under the attribute 'repertoire'
			## so we set the attribute name during create, the wasKey won't be in the imported data set.
			for xmlNode in nodeArray:
				xmlNode.setAttrValue(Globals.WAS_KEY_ATTR_NAME, 'repertoire')
			#endFor
		#endIf
		if (typeName == 'Security'):
			# fix up any data in the old format
			if (len(nodeArray) > 0):
				securityNode = nodeArray[0]
				_mkDataBackwardsCompat(securityNode, "activeAuthMechanism")
				_mkDataBackwardsCompat(securityNode, "activeUserRegistry")
				_mkDataBackwardsCompat(securityNode, "adminPreferredAuthMech")
				_mkDataBackwardsCompat(securityNode, "defaultSSLSettings")
			#endIf
		#endIf
		if (typeName.find('SECURITY.') >= 0):
			attrName = typeName.split('.')[1]
			objId = AdminConfig.showAttribute(scopeId, attrName)
			if (len(nodeArray) != 1):
				msg = "configuration elements whose parent type is a Security attribute must have 1 XML configuration stanza"
				LOGGER.error(msg)
				raise ConfigWriterException(msg)
			else:
				myConfigWriter.modify(objId, nodeArray[0], excludedAttributes)
				processedSecurityNodeByParent[objId] = nodeArray
			#endIf
		else:
			optionalTypes = ["SSLConfig", "SSLConfigGroup", "SSLInboundChannel", "SSLOutboundChannel", 
								"TrustAssociation", "CustomUserRegistry"]
			if (len(nodeArray) == 0):
				## empty xml files supplied to security will wack most security configuration
				## protect the user from breaking everything...
				## only non-singletons can be entirely removed
				if (typeName not in optionalTypes):
					msg = ("0 elements for type '" + typeName + "' found in the data file.  " +
						"You must supply configuration for this type before running this action.")
					LOGGER.error(msg)
					raise ConfigWriterException(msg)
				#endIf
			#endIf
			myConfigWriter.updateWASObject(nodeArray, scopeId, typeName, excludedAttributes)
			processedXmlNodes.extend(nodeArray)
		#endIf
	#endFor
	myConfigWriter.updateWASReferenceAttributes(processedXmlNodes, scopeId)
	for objId in processedSecurityNodeByParent.keys():
		myConfigWriter.updateWASReferenceAttributes(processedSecurityNodeByParent[objId], scopeId, objId)
	#endFor
	
#endDef

"""
Augments security settings for the WAS cell.  

This action currently supports the following types:

TrustAssociation

"""
def augmentSecurity():
	global scope, scopeType, configType, xmlFile, xmlProp, ltpa, localOSUserRegistry, ldapUserRegistry, customUserRegistry

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	
	ltpa = AdminConfig.list("LTPA")
	localOSUserRegistry = AdminConfig.list("LocalOSUserRegistry")
	ldapUserRegistry = AdminConfig.list("LDAPUserRegistry")
	customUserRegistry = AdminConfig.list("CustomUserRegistry")
	
	if (configType == "ALL"):
		LOGGER.warn("configType=ALL is not supported")
	else:
		_evaluteParams_(configType)
		_augment()
	#endIf
		
	# save config and Syncronize the Cell
	AdminHelper.saveAndSyncCell( )
	
#endDef

"""

"""
def _augment():
	global scopeType, xmlProp, typeNames, scopeId 
	xmlProp = xmlProp.findRAFWContainerNode(currentConfigType)
	
	LOGGER.info("Processing group: " + currentConfigType)
	
	myConfigWriter = SecurityConfigWriter()
	configValidator = ConfigValidator()
	
	# set custom reference id handler
	serverId = AdminConfig.getid(scope + "Security:/")
	myConfigWriter.setMissingReferenceIdHander(SecurityReferenceHandler(serverId))
	
	processedXmlNodes = []

	for typeName in typeNames:
		LOGGER.info("Processing config type: " + typeName + " under group " + currentConfigType)
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			
			if (typeName == "TrustAssociation"):
				# TAI is a singleton configuration type, augment this as the parent
				typeScopeId = AdminConfig.list(typeName, scopeId).split(newline)[0]
				taiXmlNodes = xmlNode.getFilteredChildrenArray('TAInterceptor')
				uniqueAttrName = "interceptorClassName"
				for taiXmlNode in taiXmlNodes:
					childId = configValidator.validateUniqueAttr2(taiXmlNode, typeScopeId, uniqueAttrName)
					if (childId is None):
						print "Creating new TAInterceptor with interceptorClassName=" + taiXmlNode.getAttrValue(uniqueAttrName)
						myConfigWriter.createWASObject(taiXmlNode, typeScopeId)
						if (processedXmlNodes.count(xmlNode) == 0):
							processedXmlNodes.append(xmlNode)
						#endIf
					else:
						if (SystemUtils.updateOnAugment()):
							myConfigWriter.modify(childId, taiXmlNode)
							if (processedXmlNodes.count(xmlNode) == 0):
								processedXmlNodes.append(xmlNode)
							#endIf
						#endIf
					#endIf
				#endFor
			elif (typeName == "SSLConfig"):
				## SSLConfig objects have to be created under the attribute 'repertoire'
				## so we set the attribute name during create, the wasKey won't be in the imported data set.
				xmlNode.setAttrValue(Globals.WAS_KEY_ATTR_NAME, 'repertoire')
				uniqueAttrName = "alias"
				childId = configValidator.validateUniqueAttr2(xmlNode, scopeId, uniqueAttrName)
				if (childId is None):
					print "Creating new SSLConfig with alias=" + xmlNode.getAttrValue(uniqueAttrName)
					myConfigWriter.createWASObject(xmlNode, scopeId)
					processedXmlNodes.append(xmlNode)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode)
						processedXmlNodes.append(xmlNode)
					#endIf
				#endIf
			elif (typeName == "SSLConfigGroup"):
				uniqueAttrNames = ["direction", "name"]
				childId = configValidator.validateUniqueAttrs2(xmlNode, scopeId, uniqueAttrNames)
				if (childId is None):
					print "Creating new SSLConfigGroup with name=" + xmlNode.getAttrValue("name")
					myConfigWriter.createWASObject(xmlNode, scopeId)
					processedXmlNodes.append(xmlNode)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode)
						processedXmlNodes.append(xmlNode)
					#endIf
				#endIf
			#endIf -- typeName is known type
		#endFor -- xmlNodes
	#endFor -- typeNames
	## process the references
	myConfigWriter.updateWASReferenceAttributes(processedXmlNodes, scopeId)
#endDef

def _evalParamsQuickExport(configType, optDict):
	global typeNames, excludedAttributes, scopeId, currentConfigType, version
	
	typeNames, excludedAttributes = [], []
	scopeId = AdminConfig.getid(scope + "Security:/")
	currentConfigType = optDict['marker']
	
	typeNames = [optDict['type']]
	excludedAttributes = optDict['excludedattrs']
	if configType == "Security":
		scopeId = AdminConfig.getid(scope)
	#endIf
#endDef

def _evaluteParams_(configType):
	global typeNames, excludedAttributes, scopeId, currentConfigType, version
	
	typeNames, excludedAttributes = [], []
	scopeId = AdminConfig.getid(scope + "Security:/")
	currentConfigType = configType
	
	if configType == "GlobalSecurity":
		typeNames = ['Security']
		excludedAttributes = ['Security.wsPasswordEncryptions', 'Security.wsPasswordLocators', 'Security.wsPasswords', 
							'Security.repertoire', 'Security.keySetGroups', 'Security.keyStores', 
							'Security.wsNotifications', 'Security.keyManagers', 
							'Security.sslConfigGroups', 'Security.trustManagers', 'Security.systemLoginConfig', 
							'Security.CSI', 'Security.IBM', 'Security.wsCertificateExpirationMonitor', 'Security.keySets', 
							'Security.authConfig', 'Security.userRegistries', 'Security.authMechanisms', 
							'Security.managementScopes', 'Security.wsSchedules', 'Security.applicationLoginConfig', 
							'Security.certificates', 'Security.authDataEntries']
		scopeId = AdminConfig.getid(scope)
		
	elif configType == "SSL":
		if (version == "60"):
			typeNames = ['SSLConfig', 'SSLInboundChannel', 'SSLOutboundChannel']
		else:
			typeNames = ['SSLConfig', 'SSLConfigGroup', 'SSLInboundChannel', 'SSLOutboundChannel']
		
	elif configType == "SSO":
		typeNames = ['SingleSignon']
		
	elif configType == "TAI":
		typeNames = ['TrustAssociation']
		
	elif configType == "LocalOS":
		typeNames = ['LocalOSUserRegistry']
		
	elif configType == "LDAP":
		typeNames = ['LDAPUserRegistry']

	elif configType == "CustomReg":
		typeNames = ['CustomUserRegistry']
	elif configType == "FederatedRepository":
		typeNames = ['WIMUserRegistry']
		excludedAttributes = ['WIMUserRegistry.registryClassName']
	
	elif configType == "SECURITY.applicationLoginConfig":
		typeNames = ['SECURITY.applicationLoginConfig']
		
	elif configType == "SECURITY.systemLoginConfig":
		typeNames = ['SECURITY.systemLoginConfig']
		
	else:
		raise "Unsupported CONFIG TYPE supplied: " + configType
		
	"""	not covered at the moment
	
	elif configType == "JAASConfiguration":
		typeNames = ['JAASConfiguration']
		# TODO handle cases where JAASConfigurationEntry.loginModules="" - execute mode fails if this attribute is empty
		
	elif configType == "CSIia":
		typeNames = ['MessageLayer', 'TransportLayer', 'IdentityAssertionLayer', 'SecurityProtocolConfig']
		
	elif configType == "CSIoa":
		typeNames = ['MessageLayer', 'TransportLayer', 'IdentityAssertionLayer', 'SecurityProtocolConfig']
		
	elif configType == "CSIic":
		# parents 'CSIv2 Inbound Configuration' < 'IIOPSecurityProtocol'
		typeNames = ['TransportLayer', 'SecurityProtocolConfig', 'serverAuthentication']
		
	elif configType == "CSIoc":
		# parents 'CSIv2 Outbound Configuration' < 'IIOPSecurityProtocol' 
		typeNames = ['TransportLayer', 'SecurityProtocolConfig', 'serverAuthentication']
		
	elif configType == "SASic":
		# parents 'SecureAssociationService' < 'IIOPSecurityProtocol'
		typeNames = ['TransportLayer', 'serverAuthentication']
		
	elif configType == "SASoc":
		# parents 'SecureAssociationService' < 'IIOPSecurityProtocol'
		typeNames = ['TransportLayer', 'serverAuthentication']
		
	else:
		raise "Unsupported CONFIG TYPE supplied: " + configType
	"""
#endDef

"""
 converts reference attributes as follows:
 activeAuthMechanism="#ref_obj_type#LTPA"
 to
 activeAuthMechanism="(cells/cell|security.xml#LTPA_1)"
"""
def _mkDataBackwardsCompat(xmlNode, attr):
	RAFW_REFERENCE_OBJ_TYPE = "#ref_obj_type#"
	if(xmlNode.hasAttr(attr)):
		## if this node is a reference to an object of the given type...
		## for example: map
		## activeAuthMechanism="#ref_obj_type#LTPA"
		## to
		## activeAuthMechanism="(cells/cell|security.xml#LTPA_1)"
		thisNodeValue = xmlNode.getAttrValue(attr)
		if (thisNodeValue.find(RAFW_REFERENCE_OBJ_TYPE) == 0):
			objType = thisNodeValue.split(RAFW_REFERENCE_OBJ_TYPE)[1]
			objIds = AdminConfig.list(objType).split(newline)
			if (len(objIds) > 0):
				thisNodeValue = objIds[0]
				xmlNode.setAttrValue(attr, thisNodeValue)
			else:
				LOGGER.error("Unable to find matching reference id for attribute: " 
								+ attr + " with value: " + thisNodeValue)
			#endIf
		#endIf
	#endIf
#endDef

def export(optDict=None):
	global version, scopeName, scopeType, scope, mode, xmlFile, configType, configTypes
	
	version = optDict['version']
	
	# Used for ALL config type
	#configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TA', 'LocalOS', 'LDAP', 'AdvancedLDAP', 'CustomReg', 'J2CAuthData', 'JAASAppLogin', 'CSIia', 'CSIoa', 'CSIic', 'CSIoc', 'SASic', 'SASoc']
	#configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg', 'J2CAuthData', 'JAASAppLogin']
	## If we get a request for it, add 'SECURITY.applicationLoginConfig', 'SECURITY.systemLoginConfig' 
	## to the list below.
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg'] 
	
	
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	scope = optDict['wasscopetype']
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['type']
	#passing None so we can skip the save of security config
	executeSecurity(None, optDict)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	##################################################################################
	##
	## Main
	##
	##################################################################################
	
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'version:;scope:;scopename:;properties:;mode:;config_type:' )
	
	global version, scopeName, scopeType, scope, mode, xmlFile, configType, configTypes
	
	version = optDict['version']
	
	# Used for ALL config type
	#configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TA', 'LocalOS', 'LDAP', 'AdvancedLDAP', 'CustomReg', 'J2CAuthData', 'JAASAppLogin', 'CSIia', 'CSIoa', 'CSIic', 'CSIoc', 'SASic', 'SASoc']
	#configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg', 'J2CAuthData', 'JAASAppLogin']
	## If we get a request for it, add 'SECURITY.applicationLoginConfig', 'SECURITY.systemLoginConfig' 
	## to the list below.
	configTypes = ['GlobalSecurity', 'SSL', 'SSO', 'TAI', 'LocalOS', 'LDAP', 'CustomReg'] 
	
	
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	scope = AdminHelper.buildScope( optDict )
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['config_type']
	
	if (mode == MODE_EXECUTE):
		LOGGER.info("Configuring Global Security in scope: " + scope)
		executeSecurity()
	
	elif (mode == MODE_AUGMENT):
		LOGGER.info("Augmenting Global Security in scope: " + scope)
		augmentSecurity()
		
	elif (mode == MODE_IMPORT):
		LOGGER.info("Importing Global Security in scope: " + scope)
		importSecurity()
		
	elif (mode == MODE_COMPARE):
		LOGGER.info("Comparing Global Security settings in scope: " + scope)
		compareSecurity()
	
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endIf