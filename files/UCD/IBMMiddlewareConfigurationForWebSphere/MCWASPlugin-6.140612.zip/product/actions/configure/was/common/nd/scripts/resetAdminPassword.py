"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: resetAdminPassword.py
	
	Resets admin password.

	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f resetAdminPassword.py 
		-properties <security configuration properties file>

	The script expects the following parameters:
		-properties <security configuration properties file>
"""


import sys

##########
## Main ##
##########

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'properties:' )

try:
 	props = SystemUtils.getPropertyDict( optDict['properties'] )
except:
 	raise "resetAdminPassword.py: ERROR: not able to find security configuration for the cell"
#endtry

# 
print "Changing password for user " + props["WAS_USERNAME"]
AdminTask.changeFileRegistryAccountPassword(['-userId', props["WAS_USERNAME"], '-password', props["WAS_PASSWORD"]])

AdminHelper.saveAndSyncCell()
#end main	
