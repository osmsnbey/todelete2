"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listAdminAgentNodeSoapPort.py
	
	This script is to list the SOAP port used by the admin agent node
	This script is invoked as:
	wsadmin -lang jython -f listAdminAgentNodeSoapPort.py -adminAgentNodeName ${ADMIN_AGENT_NODE_NAME}
"""


import sys

from com.ibm.rational.rafw.wsadmin.util import Globals
from com.ibm.rational.rafw.wsadmin.util import PropertyFileWriter
from JavaConversionHelper import JavaConversionHelper
from existingcell import Constants

from existingcell.Constants import NEWLINE

def getPorts():
	retMap = {}
	serverEntries = AdminConfig.list('ServerEntry', AdminConfig.list("Node")).split(newline)
	for serverEntry in serverEntries:
		portsMap = {}
		serverName = AdminConfig.showAttribute(serverEntry, 'serverName')
		wasNamedEndPoints = AdminConfig.list('NamedEndPoint', serverEntry).split(newline)
		for wasNamedEndPoint in wasNamedEndPoints:
			endPointName = AdminConfig.showAttribute(wasNamedEndPoint, 'endPointName')
			endPointId = AdminConfig.showAttribute(wasNamedEndPoint, 'endPoint')
			portsMap[endPointName] = AdminConfig.showAttribute(endPointId, 'port')
		#endFor
		retMap[serverName] = portsMap
	#endFor
	return retMap
#endDef

optDict, args = SystemUtils.getopt( sys.argv, 'adminAgentNodeName:' )

nodeName = optDict['adminAgentNodeName']
portDict = {}

adminAgentServerPorts = getPorts()
ports = adminAgentServerPorts.values()[0]
if (ports.has_key("SOAP_CONNECTOR_ADDRESS")):
	portDict['SOAP_PORT_VALUE'] = ports["SOAP_CONNECTOR_ADDRESS"]
else:
	portDict['SOAP_PORT_VALUE'] = "8880"
#endIf

rafwHome = Globals.getInstallRoot()
nodeSOAPfile = rafwHome + "/work/" + nodeName + "_soap" + ".properties"
PropertyFileWriter().writeFile(nodeSOAPfile, JavaConversionHelper.mapDictToJava(portDict))
#end main		
