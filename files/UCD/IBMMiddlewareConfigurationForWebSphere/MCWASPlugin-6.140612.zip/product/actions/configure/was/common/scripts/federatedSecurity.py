"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: federatedSecurity.py
"""

import java.util as util
import java.io as javaio
import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager


class federatedSecurity:
	
	def createIdMgrLDAPRepository(self, ldapId, ldapType, ldapDefault):
		federatedSecurityLogger.traceEnter([ldapId, ldapType, ldapDefault])
		commandOptions = '[-id ' + ldapId + ' -ldapServerType ' + ldapType + ' -default ' + ldapDefault + ']'
		federatedSecurityLogger.log("CRWWA0100I", [ldapId, ldapType])
		federatedSecurityLogger.debug("AdminTask.createIdMgrLDAPRepository(" + commandOptions + ")")
		try:
			AdminTask.createIdMgrLDAPRepository(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0101E", [sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0101E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
		
	def getIdMgrRepository(self, ldapId):
		federatedSecurityLogger.traceEnter([ldapId])
		commandOptions = '[-id ' + ldapId + ']'
		federatedSecurityLogger.debug("AdminTask.getIdMgrRepository(" + commandOptions + ")")
		#print "Retrieving Id Manager Repository"
		federatedSecurityLogger.log("CRWWA5002I")
		repos = ''
		try:
			repos = AdminTask.getIdMgrRepository(commandOptions)
		finally:
			return repos
	
	def addIdMgrLDAPServer(self, ldapId, ldapServer, ldapPort, ldapBindDn, ldapBindPwd):
		federatedSecurityLogger.traceEnter([ldapId, ldapServer, ldapPort, ldapBindDn, ldapBindPwd])
		dbgCommandOptions = '[-id ' + ldapId + ' -host ' + ldapServer + ' -port ' + str(ldapPort) + ' -bindDN ' + ldapBindDn + ' -bindPassword ****]'
		commandOptions = '[-id ' + ldapId + ' -host ' + ldapServer + ' -port ' + str(ldapPort) + ' -bindDN ' + ldapBindDn + ' -bindPassword ' + ldapBindPwd + ']'
		federatedSecurityLogger.log("CRWWA0102I", [ldapId, ldapServer] )
		federatedSecurityLogger.debug("AdminTask.addIdMgrLDAPServer(" + str(dbgCommandOptions) + ")")
		try:
			AdminTask.addIdMgrLDAPServer(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0103E", [sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0103E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def updateIdMgrSupportedEntityType(self, entityName, entityParent):
		federatedSecurityLogger.traceEnter([entityName, entityParent])
		commandOptions = '[-name ' + entityName + ' -defaultParent ' + entityParent + ']'
		federatedSecurityLogger.debug('AdminTask.updateIdMgrSupportedEntityType(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0104I",[entityName,entityParent])
		AdminTask.updateIdMgrSupportedEntityType(commandOptions)
		federatedSecurityLogger.traceExit()
	
	def addIdMgrRepositoryBaseEntry(self, ldapId, baseEntryName, nameInRepos):
		federatedSecurityLogger.traceEnter([ldapId, baseEntryName, nameInRepos])
		commandOptions = '[-id ' + ldapId + ' -name ' + baseEntryName + ' -nameInRepository ' + nameInRepos + ']'
		federatedSecurityLogger.debug('AdminTask.addIdMgrRepositoryBaseEntry(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0105I",[baseEntryName,nameInRepos])
		try:
			AdminTask.addIdMgrRepositoryBaseEntry(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0106E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0106E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def addIdMgrRealmBaseEntry(self, realmId, realmBaseEntry):
		federatedSecurityLogger.traceEnter([realmId, realmBaseEntry])
		commandOptions = '[-name ' + realmId + ' -baseEntry ' + realmBaseEntry + ']'
		federatedSecurityLogger.debug('AdminTask.addIdMgrRealmBaseEntry(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0107I",[realmId,realmBaseEntry])
		try:
			AdminTask.addIdMgrRealmBaseEntry(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0108E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0108E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def deleteIdMgrRealmBaseEntry(self, realmId, realmBaseEntry):
		federatedSecurityLogger.traceEnter([realmId, realmBaseEntry])
		commandOptions = '[-name ' + realmId + ' -baseEntry ' + realmBaseEntry + ']'
		federatedSecurityLogger.debug('AdminTask.deleteIdMgrRealmBaseEntry(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0109I",[realmId])
		try:
			AdminTask.deleteIdMgrRealmBaseEntry (commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0110E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0110E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def updateIdMgrLDAPRepository(self, ldapId, loginProperties):
		federatedSecurityLogger.traceEnter([ldapId, loginProperties])
		commandOptions = '[-id ' + ldapId + ' -loginProperties ' + loginProperties + ']'
		federatedSecurityLogger.debug("AdminTask.updateIdMgrLDAPRepository(" + commandOptions + ")")
		federatedSecurityLogger.log("CRWWA0111I",[ldapId,loginProperties])
		AdminTask.updateIdMgrLDAPRepository(commandOptions)
		federatedSecurityLogger.traceExit()
	
	def getIdMgrRealm(self, realmId):
		federatedSecurityLogger.traceEnter([realmId])
		commandOptions = '[-name ' + realmId + ']'
		realm = ''
		try:
			realm = AdminTask.getIdMgrRealm(commandOptions)
		finally:
			return realm
	
	def renameIdMgrRealm(self, realmId, newRealmId):
		federatedSecurityLogger.traceEnter([realmId, newRealmId])
		commandOptions = '[-name ' + realmId + ' -newName ' + newRealmId + ']'
		federatedSecurityLogger.debug("AdminTask.renameIdMgrRealm(" + commandOptions + ")" )
		federatedSecurityLogger.log("CRWWA0112I",[realmId,newRealmId])
		try:
			AdminTask.renameIdMgrRealm(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0113E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0113E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def createIdMgrRealm(self, realmId, isActive, isAllowOperationIfReposDown):
		federatedSecurityLogger.traceEnter([realmId, isActive, isAllowOperationIfReposDown])
		commandOptions = '[-name ' + realmId + ' -securityUse ' + isActive + ' -allowOperationIfReposDown ' + isAllowOperationIfReposDown + ']'
		federatedSecurityLogger.debug('AdminTask.createIdMgrRealm(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0114I",[realmId])
		try:
			AdminTask.createIdMgrRealm(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0115E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0115E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def deleteIdMgrRealm(self, realmId):
		federatedSecurityLogger.traceEnter([realmId])
		commandOptions = '[-name ' + realmId + ']'
		federatedSecurityLogger.debug('AdminTask.deleteIdMgrRealm(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0116I",[realmId])
		try:
			AdminTask.deleteIdMgrRealm(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0117E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0117E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def setGroupMemberAttribute(self, ldapId, groupAttributeName, groupAttributeScope):
		federatedSecurityLogger.traceEnter([ldapId, groupAttributeName, groupAttributeScope])
		commandOptions = '[-id ' + ldapId + ' -name ' + groupAttributeName + ' -scope ' + groupAttributeScope + ']'
		federatedSecurityLogger.debug('AdminTask.setIdMgrLDAPGroupConfig(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0118I",[groupAttributeName,groupAttributeScope])
		try:
			AdminTask.setIdMgrLDAPGroupConfig(commandOptions)
		except:
			federatedSecurityLogger.log("CRWWA0119E",[sys.exc_info()[0],sys.exc_info()[1]])
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0119E", [sys.exc_info()[0],sys.exc_info()[1]])
		federatedSecurityLogger.traceExit()
	
	def addGroupMemberAttribute():
		federatedSecurityLogger.traceEnter()
		commandOptions = '[-id ' + ldapId + ' -name ' + groupAttributeName + ' -objectClass ' + objectClass + ']'
		federatedSecurityLogger.debug('AdminTask.addIdMgrLDAPGroupMemberAttr(' + commandOptions + ')')
		federatedSecurityLogger.log("CRWWA0120I",[groupAttributeName,objectClass])
		try:
			AdminTask.addIdMgrLDAPGroupMemberAttr()
		except:
			raise( "An error occurred adding the Group Manager Attribute.  Ensure the attribute name and scope are correct."
				+ "\n  Error: " + str(sys.exc_info()[0])
				+ "\n  Details: " + str(sys.exc_info()[1]))
		federatedSecurityLogger.traceExit()
	
	def setUserRegistryType(self, userRegistryType):
		federatedSecurityLogger.traceEnter([userRegistryType])
		userRegistry = AdminConfig.list(userRegistryType)
		securityId = AdminConfig.list('Security')
		AdminConfig.modify(securityId,[['activeUserRegistry',userRegistry]])
		federatedSecurityLogger.traceExit()
	
	def readProperties(self, aFile):
		federatedSecurityLogger.traceEnter([aFile])
		federatedSecurityLogger.debug("Reading security properties file: " + aFile)
		properties = util.Properties()
		propertiesFileInputStream =javaio.FileInputStream(aFile)
		properties.load(propertiesFileInputStream)
		federatedSecurityLogger.traceExit()
		return properties
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;cellName:' )

# get scope
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties'] 
scopeType = optDict['scope']
action = optDict['action']
mode = optDict['mode']

federatedSecurityLogger = _Logger("federatedSecurity", MessageManager.RB_WEBSPHERE_WAS)
thisFederator = federatedSecurity()

properties = thisFederator.readProperties(xmlFile)

#get realm properties
realmId = properties.get('realmId')
newRealmId = properties.get('newRealmId')  
#get ldap properties
ldapId = properties.get('ldapId')
ldapType = properties.get('ldapType')
ldapDefault = properties.get('ldapDefault')
ldapServer = properties.get('ldapServer')
ldapPort = properties.get('ldapPort')
ldapBindDn = properties.get('ldapBindDn')
ldapBindPwd = properties.get('ldapBindPwd')
loginProperties = properties.get('loginProperties')
fileRealmBaseEntry = properties.get('fileRealmBaseEntry')

if(mode == MODE_EXECUTE):
	#print "Configuring WebSphere Federated Security on %s" % optDict['cellName']
	federatedSecurityLogger.log("CRWWA5003I",[optDict['cellName']])	
	if(action == "CONFIGURE_FEDERATED_SECURITY"):
		thisFederator.createIdMgrLDAPRepository(ldapId, ldapType, ldapDefault)
		thisFederator.addIdMgrLDAPServer(ldapId, ldapServer, ldapPort, ldapBindDn, ldapBindPwd)
		for i in range(int(properties.get('numberOfIdMgrSupportedEntityTypes'))):
			j = str(i)
			baseEntryName = properties.get('baseEntryName.' + j)
			nameInRepos = properties.get('nameInRepos.' + j)
			thisFederator.addIdMgrRepositoryBaseEntry(ldapId, baseEntryName, nameInRepos)
			
		thisFederator.updateIdMgrLDAPRepository(ldapId, loginProperties)
		for i in range(int(properties.get('numberOfIdMgrRepositoryBaseEntries'))):
			j = str(i)
			entityName = properties.get('entityName.' + j)
			entityParent = properties.get('entityParent.' + j)
			thisFederator.updateIdMgrSupportedEntityType(entityName, entityParent)
		
		for i in range(int(properties.get('numberOfIdMgrRealmBaseEntries'))):
			j = str(i)
			realmId = properties.get('realmId')
			realmBaseEntry = properties.get('realmBaseEntry.' + j)
			thisFederator.addIdMgrRealmBaseEntry(realmId, realmBaseEntry)
			
		thisFederator.deleteIdMgrRealmBaseEntry(realmId, fileRealmBaseEntry)		
		thisFederator.renameIdMgrRealm(realmId, newRealmId)
		
	elif (action == "RENAME_REALM"):
		#check to see if realm exists
		realm = thisFederator.getIdMgrRealm(realmId)
		if (realm != ''):
			thisFederator.renameIdMgrRealm(realmId, newRealmId)
		else:
			#print "Realm: " + realmId + " does not exist!"
			federatedSecurityLogger.log("CRWWA5004I",[realmId])
			
	elif (action == "CREATE_LDAP_REPOSITORY"):	
		#check to see if ldap repository exists
		repos = thisFederator.getIdMgrRepository(ldapId)
		if (repos == ''):
			thisFederator.createIdMgrLDAPRepository(ldapId, ldapType, ldapDefault)
		else:
			#print("LDAP repository exists, editing repository")
			federatedSecurityLogger.log("CRWWA5005I",[realmId])
			
		thisFederator.addIdMgrLDAPServer(ldapId, ldapServer, ldapPort, ldapBindDn, ldapBindPwd)
		thisFederator.addIdMgrRepositoryBaseEntry(ldapId, baseEntryName, nameInRepos)
		thisFederator.updateIdMgrLDAPRepository(ldapId, loginProperties)
		
	elif (action == "UPDATE_LDAP_REPOSITORY"):
		#check to see if ldap repository exists
		repos = thisFederator.getIdMgrRepository(ldapId)
		if (repos != ''):
			#update ldap repository
			thisFederator.updateIdMgrLDAPRepository(ldapId, loginProperties)
		else:
			#print("LDAP repository does not exist!")
			federatedSecurityLogger.log("CRWWA5006I")
		
	elif (action == "ADD_REALM_BASE_ENTRY"):	
		#look up existing realm to see if it exists
		realm = thisFederator.getIdMgrRealm(realmId)
		if (realm != ''):
			thisFederator.addIdMgrRealmBaseEntry(realmId)
		else:
			#print "Realm: " + realmId + " does not exist!"
			federatedSecurityLogger.log("CRWWA5004I",[realmId])
			
	elif (action == "DELETE_REALM_BASE_ENTRY"):	
		#look up existing realm to see if it exists
		realm = thisFederator.getIdMgrRealm(realmId)
		if (realm != ''):
			thisFederator.deleteIdMgrRealmBaseEntry(realmId, realmBaseEntry)
		else:
			#print "Realm: " + realmId + " does not exist!"
			federatedSecurityLogger.log("CRWWA5004I",[realmId])
	elif (action == "ADD_LDAP_BASE_ENTRY"):
		#check to see if ldap repository exists
		
		#update ldap repository
		thisFederator.addIdMgrRepositoryBaseEntry(ldapId, baseEntryName, nameInRepos)
	elif (action == "UPDATE_SUPPORTED_ENTITY_TYPE"):	
		thisFederator.updateIdMgrSupportedEntityType(entityName, entityParent)	
	elif (action == "SET_REGISTRY_TYPE"):
		thisFederator.setUserRegistryType(properties.get('Security.UserRegistryType'))
	else:
		#print "Unsupported ACTION supplied: %s " % optDict['action']
		federatedSecurityLogger.log("CRWWA5000I",[optDict['action']])
	AdminHelper.saveAndSyncCell()
else:
	#print "Unsupported MODE supplied: %s " % optDict['mode']
	federatedSecurityLogger.log("CRWWA5001I",[optDict['mode']])