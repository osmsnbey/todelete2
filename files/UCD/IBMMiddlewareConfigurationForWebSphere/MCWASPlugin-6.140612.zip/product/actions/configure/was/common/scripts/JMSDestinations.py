"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: JMSDestinations.py
	
	This script is to manage jms destinations, including GenericJMSDestination, MQQueue, and MQTopic in a given scope.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f JMSDestinations.py 
		-scope <scope>: specify the scope of the jms destination factories to be created
		-scopename <scope name>: specify the scope name of the jms destination to be created 
		-properties <jms properties file>: specify the name of the jms properties file 
			to be used for the creation
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
import Globals

from AdminHelper import AdminHelper
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigValidator import ConfigValidator

JMSDestinationsLogger = _Logger("JMSDestinations", MessageManager.RB_WEBSPHERE_WAS)
class dsMediator:
    
	def createJ2CWASObject(self, xmlNode, parentId, excludedNodeNames = ['builtin']):
		type = xmlNode.getNodeNameFixed()
		if (xmlNode.hasAttr(Globals.RAFW_TYPE) and xmlNode.getAttrValue(Globals.RAFW_TYPE) == Globals.RAFW_TYPE_REFERENCE):
			##print "References will not be created for xmlNode: " + type
			JMSDestinationsLogger.log("CRWWA1142I",[type])
			return
		#endIf
		if (type not in excludedNodeNames):
			##print "createJ2CWASObject: " + type + ", " + parentId
			JMSDestinationsLogger.log("CRWWA1143I",[type,parentId])
			attrs = xmlNode.buildNodeAttrs(excludedNodeNames)
			
			# we need to get the adminObject Id from the config to be able to
			# create the queues and topics
			for xmlChild in xmlNode.getChildrenArray():
				if  (xmlChild.getNodeNameFixed() == "AdminObject"):
					childObjectInt=xmlChild.getAttrValue("adminObjectInterface")
					adminObjects=AdminConfig.list("AdminObject", parentId).split(newline)
					for adminObject in adminObjects:
						objectType=AdminConfig.showAttribute(adminObject, "adminObjectInterface")
						if (objectType == childObjectInt):
							adminObjectId = adminObject
						#endIf
					#endFor
					# fix the attributes by adding connectionDefninition to it
					attrs.append(["adminObject", adminObjectId])
				#endIf
			#endFor
			if ( xmlNode.hasAttr(Globals.WAS_KEY_ATTR_NAME) ):
				## case where we need a fourth parameter
				wasAttrName = xmlNode.getAttrValue(Globals.WAS_KEY_ATTR_NAME)
				newId = AdminConfig.create(type, parentId, attrs, wasAttrName)
			else:
				newId = AdminConfig.create(type, parentId, attrs)
			#endIf
			if (newId == None):
				##print "Error: Unable to create type: " + type + " under parent: " + parentId
				JMSDestinationsLogger.error("CRWWA1144E",[type,parentId])
			else:
				#Child J2EEResourceProperty objects are created by default, remove them or duplicates
				#will be created
				if( type == "J2CAdminObject"):
					##print "Unsetting attribute properties for config id " + str(newId) + " to avoid duplicates"
					JMSDestinationsLogger.log("CRWWA1145E",[str(newId)])
					AdminConfig.modify(newId, "[[properties '']]")
				for xmlChild in xmlNode.getChildrenArray():
					if (xmlChild.getNodeNameFixed() not in excludedNodeNames):
						self.createJ2CWASObject(xmlChild, newId)
					#endIf
				#endFor
			#endIf
		#endIf
		return newId
	#endDef
	
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			self.createConfigType(scopeId, scopeType, xmlProp, typeName)
		#endFor
		
	#endDef
	
	def createConfigType(self, scopeId, scopeType, xmlProp, typeName):
	
		myConfigWriter = ConfigWriter();	
		myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
		
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			xmlNode.xmlProperty.clearSkipAttributeOnWriteFilters()
			
			if (typeName == "MQQueue" or typeName == "MQTopic"):
				JMSProviderName = "WebSphere MQ JMS Provider"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				if ( (xmlNode.hasAttr("CCSID")) and (xmlNode.getAttrValue("CCSID")=="0")):
					xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('CCSID'))
				#endIf
				myConfigWriter.createWASObject(xmlNode, parentId)
			elif (typeName == "WASQueue" or typeName == "WASTopic"):
				JMSProviderName = "WebSphere JMS Provider"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				myConfigWriter.createWASObject(xmlNode, parentId)
			elif (typeName == "J2CAdminObject"):
				J2CResourceAdapterName = "SIB JMS Resource Adapter"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'J2CResourceAdapter', J2CResourceAdapterName)[0]
				self.createJ2CWASObject(xmlNode, parentId)
			else:
				JMSProviderNode = xmlNode.getFilteredChildrenArray("JMSProvider")[0]
				JMSProviderName = JMSProviderNode.getAttrValue("name")
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				myConfigWriter.createWASObject(xmlNode, parentId)
			#endIf
		#endFor
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames, configValidator):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			self.augmentConfigType(scopeId, scopeType, xmlProp, typeName, configValidator)
		#endFor
		
	#endDef
	
	def augmentConfigType(self, scopeId, scopeType, xmlProp, typeName, configValidator):
	
		myConfigWriter = ConfigWriter();	
		
		nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			xmlNode.xmlProperty.clearSkipAttributeOnWriteFilters()
			
			if (typeName == "MQQueue" or typeName == "MQTopic"):
				JMSProviderName = "WebSphere MQ JMS Provider"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSDestinationsLogger.log("CRWWA5007I",[typeName],[xmlNode.getAttrValue("jndiName")])
					myConfigWriter.createWASObject(xmlNode, parentId)
				else:
					if (SystemUtils.updateOnAugment()):
						if ( (xmlNode.hasAttr("CCSID")) and (xmlNode.getAttrValue("CCSID")=="0")):
							xmlNode.xmlProperty.addSkipAttributeOnWriteFilter(SkipNamedAttribute('CCSID'))
						#endIf
						myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
					else:
						##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
						JMSDestinationsLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			elif (typeName == "WASQueue" or typeName == "WASTopic"):
				JMSProviderName = "WebSphere JMS Provider"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					#print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSDestinationsLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
					JMSDestinationsLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
					myConfigWriter.createWASObject(xmlNode, parentId)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
					else:
						##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
						JMSDestinationsLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			elif (typeName == "J2CAdminObject"):
				J2CResourceAdapterName = "SIB JMS Resource Adapter"
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'J2CResourceAdapter', J2CResourceAdapterName)[0]
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSDestinationsLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
					self.createJ2CWASObject(xmlNode, parentId)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode, ['J2CResourceAdapter', 'builtin'])
					else:
						##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
						JMSDestinationsLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			else:
				JMSProviderNode = xmlNode.getFilteredChildrenArray("JMSProvider")[0]
				JMSProviderName = JMSProviderNode.getAttrValue("name")
				#TODO: refactor to use AdminHelper.findProviderId
				parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
				childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				if (childId is None):
					##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSDestinationsLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
					myConfigWriter.createWASObject(xmlNode, parentId)
				else:
					if (SystemUtils.updateOnAugment()):
						myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
					else:
						##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
						JMSDestinationsLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endIf
		#endFor
	#endDef
    
	def readConfigData(self, scope, scopeType, typeName, excludeTypes):
		myConfigReader = ConfigReader()
		data = []
		data.extend(myConfigReader.readConfigData(scope, scopeType, typeName, excludeTypes))
		## filter out most attributes of JMSProvider since it won't be written when we createConfig
		myConfigReader.stripElement(data, "provider", "JMSProvider", ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])
		data = self.removeAttrsFromData(data, ['MQQueue', 'MQTopic'], 'CCSID', '0')
		return data
	#endDef
	
	## Removes attributes from data with specified typeNames, attrName and attrValue (optional)
	## Eg: To remove CCSID attribute from MQQueue when its value is 0, invoke this procedure as:
	## newData = removeAttrsFromData(data, ['MQQueue'], 'CCSID', '0')
	def removeAttrsFromData(self, data, typeNames, attrName, attrVal=None):
		if (len(data) > 0):
			for element in data:
				if (element['id'] in typeNames):
					if(element['attrs'].has_key(attrName)):
						if (attrVal is None):
							del element['attrs'][attrName]
						elif (element['attrs'][attrName] == attrVal):
							del element['attrs'][attrName]
						#endIf
					#endIf
				#endIf
			#endFor
		#endIf
		
		return data
	#endDef
	
#endClass

def export(optDict=None):
	global scope, newline
	newline = java.lang.System.getProperty("line.separator")
	scope = optDict['wasscopetype']
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	excludeTypes = ['builtin']
	
	mode = optDict['mode']
	typeNames = [optDict['type']]
	thisMediator = dsMediator()
	marker = optDict['marker']
	
	thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	excludeTypes = ['builtin']
	
	mode = optDict['mode']
	## GenericJMSDestination seems to pull back nothing in WAS61 but is listed as a valid type
	## JMSDesintation pulls back all 4 of "MQQueue", "MQTopic", "WASQueue", "WASTopic"
	typeNames = ["MQQueue", "MQTopic", "WASQueue", "WASTopic", "J2CAdminObject","GenericJMSDestination"]
	thisMediator = dsMediator()
	marker = 'JMSDestinations'
	
	if (mode == MODE_EXECUTE):
		##print "Creating JMS Destinations in scope: " + scope
		JMSDestinationsLogger.log("CRWWA1145I",[scope])
		thisMediator.createConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		##print "Augmenting JMS Destinations in scope: " + scope
		JMSDestinationsLogger.log("CRWWA1146I",[scope])
		thisMediator.augmentConfig(scope, scopeType, propFile, marker, typeNames, ConfigValidator())
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing JMS Destinations in scope: " + scope
		JMSDestinationsLogger.log("CRWWA1147I",[scope])
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator )
	
	elif (mode == MODE_COMPARE):
		##print "Comparing JMS Destinations in RAFW and WAS in scope: " + scope
		JMSDestinationsLogger.log("CRWWA1148I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, thisMediator )
	
	else:
		##print "Unsupported MODE supplied: " + mode
		JMSDestinationsLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf