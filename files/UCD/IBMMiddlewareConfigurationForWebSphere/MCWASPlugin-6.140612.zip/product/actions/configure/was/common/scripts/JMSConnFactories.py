"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: JMSConnFactories.py
	
	This script is to create jms (includine generic and MQ) conneciton factories in a given scope.
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f JMSConnFactories.py 
		-version <WAS version>: specify the WAS version of the server
		-scope <scope>: specify the scope of the jms connection factories to be created
		-scopename <scope name>: specify the scope name of the jms connection to be created 
		-properties <jms properties file>: specify the name of the jms properties 
			file to be used for the creation
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from ConfigReader import ConfigTypeKeys
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigValidator import ConfigValidator
from J2CMediator import J2CConnFactoryMediator
from AdminHelper import AdminHelper

J2CResourceAdapterName = "SIB JMS Resource Adapter"
JMSProviderName = "WebSphere JMS Provider"
MQProviderName = "WebSphere MQ JMS Provider"

JMSConnFactoriesLogger = _Logger("JMSConnFactories", MessageManager.RB_WEBSPHERE_WAS)

class _JMSConfigReader(ConfigReader):
	def __init__(self, importedIds=[], excludedTypes = [], excludedAttributes = []):
		self.importedIds = importedIds
		self.excludedTypes = excludedTypes
		self.processTypesFirst = []
		self.excludedAttributes = excludedAttributes
		self.LOGGER = _Logger("JMSConfigReader", MessageManager.RB_WEBSPHERE_WAS)
		self._updatePasswordAttributes()
		self.configTypeKeys = ConfigTypeKeys()
		## default to read passwords
		self.excludePasswords = 0
		self.allTypes = AdminConfig.types().split(newline)
	#endDef
	
	def readConfigDataUsingParentId(self, scopeId, scopeType, configType, excludedTypes = [], excludedAttributes = None):
		if (excludedAttributes is not None):
			JMSConnFactoriesLogger.warn("CRWWA1135W")
			self.excludedAttributes = excludedAttributes
		#endIf
		data = []
		if (len(scopeId) == 0):
			JMSConnFactoriesLogger.error("CRWWA1135E",[scopeId])
			JMSConnFactoriesLogger.error("CRWWA1136E")
			return data
		#endIf

		for objId in AdminConfig.list(configType, scopeId).split(newline):
			self.importedIds = []
			## if anything found, is in scope, and not builtin
			if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId) and (objId.find("builtin") == -1)):
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							match = "yes"
						#endIf
					#endFor
					if (match == "no"):
						if self._isJMS(objId,configType):
							JMSConnFactoriesLogger.log("CRWWA1136I",[objId])
							self.importedIds.append(objId)
							data.append(self.showAll(objId))
					#endIf
				else:
					if self._isJMS(objId,configType):
						JMSConnFactoriesLogger.log("CRWWA1136I ",[objId])
						self.importedIds.append(objId)
						data.append(self.showAll(objId))
				#endIf
			#endIf
		#endFor
		return data
	#endDef
	
	"""
	This function is needed since we need some logic to tell the difference between
	J2CConnectionFactories that are or aren't related to JMS.  For this purpose, lets
	assume that all J2CConnectionFactories that utilize the SIB JMS Resource Adapter
	are in fact, JMSConnectionFactories
	"""
	def _isJMS(self,objId,configType):
		self.LOGGER.traceEnter([objId,configType])
		# 1. of the many types encompassed by JMS, this one is a J2CConnectionFactory
		if ( configType == "J2CConnectionFactory" ):
			thisAdapterId = AdminConfig.showAttribute(objId,'provider')
			thisAdapterId = AdminHelper.extractWASIdsFromList(thisAdapterId)
			# 2. this factory does indeed have a provider (length should be either 1 or 0)
			if ( len(thisAdapterId) == 1 ):
				thisAdapterName = AdminConfig.showAttribute(thisAdapterId[0],'name')
				#3. the provider name matches the one provider that is specific to JMS
				if ( thisAdapterName == J2CResourceAdapterName ):
					self.LOGGER.traceExit(1)
					return 1
				#endIf
			#endIf
		else:
			# We are really only interested in J2C here, so lets let all others get a pass
			self.LOGGER.traceExit(1)
			return 1
		#endIf
		self.LOGGER.traceExit(0)
		return 0
	#endDef
#endClass

def createConfig(scope, scopeType, xmlFile, marker, typeNames):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeId = AdminConfig.getid( scope )
	for typeName in typeNames:
		createConfigType(scopeId, scopeType, xmlProp, typeName)
	#endFor
	
#endDef

def createConfigType(scopeId, scopeType, xmlProp, typeName):
	
	myJ2CMediator = J2CConnFactoryMediator()
	myConfigWriter = ConfigWriter();	
	myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId, ["CMPConnectorFactory"])

	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	for xmlNode in nodeArray:
		
		if (typeName == "MQTopicConnectionFactory" or typeName == "MQQueueConnectionFactory" or typeName == "MQConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', MQProviderName)[0]
			##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
			JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
			myConfigWriter.createWASObject(xmlNode, parentId)
		elif (typeName == "WASQueueConnectionFactory" or typeName == "WASTopicConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
			##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
			JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
			myConfigWriter.createWASObject(xmlNode, parentId)
		elif (typeName == "J2CConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'J2CResourceAdapter', J2CResourceAdapterName)[0]
			##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
			JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
			myJ2CMediator.createJ2CWASObject(xmlNode, parentId, scopeId)
		else:
			parentId = AdminHelper.findProviderId(xmlNode, scope, "JMSProvider", "name", "builtin")
			##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
			JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
			myConfigWriter.createWASObject(xmlNode, parentId)
		#endIf
	#endFor
#endDef

def augmentConfig(scope, scopeType, xmlFile, marker, typeNames):

	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)

	scopeId = AdminConfig.getid( scope )
	for typeName in typeNames:
		augmentConfigType(scopeId, scopeType, xmlProp, typeName)
	#endFor
	
#endDef

def augmentConfigType(scopeId, scopeType, xmlProp, typeName):
	
	myConfigWriter = ConfigWriter()	
	configValidator = ConfigValidator()

	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	for xmlNode in nodeArray:
		
		if (typeName == "MQTopicConnectionFactory" or typeName == "MQQueueConnectionFactory" or typeName == "MQConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', MQProviderName)[0]
			childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
			if (childId is None):
				##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
				JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
				myConfigWriter.createWASObject(xmlNode, parentId)
			else:
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
				else:
					##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSConnFactoriesLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endIf
		elif (typeName == "WASQueueConnectionFactory" or typeName == "WASTopicConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
			childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
			if (childId is None):
				##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
				JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
				myConfigWriter.createWASObject(xmlNode, parentId)
			else:
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
				else:
					##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSConnFactoriesLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endIf
		elif (typeName == "J2CConnectionFactory"):
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'J2CResourceAdapter', J2CResourceAdapterName)[0]
			childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
			if (childId is None):
				##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
				JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
				myJ2CMediator.createJ2CWASObject(xmlNode, parentId, scopeId)
			else:
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(childId, xmlNode, ['J2CResourceAdapter', 'builtin'])
				else:
					##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSConnFactoriesLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endIf
		else:
			JMSProviderNode = xmlNode.getFilteredChildrenArray("JMSProvider")[0]
			JMSProviderName = JMSProviderNode.getAttrValue("name")
			#TODO: refactor to use AdminHelper.findProviderId
			parentId = AdminHelper.findProviderIdByName( scope, 'JMSProvider', JMSProviderName)[0]
			childId = configValidator.validateUniqueJndiName2(xmlNode, scopeId)
			if (childId is None):
				##print "Info: Creating " + typeName + " with jndiName " + xmlNode.getAttrValue("jndiName")
				JMSConnFactoriesLogger.log("CRWWA1137I",[typeName,xmlNode.getAttrValue("jndiName")])
				myConfigWriter.createWASObject(xmlNode, parentId)
			else:
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(childId, xmlNode, ['JMSProvider', 'builtin'])
				else:
					##print "Warning: " + typeName + " will not be created with jndiName " + xmlNode.getAttrValue("jndiName")
					JMSConnFactoriesLogger.log("CRWWA1137W",[typeName,xmlNode.getAttrValue("jndiName")])
			#endIf
		#endIf
	#endFor
#endDef

def export(optDict=None):
	global newline, scope
	newline = java.lang.System.getProperty("line.separator")
	version= optDict['version']
		
	# get scope
	scope = optDict['wasscopetype']
	scopeType=optDict['scope']
	
	propFile = optDict['properties'] 
	
	mode = optDict['mode']
	# JMSConnectionFactory includes all of the following types. 
	#     MQTopicConnectionFactory, MQQueueConnectionFactory, MQConnectionFactory,
	#     WASQueueConnectionFactory, WASTopicConnectionFactory
	#
	# GenericJMSConnectionFactory seems to pull back nothing in WAS61 but is listed as a valid type
	#
	typeNames = [optDict['type']]
	
	excludeTypes = optDict['excludedtypes']
	marker = optDict['marker']
	
#	myConfigReader = _JMSConfigReader()
#	myJ2CMediator = J2CConnFactoryMediator()
	
	createConfig(scope, scopeType, propFile, marker, typeNames)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt(sys.argv, 'version:;scope:;properties:;nodename:;scopename:;mode:')
	version= optDict['version']
		
	# get scope
	scope = AdminHelper.buildScope(optDict)
	scopeType=optDict['scope']
	
	propFile = optDict['properties'] 
	
	mode = optDict['mode']
	# JMSConnectionFactory includes all of the following types. 
	#     MQTopicConnectionFactory, MQQueueConnectionFactory, MQConnectionFactory,
	#     WASQueueConnectionFactory, WASTopicConnectionFactory
	#
	# GenericJMSConnectionFactory seems to pull back nothing in WAS61 but is listed as a valid type
	#
	typeNames = ["MQTopicConnectionFactory", "MQQueueConnectionFactory", "MQConnectionFactory",
				"WASQueueConnectionFactory", "WASTopicConnectionFactory", "J2CConnectionFactory", "GenericJMSConnectionFactory"]
	
	excludeTypes = ["CMPConnectorFactory"]
	marker = "JMSConnFactories"
	
	myConfigReader = _JMSConfigReader()
	myJ2CMediator = J2CConnFactoryMediator()
	
	if (mode == MODE_EXECUTE):
		##print "Creating JMS Connection Factories in scope: " + scope
		JMSConnFactoriesLogger.log("CRWWA1138I",[scope])
		createConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
		##print "Augmenting JMS Connection Factories in scope: " + scope
		JMSConnFactoriesLogger.log("CRWWA1139I",[scope])
		augmentConfig(scope, scopeType, propFile, marker, typeNames)
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing JMS Connection Factories in scope: " + scope
		JMSConnFactoriesLogger.log("CRWWA1140I",[scope])
		ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes, myConfigReader)
	
	elif (mode == MODE_COMPARE):
		##print "Comparing JMS Connection Factories in RAFW and WAS in scope: " + scope
		JMSConnFactoriesLogger.log("CRWWA1141I",[scope])
		ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
	else:
		##print "Unsupported MODE supplied: " + mode
		JMSConnFactoriesLogger.log("CRWWA0008W",[mode])
	#endIf
#endIf
