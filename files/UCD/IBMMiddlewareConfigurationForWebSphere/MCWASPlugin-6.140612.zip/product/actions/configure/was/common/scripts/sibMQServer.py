"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: sibMQServer.py
	
	This script is used to create/import MQ Servers
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f sibMQServer.py 
		-properties <xml file describing MQServers> 
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from org.python.modules import re
from org.python.modules import sre
from java.util import Properties
from java.io import FileInputStream

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException

class dsMediator:

	def importMQServer(self, xmlFile):
		data = self.readConfigData(None, None, None, [])
		myFileWriter = ConfigFileWriter("sibMQServer.vm")
		marker = "sibMQServer"
		myFileWriter.processBasicFile(xmlFile, data, marker)
	#endDef
	
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
		MQServers = AdminTask.listSIBWMQServers().split( newline )
		myConfigReader = ConfigReader()
		data = []
		for MQServer in MQServers:
			mqServerName = MQServer.split('(', 1)[0]
			if (mqServerName.startswith('"')):
				mqServerName = mqServerName[1:len(mqServerName)]
			#endIf
			if (len(mqServerName) > 0):
				SCRIPT_LOGGER.log("Showing data for server: " + mqServerName)
				configAttrs = myConfigReader.convertToDict(
					AdminTask.showSIBWMQServer(["-name", mqServerName]))
				serverData = {}
				serverData['id'] = "MQServer"
				serverData['attrs'] = configAttrs
				serverData['children'] = []
				data.append(serverData)
			#endIf
		#endFor
		return data
	#endDef
		
	def createMQServer (self, xmlProp, xmlNode) :
		if (xmlNode.hasAttr("name")):
			##print "Creating MQ Server: " + xmlNode.getAttrValue("name")
			SCRIPT_LOGGER.log("CRWWA2044I",[xmlNode.getAttrValue("name")])
			AdminTask.createSIBWMQServer(xmlNode.buildNodeAttrsList())
		else:
			##print "Warning: Supplied xml node doesn't contain the attribute 'name'"
			SCRIPT_LOGGER.log("CRWWA2045I")
			##print "         Before MQ Servers can be created, the xml must specify the"
			
			##print "         MQ Server name"
			
		#endIf
	#endDef
	
	def updateMQServers(self, configId, xmlNode):
		if (xmlNode.hasAttr("name")):
			##print "Updating MQ Server: " + xmlNode.getAttrValue("name")
			SCRIPT_LOGGER.log("CRWWA2099I",[xmlNode.getAttrValue("name")])
			## type is not valid on modify
			skipReadOnlyAttribute = SkipNamedAttribute("type")
			xmlNode.addSkipAttributeOnWriteFilter(skipReadOnlyAttribute)
			AdminTask.modifySIBWMQServer(xmlNode.buildNodeAttrsList())
		else:
			##print "Warning: Supplied xml node doesn't contain the attribute 'name'"
			SCRIPT_LOGGER.log("CRWWA2045I")
			##print "         Before MQ Servers can be updated, the xml must specify the"
			##print "         MQ Server name"
		#endIf
	#endDef
		
	def deleteExistingMQServers(self):
	
		MQServers = AdminTask.listSIBWMQServers().split( newline )
		for MQServer in MQServers:
			if (len(MQServer) > 0):
				serverName = MQServer.split('(', 1)[0]
				if (serverName.startswith('"')):
				    serverName = serverName[1:len(serverName)]
				#endDef
				##print "Info: Deleting existing MQ Server:" + serverName
				SCRIPT_LOGGER.log("CRWWA2048I",[serverName])
				AdminTask.deleteSIBWMQServer(["-name", serverName])
			#endIf
		#endFor
	#endDef
	
	def validateUniqueAttr2(self, xmlNode, attrName):
		SCRIPT_LOGGER.traceEnter([xmlNode, attrName])
		if (xmlNode.hasAttr(attrName)):
			rafwName = xmlNode.getAttrValue(attrName)
			MQServers = AdminTask.listSIBWMQServers().split( newline )
			for MQServer in MQServers:
				SCRIPT_LOGGER.trace("Processing MQServer: " + MQServer)
				if (len(MQServer) > 0):
					serverName = MQServer.split('(', 1)[0]
					if (serverName.startswith('"')):
						serverName = serverName[1:len(serverName)]
					#endIf
					SCRIPT_LOGGER.trace(attrName + " in XML: " + rafwName)
					SCRIPT_LOGGER.trace("serverName in WAS: " + serverName)
					if (rafwName == serverName):
						if (not SystemUtils.updateOnAugment()):
							#print "Warning: An MQ Server with " + attrName 
							#print "         '" + serverName + "' already exists."
							#print "         You must use a unique value for " + attrName 
							#print "         when creating MQ Servers"
							SCRIPT_LOGGER.log("CRWWA5035I",[attrName,serverName,attrName])
						#endIf
						return MQServer
					#endIf
				#endIf
			#endFor
		else:
			msg = "Warning: Supplied xml node doesn't contain the attribute '" + attrName + "'"
			msg += "         Before MQ Servers can be created, the xml must specify the"
			msg += "         MQ Server name"
			raise InvalidXmlConfigException(msg);
		#endIf
		return None
	#endDef
#endClass

SCRIPT_LOGGER = _Logger("sibMQServer", MessageManager.RB_WEBSPHERE_WAS)

'''
This is the function that is used by quick export to push the configuration data back to WAS
'''
def export(optDict=None):
	global newline
	newline = java.lang.System.getProperty("line.separator")
	propFile = optDict['properties'] 
	mode = optDict['mode'] 
	thisMediator = dsMediator()
	marker = optDict['marker']
	
	xmlProp = ConfigFileReader.openXmlConfig(propFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	nodeArray = xmlProp.getFilteredNodeArray('MQServer' ) 
	
	thisMediator.deleteExistingMQServers()
	
	for xmlNode in nodeArray:
		thisMediator.createMQServer (xmlProp, xmlNode)
#endDef
#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:' )
		
	# parse the properties into props
	propFile = optDict['properties'] 
	mode = optDict['mode'] 
	thisMediator = dsMediator()
	marker = "sibMQServer"
	
	if (mode == MODE_EXECUTE):
	
		##print "Creating MQServers"
		SCRIPT_LOGGER.log("CRWWA2049I")
		xmlProp = ConfigFileReader.openXmlConfig(propFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray('MQServer' ) 
	
		thisMediator.deleteExistingMQServers()
	
		for xmlNode in nodeArray:
			thisMediator.createMQServer (xmlProp, xmlNode)
		#endFor
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_AUGMENT):
	
		print "Augmenting MQServers"
		xmlProp = ConfigFileReader.openXmlConfig(propFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray('MQServer' ) 
		for xmlNode in nodeArray:
			# do work
			childId = thisMediator.validateUniqueAttr2(xmlNode, "name")
			if (childId is None):
				##print "Info: Creating MQ Servers with name " + xmlNode.getAttrValue("name")
				SCRIPT_LOGGER.log("CRWWA2050I",[xmlNode.getAttrValue("name")])
				thisMediator.createMQServer(xmlProp, xmlNode)
			else:
				if (SystemUtils.updateOnAugment()):
					thisMediator.updateMQServers(childId, xmlNode)
				else:
					##print "Warning: MQ Server will not be created."
					SCRIPT_LOGGER.log("CRWWA2051I")
			#endIf	
		#endFor
		AdminHelper.saveAndSyncCell()
	elif (mode == MODE_IMPORT):
		##print "Importing MQServers"
		SCRIPT_LOGGER.log("CRWWA2052I")
		thisMediator.importMQServer(propFile)
	elif (mode == MODE_COMPARE):
	    ##print "Comparing MQ Servers in RAFW and WAS"
	    SCRIPT_LOGGER.log("CRWWA2053I")
	    ConfigMediator.compareConfig(None, None, propFile, marker, ["MQServer"], [], thisMediator )
		
	else:
		##print "Unsupported MODE supplied: " + mode
		SCRIPT_LOGGER.log("CRWWA0008W",[mode])
	#endIf
#endIf