"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: oracleURL.py
"""
import java.util as util
import java.io as javaio

class oracleURL:
	
	#create CEI resources for Oracle
	def parseOracleURL(self):
		ceiLogger.debug("entering Oracle")
		sysUser = properties.get('wbi.DB.CEIEvent.DBAUser');
		sysPassword = properties.get('wbi.DB.CEIEvent.DBAPassword');
		commandOptions = '[-clusterName ' + clusterName + ' -jdbcClassPath ' + jdbcClassPath + ' -dbHostName ' + dbHostName + ' -dbPort ' + dbPort + ' -dbName ' + dbName + ' -dbUser ' + dbUser + ' -dbPassword ' + dbPassword + ' -sysUser ' + sysUser + ' -sysPassword ' + sysPassword + ']'
		ceiLogger.debug("AdminTask.configEventServiceOracleDB('" + commandOptions + "')")
		AdminTask.configEventServiceOracleDB(commandOptions);
	#create CEI resources for DB2

	def readProperties(self, aFile):
		ceiLogger.debug("Reading properties file: " + aFile)
		properties = util.Properties()
		propertiesFileInputStream =javaio.FileInputStream(aFile)
		properties.load(propertiesFileInputStream)
		return properties
		
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

urlLogger = _Logger("oracleURL", MessageManager.RB_WEBSPHERE_BPM)
thisOracleURL = oracleURL()

properties = thisOracleURL.readProperties(xmlFile);

if(mode == MODE_EXECUTE):
	if(action == 'PARSE_URL'):
		dbTypes = ['wbi','wps']
		dbNames = ['Common','CEIEvent','CEIME','SCASYSME', 'SCAAPPME', 'BSPACE', 'BPC', 'BPCME', 'BPCEventCollector']
		#get all common properties and pass to functions as parameters
		#get all function specific parameters within said function
		dbType = properties.get('wbi.DB.DbType');
		jdbcClassPath = properties.get('wbi.DB.jdbcDriverPath');
		dbHostName = properties.get('wbi.DB.CEIEvent.DbHost');
		dbPort = properties.get('wbi.DB.CEIEvent.DbPort');
		dbName = properties.get('wbi.DB.CEIEvent.DbName');
		dbUser = properties.get('wbi.DB.CEIEvent.DbUser');
		dbPassword = properties.get('wbi.DB.CEIEvent.DbPassword');
		if(dbType == "Oracle10g"):
			thisCommonEventInfrastructure.configureOracle(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		elif(dbType == "DB2_Universal"):
			thisCommonEventInfrastructure.configureDB2(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		elif(dbType == "DB2UDBOS390_V8_1"):
			thisCommonEventInfrastructure.configureDB2UDBOS390(clusterName, dbType, jdbcClassPath, dbHostName, dbPort, dbName, dbUser, dbPassword);
		else:
			print "Invalid dbType!"
	else:
		urlLogger.fail("Invalid action: " + action)

	AdminHelper.saveAndSyncCell()
else:
	urlLogger.fail("Unsupported MODE supplied: " + mode)
