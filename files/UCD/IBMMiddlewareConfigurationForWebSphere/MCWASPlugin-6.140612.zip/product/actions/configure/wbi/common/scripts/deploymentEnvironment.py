"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: deploymentEnvironment.py
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

deploymentEnvironmentLogger = _Logger("deploymentEnvironment", MessageManager.RB_WEBSPHERE_WP)

class deploymentEnvironment:
	def importDeploymentEnvironmentDefinition(self):
		#print "Importing deployment environment definition into WPS"
		deploymentEnvironmentLogger.log("CRWWP2003I")
		AdminTask.importDeploymentEnvDef('-filePath ' + optDict['properties'] + ' -topologyName ' + optDict['depenvname'])
	def exportDeploymentEnvironmentDefinition(self):
		#print "Exporting deployment environment definition from WPS"
		deploymentEnvironmentLogger.log("CRWWP2004I")
		AdminTask.exportDeploymentEnvDef('-filePath ' + optDict['properties'] + ' -topologyName ' + optDict['depenvname'])
	def deleteDeploymentEnvironment(self):
		#print "Deleting deployment environment definition %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2005I",[optDict['depenvname']])
		AdminTask.deleteDeploymentEnvDef('-topologyName ' + optDict['depenvname'])
	def startDeploymentEnvironment(self):
		#print "Starting deployment environment %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2006I",[optDict['depenvname']])
		AdminTask.startDeploymentEnv('-topologyName ' + optDict['depenvname'])
	def stopDeploymentEnvironment(self):
		#print "Stopping deployment environment %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2007I",[optDict['depenvname']])
		AdminTask.stopDeploymentEnv('-topologyName ' + optDict['depenvname'])
	def getDeploymentEnvironmentStatus(self):
		#print "Showing status of deployment environment definition %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2008I",[optDict['depenvname']])
		print AdminTask.showDeploymentEnvStatus('-topologyName ' + optDict['depenvname'])
	def generateDeploymentEnvironment(self):
		#print "Generating deployment environment %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2009I",[optDict['depenvname']])
		AdminTask.generateDeploymentEnv('-topologyName ' + optDict['depenvname'])
	def renameDeploymentEnvironment(self):
		AdminTask.renameDeploymentEnvDef('-oldName ' + optDict['olddepenvname'] + ' -newName ' + optDict['newdepenvname'])
	def validateDeploymentEnvironment(self):
		#print "Validating deployment environment definition %s" % optDict['depenvname']
		deploymentEnvironmentLogger.log("CRWWP2010I",[optDict['depenvname']])
		AdminTask.validateDeploymentEnvDef('-topologyName ' + optDict['depenvname'])
	def addNodeToDeploymentEnvironment(self):
		AdminTask.addNodeToDeploymentEnvDef('-topologyName ' + optDict['depenvname'] + ' -nodeRuntime ' + optDict['nodeRuntime'] + ' -topologyRole ' + optDict['topologyRole'] + ' -nodeName ' + optDict['nodeName'] + ' -serverCount ' + optDict['serverCount'])
		
		
# parse the options into optDict
optDict, args = SystemUtils.getopt(sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;nodename:;depenvname:;olddepenvname:;newdepenvname:')

# get scope
scopeType = optDict['scope']
scope = AdminHelper.buildScope(optDict)
xmlFile = optDict['properties']
mode = optDict['mode']
action = optDict['action']

thisDeploymentEnvironment = deploymentEnvironment()
 
#if (mode == MODE_IMPORT):
#	thisDeploymentEnvironment.exportDeploymentEnvironmentDefinition()
#elif (mode == MODE_COMPARE):
#   print "Comparing variables in RAFW and WAS in cell: " + cellName
#   ConfigMediator.compareConfig(scope, scopeType, xmlFile, typeNames)
#else:
#   print "Unsupported MODE supplied: " + mode
#endIf
if(mode == MODE_EXECUTE):
	if (action == 'import'):
		thisDeploymentEnvironment.importDeploymentEnvironmentDefinition()
	elif (action == 'export'):
		thisDeploymentEnvironment.exportDeploymentEnvironmentDefinition()
	elif (action == 'delete'):
		thisDeploymentEnvironment.deleteDeploymentEnvironment()
	elif (action == 'start'):
		thisDeploymentEnvironment.startDeploymentEnvironment()
	elif (action == 'stop'):
		thisDeploymentEnvironment.stopDeploymentEnvironment()
	elif (action == 'status'):
		thisDeploymentEnvironment.getDeploymentEnvironmentStatus()
	elif (action == 'generate'):
		thisDeploymentEnvironment.generateDeploymentEnvironment()
	elif (action == 'rename'):
		thisDeploymentEnvironment.renameDeploymentEnvironment()
	elif (action == 'validate'):
		thisDeploymentEnvironment.validateDeploymentEnvironment()
	elif (action == 'addNode'):
		thisDeploymentEnvironment.addNodeToDeploymentEnvironment()
	else:
		#print "Invalid action supplied: " + action
		deploymentEnvironmentLogger.log("CRWWP2011I",[action])
	AdminHelper.saveAndSyncCell()
else:
	#print "Unsupported MODE supplied: " + mode
	deploymentEnvironmentLogger.log("CRWWP2012I",[mode])
