"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: odrclusterTasks.py
"""

import sys
from org.python.modules import time

class OdrclusterTasks:
	
	def __init__(self):
		self.LOGGER = _Logger("OdrclusterTasks", MessageManager.RB_WEBSPHERE_WVE)
	#endDef
	
	def createCluster (self, clusterName, modelJVM, nodes, namePrefix, serversPerNode, weight, serverTemplate, transportStartPort, transportInc, wasVersion):
		self.LOGGER.traceEnter( [clusterName, modelJVM, nodes, namePrefix, serversPerNode, weight, serverTemplate, transportStartPort, transportInc, wasVersion])
	
		#---------------------------------------------------------
		# We assume that there is only one cell, and we are on it
		#---------------------------------------------------------
		cellname = AdminControl.getCell()
		cell = AdminConfig.getid("/Cell:"+cellname+"/")
	
		#---------------------------------------------------------
		# Construct the attribute list to be used in creating a ServerCluster 
		# attribute.	  
		#---------------------------------------------------------
	
		name_attr = ["name", clusterName]
		desc_attr = ["description", clusterName+" cluster"]
		pref_attr = ["preferLocal", "true"]
		statem_attr = ["stateManagement", [["initialState", "STOP"]]]
		type_attr = ["serverType", "ONDEMAND_ROUTER"]
		attrs = [name_attr, desc_attr, pref_attr, statem_attr, type_attr]
	
		#---------------------------------------------------------
		# Create the server cluster 
		#---------------------------------------------------------
	
		cluster = AdminConfig.getid("/Cell:"+cellname+"/ServerCluster:"+clusterName)
	
		if (len(cluster) == 0):
			self.LOGGER.info("creating the ServerCluster " + clusterName )
			cluster = AdminConfig.create("ServerCluster", cell, attrs)
		else:
			self.LOGGER.info("ServerCluster "+clusterName+" already exists...")
		#endIf 
	
		#---------------------------------------------------------
		# For each node, create the required number of servers
		# 
		#---------------------------------------------------------
		cloneIndex=1
		for nodeName in nodes.split(","):
			self.LOGGER.trace("creating servers on node: " + nodeName)
			node = AdminConfig.getid("/Node:"+nodeName+"/")
		  	if (len(node) == 0):
		  		raise ("Error: Node not found in WAS Config"
		  			+ ".  The node " + nodeName + " could not be found in the WebSphere configuration"
		  			+ ".  The cluster cannot be created before the managed profiles are created."
		  			+ ".  Please verify that the node exists and has been federated into the cell.")
		  	else:
		  		modelServer  = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+modelJVM+"/")
				portIndex = 1  #forStart
				while (portIndex <= int(serversPerNode)):  #forTest
					serverName = namePrefix + str(cloneIndex)
					self.LOGGER.trace("processing server: " + serverName + " on node: " + nodeName)
					name_attr = ["memberName", serverName]
					weight_attr = ["weight", weight]
					attrs = [name_attr, weight_attr]
					serverJVM  = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/")
					if (len(serverJVM) == 0):
						self.LOGGER.info("creating server "+ serverName + " on node "+nodeName)
						# if serverTemplate is defined then we'll need to grab the containment path for the
						# template we want to use when we create the cluster. If modelServer is also defined
						# then serverTemplate is ignored. You cannot do both.
					 	serverTpl = None
						if (len(serverTemplate) > 0):
							serverTpl = AdminConfig.listTemplates('Server', serverTemplate)
							# fixing a bug whereby listing the template would return the zOS and non zOS serverTpl (we only want non zOS)
							if (serverTemplate in ['defaultProcessServer', 'http_sip_odr_server', 'sip_odr_server', 'odr']):
								i=0 
								for tpl in serverTpl.split(newline):
									if (i == 0):
										serverTpl = tpl 
										break
									i=i+1
								#endFor
							#endIf
						#endIf
						self.LOGGER.trace("modelServer:" + str(modelServer))
						self.LOGGER.trace("serverTpl:" + str(serverTpl))
						if (len(modelServer) > 0):
							print "\t--## Using Model %10s : %10s ##--" % (AdminConfig.showAttribute(modelServer, 'name'), serverName)
							server = AdminConfig.createClusterMember(cluster, node, attrs, modelServer)
						elif (serverTpl != None and len(serverTpl) > 0):
							print "--## Template: " + serverTemplate + " to create " + serverName + " ## --"
							server = AdminConfig.createClusterMember(cluster, node, attrs, serverTpl)
						else:
							print "--## Creating cluster members without Template or Model Server ##--"
							server = AdminConfig.createClusterMember(cluster, node, attrs)
						#endIf
						serverJVM = AdminConfig.getid("/Cell:"+cellname+"/Node:"+nodeName+"/Server:"+serverName+"/")
					else:
						print "cluster: ServerClone "+serverName+" already exists..."
						## make sure the server is part of this cluster already, if it isn't we have a problem
						currentCluster = AdminConfig.showAttribute(serverJVM, "clusterName")
						if (currentCluster != clusterName):
							raise ("Error: Server " + serverName + " is already a member of cluster " + currentCluster
								+ ".  The cluster member PREFIX property is " + namePrefix
								+ ".  Please verify the PREFIX property in cluster.properties")
						#endIf
					#endIf
					self.updateServerPorts(wasVersion, nodeName, serverName, portIndex, transportInc, transportStartPort)
					portIndex += 1  #forNext
					cloneIndex += 1  #forNext
				#endWhile 
			#endIf - the node id was found and valid
		#endFor
	
		#---------------------------------------------------------
		# save changes 
		# 
		#---------------------------------------------------------
	
		print "cluster: saving config changes."
		AdminConfig.save()
	
		#---------------------------------------------------------
		# Ask the ClusterMgr to refresh its list of clusters 
		# 
		#---------------------------------------------------------
	
		clusterMgr = AdminControl.completeObjectName("type=ClusterMgr,cell="+cellname+",*")
		if (len(clusterMgr) == 0):
			print "cluster: Error -- clusterMgr MBean not found for cell "+cellname
			return 
		#endIf 
		AdminControl.invoke(clusterMgr, "retrieveClusters")
	
		# Syncronize the nodes
		AdminHelper.syncCell()
	
		#---------------------------------------------------------
		# Ask the Cluster MBean to start the cluster
		# 
		#---------------------------------------------------------
	
		#		print "--## Sleeping 5 seconds ##--"
		#		time.sleep(5)
		
		#		cluster = AdminControl.completeObjectName("type=Cluster,name="+clusterName+",*" )
		#		print "--## Starting Cluster: %20s ##--" % clusterName
		#		AdminControl.invoke(cluster, "start" )
	
	#endDef
	
	def deleteCluster(self, clusterName):
		self.LOGGER.info('Deleting cluster: ' + clusterName)
		cellName = AdminControl.getCell()
		clusterId = AdminConfig.getid("/Cell:" + cellName + "/ServerCluster:" + clusterName + "/")
		AdminTask.deleteCluster(clusterId)
	#endDef
	
	# note that any changes to this action will effect wp_common_configure_update_wpconfig_ports since this action assumes a certain order
	def updateServerPorts(self, wasVersion, nodeName, serverName, serverNumber=1, transportInc=0, transportStartPort=0):
		self.LOGGER.traceEnter([wasVersion, nodeName, serverName, serverNumber, transportInc, transportStartPort])
		endPointNames = [ "BOOTSTRAP_ADDRESS", 
		"CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS",
		"CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", 
		"DCS_UNICAST_ADDRESS",
		"ORB_LISTENER_ADDRESS",
		"SAS_SSL_SERVERAUTH_LISTENER_ADDRESS",
		"SOAP_CONNECTOR_ADDRESS",
		"WC_defaulthost", 
		"WC_defaulthost_secure",
		"DRS_CLIENT_ADDRESS",
		"PROXY_HTTP_ADDRESS",
		"PROXY_HTTPS_ADDRESS"]
		
		wasVersInt = int(wasVersion)
		
		#  The following are added in WAS 8.0
		if (wasVersInt > 70):
			endPointNames.append("OVERLAY_UDP_LISTENER_ADDRESS")
			endPointNames.append("OVERLAY_TCP_LISTENER_ADDRESS")
		#endIf
		
		#  Not sure when these wer added, but they are missing in WAS 8.5
		## may need to be added earlier if PMRs are raised.
		if (wasVersInt > 80):
			endPointNames.append("PROXY_SIP_ADDRESS")
			endPointNames.append("PROXY_SIPS_ADDRESS")
		#endIf
		
		# Now we're going to adjust the tcp transports if TRANSPORT_STARTING_POINT was defined
		if (transportStartPort > 0):
			myPort = ((serverNumber-1) * transportInc) + transportStartPort
			for sEPoint in endPointNames:
				sAttrs = '[-nodeName ' + nodeName + ' -endPointName ' + sEPoint + ' -port ' + str(myPort) + ' -modifyShared]'
				print "--## Setting %10s:%40s == %5s ##--" % (serverName, sEPoint, str(myPort))
				AdminTask.modifyServerPort(serverName, sAttrs)
				myPort = myPort+1
			#endFor
		#endif
		self.LOGGER.traceExit()
	#endDef
#endClass

#-----------------------------------------------------------------
# Main
#-----------------------------------------------------------------

# relies on extra properties
##  -cellProperties configure.properties in CELL scope
##  -properties configure.properties in cluster scope for the new cluster
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:;cellProperties:;action:' )

propFile=optDict['properties']
cellFile=optDict['cellProperties']

cellProps = SystemUtils.getPropertyDict(cellFile)
properties = SystemUtils.getPropertyDict(propFile)

clusterName = str(properties["CLUSTER_NAME"])
modelServer = str(None)
if (properties.has_key("MODEL_SERVER")):
	modelServer = str(properties["MODEL_SERVER"])
#endIf
nodes = str(properties["NODES"])
serverTemplate = str(None)
if (properties.has_key("SERVER_TEMPLATE")):
	serverTemplate = str(properties["SERVER_TEMPLATE"])
#endIf
transportStartPort = 0
if (properties.has_key("TRANSPORT_STARTING_POINT")):
	if (len(properties["TRANSPORT_STARTING_POINT"]) > 0):
		transportStartPort = int(properties["TRANSPORT_STARTING_POINT"])
	#endif
#endif
transportInc = 0
if (properties.has_key("TRANSPORT_NODE_INCREMENTOR")):
	if (len(properties["TRANSPORT_NODE_INCREMENTOR"]) > 0):
		transportInc = int(properties["TRANSPORT_NODE_INCREMENTOR"])
#endif
# remove quotes from nodes property
prefix = str(properties["PREFIX"])
perNode = int(properties["PERNODE"])
weight = 2
if (properties.has_key("WEIGHT")):
	if (len(properties["WEIGHT"]) > 0):
		weight = int(properties["WEIGHT"])
#endif
		
wasVersion = cellProps["WAS_VERSION"]

mode = optDict['mode']
action = optDict['action']

odrclusterTasks = OdrclusterTasks()

if (mode == MODE_EXECUTE):
	if action == 'createCluster':
		odrclusterTasks.createCluster(clusterName, modelServer, nodes, prefix, perNode, weight, serverTemplate, transportStartPort, transportInc, wasVersion)
	elif action == 'deleteCluster':
		odrclusterTasks.deleteCluster(clusterName)
	else:
		raise "Unsupported action supplied: " + action
	AdminHelper.saveAndSyncCell()

else:
	raise "Unsupported MODE supplied: " + mode
#endIf