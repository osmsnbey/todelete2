--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create schema for DB2 UDB
-- Process this script in the DB2 command line processor
----------------------------------------------------------------------
-- The following variable needs to be changed for customization and
-- before running this script.
-- @SCHEMA@ = Schema name
----------------------------------------------------------------------
-- Example:
--             db2 connect to BPEDB
--             db2 -tf createSchema.sql
-- The schema assumes existing tablespaces that should have been
-- created before using createTablespace.sql script.


-------------------
-- Create tables --
-------------------

CREATE TABLE @SCHEMA@.SCHEMA_VERSION
(
  SCHEMA_VERSION                     INTEGER                           NOT NULL ,
  DATA_MIGRATION                     SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SCHEMA_VERSION )
) IN TEMPLATE;

CREATE TABLE @SCHEMA@.PROCESS_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  DEFINITION_NAME                    VARCHAR(220)                               ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  EXECUTION_MODE                     INTEGER                           NOT NULL ,
  IS_SHARED                          SMALLINT                          NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  VALID_FROM                         TIMESTAMP                         NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR(250)                               ,
  CREATED                            TIMESTAMP                         NOT NULL ,
  AUTO_DELETE                        SMALLINT                          NOT NULL ,
  EXTENDED_AUTO_DELETE               INTEGER                           NOT NULL ,
  VERSION                            VARCHAR(32)                                ,
  SCHEMA_VERSION                     INTEGER                           NOT NULL ,
  ABSTRACT_BASE_NAME                 VARCHAR(254)                               ,
  S_BEAN_LOOKUP_NAME                 VARCHAR(254)                               ,
  S_BEAN60_LOOKUP_NAME               VARCHAR(254)                               ,
  E_BEAN_LOOKUP_NAME                 VARCHAR(254)                               ,
  PROCESS_BASE_NAME                  VARCHAR(254)                               ,
  S_BEAN_HOME_NAME                   VARCHAR(254)                               ,
  E_BEAN_HOME_NAME                   VARCHAR(254)                               ,
  BPEWS_UTID                         CHAR(16)            FOR BIT DATA           ,
  WPC_UTID                           CHAR(16)            FOR BIT DATA           ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  ADMINISTRATOR_QTID                 CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  A_TKTIDFOR_ACTS                    CHAR(16)            FOR BIT DATA           ,
  COMPENSATION_SPHERE                INTEGER                           NOT NULL ,
  AUTONOMY                           INTEGER                           NOT NULL ,
  CAN_CALL                           SMALLINT                          NOT NULL ,
  CAN_INITIATE                       SMALLINT                          NOT NULL ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  IGNORE_MISSING_DATA                INTEGER                           NOT NULL ,
  PRIMARY KEY ( PTID )
) IN BPETS8K;

ALTER TABLE @SCHEMA@.PROCESS_TEMPLATE_B_T VOLATILE;

CREATE UNIQUE INDEX @SCHEMA@.PTB_NAME_VALID ON @SCHEMA@.PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM
);

CREATE INDEX @SCHEMA@.PTB_NAME_VF_STATE ON @SCHEMA@.PROCESS_TEMPLATE_B_T
(   
  NAME, VALID_FROM, STATE, PTID
);

CREATE INDEX @SCHEMA@.PTB_TOP_APP ON @SCHEMA@.PROCESS_TEMPLATE_B_T
(   
  APPLICATION_NAME
);

CREATE INDEX @SCHEMA@.PTB_STATE_PTID ON @SCHEMA@.PROCESS_TEMPLATE_B_T
(   
  STATE, PTID
);

CREATE INDEX @SCHEMA@.PTB_NAME ON @SCHEMA@.PROCESS_TEMPLATE_B_T
(   
  PTID, NAME
);

CREATE TABLE @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(220)                      NOT NULL ,
  VALUE                              VARCHAR(254)                               ,
  PRIMARY KEY ( PTID, ATTR_KEY )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.PTAB_PTID ON @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.SCOPE_TEMPLATE_B_T
(
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_STID                        CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COMP_HANDLER_ATID                  CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTS_EHTID                   CHAR(16)            FOR BIT DATA           ,
  FOR_EACH_ATID                      CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  ISOLATED                           SMALLINT                          NOT NULL ,
  IS_COMPENSABLE                     SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  IS_IMPLICIT                        SMALLINT                          NOT NULL ,
  PRIMARY KEY ( STID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.ST_PTID ON @SCHEMA@.SCOPE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.SERVICE_TEMPLATE_B_T
(
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_UTID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  OPERATION_NAME                     VARCHAR(254)                      NOT NULL ,
  NAME                               VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  TRANSACTION_BEHAVIOR               INTEGER                           NOT NULL ,
  IS_TWO_WAY                         SMALLINT                          NOT NULL ,
  NUMBER_OF_RECEIVE_ACTS             INTEGER                           NOT NULL ,
  PRIMARY KEY ( VTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.VT_VTID_PTUTID ON @SCHEMA@.SERVICE_TEMPLATE_B_T
(   
  VTID, PORT_TYPE_UTID
);

CREATE INDEX @SCHEMA@.VT_PTID ON @SCHEMA@.SERVICE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.ACTIVITY_SERVICE_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR(220)                               ,
  INPUT_CTID                         CHAR(16)            FOR BIT DATA           ,
  OUTPUT_CTID                        CHAR(16)            FOR BIT DATA           ,
  LINK_ORDER_NUMBER                  INTEGER                                    ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  UNDO_MSG_TEMPLATE                  BLOB(1073741823)                           ,
  PRIMARY KEY ( ATID, VTID, KIND )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.AST_PTID ON @SCHEMA@.ACTIVITY_SERVICE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.SERVICE_LOCATION_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  MODULE_NAME                        VARCHAR(220)                      NOT NULL ,
  EXPORT_NAME                        CLOB(4096)                                 ,
  COMPONENT_NAME                     CLOB(4096)                        NOT NULL ,
  PRIMARY KEY ( PTID, VTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.SLT_PTID ON @SCHEMA@.SERVICE_LOCATION_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.SERVICE_FAULT_TEMPLATE_B_T
(
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(220)                      NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                       NOT NULL ,
  PRIMARY KEY ( VTID, FAULT_NAME )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.SFT_PTID ON @SCHEMA@.SERVICE_FAULT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.ACTIVITY_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_STID                        CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTS_STID                    CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IMPLEMENTS_EHTID                   CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_ATID            CHAR(16)            FOR BIT DATA           ,
  IS_EVENT_HANDLER_END_ACTIVITY      SMALLINT                          NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  NAME                               VARCHAR(220)                               ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  JOIN_CONDITION                     INTEGER                           NOT NULL ,
  JOIN_CONDITION_NAME                VARCHAR(254)                               ,
  EXIT_CONDITION                     INTEGER                           NOT NULL ,
  EXIT_CONDITION_NAME                VARCHAR(254)                               ,
  EXIT_CONDITION_EXECUTE_AT          INTEGER                           NOT NULL ,
  NUMBER_OF_LINKS                    INTEGER                           NOT NULL ,
  SUPPRESS_JOIN_FAILURE              SMALLINT                          NOT NULL ,
  SOURCES_TYPE                       INTEGER                           NOT NULL ,
  TARGETS_TYPE                       INTEGER                           NOT NULL ,
  CREATE_INSTANCE                    SMALLINT                                   ,
  IS_END_ACTIVITY                    SMALLINT                          NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  HAS_OWN_FAULT_HANDLER              SMALLINT                          NOT NULL ,
  COMPLEX_BEGIN_ATID                 CHAR(16)            FOR BIT DATA           ,
  CORRESPONDING_END_ATID             CHAR(16)            FOR BIT DATA           ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA           ,
  HAS_CROSSING_LINK                  SMALLINT                                   ,
  SCRIPT_NAME                        VARCHAR(254)                               ,
  AFFILIATION                        INTEGER                           NOT NULL ,
  TRANSACTION_BEHAVIOR               INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  FAULT_NAME_UTID                    CHAR(16)            FOR BIT DATA           ,
  FAULT_VARIABLE_CTID                CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  IS_TRANSACTIONAL                   SMALLINT                          NOT NULL ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  ENCLOSED_FTID                      CHAR(16)            FOR BIT DATA           ,
  EXPRESSION                         CLOB(3900K)                                ,
  EXIT_EXPRESSION                    CLOB(3900K)                                ,
  HAS_INBOUND_LINK                   SMALLINT                          NOT NULL ,
  COMPENSATION_STID                  CHAR(16)            FOR BIT DATA           ,
  A_TKTID                            CHAR(16)            FOR BIT DATA           ,
  CUSTOM_IMPLEMENTATION              BLOB(3900K)                                ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  EXIT_EXPRESSION_MAP                BLOB(3900K)                                ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( ATID )
) IN BPETS8K;

CREATE INDEX @SCHEMA@.ATB_PTID ON @SCHEMA@.ACTIVITY_TEMPLATE_B_T
(   
  PTID
);

CREATE INDEX @SCHEMA@.ATB_NAME ON @SCHEMA@.ACTIVITY_TEMPLATE_B_T
(   
  NAME
);

CREATE INDEX @SCHEMA@.ATB_KIND_BR_NAME ON @SCHEMA@.ACTIVITY_TEMPLATE_B_T
(   
  KIND, BUSINESS_RELEVANCE, NAME
);

CREATE TABLE @SCHEMA@.ALARM_TEMPLATE_B_T
(
  XTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EXPRESSION                         BLOB(3900K)                                ,
  EXPRESSION_NAME                    VARCHAR(254)                               ,
  DURATION                           VARCHAR(254)                               ,
  CALENDAR                           VARCHAR(254)                               ,
  CALENDAR_JNDI_NAME                 VARCHAR(254)                               ,
  REPEAT_KIND                        INTEGER                           NOT NULL ,
  REPEAT_EXPRESSION                  BLOB(3900K)                                ,
  REPEAT_EXP_NAME                    VARCHAR(254)                               ,
  ON_ALARM_ORDER_NUMBER              INTEGER                                    ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  REPEAT_EXPRESSION_MAP              BLOB(3900K)                                ,
  PRIMARY KEY ( XTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.XT_PTID ON @SCHEMA@.ALARM_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.FAULT_HANDLER_TEMPLATE_B_T
(
  FTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  CTID                               CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA           ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  FAULT_LINK_SOURCE_ATID             CHAR(16)            FOR BIT DATA           ,
  FAULT_LINK_TARGET_ATID             CHAR(16)            FOR BIT DATA           ,
  IMPLEMENTATION_ATID                CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME_UTID                    CHAR(16)            FOR BIT DATA           ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  PRIMARY KEY ( FTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.FT_PTID ON @SCHEMA@.FAULT_HANDLER_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.LINK_TEMPLATE_B_T
(
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  FLOW_BEGIN_ATID                    CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_ATID            CHAR(16)            FOR BIT DATA           ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  NAME                               VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  LIFETIME                           INTEGER                           NOT NULL ,
  TRANSITION_CONDITION               INTEGER                           NOT NULL ,
  TRANSITION_CONDITION_NAME          VARCHAR(254)                               ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  SEQUENCE_NUMBER                    INTEGER                           NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  EXPRESSION                         CLOB(3900K)                                ,
  IS_INBOUND_LINK                    SMALLINT                          NOT NULL ,
  OUTBOUND_ATID                      CHAR(16)            FOR BIT DATA           ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.LNK_PTID ON @SCHEMA@.LINK_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.LINK_BOUNDARY_TEMPLATE_B_T
(
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  BOUNDARY_STID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_OUTMOST_BOUNDARY                SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SOURCE_ATID, TARGET_ATID, BOUNDARY_STID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.BND_PTID ON @SCHEMA@.LINK_BOUNDARY_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.RESET_TEMPLATE_B_T
(
  LOOP_ENTRY_ATID                    CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOOP_BODY_ATID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PRIMARY KEY ( LOOP_ENTRY_ATID, LOOP_BODY_ATID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.RST_PTID ON @SCHEMA@.RESET_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.VARIABLE_MAPPING_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE_CTID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_CTID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARAMETER                          VARCHAR(254)                      NOT NULL ,
  PRIMARY KEY ( PTID, ATID, VTID, SOURCE_CTID, TARGET_CTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.VMT_TCTID ON @SCHEMA@.VARIABLE_MAPPING_TEMPLATE_B_T
(   
  PTID, ATID, VTID, TARGET_CTID
);

CREATE TABLE @SCHEMA@.VARIABLE_TEMPLATE_B_T
(
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA           ,
  FTID                               CHAR(16)            FOR BIT DATA           ,
  DERIVED                            SMALLINT                          NOT NULL ,
  DISPLAY_ID                         INTEGER                           NOT NULL ,
  FROM_SPEC                          INTEGER                           NOT NULL ,
  NAME                               VARCHAR(254)                      NOT NULL ,
  MESSAGE_TEMPLATE                   BLOB(3900K)                                ,
  IS_QUERYABLE                       SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  GENERATED_BY                       VARCHAR(220)                               ,
  PRIMARY KEY ( CTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.CT_PTID ON @SCHEMA@.VARIABLE_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.VARIABLE_STACK_TEMPLATE_B_T
(
  VSID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FTID                               CHAR(16)            FOR BIT DATA           ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  NAME                               VARCHAR(255)                      NOT NULL ,
  PRIMARY KEY ( VSID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.VS_PTID ON @SCHEMA@.VARIABLE_STACK_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.ACTIVITY_FAULT_TEMPLATE_B_T
(
  AFID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                      NOT NULL ,
  FAULT_UTID                         CHAR(16)            FOR BIT DATA           ,
  MESSAGE                            BLOB(3900K)                       NOT NULL ,
  PRIMARY KEY ( AFID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.AF_PTID ON @SCHEMA@.ACTIVITY_FAULT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.PARTNER_LINK_TEMPLATE_B_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARTNER_LINK_NAME                  VARCHAR(220)                      NOT NULL ,
  PROCESS_NAME                       VARCHAR(220)                               ,
  TARGET_NAMESPACE                   VARCHAR(250)                               ,
  RESOLUTION_SCOPE                   INTEGER                           NOT NULL ,
  MY_ROLE                            SMALLINT                          NOT NULL ,
  MY_ROLE_IMPL                       BLOB(3900K)                                ,
  MY_ROLE_LOCALNAME                  VARCHAR(220)                               ,
  MY_ROLE_NAMESPACE                  VARCHAR(220)                               ,
  THEIR_ROLE                         SMALLINT                          NOT NULL ,
  THEIR_ROLE_IMPL                    BLOB(3900K)                                ,
  THEIR_ROLE_LOCALNAME               VARCHAR(220)                               ,
  THEIR_ROLE_NAMESPACE               VARCHAR(220)                               ,
  PRIMARY KEY ( PTID, PARTNER_LINK_NAME )
) IN TEMPLATE;

CREATE TABLE @SCHEMA@.URI_TEMPLATE_B_T
(
  UTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  URI                                VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( UTID )
) IN TEMPLATE;

CREATE UNIQUE INDEX @SCHEMA@.UT_PTID_URI ON @SCHEMA@.URI_TEMPLATE_B_T
(   
  PTID, URI
);

CREATE INDEX @SCHEMA@.UT_UTID_URI ON @SCHEMA@.URI_TEMPLATE_B_T
(   
  UTID, URI
);

CREATE TABLE @SCHEMA@.CLIENT_SETTING_TEMPLATE_B_T
(
  CSID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA           ,
  SETTINGS                           BLOB(3900K)                                ,
  PRIMARY KEY ( CSID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.CS_PTID ON @SCHEMA@.CLIENT_SETTING_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.ASSIGN_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ORDER_NUMBER                       INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_SPEC                          INTEGER                           NOT NULL ,
  FROM_VARIABLE_CTID                 CHAR(16)            FOR BIT DATA           ,
  FROM_PARAMETER2                    VARCHAR(254)                               ,
  FROM_PARAMETER3                    BLOB(1073741823)                           ,
  FROM_PARAMETER3_LANGUAGE           INTEGER                           NOT NULL ,
  TO_SPEC                            INTEGER                           NOT NULL ,
  TO_VARIABLE_CTID                   CHAR(16)            FOR BIT DATA           ,
  TO_PARAMETER2                      VARCHAR(254)                               ,
  TO_PARAMETER3                      BLOB(3900K)                                ,
  TO_PARAMETER3_LANGUAGE             INTEGER                           NOT NULL ,
  FROM_EXPRESSION_MAP                BLOB(3900K)                                ,
  TO_EXPRESSION_MAP                  BLOB(3900K)                                ,
  PRIMARY KEY ( ATID, ORDER_NUMBER )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.ASTB_PTID ON @SCHEMA@.ASSIGN_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.CORRELATION_SET_TEMPLATE_B_T
(
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(255)                      NOT NULL ,
  PRIMARY KEY ( COID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.CSTB_PTID ON @SCHEMA@.CORRELATION_SET_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.CORRELATION_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_FOR_EVENT_HANDLER               SMALLINT                          NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  INITIATE                           INTEGER                           NOT NULL ,
  PATTERN                            INTEGER                           NOT NULL ,
  PRIMARY KEY ( ATID, VTID, COID, IS_FOR_EVENT_HANDLER )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.COID_PTID ON @SCHEMA@.CORRELATION_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T
(
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SEQUENCE_NUMBER                    INTEGER                           NOT NULL ,
  PROPERTY_UTID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  PROPERTY_NAME                      VARCHAR(255)                      NOT NULL ,
  JAVA_TYPE                          VARCHAR(255)                      NOT NULL ,
  MSG_TYPE_UTID                      CHAR(16)            FOR BIT DATA  NOT NULL ,
  MSG_TYPE_NAME                      VARCHAR(255)                      NOT NULL ,
  MSG_TYPE_KIND                      INTEGER                           NOT NULL ,
  PROPERTY_TYPE_UTID                 CHAR(16)            FOR BIT DATA           ,
  PROPERTY_TYPE_NAME                 VARCHAR(255)                               ,
  PART                               VARCHAR(255)                               ,
  QUERY                              VARCHAR(255)                               ,
  QUERY_LANGUAGE                     INTEGER                           NOT NULL ,
  IS_DEFINED_INLINE                  SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PAID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.PATB_COID_UTID ON @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T
(   
  COID, MSG_TYPE_UTID
);

CREATE INDEX @SCHEMA@.PATB_PTID_UTIDS ON @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T
(   
  PTID, MSG_TYPE_UTID, PROPERTY_UTID
);

CREATE TABLE @SCHEMA@.EVENT_HANDLER_TEMPLATE_B_T
(
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IMPL_ATID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA           ,
  INPUT_CTID                         CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  KIND                               INTEGER                           NOT NULL ,
  PRIMARY KEY ( EHTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.EHT_PTID ON @SCHEMA@.EVENT_HANDLER_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.EHALARM_TEMPLATE_B_T
(
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  EXPRESSION                         BLOB(3900K)                                ,
  EXPRESSION_NAME                    VARCHAR(254)                               ,
  DURATION                           VARCHAR(254)                               ,
  CALENDAR                           VARCHAR(254)                               ,
  CALENDAR_JNDI_NAME                 VARCHAR(254)                               ,
  REPEAT_KIND                        INTEGER                           NOT NULL ,
  REPEAT_EXPRESSION                  BLOB(3900K)                                ,
  REPEAT_EXP_NAME                    VARCHAR(254)                               ,
  REPEAT_DURATION                    VARCHAR(254)                               ,
  REPEAT_CALENDAR                    VARCHAR(254)                               ,
  REPEAT_CALENDAR_JNDI_NAME          VARCHAR(254)                               ,
  EXPRESSION_MAP                     BLOB(3900K)                                ,
  REPEAT_EXPRESSION_MAP              BLOB(3900K)                                ,
  PRIMARY KEY ( EHTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.EXT_PTID ON @SCHEMA@.EHALARM_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.CUSTOM_EXT_TEMPLATE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  TEMPLATE_INFO                      BLOB(3900K)                                ,
  INSTANCE_INFO                      BLOB(3900K)                                ,
  PRIMARY KEY ( PKID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.CETB_PTID ON @SCHEMA@.CUSTOM_EXT_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.CUSTOM_STMT_TEMPLATE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  PURPOSE                            VARCHAR(220)                      NOT NULL ,
  STATEMENT                          BLOB(3900K)                                ,
  PRIMARY KEY ( PKID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.CST_PTID_NS_LN_P ON @SCHEMA@.CUSTOM_STMT_TEMPLATE_B_T
(   
  PTID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE TABLE @SCHEMA@.PROCESS_CELL_MAP_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CELL                               VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( PTID, CELL )
) IN TEMPLATE;

CREATE TABLE @SCHEMA@.ACTIVITY_TEMPLATE_ATTR_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(192)                      NOT NULL ,
  ATTR_VALUE                         VARCHAR(254)                               ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PRIMARY KEY ( ATID, ATTR_KEY )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.ATAB_PTID ON @SCHEMA@.ACTIVITY_TEMPLATE_ATTR_B_T
(   
  PTID
);

CREATE INDEX @SCHEMA@.ATAB_VALUE ON @SCHEMA@.ACTIVITY_TEMPLATE_ATTR_B_T
(   
  ATTR_VALUE
);

CREATE TABLE @SCHEMA@.FOR_EACH_TEMPLATE_B_T
(
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COUNTER_CTID                       CHAR(16)            FOR BIT DATA  NOT NULL ,
  SUCCESSFUL_BRANCHES_ONLY           SMALLINT                          NOT NULL ,
  START_COUNTER_LANGUAGE             INTEGER                           NOT NULL ,
  FINAL_COUNTER_LANGUAGE             INTEGER                           NOT NULL ,
  COMPLETION_CONDITION_LANGUAGE      INTEGER                           NOT NULL ,
  START_COUNTER_EXPRESSION           BLOB(3900K)                                ,
  FINAL_COUNTER_EXPRESSION           BLOB(3900K)                                ,
  COMPLETION_COND_EXPRESSION         BLOB(3900K)                                ,
  FOR_EACH_METHOD                    VARCHAR(254)                               ,
  START_COUNTER_EXPRESSION_MAP       BLOB(3900K)                                ,
  FINAL_COUNTER_EXPRESSION_MAP       BLOB(3900K)                                ,
  COMPLETION_COND_EXPRESSION_MAP     BLOB(3900K)                                ,
  PRIMARY KEY ( ATID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.FET_PTID ON @SCHEMA@.FOR_EACH_TEMPLATE_B_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.GRAPHICAL_PROCESS_MODEL_T
(
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE                             VARCHAR(100)                      NOT NULL ,
  KIND                               VARCHAR(100)                      NOT NULL ,
  GRAPHICAL_DATA                     BLOB(10000K)                               ,
  ID_MAPPING                         BLOB(10000K)                               ,
  PRIMARY KEY ( PTID, SOURCE, KIND )
) IN TEMPLATE;

CREATE TABLE @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  QUERY_TYPE                         INTEGER                           NOT NULL ,
  PRIMARY KEY ( PKID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.QVT_PTID ON @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T
(   
  PTID
);

CREATE TABLE @SCHEMA@.STAFF_QUERY_TEMPLATE_T
(
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  T_QUERY                            VARCHAR(32)                       NOT NULL ,
  QUERY                              BLOB(3900K)                       NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  STAFF_VERB                         BLOB(3900K)                                ,
  PRIMARY KEY ( QTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.SQT_HASH ON @SCHEMA@.STAFF_QUERY_TEMPLATE_T
(   
  ASSOCIATED_OID, HASH_CODE, T_QUERY, ASSOCIATED_OBJECT_TYPE
);

CREATE TABLE @SCHEMA@.PROCESS_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  PENDING_REQUEST                    INTEGER                           NOT NULL ,
  CREATED                            TIMESTAMP                                  ,
  STARTED                            TIMESTAMP                                  ,
  COMPLETED                          TIMESTAMP                                  ,
  LAST_STATE_CHANGE                  TIMESTAMP                                  ,
  LAST_MODIFIED                      TIMESTAMP                                  ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  PARENT_NAME                        VARCHAR(220)                               ,
  TOP_LEVEL_NAME                     VARCHAR(220)                      NOT NULL ,
  COMPENSATION_SPHERE_NAME           VARCHAR(100)                               ,
  STARTER                            VARCHAR(128)                               ,
  DESCRIPTION                        VARCHAR(254)                               ,
  INPUT_SNID                         CHAR(16)            FOR BIT DATA           ,
  INPUT_ATID                         CHAR(16)            FOR BIT DATA           ,
  INPUT_VTID                         CHAR(16)            FOR BIT DATA           ,
  OUTPUT_SNID                        CHAR(16)            FOR BIT DATA           ,
  OUTPUT_ATID                        CHAR(16)            FOR BIT DATA           ,
  OUTPUT_VTID                        CHAR(16)            FOR BIT DATA           ,
  FAULT_NAME                         VARCHAR(254)                               ,
  TOP_LEVEL_PIID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_AIID                        CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  TERMIN_ON_REC                      SMALLINT                          NOT NULL ,
  AWAITED_SUB_PROC                   SMALLINT                          NOT NULL ,
  IS_CREATING                        SMALLINT                          NOT NULL ,
  PREVIOUS_STATE                     INTEGER                                    ,
  EXECUTING_ISOLATED_SCOPE           SMALLINT                          NOT NULL ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  RESUMES                            TIMESTAMP                                  ,
  PENDING_SKIP_REQUEST               SMALLINT                          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.PROCESS_INSTANCE_B_T VOLATILE;

CREATE UNIQUE INDEX @SCHEMA@.PIB_NAME ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  NAME
);

CREATE INDEX @SCHEMA@.PIB_TOP ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  TOP_LEVEL_PIID
);

CREATE INDEX @SCHEMA@.PIB_PAP ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  PARENT_PIID
);

CREATE INDEX @SCHEMA@.PIB_PAR ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  PARENT_AIID
);

CREATE INDEX @SCHEMA@.PIB_PTID ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  PTID
);

CREATE INDEX @SCHEMA@.PIB_PIID_STATE ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  PIID, STATE
);

CREATE INDEX @SCHEMA@.PIB_STATE ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  STATE
);

CREATE INDEX @SCHEMA@.PIB_PIID_PTID_STAT ON @SCHEMA@.PROCESS_INSTANCE_B_T
(   
  PIID, PTID, STATE, STARTER, STARTED
);

CREATE TABLE @SCHEMA@.SCOPE_INSTANCE_B_T
(
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_SIID                        CHAR(16)            FOR BIT DATA           ,
  STID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FEIID                    CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FOR_EACH_END_AIID        CHAR(16)            FOR BIT DATA           ,
  COMPENSATE_AIID                    CHAR(16)            FOR BIT DATA           ,
  PARENT_COMP_SIID                   CHAR(16)            FOR BIT DATA           ,
  LAST_COMP_SIID                     CHAR(16)            FOR BIT DATA           ,
  RUNNING_EVENT_HANDLERS             INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  NOTIFY_PARENT                      SMALLINT                          NOT NULL ,
  AWAITED_SCOPES                     INTEGER                           NOT NULL ,
  AWAITED_SUB_PROCESSES              INTEGER                           NOT NULL ,
  BPEL_EXCEPTION                     BLOB(1073741823)                           ,
  IS_ACTIVE                          SMALLINT                          NOT NULL ,
  INITIATED_COMP                     SMALLINT                          NOT NULL ,
  IS_TERMINATION_FROM_FOR_EACH       SMALLINT                          NOT NULL ,
  TOTAL_COMPL_NUMBER                 BIGINT                            NOT NULL ,
  SCOPE_COMPL_NUMBER                 BIGINT                            NOT NULL ,
  A_TKIID                            CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.SCOPE_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.SI_PI_ST_EH_STA_FE ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  PIID, STID, STATE, EHIID, ENCLOSING_FEIID
);

CREATE INDEX @SCHEMA@.SI_PI_ST_EH_ACT_FE ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  PIID, STID, IS_ACTIVE, EHIID, ENCLOSING_FEIID
);

CREATE INDEX @SCHEMA@.SI_PIID_PARSI ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  PIID, PARENT_SIID, IS_ACTIVE
);

CREATE INDEX @SCHEMA@.SI_PARCOMP_STA_ST ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  PARENT_COMP_SIID, STATE, STID
);

CREATE INDEX @SCHEMA@.SI_PIID_STATE ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  PIID, STATE
);

CREATE INDEX @SCHEMA@.SI_LAST_COMPSIID ON @SCHEMA@.SCOPE_INSTANCE_B_T
(   
  LAST_COMP_SIID
);

CREATE TABLE @SCHEMA@.ACTIVITY_INSTANCE_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  ENCLOSING_FEIID                    CHAR(16)            FOR BIT DATA           ,
  P_TKIID                            CHAR(16)            FOR BIT DATA           ,
  A_TKIID                            CHAR(16)            FOR BIT DATA           ,
  INVOKED_INSTANCE_ID                CHAR(16)            FOR BIT DATA           ,
  INVOKED_INSTANCE_TYPE              INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  TRANS_COND_VALUES                  VARCHAR(66)         FOR BIT DATA  NOT NULL ,
  NUMBER_LINKS_EVALUATED             INTEGER                           NOT NULL ,
  FINISHED                           TIMESTAMP                                  ,
  ACTIVATED                          TIMESTAMP                                  ,
  FIRST_ACTIVATED                    TIMESTAMP                                  ,
  STARTED                            TIMESTAMP                                  ,
  LAST_MODIFIED                      TIMESTAMP                                  ,
  LAST_STATE_CHANGE                  TIMESTAMP                                  ,
  OWNER                              VARCHAR(128)                               ,
  DESCRIPTION                        VARCHAR(254)                               ,
  LINK_ORDER_NUMBER                  INTEGER                                    ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  EXPIRES                            TIMESTAMP                                  ,
  CONTINUE_ON_ERROR                  SMALLINT                          NOT NULL ,
  UNHANDLED_EXCEPTION                BLOB(1073741823)                           ,
  STOP_REASON                        INTEGER                           NOT NULL ,
  PREVIOUS_STATE                     INTEGER                                    ,
  INVOCATION_COUNTER                 INTEGER                           NOT NULL ,
  FOR_EACH_START_COUNTER_VALUE       BIGINT                                     ,
  FOR_EACH_FINAL_COUNTER_VALUE       BIGINT                                     ,
  FOR_EACH_CURRENT_COUNTER_VALUE     BIGINT                                     ,
  FOR_EACH_COMPLETED_BRANCHES        BIGINT                                     ,
  FOR_EACH_FAILED_BRANCHES           BIGINT                                     ,
  FOR_EACH_MAX_COMPL_BRANCHES        BIGINT                                     ,
  FOR_EACH_AWAITED_BRANCHES          BIGINT                                     ,
  IS51_ACTIVITY                      SMALLINT                          NOT NULL ,
  MAY_HAVE_SUBPROCESS                SMALLINT                                   ,
  SKIP_REQUESTED                     SMALLINT                          NOT NULL ,
  JUMP_TARGET_ATID                   CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ACTIVITY_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.AIB_PI_ATID_EH_FE ON @SCHEMA@.ACTIVITY_INSTANCE_B_T
(   
  PIID, ATID, EHIID, ENCLOSING_FEIID
);

CREATE INDEX @SCHEMA@.AIB_PTID ON @SCHEMA@.ACTIVITY_INSTANCE_B_T
(   
  PTID
);

CREATE INDEX @SCHEMA@.AIB_PIID_STAT_AIID ON @SCHEMA@.ACTIVITY_INSTANCE_B_T
(   
  PIID, STATE, AIID, ACTIVATED
);

CREATE INDEX @SCHEMA@.AIB_AI_AT_STAT_PI ON @SCHEMA@.ACTIVITY_INSTANCE_B_T
(   
  AIID, ATID, STATE, PIID, OWNER, ACTIVATED
);

CREATE INDEX @SCHEMA@.AIB_SIID ON @SCHEMA@.ACTIVITY_INSTANCE_B_T
(   
  SIID
);

CREATE TABLE @SCHEMA@.VARIABLE_INSTANCE_B_T
(
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CTID, PIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.VARIABLE_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.CI_PIID ON @SCHEMA@.VARIABLE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.SCOPED_VARIABLE_INSTANCE_B_T
(
  SVIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  DATA                               BLOB(1073741823)                           ,
  DATA_IL                            VARCHAR(3000)       FOR BIT DATA           ,
  IS_ACTIVE                          SMALLINT                          NOT NULL ,
  IS_INITIALIZED                     SMALLINT                          NOT NULL ,
  IS_QUERYABLE                       SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SVIID )
) IN BPETS8K;

ALTER TABLE @SCHEMA@.SCOPED_VARIABLE_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.SVI_PI_CT_EH_FE ON @SCHEMA@.SCOPED_VARIABLE_INSTANCE_B_T
(   
  PIID, CTID, IS_ACTIVE, EHIID, FEIID
);

CREATE INDEX @SCHEMA@.SVI_CT_SI_EH_AC ON @SCHEMA@.SCOPED_VARIABLE_INSTANCE_B_T
(   
  SIID, CTID, IS_ACTIVE, EHIID
);

CREATE TABLE @SCHEMA@.STAFF_MESSAGE_INSTANCE_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID, KIND )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.STAFF_MESSAGE_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.SMI_PIID ON @SCHEMA@.STAFF_MESSAGE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.EVENT_INSTANCE_B_T
(
  EIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_TWO_WAY                         SMALLINT                          NOT NULL ,
  IS_PRIMARY_EVENT_INSTANCE          SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  EHTID                              CHAR(16)            FOR BIT DATA           ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  NEXT_POSTED_EVENT                  CHAR(16)            FOR BIT DATA           ,
  LAST_POSTED_EVENT                  CHAR(16)            FOR BIT DATA           ,
  POST_COUNT                         INTEGER                           NOT NULL ,
  MESSAGE                            BLOB(1073741823)                           ,
  REPLY_CONTEXT                      BLOB(3900k)                                ,
  POST_TIME                          TIMESTAMP                                  ,
  MAX_NUMBER_OF_POSTS                INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( EIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.EVENT_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.EI_PIID_PRIM ON @SCHEMA@.EVENT_INSTANCE_B_T
(   
  PIID, IS_PRIMARY_EVENT_INSTANCE, STATE
);

CREATE INDEX @SCHEMA@.EI_PIID_VTID ON @SCHEMA@.EVENT_INSTANCE_B_T
(   
  PIID, VTID, IS_PRIMARY_EVENT_INSTANCE
);

CREATE INDEX @SCHEMA@.EI_AIID ON @SCHEMA@.EVENT_INSTANCE_B_T
(   
  AIID
);

CREATE INDEX @SCHEMA@.EI_STATE_VTID ON @SCHEMA@.EVENT_INSTANCE_B_T
(   
  VTID, STATE, EIID, AIID, PIID
);

CREATE TABLE @SCHEMA@.REQUEST_INSTANCE_B_T
(
  RIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  INSTANTIATING                      SMALLINT                          NOT NULL ,
  REPLY_CONTEXT                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( RIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.REQUEST_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.RI_PIID_VTID_EHIID ON @SCHEMA@.REQUEST_INSTANCE_B_T
(   
  PIID, VTID
);

CREATE TABLE @SCHEMA@.PARTNER_LINK_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  ENDPOINT_REFERENCE                 BLOB(3900k)                                ,
  SERVICE_DEFINITION                 BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, NAME )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.PARTNER_LINK_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.PA_PIID ON @SCHEMA@.PARTNER_LINK_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.VARIABLE_SNAPSHOT_B_T
(
  SNID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  COPY_VERSION                       SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SNID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.VARIABLE_SNAPSHOT_B_T VOLATILE;

CREATE INDEX @SCHEMA@.SN_PIID_CTID ON @SCHEMA@.VARIABLE_SNAPSHOT_B_T
(   
  PIID, CTID
);

CREATE TABLE @SCHEMA@.SUSPENDED_MESSAGE_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ENGINE_MESSAGE                     BLOB(1073741823)                  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.SUSPENDED_MESSAGE_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.PIID ON @SCHEMA@.SUSPENDED_MESSAGE_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.CROSSING_LINK_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SOURCE_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  TARGET_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  CONDITION_VALUE                    INTEGER                           NOT NULL ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.CROSSING_LINK_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.CL_PI_TAT_EH_FE_SA ON @SCHEMA@.CROSSING_LINK_INSTANCE_B_T
(   
  PIID, TARGET_ATID, EHIID, FEIID, SOURCE_ATID
);

CREATE TABLE @SCHEMA@.INVOKE_RESULT_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  INVOKE_RESULT                      BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, ATID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.INVOKE_RESULT_B_T VOLATILE;

CREATE TABLE @SCHEMA@.INVOKE_RESULT2_B_T
(
  IRID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  INVOKE_RESULT                      BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IRID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.INVOKE_RESULT2_B_T VOLATILE;

CREATE INDEX @SCHEMA@.IR2_PI_AT_EH_FE ON @SCHEMA@.INVOKE_RESULT2_B_T
(   
  PIID, ATID, EHIID, FEIID
);

CREATE TABLE @SCHEMA@.EVENT_HANDLER_INSTANCE_B_T
(
  EHIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  SCHEDULER_TASK_ID                  VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( EHIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.EVENT_HANDLER_INSTANCE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.EHI_PIID_EHTID ON @SCHEMA@.EVENT_HANDLER_INSTANCE_B_T
(   
  PIID, EHTID
);

CREATE INDEX @SCHEMA@.EHI_SIID_EHTID ON @SCHEMA@.EVENT_HANDLER_INSTANCE_B_T
(   
  SIID, EHTID
);

CREATE TABLE @SCHEMA@.CORRELATION_SET_INSTANCE_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PROCESS_NAME                       VARCHAR(220)                      NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  STATUS                             INTEGER                           NOT NULL ,
  HASH_CODE                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               VARCHAR(3072)                              ,
  DATA_LONG                          CLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, COID, SIID )
) IN BPETS8K;

ALTER TABLE @SCHEMA@.CORRELATION_SET_INSTANCE_B_T VOLATILE;

CREATE UNIQUE INDEX @SCHEMA@.CSIB_HASH_PN ON @SCHEMA@.CORRELATION_SET_INSTANCE_B_T
(   
  HASH_CODE, PROCESS_NAME
);

CREATE INDEX @SCHEMA@.CSIB_PIID ON @SCHEMA@.CORRELATION_SET_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.CORRELATION_SET_PROPERTIES_B_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA                               BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, COID, SIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.CORRELATION_SET_PROPERTIES_B_T VOLATILE;

CREATE TABLE @SCHEMA@.UNDO_ACTION_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_AIID                        CHAR(16)            FOR BIT DATA           ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  PROCESS_NAME                       VARCHAR(220)                      NOT NULL ,
  CSCOPE_ID                          VARCHAR(100)                      NOT NULL ,
  UUID                               VARCHAR(100)                      NOT NULL ,
  COMP_CREATION_TIME                 TIMESTAMP                         NOT NULL ,
  DO_OP_WAS_TXNAL                    SMALLINT                          NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  INPUT_DATA                         BLOB(1073741823)                  NOT NULL ,
  FAULT_DATA                         BLOB(1073741823)                           ,
  CREATED                            INTEGER                           NOT NULL ,
  PROCESS_ADMIN                      VARCHAR(128)                      NOT NULL ,
  IS_VISIBLE                         SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.UNDO_ACTION_B_T VOLATILE;

CREATE INDEX @SCHEMA@.UA_CSID_DOOP_UUID ON @SCHEMA@.UNDO_ACTION_B_T
(   
  CSCOPE_ID, DO_OP_WAS_TXNAL, UUID
);

CREATE INDEX @SCHEMA@.UA_CSID_STATE_CCT ON @SCHEMA@.UNDO_ACTION_B_T
(   
  CSCOPE_ID, STATE, UUID
);

CREATE INDEX @SCHEMA@.UA_STATE_ISV ON @SCHEMA@.UNDO_ACTION_B_T
(   
  STATE, IS_VISIBLE
);

CREATE INDEX @SCHEMA@.UA_AIID_STATE_UUID ON @SCHEMA@.UNDO_ACTION_B_T
(   
  PARENT_AIID, STATE, UUID
);

CREATE INDEX @SCHEMA@.UA_PIID ON @SCHEMA@.UNDO_ACTION_B_T
(   
  PARENT_PIID
);

CREATE INDEX @SCHEMA@.UA_PT_AT_CS_UU_CCT ON @SCHEMA@.UNDO_ACTION_B_T
(   
  PTID, ATID, CSCOPE_ID, UUID, COMP_CREATION_TIME
);

CREATE TABLE @SCHEMA@.CUSTOM_STMT_INSTANCE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SVIID                              CHAR(16)            FOR BIT DATA           ,
  NAMESPACE                          VARCHAR(220)                      NOT NULL ,
  LOCALNAME                          VARCHAR(220)                      NOT NULL ,
  PURPOSE                            VARCHAR(220)                      NOT NULL ,
  STATEMENT                          BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

CREATE INDEX @SCHEMA@.CSI_PIID_NS_LN_P ON @SCHEMA@.CUSTOM_STMT_INSTANCE_B_T
(   
  PIID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE INDEX @SCHEMA@.CSI_SVIID_NS_LN_P ON @SCHEMA@.CUSTOM_STMT_INSTANCE_B_T
(   
  SVIID, NAMESPACE, LOCALNAME, PURPOSE
);

CREATE TABLE @SCHEMA@.COMP_WORK_PENDING_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_ATID                        CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_EHIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  CSCOPE_ID                          VARCHAR(100)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.COMP_WORK_PENDING_B_T VOLATILE;

CREATE INDEX @SCHEMA@.CWP_PI_AT_CS_EH_FE ON @SCHEMA@.COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, CSCOPE_ID, PARENT_EHIID, PARENT_FEIID
);

CREATE INDEX @SCHEMA@.CWP_PI_AT_EHI ON @SCHEMA@.COMP_WORK_PENDING_B_T
(   
  PARENT_PIID, PARENT_ATID, PARENT_EHIID
);

CREATE TABLE @SCHEMA@.COMP_PARENT_ACTIVITY_INST_B_T
(
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COMPLETION_NUMBER                  BIGINT                            NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( AIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.COMP_PARENT_ACTIVITY_INST_B_T VOLATILE;

CREATE INDEX @SCHEMA@.CPAI_SI_S_CN_AI_PI ON @SCHEMA@.COMP_PARENT_ACTIVITY_INST_B_T
(   
  SIID, STATE, COMPLETION_NUMBER, AIID, PIID
);

CREATE INDEX @SCHEMA@.CPAI_PIID ON @SCHEMA@.COMP_PARENT_ACTIVITY_INST_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.RESTART_EVENT_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PORT_TYPE                          VARCHAR(254)                      NOT NULL ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  INPUT_MESSAGE                      BLOB(1073741823)                           ,
  REPLY_CTX                          BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.RESTART_EVENT_B_T VOLATILE;

CREATE INDEX @SCHEMA@.REB_PIID ON @SCHEMA@.RESTART_EVENT_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.PROGRESS_COUNTER_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  COUNTER                            BIGINT                            NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.PROGRESS_COUNTER_T VOLATILE;

CREATE TABLE @SCHEMA@.RELEVANT_SCOPE_ATASK_T
(
  SIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SIID, TKIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.RELEVANT_SCOPE_ATASK_T VOLATILE;

CREATE TABLE @SCHEMA@.CONFIG_INFO_T
(
  IDENTIFIER                         VARCHAR(64)                       NOT NULL ,
  DESCRIPTION                        VARCHAR(128)                               ,
  PROPERTY                           INTEGER                                    ,
  COUNTER                            BIGINT                                     ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IDENTIFIER )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.CONFIG_INFO_T VOLATILE;

CREATE TABLE @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATTR_KEY                           VARCHAR(220)                      NOT NULL ,
  VALUE                              VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID, ATTR_KEY )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T VOLATILE;

CREATE INDEX @SCHEMA@.PIA_VALUE ON @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T
(   
  VALUE
);

CREATE INDEX @SCHEMA@.PIA_DATY ON @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T
(   
  DATA_TYPE
);

CREATE TABLE @SCHEMA@.PROCESS_CONTEXT_T
(
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  REPLY_CONTEXT                      BLOB(3900K)                                ,
  SERVICE_CONTEXT                    BLOB(3900K)                                ,
  STARTER_EXPIRES                    TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.PROCESS_CONTEXT_T VOLATILE;

CREATE TABLE @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  ATID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EHIID                              CHAR(16)            FOR BIT DATA           ,
  FEIID                              CHAR(16)            FOR BIT DATA           ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  ATTR_KEY                           VARCHAR(189)                      NOT NULL ,
  ATTR_VALUE                         VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T VOLATILE;

CREATE UNIQUE INDEX @SCHEMA@.AIA_UNIQUE ON @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T
(   
  PIID, ATID, EHIID, FEIID, ATTR_KEY
);

CREATE INDEX @SCHEMA@.AIA_AIID ON @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T
(   
  AIID
);

CREATE INDEX @SCHEMA@.AIA_VALUE ON @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T
(   
  ATTR_VALUE
);

CREATE INDEX @SCHEMA@.AIA_DATY ON @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T
(   
  DATA_TYPE
);

CREATE TABLE @SCHEMA@.NAVIGATION_EXCEPTION_T
(
  CORRELATION_ID                     VARCHAR(220)        FOR BIT DATA  NOT NULL ,
  EXCEPTION_TYPE                     INTEGER                           NOT NULL ,
  OUTPUT_MESSAGE                     BLOB(1073741823)                           ,
  TYPE_SYSTEM                        VARCHAR(32)                                ,
  PROCESS_EXCEPTION                  BLOB(3900K)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CORRELATION_ID, EXCEPTION_TYPE )
) IN INSTANCE;

CREATE TABLE @SCHEMA@.AWAITED_INVOCATION_T
(
  CORRELATION_ID                     VARCHAR(254)        FOR BIT DATA  NOT NULL ,
  CORRELATION_INFO                   BLOB(3900K)                       NOT NULL ,
  AIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( CORRELATION_ID )
) IN INSTANCE;

CREATE INDEX @SCHEMA@.AWI_PIID ON @SCHEMA@.AWAITED_INVOCATION_T
(   
  PIID
);

CREATE INDEX @SCHEMA@.AWI_AIID ON @SCHEMA@.AWAITED_INVOCATION_T
(   
  AIID
);

CREATE TABLE @SCHEMA@.STORED_QUERY_T
(
  SQID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  NAME                               VARCHAR(64)                       NOT NULL ,
  OWNER_ID                           VARCHAR(128)                      NOT NULL ,
  SELECT_CLAUSE                      CLOB(20K)                         NOT NULL ,
  WHERE_CLAUSE                       CLOB(20K)                                  ,
  ORDER_CLAUSE                       VARCHAR(254)                               ,
  THRESHOLD                          INTEGER                                    ,
  TIMEZONE                           VARCHAR(63)                                ,
  CREATOR                            VARCHAR(128)                               ,
  TYPE                               VARCHAR(128)                               ,
  PROPERTY                           BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SQID )
) IN INSTANCE;

CREATE UNIQUE INDEX @SCHEMA@.SQ_NAME ON @SCHEMA@.STORED_QUERY_T
(   
  KIND, OWNER_ID, NAME
);

CREATE TABLE @SCHEMA@.FOR_EACH_INSTANCE_B_T
(
  FEIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_FEIID                       CHAR(16)            FOR BIT DATA           ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( FEIID )
) IN INSTANCE;

CREATE INDEX @SCHEMA@.FEI_PIID ON @SCHEMA@.FOR_EACH_INSTANCE_B_T
(   
  PIID
);

CREATE TABLE @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  CTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PAID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  VARIABLE_NAME                      VARCHAR(254)                      NOT NULL ,
  PROPERTY_NAME                      VARCHAR(255)                      NOT NULL ,
  PROPERTY_NAMESPACE                 VARCHAR(254)                      NOT NULL ,
  TYPE                               INTEGER                           NOT NULL ,
  GENERIC_VALUE                      VARCHAR(512)                               ,
  STRING_VALUE                       VARCHAR(512)                               ,
  NUMBER_VALUE                       BIGINT                                     ,
  DECIMAL_VALUE                      DOUBLE                                     ,
  TIMESTAMP_VALUE                    TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T VOLATILE;

CREATE INDEX @SCHEMA@.QVI_PI_CT_PA ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, CTID, PAID
);

CREATE INDEX @SCHEMA@.QVI_PI_VARNAME ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, VARIABLE_NAME
);

CREATE INDEX @SCHEMA@.QVI_PI_PROPNAME ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAME
);

CREATE INDEX @SCHEMA@.QVI_PI_NAMESPACE ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, PROPERTY_NAMESPACE
);

CREATE INDEX @SCHEMA@.QVI_PI_GEN_VALUE ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, GENERIC_VALUE
);

CREATE INDEX @SCHEMA@.QVI_PI_STR_VALUE ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, STRING_VALUE
);

CREATE INDEX @SCHEMA@.QVI_PI_NUM ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, NUMBER_VALUE
);

CREATE INDEX @SCHEMA@.QVI_PI_DEC ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, DECIMAL_VALUE
);

CREATE INDEX @SCHEMA@.QVI_PI_TIME ON @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T
(   
  PIID, TIMESTAMP_VALUE
);

CREATE TABLE @SCHEMA@.SYNC_T
(
  IDENTIFIER                         VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( IDENTIFIER )
) IN INSTANCE;

CREATE TABLE @SCHEMA@.MV_CTR_T
(
  ID                                 INTEGER                           NOT NULL ,
  SELECT_CLAUSE                      VARCHAR(1024)                     NOT NULL ,
  WHERE_CLAUSE                       VARCHAR(1024)                              ,
  ORDER_CLAUSE                       VARCHAR(512)                               ,
  TBL_SPACE                          VARCHAR(32)                       NOT NULL ,
  UPDATED                            TIMESTAMP                         NOT NULL ,
  UPD_STARTED                        TIMESTAMP                                  ,
  AVG_UPD_TIME                       BIGINT                                     ,
  UPD_INTERVAL                       BIGINT                            NOT NULL ,
  IS_UPDATING                        SMALLINT                          NOT NULL ,
  ACTIVE_MV                          SMALLINT                          NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ID )
) IN INSTANCE;

CREATE TABLE @SCHEMA@.MV_MODS_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  MODIFIED                           TIMESTAMP                         NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.MV_MODS_T VOLATILE;

CREATE TABLE @SCHEMA@.SAVED_ENGINE_MESSAGE_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA           ,
  CREATION_TIME                      TIMESTAMP                         NOT NULL ,
  REASON                             INTEGER                           NOT NULL ,
  ENGINE_MESSAGE_S                   VARCHAR(2000)       FOR BIT DATA           ,
  ENGINE_MESSAGE_L                   BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.SAVED_ENGINE_MESSAGE_B_T VOLATILE;

CREATE INDEX @SCHEMA@.SEM_PIID ON @SCHEMA@.SAVED_ENGINE_MESSAGE_B_T
(   
  PIID
);

CREATE INDEX @SCHEMA@.SEM_REAS ON @SCHEMA@.SAVED_ENGINE_MESSAGE_B_T
(   
  REASON
);

CREATE TABLE @SCHEMA@.NAVIGATION_CLEANUP_TIMER_B_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  SCHEDULED_TIME                     TIMESTAMP                         NOT NULL ,
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.NAVIGATION_CLEANUP_TIMER_B_T VOLATILE;

CREATE TABLE @SCHEMA@.SCHEDULER_ACTION_T
(
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  ACTION_OBJECT                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SCHEDULER_ID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.SCHEDULER_ACTION_T VOLATILE;

CREATE INDEX @SCHEMA@.SCEACT_OID ON @SCHEMA@.SCHEDULER_ACTION_T
(   
  OID
);

CREATE TABLE @SCHEMA@.QUERY_TABLE_T
(
  NAME                               VARCHAR(32)                       NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  TYPE                               INTEGER                           NOT NULL ,
  VERSION                            INTEGER                           NOT NULL ,
  LAST_UPDATED                       TIMESTAMP                         NOT NULL ,
  PRIMARY_VIEW                       VARCHAR(32)                                ,
  DEFINITION                         BLOB(1073741823)                  NOT NULL ,
  VV_CFG                             BLOB(1073741823)                           ,
  DV_CFG                             BLOB(1073741823)                           ,
  MV_CFG                             BLOB(1073741823)                           ,
  MT_CFG                             BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( NAME )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.QUERY_TABLE_T VOLATILE;

CREATE INDEX @SCHEMA@.QT_KI ON @SCHEMA@.QUERY_TABLE_T
(   
  KIND
);

CREATE INDEX @SCHEMA@.QT_TY ON @SCHEMA@.QUERY_TABLE_T
(   
  TYPE
);

CREATE TABLE @SCHEMA@.QUERY_TABLE_REF_T
(
  REFEREE                            VARCHAR(32)                       NOT NULL ,
  SOURCE                             VARCHAR(32)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( REFEREE, SOURCE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.QUERY_TABLE_REF_T VOLATILE;

CREATE INDEX @SCHEMA@.QTR_SRC ON @SCHEMA@.QUERY_TABLE_REF_T
(   
  SOURCE
);

CREATE TABLE @SCHEMA@.AUDIT_LOG_T
(
  ALID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVENT_TIME                         TIMESTAMP                         NOT NULL ,
  EVENT_TIME_UTC                     TIMESTAMP                                  ,
  AUDIT_EVENT                        INTEGER                           NOT NULL ,
  PTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PIID                               CHAR(16)            FOR BIT DATA           ,
  AIID                               CHAR(16)            FOR BIT DATA           ,
  SIID                               CHAR(16)            FOR BIT DATA           ,
  VARIABLE_NAME                      VARCHAR(254)                               ,
  PROCESS_TEMPL_NAME                 VARCHAR(254)                      NOT NULL ,
  PROCESS_INST_NAME                  VARCHAR(254)                               ,
  TOP_LEVEL_PI_NAME                  VARCHAR(254)                               ,
  TOP_LEVEL_PIID                     CHAR(16)            FOR BIT DATA           ,
  PARENT_PI_NAME                     VARCHAR(254)                               ,
  PARENT_PIID                        CHAR(16)            FOR BIT DATA           ,
  VALID_FROM                         TIMESTAMP                                  ,
  VALID_FROM_UTC                     TIMESTAMP                                  ,
  ATID                               CHAR(16)            FOR BIT DATA           ,
  ACTIVITY_NAME                      VARCHAR(254)                               ,
  ACTIVITY_KIND                      INTEGER                                    ,
  ACTIVITY_STATE                     INTEGER                                    ,
  CONTROL_LINK_NAME                  VARCHAR(254)                               ,
  IMPL_NAME                          VARCHAR(254)                               ,
  PRINCIPAL                          VARCHAR(128)                               ,
  TERMINAL_NAME                      VARCHAR(254)                               ,
  VARIABLE_DATA                      BLOB(1073741823)                           ,
  EXCEPTION_TEXT                     CLOB(4096)                                 ,
  DESCRIPTION                        VARCHAR(254)                               ,
  CORR_SET_INFO                      CLOB(4096)                                 ,
  USER_NAME                          VARCHAR(128)                               ,
  ADDITIONAL_INFO                    CLOB(4096)                                 ,
  OBJECT_META_TYPE                   INTEGER                                    ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ALID )
) IN AUDITLOG;

CREATE TABLE @SCHEMA@.WORK_ITEM_T
(
  WIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_WIID                        CHAR(16)            FOR BIT DATA           ,
  OWNER_ID                           VARCHAR(128)                               ,
  GROUP_NAME                         VARCHAR(128)                               ,
  EVERYBODY                          SMALLINT                          NOT NULL ,
  EXCLUDE                            SMALLINT                          NOT NULL ,
  QIID                               CHAR(16)            FOR BIT DATA           ,
  OBJECT_TYPE                        INTEGER                           NOT NULL ,
  OBJECT_ID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA           ,
  REASON                             INTEGER                           NOT NULL ,
  CREATION_TIME                      TIMESTAMP                         NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  AUTH_INFO                          INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( WIID )
) IN WORKITEM;

ALTER TABLE @SCHEMA@.WORK_ITEM_T VOLATILE;

CREATE INDEX @SCHEMA@.WI_ASSOBJ_REASON ON @SCHEMA@.WORK_ITEM_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE, REASON, PARENT_WIID
);

CREATE INDEX @SCHEMA@.WI_OBJID_TYPE_QIID ON @SCHEMA@.WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, QIID
);

CREATE INDEX @SCHEMA@.WI_OBJID_TYPE_REAS ON @SCHEMA@.WORK_ITEM_T
(   
  OBJECT_ID, OBJECT_TYPE, REASON
);

CREATE INDEX @SCHEMA@.WI_GROUP_NAME ON @SCHEMA@.WORK_ITEM_T
(   
  GROUP_NAME
);

CREATE INDEX @SCHEMA@.WI_AUTH_L ON @SCHEMA@.WORK_ITEM_T
(   
  EVERYBODY, GROUP_NAME, OWNER_ID, QIID
);

CREATE INDEX @SCHEMA@.WI_AUTH_U ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, QIID
);

CREATE INDEX @SCHEMA@.WI_AUTH_O ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, OWNER_ID DESC
);

CREATE INDEX @SCHEMA@.WI_AUTH_G ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, GROUP_NAME
);

CREATE INDEX @SCHEMA@.WI_AUTH_E ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, EVERYBODY
);

CREATE INDEX @SCHEMA@.WI_AUTH_R ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, REASON DESC
);

CREATE INDEX @SCHEMA@.WI_REASON ON @SCHEMA@.WORK_ITEM_T
(   
  REASON
);

CREATE INDEX @SCHEMA@.WI_OWNER ON @SCHEMA@.WORK_ITEM_T
(   
  OWNER_ID, OBJECT_ID, REASON, OBJECT_TYPE
);

CREATE INDEX @SCHEMA@.WI_QIID ON @SCHEMA@.WORK_ITEM_T
(   
  QIID
);

CREATE INDEX @SCHEMA@.WI_QRY ON @SCHEMA@.WORK_ITEM_T
(   
  OBJECT_ID, REASON, EVERYBODY, OWNER_ID
);

CREATE INDEX @SCHEMA@.WI_QI_OID_RS_OWN ON @SCHEMA@.WORK_ITEM_T
(   
  QIID, OBJECT_ID, REASON, OWNER_ID
);

CREATE INDEX @SCHEMA@.WI_QI_OID_OWN ON @SCHEMA@.WORK_ITEM_T
(   
  QIID, OBJECT_ID, OWNER_ID
);

CREATE INDEX @SCHEMA@.WI_OT_OID_RS ON @SCHEMA@.WORK_ITEM_T
(   
  OBJECT_TYPE, OBJECT_ID, REASON
);

CREATE INDEX @SCHEMA@.WI_WI_QI ON @SCHEMA@.WORK_ITEM_T
(   
  WIID, QIID
);

CREATE INDEX @SCHEMA@.WI_PARENT_WIID ON @SCHEMA@.WORK_ITEM_T
(   
  PARENT_WIID
);

CREATE INDEX @SCHEMA@.WI_AUTH_GR_O_E ON @SCHEMA@.WORK_ITEM_T
(   
  AUTH_INFO, GROUP_NAME, OWNER_ID, EVERYBODY
);

CREATE TABLE @SCHEMA@.RETRIEVED_USER_T
(
  QIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  OWNER_ID                           VARCHAR(128)                      NOT NULL ,
  REASON                             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QIID, OWNER_ID )
) IN WORKITEM;

ALTER TABLE @SCHEMA@.RETRIEVED_USER_T VOLATILE;

CREATE INDEX @SCHEMA@.RUT_OWN_QIID ON @SCHEMA@.RETRIEVED_USER_T
(   
  OWNER_ID, QIID
);

CREATE INDEX @SCHEMA@.RUT_ASSOC ON @SCHEMA@.RETRIEVED_USER_T
(   
  ASSOCIATED_OID
);

CREATE INDEX @SCHEMA@.RUT_QIID ON @SCHEMA@.RETRIEVED_USER_T
(   
  QIID
);

CREATE INDEX @SCHEMA@.RUT_OWN_QIDESC ON @SCHEMA@.RETRIEVED_USER_T
(   
  OWNER_ID, QIID DESC
);

CREATE TABLE @SCHEMA@.STAFF_QUERY_INSTANCE_T
(
  QIID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVERYBODY                          SMALLINT                          NOT NULL ,
  NOBODY                             SMALLINT                          NOT NULL ,
  IS_SHAREABLE                       SMALLINT                          NOT NULL ,
  IS_TRANSFERRED                     SMALLINT                          NOT NULL ,
  SR_HASH_CODE                       INTEGER                                    ,
  GROUP_NAME                         VARCHAR(128)                               ,
  CONTEXT_VALUES                     VARCHAR(3072)                              ,
  CONTEXT_VALUES_LONG                CLOB(3096K)                                ,
  HASH_CODE                          INTEGER                                    ,
  EXPIRES                            TIMESTAMP                                  ,
  ASSOCIATED_OBJECT_TYPE             INTEGER                           NOT NULL ,
  ASSOCIATED_OID                     CHAR(16)            FOR BIT DATA  NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QIID )
) IN BPETS8K;

CREATE INDEX @SCHEMA@.SQI_QTID ON @SCHEMA@.STAFF_QUERY_INSTANCE_T
(   
  QTID, HASH_CODE
);

CREATE INDEX @SCHEMA@.SQI_ASSOCID ON @SCHEMA@.STAFF_QUERY_INSTANCE_T
(   
  ASSOCIATED_OID, ASSOCIATED_OBJECT_TYPE
);

CREATE INDEX @SCHEMA@.SQI_QIIDGN ON @SCHEMA@.STAFF_QUERY_INSTANCE_T
(   
  QIID, GROUP_NAME
);

CREATE INDEX @SCHEMA@.SQI_QIIDTREX ON @SCHEMA@.STAFF_QUERY_INSTANCE_T
(   
  QIID, IS_TRANSFERRED, EXPIRES
);

CREATE TABLE @SCHEMA@.STAFF_LOCK_T
(
  QTID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( QTID, HASH_CODE )
) IN STAFFQRY;

CREATE TABLE @SCHEMA@.APPLICATION_COMPONENT_T
(
  ACOID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(64)                       NOT NULL ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                      NOT NULL ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  INSTANCE_CREATOR_QTID              CHAR(16)            FOR BIT DATA           ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  PRIMARY KEY ( ACOID )
) IN TEMPLATE;

CREATE UNIQUE INDEX @SCHEMA@.ACO_NAME ON @SCHEMA@.APPLICATION_COMPONENT_T
(   
  NAME
);

CREATE TABLE @SCHEMA@.ESCALATION_TEMPLATE_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  FIRST_ESTID                        CHAR(16)            FOR BIT DATA           ,
  PREVIOUS_ESTID                     CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  MNTID                              CHAR(16)            FOR BIT DATA           ,
  NAME                               VARCHAR(220)                               ,
  ACTIVATION_STATE                   INTEGER                           NOT NULL ,
  AT_LEAST_EXPECTED_STATE            INTEGER                           NOT NULL ,
  DURATION_UNTIL_ESCALATION          VARCHAR(254)                               ,
  DURATION_UNTIL_REPEATS             VARCHAR(254)                               ,
  INCREASE_PRIORITY                  INTEGER                           NOT NULL ,
  ACTION                             INTEGER                           NOT NULL ,
  ESCALATION_RECEIVER_QTID           CHAR(16)            FOR BIT DATA           ,
  RECEIVER_EMAIL_QTID                CHAR(16)            FOR BIT DATA           ,
  PRIMARY KEY ( ESTID )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.ESCALATION_TEMPLATE_T VOLATILE;

CREATE INDEX @SCHEMA@.ET_TKTID ON @SCHEMA@.ESCALATION_TEMPLATE_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.ET_CCID ON @SCHEMA@.ESCALATION_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.ESC_TEMPL_CPROP_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  PRIMARY KEY ( ESTID, NAME )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.ESC_TEMPL_CPROP_T VOLATILE;

CREATE INDEX @SCHEMA@.ETCP_TKTID ON @SCHEMA@.ESC_TEMPL_CPROP_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.ETCP_CCID ON @SCHEMA@.ESC_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.ESC_TEMPL_LDESC_T
(
  ESTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  PRIMARY KEY ( ESTID, LOCALE )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.ESC_TEMPL_LDESC_T VOLATILE;

CREATE INDEX @SCHEMA@.ETLD_TKTID ON @SCHEMA@.ESC_TEMPL_LDESC_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.ETLD_CCID ON @SCHEMA@.ESC_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TTASK_MESSAGE_DEFINITION_T
(
  TMTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                                ,
  PRIMARY KEY ( TMTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.TTMD_TKTID ON @SCHEMA@.TTASK_MESSAGE_DEFINITION_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.TTMD_CCID ON @SCHEMA@.TTASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_TEMPLATE_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  DEFINITION_NAME                    VARCHAR(220)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  TARGET_NAMESPACE                   VARCHAR(254)                      NOT NULL ,
  VALID_FROM                         TIMESTAMP                         NOT NULL ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  APPLICATION_DEFAULTS_ID            CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  SVTID                              CHAR(16)            FOR BIT DATA           ,
  KIND                               INTEGER                           NOT NULL ,
  STATE                              INTEGER                           NOT NULL ,
  AUTO_DELETE_MODE                   INTEGER                           NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  IS_INLINE                          SMALLINT                          NOT NULL ,
  IS_SHARED                          SMALLINT                          NOT NULL ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  CONTEXT_AUTHORIZATION              INTEGER                           NOT NULL ,
  AUTONOMY                           INTEGER                           NOT NULL ,
  ADMIN_QTID                         CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  INSTANCE_CREATOR_QTID              CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_STARTER_QTID             CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  DEFAULT_LOCALE                     VARCHAR(32)                                ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  DURATION_UNTIL_DUE                 VARCHAR(254)                               ,
  DURATION_UNTIL_EXPIRES             VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                      NOT NULL ,
  TYPE                               VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  PRIORITY                           INTEGER                                    ,
  PRIORITY_DEFINITION                VARCHAR(254)                               ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  CONTACTS_QTIDS                     BLOB(3900k)                                ,
  UI_SETTINGS                        BLOB(3900k)                                ,
  PRIMARY KEY ( TKTID )
) IN BPETS8K;

ALTER TABLE @SCHEMA@.TASK_TEMPLATE_T VOLATILE;

CREATE UNIQUE INDEX @SCHEMA@.TT_NAME_VF_NS ON @SCHEMA@.TASK_TEMPLATE_T
(   
  NAME, VALID_FROM, NAMESPACE
);

CREATE INDEX @SCHEMA@.TT_CCID_STATE ON @SCHEMA@.TASK_TEMPLATE_T
(   
  CONTAINMENT_CONTEXT_ID, STATE
);

CREATE INDEX @SCHEMA@.TT_KND_INLN_VAL ON @SCHEMA@.TASK_TEMPLATE_T
(   
  KIND, IS_INLINE, VALID_FROM
);

CREATE TABLE @SCHEMA@.TASK_TEMPL_CPROP_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA_TYPE                          VARCHAR(254)                               ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  PRIMARY KEY ( TKTID, NAME )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.TASK_TEMPL_CPROP_T VOLATILE;

CREATE INDEX @SCHEMA@.TTCP_TKTID ON @SCHEMA@.TASK_TEMPL_CPROP_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.TTCP_CCID ON @SCHEMA@.TASK_TEMPL_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_TEMPL_LDESC_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  PRIMARY KEY ( TKTID, LOCALE )
) IN TEMPLATE;

ALTER TABLE @SCHEMA@.TASK_TEMPL_LDESC_T VOLATILE;

CREATE INDEX @SCHEMA@.TTLD_TKTID ON @SCHEMA@.TASK_TEMPL_LDESC_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.TTLD_CCID ON @SCHEMA@.TASK_TEMPL_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX @SCHEMA@.TTLD_TT_LOC ON @SCHEMA@.TASK_TEMPL_LDESC_T
(   
  TKTID, LOCALE DESC
);

CREATE TABLE @SCHEMA@.TSERVICE_DESCRIPTION_T
(
  SVTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_ONE_WAY                         SMALLINT                          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR(254)                               ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  PORT                               VARCHAR(254)                               ,
  PORT_TYPE_NS                       VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR(254)                               ,
  SERVICE                            VARCHAR(254)                               ,
  PRIMARY KEY ( SVTID )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.TSD_TKTID ON @SCHEMA@.TSERVICE_DESCRIPTION_T
(   
  TKTID
);

CREATE INDEX @SCHEMA@.TSD_CCID ON @SCHEMA@.TSERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_CELL_MAP_T
(
  TKTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CELL                               VARCHAR(220)                      NOT NULL ,
  PRIMARY KEY ( TKTID, CELL )
) IN TEMPLATE;

CREATE TABLE @SCHEMA@.TMAIL_T
(
  MNTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_STATE                         INTEGER                           NOT NULL ,
  TO_STATE                           INTEGER                           NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  HASH_CODE                          INTEGER                           NOT NULL ,
  SUBJECT                            VARCHAR(254)                      NOT NULL ,
  BODY_TEXT                          CLOB(4096)                                 ,
  PRIMARY KEY ( MNTID, FROM_STATE, TO_STATE, LOCALE )
) IN TEMPLATE;

CREATE INDEX @SCHEMA@.EMT_HC ON @SCHEMA@.TMAIL_T
(   
  HASH_CODE
);

CREATE TABLE @SCHEMA@.ESCALATION_INSTANCE_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  ESTID                              CHAR(16)            FOR BIT DATA           ,
  FIRST_ESIID                        CHAR(16)            FOR BIT DATA           ,
  PREVIOUS_ESIID                     CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  MNTID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                               ,
  STATE                              INTEGER                           NOT NULL ,
  ACTIVATION_STATE                   INTEGER                           NOT NULL ,
  AT_LEAST_EXPECTED_STATE            INTEGER                           NOT NULL ,
  ACTIVATION_TIME                    TIMESTAMP                                  ,
  ESCALATION_TIME                    TIMESTAMP                                  ,
  DURATION_UNTIL_ESCALATION          VARCHAR(254)                               ,
  DURATION_UNTIL_REPEATS             VARCHAR(254)                               ,
  INCREASE_PRIORITY                  INTEGER                           NOT NULL ,
  ACTION                             INTEGER                           NOT NULL ,
  ESCALATION_RECEIVER_QTID           CHAR(16)            FOR BIT DATA           ,
  RECEIVER_EMAIL_QTID                CHAR(16)            FOR BIT DATA           ,
  SCHEDULER_ID                       VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ESCALATION_INSTANCE_T VOLATILE;

CREATE INDEX @SCHEMA@.ESI_FIRST ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  FIRST_ESIID
);

CREATE INDEX @SCHEMA@.ESI_TKIID_ASTATE ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  TKIID, ACTIVATION_STATE, STATE
);

CREATE INDEX @SCHEMA@.ESI_TKIID_STATE ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  TKIID, STATE
);

CREATE INDEX @SCHEMA@.ESI_PREV ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  PREVIOUS_ESIID
);

CREATE INDEX @SCHEMA@.ESI_ESTID ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  ESTID
);

CREATE INDEX @SCHEMA@.ESI_CCID ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX @SCHEMA@.ESI_EST_ESI ON @SCHEMA@.ESCALATION_INSTANCE_T
(   
  ESTID, ESIID
);

CREATE TABLE @SCHEMA@.ESC_INST_CPROP_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA_TYPE                          VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, NAME )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ESC_INST_CPROP_T VOLATILE;

CREATE INDEX @SCHEMA@.EICP_CCID ON @SCHEMA@.ESC_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.ESC_INST_LDESC_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, LOCALE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ESC_INST_LDESC_T VOLATILE;

CREATE INDEX @SCHEMA@.EILD_CCID ON @SCHEMA@.ESC_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.EIDOCUMENTATION_T
(
  ESIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ESIID, LOCALE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.EIDOCUMENTATION_T VOLATILE;

CREATE INDEX @SCHEMA@.EIDOC_CCID ON @SCHEMA@.EIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.ISERVICE_DESCRIPTION_T
(
  SVTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  IS_ONE_WAY                         SMALLINT                          NOT NULL ,
  SERVICE_REF_NAME                   VARCHAR(254)                               ,
  OPERATION                          VARCHAR(254)                      NOT NULL ,
  PORT                               VARCHAR(254)                               ,
  PORT_TYPE_NS                       VARCHAR(254)                      NOT NULL ,
  PORT_TYPE_NAME                     VARCHAR(254)                      NOT NULL ,
  S_BEAN_JNDI_NAME                   VARCHAR(254)                               ,
  SERVICE                            VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( SVTID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ISERVICE_DESCRIPTION_T VOLATILE;

CREATE INDEX @SCHEMA@.ISD_TKIID ON @SCHEMA@.ISERVICE_DESCRIPTION_T
(   
  TKIID
);

CREATE INDEX @SCHEMA@.ISD_CCID ON @SCHEMA@.ISERVICE_DESCRIPTION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_INSTANCE_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  NAMESPACE                          VARCHAR(254)                      NOT NULL ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  TOP_TKIID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  FOLLOW_ON_TKIID                    CHAR(16)            FOR BIT DATA           ,
  APPLICATION_NAME                   VARCHAR(220)                               ,
  APPLICATION_DEFAULTS_ID            CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  PARENT_CONTEXT_ID                  CHAR(16)            FOR BIT DATA           ,
  STATE                              INTEGER                           NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  AUTO_DELETE_MODE                   INTEGER                           NOT NULL ,
  HIERARCHY_POSITION                 INTEGER                           NOT NULL ,
  TYPE                               VARCHAR(254)                               ,
  SVTID                              CHAR(16)            FOR BIT DATA           ,
  SUPPORTS_CLAIM_SUSPENDED           SMALLINT                          NOT NULL ,
  SUPPORTS_AUTO_CLAIM                SMALLINT                          NOT NULL ,
  SUPPORTS_FOLLOW_ON_TASK            SMALLINT                          NOT NULL ,
  IS_AD_HOC                          SMALLINT                          NOT NULL ,
  IS_ESCALATED                       SMALLINT                          NOT NULL ,
  IS_INLINE                          SMALLINT                          NOT NULL ,
  IS_SUSPENDED                       SMALLINT                          NOT NULL ,
  IS_WAITING_FOR_SUBTASK             SMALLINT                          NOT NULL ,
  SUPPORTS_DELEGATION                SMALLINT                          NOT NULL ,
  SUPPORTS_SUB_TASK                  SMALLINT                          NOT NULL ,
  IS_CHILD                           SMALLINT                          NOT NULL ,
  HAS_ESCALATIONS                    SMALLINT                                   ,
  START_TIME                         TIMESTAMP                                  ,
  ACTIVATION_TIME                    TIMESTAMP                                  ,
  LAST_MODIFICATION_TIME             TIMESTAMP                                  ,
  LAST_STATE_CHANGE_TIME             TIMESTAMP                                  ,
  COMPLETION_TIME                    TIMESTAMP                                  ,
  DUE_TIME                           TIMESTAMP                                  ,
  EXPIRATION_TIME                    TIMESTAMP                                  ,
  FIRST_ACTIVATION_TIME              TIMESTAMP                                  ,
  DEFAULT_LOCALE                     VARCHAR(32)                                ,
  DURATION_UNTIL_DELETED             VARCHAR(254)                               ,
  DURATION_UNTIL_DUE                 VARCHAR(254)                               ,
  DURATION_UNTIL_EXPIRES             VARCHAR(254)                               ,
  CALENDAR_NAME                      VARCHAR(254)                               ,
  JNDI_NAME_CALENDAR                 VARCHAR(254)                               ,
  JNDI_NAME_STAFF_PROVIDER           VARCHAR(254)                               ,
  CONTEXT_AUTHORIZATION              INTEGER                           NOT NULL ,
  ORIGINATOR                         VARCHAR(128)                               ,
  STARTER                            VARCHAR(128)                               ,
  OWNER                              VARCHAR(128)                               ,
  ADMIN_QTID                         CHAR(16)            FOR BIT DATA           ,
  EDITOR_QTID                        CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_OWNER_QTID               CHAR(16)            FOR BIT DATA           ,
  POTENTIAL_STARTER_QTID             CHAR(16)            FOR BIT DATA           ,
  READER_QTID                        CHAR(16)            FOR BIT DATA           ,
  PRIORITY                           INTEGER                                    ,
  SCHEDULER_ID                       VARCHAR(254)                               ,
  SERVICE_TICKET                     VARCHAR(254)                               ,
  EVENT_HANDLER_NAME                 VARCHAR(64)                                ,
  BUSINESS_RELEVANCE                 SMALLINT                          NOT NULL ,
  RESUMES                            TIMESTAMP                                  ,
  SUBSTITUTION_POLICY                INTEGER                           NOT NULL ,
  DELETION_TIME                      TIMESTAMP                                  ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
) IN BPETS8K;

ALTER TABLE @SCHEMA@.TASK_INSTANCE_T VOLATILE;

CREATE INDEX @SCHEMA@.TI_PARENT ON @SCHEMA@.TASK_INSTANCE_T
(   
  PARENT_CONTEXT_ID
);

CREATE INDEX @SCHEMA@.TI_ACOID ON @SCHEMA@.TASK_INSTANCE_T
(   
  APPLICATION_DEFAULTS_ID
);

CREATE INDEX @SCHEMA@.TI_NAME ON @SCHEMA@.TASK_INSTANCE_T
(   
  NAME
);

CREATE INDEX @SCHEMA@.TI_STATE ON @SCHEMA@.TASK_INSTANCE_T
(   
  STATE
);

CREATE INDEX @SCHEMA@.TI_SERVICET ON @SCHEMA@.TASK_INSTANCE_T
(   
  SERVICE_TICKET
);

CREATE INDEX @SCHEMA@.TI_CCID ON @SCHEMA@.TASK_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE INDEX @SCHEMA@.TI_TK_TOPTK ON @SCHEMA@.TASK_INSTANCE_T
(   
  TKTID, TKIID, TOP_TKIID
);

CREATE INDEX @SCHEMA@.TI_TOPTKIID ON @SCHEMA@.TASK_INSTANCE_T
(   
  TOP_TKIID
);

CREATE INDEX @SCHEMA@.TI_TI_KND_ST ON @SCHEMA@.TASK_INSTANCE_T
(   
  TKIID, KIND, STATE
);

CREATE INDEX @SCHEMA@.TI_ST_KND_TI_NAME ON @SCHEMA@.TASK_INSTANCE_T
(   
  STATE, KIND, TKIID, NAME
);

CREATE INDEX @SCHEMA@.TI_TT_KND ON @SCHEMA@.TASK_INSTANCE_T
(   
  TKTID, KIND
);

CREATE TABLE @SCHEMA@.TASK_CONTEXT_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  SERVICE_CONTEXT                    BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
) IN INSTANCE;

CREATE INDEX @SCHEMA@.TC_CCID ON @SCHEMA@.TASK_CONTEXT_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.CONTACT_QUERIES_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTACTS_QTIDS                     BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.CONTACT_QUERIES_T VOLATILE;

CREATE INDEX @SCHEMA@.CQ_CCID ON @SCHEMA@.CONTACT_QUERIES_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.UISETTINGS_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  UI_SETTINGS                        BLOB(3900k)                       NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.UISETTINGS_T VOLATILE;

CREATE INDEX @SCHEMA@.UIS_CCID ON @SCHEMA@.UISETTINGS_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.REPLY_HANDLER_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  REPLY_HANDLER                      BLOB(3900k)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.REPLY_HANDLER_T VOLATILE;

CREATE INDEX @SCHEMA@.RH_CCID ON @SCHEMA@.REPLY_HANDLER_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_TIMER_T
(
  OID                                CHAR(16)            FOR BIT DATA  NOT NULL ,
  KIND                               INTEGER                           NOT NULL ,
  SCHEDULER_ID                       VARCHAR(254)                      NOT NULL ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( OID, KIND )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TASK_TIMER_T VOLATILE;

CREATE TABLE @SCHEMA@.TASK_INST_CPROP_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  NAME                               VARCHAR(220)                      NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DATA_TYPE                          VARCHAR(254)                               ,
  STRING_VALUE                       VARCHAR(254)                               ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, NAME )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TASK_INST_CPROP_T VOLATILE;

CREATE INDEX @SCHEMA@.TICP_CCID ON @SCHEMA@.TASK_INST_CPROP_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_INST_LDESC_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DISPLAY_NAME                       VARCHAR(64)                                ,
  DESCRIPTION                        VARCHAR(254)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, LOCALE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TASK_INST_LDESC_T VOLATILE;

CREATE INDEX @SCHEMA@.TILD_CCID ON @SCHEMA@.TASK_INST_LDESC_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TIDOCUMENTATION_T
(
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  DOCUMENTATION                      CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TKIID, LOCALE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TIDOCUMENTATION_T VOLATILE;

CREATE INDEX @SCHEMA@.TIDOC_CCID ON @SCHEMA@.TIDOCUMENTATION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.ITASK_MESSAGE_DEFINITION_T
(
  TMTID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  KIND                               INTEGER                           NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  MESSAGE_DEFINITION                 BLOB(3900K)                                ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TMTID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.ITASK_MESSAGE_DEFINITION_T VOLATILE;

CREATE INDEX @SCHEMA@.ITMD_IDKINSTYPE ON @SCHEMA@.ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, MESSAGE_TYPE_NS, MESSAGE_TYPE_NAME, KIND
);

CREATE INDEX @SCHEMA@.ITMD_TKIIDKINDFN ON @SCHEMA@.ITASK_MESSAGE_DEFINITION_T
(   
  TKIID, KIND, FAULT_NAME
);

CREATE INDEX @SCHEMA@.ITMD_CCID ON @SCHEMA@.ITASK_MESSAGE_DEFINITION_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_MESSAGE_INSTANCE_T
(
  TMIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  TMTID                              CHAR(16)            FOR BIT DATA           ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  FAULT_NAME                         VARCHAR(254)                               ,
  KIND                               INTEGER                           NOT NULL ,
  MESSAGE_TYPE_NS                    VARCHAR(220)                      NOT NULL ,
  MESSAGE_TYPE_NAME                  VARCHAR(220)                      NOT NULL ,
  DATA                               BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( TMIID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TASK_MESSAGE_INSTANCE_T VOLATILE;

CREATE INDEX @SCHEMA@.TMI_TI_K ON @SCHEMA@.TASK_MESSAGE_INSTANCE_T
(   
  TKIID, KIND
);

CREATE INDEX @SCHEMA@.TMI_TMTID ON @SCHEMA@.TASK_MESSAGE_INSTANCE_T
(   
  TMTID
);

CREATE INDEX @SCHEMA@.TMI_CCID ON @SCHEMA@.TASK_MESSAGE_INSTANCE_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_AUDIT_LOG_T
(
  ALID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  AUDIT_EVENT                        INTEGER                           NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA           ,
  TKTID                              CHAR(16)            FOR BIT DATA           ,
  ESIID                              CHAR(16)            FOR BIT DATA           ,
  ESTID                              CHAR(16)            FOR BIT DATA           ,
  TOP_TKIID                          CHAR(16)            FOR BIT DATA           ,
  FOLLOW_ON_TKIID                    CHAR(16)            FOR BIT DATA           ,
  PARENT_TKIID                       CHAR(16)            FOR BIT DATA           ,
  PARENT_CONTEXT_ID                  CHAR(16)            FOR BIT DATA           ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA           ,
  WI_REASON                          INTEGER                                    ,
  NAME                               VARCHAR(254)                               ,
  NAMESPACE                          VARCHAR(254)                               ,
  VALID_FROM_UTC                     TIMESTAMP                                  ,
  EVENT_TIME_UTC                     TIMESTAMP                                  ,
  PARENT_TASK_NAME                   VARCHAR(254)                               ,
  PARENT_TASK_NAMESPACE              VARCHAR(254)                               ,
  TASK_KIND                          INTEGER                                    ,
  TASK_STATE                         INTEGER                                    ,
  FAULT_TYPE_NAME                    VARCHAR(220)                               ,
  FAULT_NAMESPACE                    VARCHAR(220)                               ,
  FAULT_NAME                         VARCHAR(220)                               ,
  NEW_USER                           VARCHAR(128)                               ,
  OLD_USER                           VARCHAR(128)                               ,
  PRINCIPAL                          VARCHAR(128)                               ,
  USERS                              CLOB(8192)                                 ,
  DESCRIPTION                        CLOB(8192)                                 ,
  MESSAGE_DATA                       BLOB(1073741823)                           ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( ALID )
) IN AUDITLOG;

CREATE TABLE @SCHEMA@.IMAIL_T
(
  OBJECT_ID                          CHAR(16)            FOR BIT DATA  NOT NULL ,
  FROM_STATE                         INTEGER                           NOT NULL ,
  TO_STATE                           INTEGER                           NOT NULL ,
  LOCALE                             VARCHAR(32)                       NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  SUBJECT                            VARCHAR(254)                      NOT NULL ,
  URI                                VARCHAR(254)                               ,
  BODY_TEXT                          CLOB(4096)                                 ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( OBJECT_ID, FROM_STATE, TO_STATE, LOCALE )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.IMAIL_T VOLATILE;

CREATE INDEX @SCHEMA@.IMN_CTX ON @SCHEMA@.IMAIL_T
(   
  CONTAINMENT_CONTEXT_ID
);

CREATE TABLE @SCHEMA@.TASK_HISTORY_T
(
  PKID                               CHAR(16)            FOR BIT DATA  NOT NULL ,
  EVENT                              INTEGER                           NOT NULL ,
  TKIID                              CHAR(16)            FOR BIT DATA  NOT NULL ,
  CONTAINMENT_CONTEXT_ID             CHAR(16)            FOR BIT DATA  NOT NULL ,
  PARENT_TKIID                       CHAR(16)            FOR BIT DATA           ,
  ESIID                              CHAR(16)            FOR BIT DATA           ,
  REASON                             INTEGER                           NOT NULL ,
  EVENT_TIME                         TIMESTAMP                         NOT NULL ,
  NEXT_TIME                          TIMESTAMP                                  ,
  PRINCIPAL                          VARCHAR(128)                      NOT NULL ,
  WORK_ITEM_KIND                     INTEGER                           NOT NULL ,
  FROM_ID                            VARCHAR(128)                               ,
  TO_ID                              VARCHAR(128)                               ,
  VERSION_ID                         SMALLINT                          NOT NULL ,
  PRIMARY KEY ( PKID )
) IN INSTANCE;

ALTER TABLE @SCHEMA@.TASK_HISTORY_T VOLATILE;

CREATE INDEX @SCHEMA@.TH_TKIID ON @SCHEMA@.TASK_HISTORY_T
(   
  TKIID
);

CREATE INDEX @SCHEMA@.TH_CTXID ON @SCHEMA@.TASK_HISTORY_T
(   
  CONTAINMENT_CONTEXT_ID
);
-- set schema version to: 620
INSERT INTO @SCHEMA@.SCHEMA_VERSION (SCHEMA_VERSION, DATA_MIGRATION) VALUES( 620, 0 );


-- View: ProcessTemplate
CREATE VIEW @SCHEMA@.PROCESS_TEMPLATE(PTID, NAME, DISPLAY_NAME, VALID_FROM, TARGET_NAMESPACE, APPLICATION_NAME, VERSION, CREATED, STATE, EXECUTION_MODE, DESCRIPTION, CAN_RUN_SYNC, CAN_RUN_INTERRUP, COMP_SPHERE, CONTINUE_ON_ERROR ) AS
 SELECT @SCHEMA@.PROCESS_TEMPLATE_B_T.PTID, @SCHEMA@.PROCESS_TEMPLATE_B_T.NAME, @SCHEMA@.PROCESS_TEMPLATE_B_T.DISPLAY_NAME, @SCHEMA@.PROCESS_TEMPLATE_B_T.VALID_FROM, @SCHEMA@.PROCESS_TEMPLATE_B_T.TARGET_NAMESPACE, @SCHEMA@.PROCESS_TEMPLATE_B_T.APPLICATION_NAME, @SCHEMA@.PROCESS_TEMPLATE_B_T.VERSION, @SCHEMA@.PROCESS_TEMPLATE_B_T.CREATED, @SCHEMA@.PROCESS_TEMPLATE_B_T.STATE, @SCHEMA@.PROCESS_TEMPLATE_B_T.EXECUTION_MODE, @SCHEMA@.PROCESS_TEMPLATE_B_T.DESCRIPTION, @SCHEMA@.PROCESS_TEMPLATE_B_T.CAN_CALL, @SCHEMA@.PROCESS_TEMPLATE_B_T.CAN_INITIATE, @SCHEMA@.PROCESS_TEMPLATE_B_T.COMPENSATION_SPHERE, @SCHEMA@.PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM @SCHEMA@.PROCESS_TEMPLATE_B_T;

-- View: ProcessTemplAttr
CREATE VIEW @SCHEMA@.PROCESS_TEMPL_ATTR(PTID, NAME, VALUE ) AS
 SELECT @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T.PTID, @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T.ATTR_KEY, @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T.VALUE
 FROM @SCHEMA@.PROCESS_TEMPLATE_ATTRIBUTE_B_T;

-- View: ProcessInstance
CREATE VIEW @SCHEMA@.PROCESS_INSTANCE(PTID, PIID, NAME, STATE, CREATED, STARTED, COMPLETED, PARENT_NAME, TOP_LEVEL_NAME, PARENT_PIID, TOP_LEVEL_PIID, STARTER, DESCRIPTION, TEMPLATE_NAME, TEMPLATE_DESCR, RESUMES, CONTINUE_ON_ERROR ) AS
 SELECT @SCHEMA@.PROCESS_INSTANCE_B_T.PTID, @SCHEMA@.PROCESS_INSTANCE_B_T.PIID, @SCHEMA@.PROCESS_INSTANCE_B_T.NAME, @SCHEMA@.PROCESS_INSTANCE_B_T.STATE, @SCHEMA@.PROCESS_INSTANCE_B_T.CREATED, @SCHEMA@.PROCESS_INSTANCE_B_T.STARTED, @SCHEMA@.PROCESS_INSTANCE_B_T.COMPLETED, @SCHEMA@.PROCESS_INSTANCE_B_T.PARENT_NAME, @SCHEMA@.PROCESS_INSTANCE_B_T.TOP_LEVEL_NAME, @SCHEMA@.PROCESS_INSTANCE_B_T.PARENT_PIID, @SCHEMA@.PROCESS_INSTANCE_B_T.TOP_LEVEL_PIID, @SCHEMA@.PROCESS_INSTANCE_B_T.STARTER, @SCHEMA@.PROCESS_INSTANCE_B_T.DESCRIPTION, @SCHEMA@.PROCESS_TEMPLATE_B_T.NAME, @SCHEMA@.PROCESS_TEMPLATE_B_T.DESCRIPTION, @SCHEMA@.PROCESS_INSTANCE_B_T.RESUMES, @SCHEMA@.PROCESS_TEMPLATE_B_T.CONTINUE_ON_ERROR
 FROM @SCHEMA@.PROCESS_INSTANCE_B_T, @SCHEMA@.PROCESS_TEMPLATE_B_T
 WHERE @SCHEMA@.PROCESS_INSTANCE_B_T.PTID = @SCHEMA@.PROCESS_TEMPLATE_B_T.PTID;

-- View: ProcessAttribute
CREATE VIEW @SCHEMA@.PROCESS_ATTRIBUTE(PIID, NAME, VALUE, DATA_TYPE ) AS
 SELECT @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T.PIID, @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T.ATTR_KEY, @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T.VALUE, @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T.DATA_TYPE
 FROM @SCHEMA@.PROCESS_INSTANCE_ATTRIBUTE_T;

-- View: Activity
CREATE VIEW @SCHEMA@.ACTIVITY(PIID, AIID, PTID, ATID, SIID, STID, EHIID, ENCLOSING_FEIID, KIND, COMPLETED, ACTIVATED, FIRST_ACTIVATED, STARTED, STATE, STOP_REASON, OWNER, DESCRIPTION, EXPIRES, TEMPLATE_NAME, TEMPLATE_DESCR, BUSINESS_RELEVANCE, SKIP_REQUESTED, CONTINUE_ON_ERROR, INVOKED_INST_ID, INVOKED_INST_TYPE ) AS
 SELECT @SCHEMA@.ACTIVITY_INSTANCE_B_T.PIID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.AIID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.PTID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.ATID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.SIID, @SCHEMA@.ACTIVITY_TEMPLATE_B_T.PARENT_STID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.EHIID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.ENCLOSING_FEIID, @SCHEMA@.ACTIVITY_TEMPLATE_B_T.KIND, @SCHEMA@.ACTIVITY_INSTANCE_B_T.FINISHED, @SCHEMA@.ACTIVITY_INSTANCE_B_T.ACTIVATED, @SCHEMA@.ACTIVITY_INSTANCE_B_T.FIRST_ACTIVATED, @SCHEMA@.ACTIVITY_INSTANCE_B_T.STARTED, @SCHEMA@.ACTIVITY_INSTANCE_B_T.STATE, @SCHEMA@.ACTIVITY_INSTANCE_B_T.STOP_REASON, @SCHEMA@.ACTIVITY_INSTANCE_B_T.OWNER, @SCHEMA@.ACTIVITY_INSTANCE_B_T.DESCRIPTION, @SCHEMA@.ACTIVITY_INSTANCE_B_T.EXPIRES, @SCHEMA@.ACTIVITY_TEMPLATE_B_T.NAME, @SCHEMA@.ACTIVITY_TEMPLATE_B_T.DESCRIPTION, @SCHEMA@.ACTIVITY_TEMPLATE_B_T.BUSINESS_RELEVANCE, @SCHEMA@.ACTIVITY_INSTANCE_B_T.SKIP_REQUESTED, @SCHEMA@.ACTIVITY_INSTANCE_B_T.CONTINUE_ON_ERROR, @SCHEMA@.ACTIVITY_INSTANCE_B_T.INVOKED_INSTANCE_ID, @SCHEMA@.ACTIVITY_INSTANCE_B_T.INVOKED_INSTANCE_TYPE
 FROM @SCHEMA@.ACTIVITY_INSTANCE_B_T, @SCHEMA@.ACTIVITY_TEMPLATE_B_T
 WHERE @SCHEMA@.ACTIVITY_INSTANCE_B_T.ATID = @SCHEMA@.ACTIVITY_TEMPLATE_B_T.ATID;

-- View: ActivityAttribute
CREATE VIEW @SCHEMA@.ACTIVITY_ATTRIBUTE(AIID, NAME, VALUE, DATA_TYPE ) AS
 SELECT @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T.AIID, @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T.ATTR_KEY, @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T.ATTR_VALUE, @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T.DATA_TYPE
 FROM @SCHEMA@.ACTIVITY_INSTANCE_ATTR_B_T;

-- View: Event
CREATE VIEW @SCHEMA@.EVENT(EIID, AIID, PIID, EHTID, SIID, NAME ) AS
 SELECT @SCHEMA@.EVENT_INSTANCE_B_T.EIID, @SCHEMA@.EVENT_INSTANCE_B_T.AIID, @SCHEMA@.EVENT_INSTANCE_B_T.PIID, @SCHEMA@.EVENT_INSTANCE_B_T.EHTID, @SCHEMA@.EVENT_INSTANCE_B_T.SIID, @SCHEMA@.SERVICE_TEMPLATE_B_T.NAME
 FROM @SCHEMA@.EVENT_INSTANCE_B_T, @SCHEMA@.SERVICE_TEMPLATE_B_T
 WHERE @SCHEMA@.EVENT_INSTANCE_B_T.STATE = 2 AND @SCHEMA@.EVENT_INSTANCE_B_T.VTID = @SCHEMA@.SERVICE_TEMPLATE_B_T.VTID;

-- View: WorkItem
CREATE VIEW @SCHEMA@.WORK_ITEM(WIID, OWNER_ID, GROUP_NAME, EVERYBODY, OBJECT_TYPE, OBJECT_ID, ASSOC_OBJECT_TYPE, ASSOC_OID, REASON, CREATION_TIME, QIID, KIND ) AS
 SELECT @SCHEMA@.WORK_ITEM_T.WIID, @SCHEMA@.WORK_ITEM_T.OWNER_ID, @SCHEMA@.WORK_ITEM_T.GROUP_NAME, @SCHEMA@.WORK_ITEM_T.EVERYBODY, @SCHEMA@.WORK_ITEM_T.OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.OBJECT_ID, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OID, @SCHEMA@.WORK_ITEM_T.REASON, @SCHEMA@.WORK_ITEM_T.CREATION_TIME, @SCHEMA@.WORK_ITEM_T.QIID, @SCHEMA@.WORK_ITEM_T.KIND
 FROM @SCHEMA@.WORK_ITEM_T
 WHERE @SCHEMA@.WORK_ITEM_T.AUTH_INFO = 1
 UNION ALL SELECT @SCHEMA@.WORK_ITEM_T.WIID, @SCHEMA@.WORK_ITEM_T.OWNER_ID, @SCHEMA@.WORK_ITEM_T.GROUP_NAME, @SCHEMA@.WORK_ITEM_T.EVERYBODY, @SCHEMA@.WORK_ITEM_T.OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.OBJECT_ID, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OID, @SCHEMA@.WORK_ITEM_T.REASON, @SCHEMA@.WORK_ITEM_T.CREATION_TIME, @SCHEMA@.WORK_ITEM_T.QIID, @SCHEMA@.WORK_ITEM_T.KIND
 FROM @SCHEMA@.WORK_ITEM_T
 WHERE @SCHEMA@.WORK_ITEM_T.AUTH_INFO = 2
 UNION ALL SELECT @SCHEMA@.WORK_ITEM_T.WIID, @SCHEMA@.WORK_ITEM_T.OWNER_ID, @SCHEMA@.WORK_ITEM_T.GROUP_NAME, @SCHEMA@.WORK_ITEM_T.EVERYBODY, @SCHEMA@.WORK_ITEM_T.OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.OBJECT_ID, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OID, @SCHEMA@.WORK_ITEM_T.REASON, @SCHEMA@.WORK_ITEM_T.CREATION_TIME, @SCHEMA@.WORK_ITEM_T.QIID, @SCHEMA@.WORK_ITEM_T.KIND
 FROM @SCHEMA@.WORK_ITEM_T
 WHERE @SCHEMA@.WORK_ITEM_T.AUTH_INFO = 3
 UNION ALL SELECT @SCHEMA@.WORK_ITEM_T.WIID, @SCHEMA@.RETRIEVED_USER_T.OWNER_ID, @SCHEMA@.WORK_ITEM_T.GROUP_NAME, @SCHEMA@.WORK_ITEM_T.EVERYBODY, @SCHEMA@.WORK_ITEM_T.OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.OBJECT_ID, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OBJECT_TYPE, @SCHEMA@.WORK_ITEM_T.ASSOCIATED_OID, @SCHEMA@.WORK_ITEM_T.REASON, @SCHEMA@.WORK_ITEM_T.CREATION_TIME, @SCHEMA@.WORK_ITEM_T.QIID, @SCHEMA@.WORK_ITEM_T.KIND
 FROM @SCHEMA@.WORK_ITEM_T, @SCHEMA@.RETRIEVED_USER_T
 WHERE @SCHEMA@.WORK_ITEM_T.AUTH_INFO = 0 AND @SCHEMA@.WORK_ITEM_T.QIID = @SCHEMA@.RETRIEVED_USER_T.QIID;

-- View: ActivityService
CREATE VIEW @SCHEMA@.ACTIVITY_SERVICE(EIID, AIID, PIID, VTID, PORT_TYPE, NAME_SPACE_URI, OPERATION ) AS
 SELECT @SCHEMA@.EVENT_INSTANCE_B_T.EIID, @SCHEMA@.EVENT_INSTANCE_B_T.AIID, @SCHEMA@.EVENT_INSTANCE_B_T.PIID, @SCHEMA@.EVENT_INSTANCE_B_T.VTID, @SCHEMA@.SERVICE_TEMPLATE_B_T.PORT_TYPE_NAME,@SCHEMA@.URI_TEMPLATE_B_T.URI, @SCHEMA@.SERVICE_TEMPLATE_B_T.OPERATION_NAME
 FROM @SCHEMA@.EVENT_INSTANCE_B_T, @SCHEMA@.SERVICE_TEMPLATE_B_T, @SCHEMA@.URI_TEMPLATE_B_T
 WHERE @SCHEMA@.EVENT_INSTANCE_B_T.STATE = 2 AND @SCHEMA@.EVENT_INSTANCE_B_T.VTID = @SCHEMA@.SERVICE_TEMPLATE_B_T.VTID AND @SCHEMA@.SERVICE_TEMPLATE_B_T.PORT_TYPE_UTID = @SCHEMA@.URI_TEMPLATE_B_T.UTID;

-- View: QueryProperty
CREATE VIEW @SCHEMA@.QUERY_PROPERTY(PIID, VARIABLE_NAME, NAME, NAMESPACE, GENERIC_VALUE, STRING_VALUE, NUMBER_VALUE, DECIMAL_VALUE, TIMESTAMP_VALUE ) AS
 SELECT @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.PIID, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.VARIABLE_NAME, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAME, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.PROPERTY_NAMESPACE, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.GENERIC_VALUE, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.STRING_VALUE, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.NUMBER_VALUE, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.DECIMAL_VALUE, @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T.TIMESTAMP_VALUE
 FROM @SCHEMA@.QUERYABLE_VARIABLE_INSTANCE_T;

-- View: QueryPropTempl
CREATE VIEW @SCHEMA@.QUERY_PROP_TEMPL(PTID, NAME, PROPERTY_NAME, URI, QUERY_TYPE, JAVA_TYPE ) AS
 SELECT @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T.PTID, @SCHEMA@.VARIABLE_TEMPLATE_B_T.NAME, @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_NAME, @SCHEMA@.URI_TEMPLATE_B_T.URI, @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T.QUERY_TYPE, @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T.JAVA_TYPE
 FROM @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T, @SCHEMA@.VARIABLE_TEMPLATE_B_T, @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T, @SCHEMA@.URI_TEMPLATE_B_T
 WHERE @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T.CTID = @SCHEMA@.VARIABLE_TEMPLATE_B_T.CTID AND @SCHEMA@.QUERYABLE_VARIABLE_TEMPLATE_T.PAID = @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T.PAID AND @SCHEMA@.PROPERTY_ALIAS_TEMPLATE_B_T.PROPERTY_UTID = @SCHEMA@.URI_TEMPLATE_B_T.UTID;

-- View: AuditLog
CREATE VIEW @SCHEMA@.AUDIT_LOG(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, SCOPE_NAME, PROCESS_TEMPL_NAME, PROCESS_INST_NAME, TOP_LEVEL_PI_NAME, TOP_LEVEL_PIID, PARENT_PI_NAME, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, IMPL_NAME, PRINCIPAL, TERMINAL_NAME, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ATID, ADDITIONAL_INFO, OBJECT_META_TYPE ) AS
 SELECT @SCHEMA@.AUDIT_LOG_T.ALID,@SCHEMA@.AUDIT_LOG_T.EVENT_TIME,@SCHEMA@.AUDIT_LOG_T.EVENT_TIME_UTC,@SCHEMA@.AUDIT_LOG_T.AUDIT_EVENT,@SCHEMA@.AUDIT_LOG_T.PTID,@SCHEMA@.AUDIT_LOG_T.PIID,@SCHEMA@.AUDIT_LOG_T.AIID,@SCHEMA@.AUDIT_LOG_T.SIID,@SCHEMA@.AUDIT_LOG_T.VARIABLE_NAME,@SCHEMA@.AUDIT_LOG_T.PROCESS_TEMPL_NAME, @SCHEMA@.AUDIT_LOG_T.PROCESS_INST_NAME,@SCHEMA@.AUDIT_LOG_T.TOP_LEVEL_PI_NAME,@SCHEMA@.AUDIT_LOG_T.TOP_LEVEL_PIID,@SCHEMA@.AUDIT_LOG_T.PARENT_PI_NAME,@SCHEMA@.AUDIT_LOG_T.PARENT_PIID,@SCHEMA@.AUDIT_LOG_T.VALID_FROM,@SCHEMA@.AUDIT_LOG_T.VALID_FROM_UTC, @SCHEMA@.AUDIT_LOG_T.ACTIVITY_NAME,@SCHEMA@.AUDIT_LOG_T.ACTIVITY_KIND,@SCHEMA@.AUDIT_LOG_T.ACTIVITY_STATE,@SCHEMA@.AUDIT_LOG_T.CONTROL_LINK_NAME,@SCHEMA@.AUDIT_LOG_T.IMPL_NAME,@SCHEMA@.AUDIT_LOG_T.PRINCIPAL, @SCHEMA@.AUDIT_LOG_T.TERMINAL_NAME,@SCHEMA@.AUDIT_LOG_T.VARIABLE_DATA,@SCHEMA@.AUDIT_LOG_T.EXCEPTION_TEXT,@SCHEMA@.AUDIT_LOG_T.DESCRIPTION,@SCHEMA@.AUDIT_LOG_T.CORR_SET_INFO,@SCHEMA@.AUDIT_LOG_T.USER_NAME, @SCHEMA@.AUDIT_LOG_T.ATID, @SCHEMA@.AUDIT_LOG_T.ADDITIONAL_INFO, @SCHEMA@.AUDIT_LOG_T.OBJECT_META_TYPE
 FROM @SCHEMA@.AUDIT_LOG_T;

-- View: AuditLogB
CREATE VIEW @SCHEMA@.AUDIT_LOG_B(ALID, EVENT_TIME, EVENT_TIME_UTC, AUDIT_EVENT, PTID, PIID, AIID, SIID, VARIABLE_NAME, PROCESS_TEMPL_NAME, TOP_LEVEL_PIID, PARENT_PIID, VALID_FROM, VALID_FROM_UTC, ATID, ACTIVITY_NAME, ACTIVITY_KIND, ACTIVITY_STATE, CONTROL_LINK_NAME, PRINCIPAL, VARIABLE_DATA, EXCEPTION_TEXT, DESCRIPTION, CORR_SET_INFO, USER_NAME, ADDITIONAL_INFO ) AS
 SELECT @SCHEMA@.AUDIT_LOG_T.ALID,@SCHEMA@.AUDIT_LOG_T.EVENT_TIME,@SCHEMA@.AUDIT_LOG_T.EVENT_TIME_UTC,@SCHEMA@.AUDIT_LOG_T.AUDIT_EVENT,@SCHEMA@.AUDIT_LOG_T.PTID,@SCHEMA@.AUDIT_LOG_T.PIID,@SCHEMA@.AUDIT_LOG_T.AIID,@SCHEMA@.AUDIT_LOG_T.SIID,@SCHEMA@.AUDIT_LOG_T.VARIABLE_NAME,@SCHEMA@.AUDIT_LOG_T.PROCESS_TEMPL_NAME, @SCHEMA@.AUDIT_LOG_T.TOP_LEVEL_PIID,@SCHEMA@.AUDIT_LOG_T.PARENT_PIID,@SCHEMA@.AUDIT_LOG_T.VALID_FROM,@SCHEMA@.AUDIT_LOG_T.VALID_FROM_UTC,@SCHEMA@.AUDIT_LOG_T.ATID, @SCHEMA@.AUDIT_LOG_T.ACTIVITY_NAME,@SCHEMA@.AUDIT_LOG_T.ACTIVITY_KIND,@SCHEMA@.AUDIT_LOG_T.ACTIVITY_STATE,@SCHEMA@.AUDIT_LOG_T.CONTROL_LINK_NAME,@SCHEMA@.AUDIT_LOG_T.PRINCIPAL, @SCHEMA@.AUDIT_LOG_T.VARIABLE_DATA,@SCHEMA@.AUDIT_LOG_T.EXCEPTION_TEXT,@SCHEMA@.AUDIT_LOG_T.DESCRIPTION,@SCHEMA@.AUDIT_LOG_T.CORR_SET_INFO,@SCHEMA@.AUDIT_LOG_T.USER_NAME, @SCHEMA@.AUDIT_LOG_T.ADDITIONAL_INFO
 FROM @SCHEMA@.AUDIT_LOG_T
 WHERE @SCHEMA@.AUDIT_LOG_T.OBJECT_META_TYPE = 1;

-- View: ApplicationComp
CREATE VIEW @SCHEMA@.APPLICATION_COMP(ACOID, BUSINESS_RELEVANCE, NAME, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON ) AS
 SELECT @SCHEMA@.APPLICATION_COMPONENT_T.ACOID, @SCHEMA@.APPLICATION_COMPONENT_T.BUSINESS_RELEVANCE, @SCHEMA@.APPLICATION_COMPONENT_T.NAME, @SCHEMA@.APPLICATION_COMPONENT_T.SUPPORTS_AUTO_CLAIM, @SCHEMA@.APPLICATION_COMPONENT_T.SUPPORTS_CLAIM_SUSPENDED, @SCHEMA@.APPLICATION_COMPONENT_T.SUPPORTS_DELEGATION, @SCHEMA@.APPLICATION_COMPONENT_T.SUPPORTS_SUB_TASK, @SCHEMA@.APPLICATION_COMPONENT_T.SUPPORTS_FOLLOW_ON_TASK
 FROM @SCHEMA@.APPLICATION_COMPONENT_T;

-- View: Task
CREATE VIEW @SCHEMA@.TASK(TKIID, ACTIVATED, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, COMPLETED, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DUE, EXPIRES, FIRST_ACTIVATED, FOLLOW_ON_TKIID, IS_AD_HOC, IS_ESCALATED, IS_INLINE, IS_WAIT_FOR_SUB_TK, KIND, LAST_MODIFIED, LAST_STATE_CHANGE, NAME, NAME_SPACE, ORIGINATOR, OWNER, PARENT_CONTEXT_ID, PRIORITY, STARTED, STARTER, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, HIERARCHY_POSITION, IS_CHILD, SUSPENDED, TKTID, TOP_TKIID, TYPE, RESUMES ) AS
 SELECT @SCHEMA@.TASK_INSTANCE_T.TKIID, @SCHEMA@.TASK_INSTANCE_T.ACTIVATION_TIME, @SCHEMA@.TASK_INSTANCE_T.APPLICATION_DEFAULTS_ID, @SCHEMA@.TASK_INSTANCE_T.APPLICATION_NAME, @SCHEMA@.TASK_INSTANCE_T.BUSINESS_RELEVANCE, @SCHEMA@.TASK_INSTANCE_T.COMPLETION_TIME, @SCHEMA@.TASK_INSTANCE_T.CONTAINMENT_CONTEXT_ID, @SCHEMA@.TASK_INSTANCE_T.CONTEXT_AUTHORIZATION, @SCHEMA@.TASK_INSTANCE_T.DUE_TIME, @SCHEMA@.TASK_INSTANCE_T.EXPIRATION_TIME, @SCHEMA@.TASK_INSTANCE_T.FIRST_ACTIVATION_TIME, @SCHEMA@.TASK_INSTANCE_T.FOLLOW_ON_TKIID, @SCHEMA@.TASK_INSTANCE_T.IS_AD_HOC, @SCHEMA@.TASK_INSTANCE_T.IS_ESCALATED, @SCHEMA@.TASK_INSTANCE_T.IS_INLINE, @SCHEMA@.TASK_INSTANCE_T.IS_WAITING_FOR_SUBTASK, @SCHEMA@.TASK_INSTANCE_T.KIND, @SCHEMA@.TASK_INSTANCE_T.LAST_MODIFICATION_TIME, @SCHEMA@.TASK_INSTANCE_T.LAST_STATE_CHANGE_TIME, @SCHEMA@.TASK_INSTANCE_T.NAME, @SCHEMA@.TASK_INSTANCE_T.NAMESPACE, @SCHEMA@.TASK_INSTANCE_T.ORIGINATOR, @SCHEMA@.TASK_INSTANCE_T.OWNER, @SCHEMA@.TASK_INSTANCE_T.PARENT_CONTEXT_ID, @SCHEMA@.TASK_INSTANCE_T.PRIORITY, @SCHEMA@.TASK_INSTANCE_T.START_TIME, @SCHEMA@.TASK_INSTANCE_T.STARTER, @SCHEMA@.TASK_INSTANCE_T.STATE, @SCHEMA@.TASK_INSTANCE_T.SUPPORTS_AUTO_CLAIM, @SCHEMA@.TASK_INSTANCE_T.SUPPORTS_CLAIM_SUSPENDED, @SCHEMA@.TASK_INSTANCE_T.SUPPORTS_DELEGATION, @SCHEMA@.TASK_INSTANCE_T.SUPPORTS_SUB_TASK, @SCHEMA@.TASK_INSTANCE_T.SUPPORTS_FOLLOW_ON_TASK, @SCHEMA@.TASK_INSTANCE_T.HIERARCHY_POSITION, @SCHEMA@.TASK_INSTANCE_T.IS_CHILD, @SCHEMA@.TASK_INSTANCE_T.IS_SUSPENDED, @SCHEMA@.TASK_INSTANCE_T.TKTID, @SCHEMA@.TASK_INSTANCE_T.TOP_TKIID, @SCHEMA@.TASK_INSTANCE_T.TYPE, @SCHEMA@.TASK_INSTANCE_T.RESUMES
 FROM @SCHEMA@.TASK_INSTANCE_T;

-- View: TaskTempl
CREATE VIEW @SCHEMA@.TASK_TEMPL(TKTID, APPLIC_DEFAULTS_ID, APPLIC_NAME, BUSINESS_RELEVANCE, CONTAINMENT_CTX_ID, CTX_AUTHORIZATION, DEFINITION_NAME, DEFINITION_NS, IS_AD_HOC, IS_INLINE, KIND, NAME, NAMESPACE, PRIORITY, STATE, SUPPORT_AUTOCLAIM, SUPPORT_CLAIM_SUSP, SUPPORT_DELEGATION, SUPPORT_SUB_TASK, SUPPORT_FOLLOW_ON, TYPE, VALID_FROM, AUTONOMY ) AS
 SELECT @SCHEMA@.TASK_TEMPLATE_T.TKTID, @SCHEMA@.TASK_TEMPLATE_T.APPLICATION_DEFAULTS_ID, @SCHEMA@.TASK_TEMPLATE_T.APPLICATION_NAME, @SCHEMA@.TASK_TEMPLATE_T.BUSINESS_RELEVANCE, @SCHEMA@.TASK_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, @SCHEMA@.TASK_TEMPLATE_T.CONTEXT_AUTHORIZATION, @SCHEMA@.TASK_TEMPLATE_T.DEFINITION_NAME, @SCHEMA@.TASK_TEMPLATE_T.TARGET_NAMESPACE, @SCHEMA@.TASK_TEMPLATE_T.IS_AD_HOC, @SCHEMA@.TASK_TEMPLATE_T.IS_INLINE, @SCHEMA@.TASK_TEMPLATE_T.KIND, @SCHEMA@.TASK_TEMPLATE_T.NAME, @SCHEMA@.TASK_TEMPLATE_T.NAMESPACE, @SCHEMA@.TASK_TEMPLATE_T.PRIORITY, @SCHEMA@.TASK_TEMPLATE_T.STATE, @SCHEMA@.TASK_TEMPLATE_T.SUPPORTS_AUTO_CLAIM, @SCHEMA@.TASK_TEMPLATE_T.SUPPORTS_CLAIM_SUSPENDED, @SCHEMA@.TASK_TEMPLATE_T.SUPPORTS_DELEGATION, @SCHEMA@.TASK_TEMPLATE_T.SUPPORTS_SUB_TASK, @SCHEMA@.TASK_TEMPLATE_T.SUPPORTS_FOLLOW_ON_TASK, @SCHEMA@.TASK_TEMPLATE_T.TYPE, @SCHEMA@.TASK_TEMPLATE_T.VALID_FROM, @SCHEMA@.TASK_TEMPLATE_T.AUTONOMY
 FROM @SCHEMA@.TASK_TEMPLATE_T;

-- View: Escalation
CREATE VIEW @SCHEMA@.ESCALATION(ESIID, ACTION, ACTIVATION_STATE, ACTIVATION_TIME, ESCALATION_TIME, AT_LEAST_EXP_STATE, ESTID, FIRST_ESIID, INCREASE_PRIORITY, NAME, STATE, TKIID ) AS
 SELECT @SCHEMA@.ESCALATION_INSTANCE_T.ESIID, @SCHEMA@.ESCALATION_INSTANCE_T.ACTION, @SCHEMA@.ESCALATION_INSTANCE_T.ACTIVATION_STATE, @SCHEMA@.ESCALATION_INSTANCE_T.ACTIVATION_TIME, @SCHEMA@.ESCALATION_INSTANCE_T.ESCALATION_TIME, @SCHEMA@.ESCALATION_INSTANCE_T.AT_LEAST_EXPECTED_STATE, @SCHEMA@.ESCALATION_INSTANCE_T.ESTID, @SCHEMA@.ESCALATION_INSTANCE_T.FIRST_ESIID, @SCHEMA@.ESCALATION_INSTANCE_T.INCREASE_PRIORITY, @SCHEMA@.ESCALATION_INSTANCE_T.NAME, @SCHEMA@.ESCALATION_INSTANCE_T.STATE, @SCHEMA@.ESCALATION_INSTANCE_T.TKIID
 FROM @SCHEMA@.ESCALATION_INSTANCE_T;

-- View: EscTempl
CREATE VIEW @SCHEMA@.ESC_TEMPL(ESTID, FIRST_ESTID, PREVIOUS_ESTID, TKTID, CONTAINMENT_CTX_ID, NAME, ACTIVATION_STATE, AT_LEAST_EXP_STATE, INCREASE_PRIORITY, ACTION ) AS
 SELECT @SCHEMA@.ESCALATION_TEMPLATE_T.ESTID, @SCHEMA@.ESCALATION_TEMPLATE_T.FIRST_ESTID, @SCHEMA@.ESCALATION_TEMPLATE_T.PREVIOUS_ESTID, @SCHEMA@.ESCALATION_TEMPLATE_T.TKTID, @SCHEMA@.ESCALATION_TEMPLATE_T.CONTAINMENT_CONTEXT_ID, @SCHEMA@.ESCALATION_TEMPLATE_T.NAME, @SCHEMA@.ESCALATION_TEMPLATE_T.ACTIVATION_STATE, @SCHEMA@.ESCALATION_TEMPLATE_T.AT_LEAST_EXPECTED_STATE, @SCHEMA@.ESCALATION_TEMPLATE_T.INCREASE_PRIORITY, @SCHEMA@.ESCALATION_TEMPLATE_T.ACTION
 FROM @SCHEMA@.ESCALATION_TEMPLATE_T;

-- View: EscTemplDesc
CREATE VIEW @SCHEMA@.ESC_TEMPL_DESC(ESTID, LOCALE, TKTID, DISPLAY_NAME, DESCRIPTION ) AS
 SELECT @SCHEMA@.ESC_TEMPL_LDESC_T.ESTID, @SCHEMA@.ESC_TEMPL_LDESC_T.LOCALE, @SCHEMA@.ESC_TEMPL_LDESC_T.TKTID, @SCHEMA@.ESC_TEMPL_LDESC_T.DISPLAY_NAME, @SCHEMA@.ESC_TEMPL_LDESC_T.DESCRIPTION
 FROM @SCHEMA@.ESC_TEMPL_LDESC_T;

-- View: TaskTemplCProp
CREATE VIEW @SCHEMA@.TASK_TEMPL_CPROP(TKTID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT @SCHEMA@.TASK_TEMPL_CPROP_T.TKTID, @SCHEMA@.TASK_TEMPL_CPROP_T.NAME, @SCHEMA@.TASK_TEMPL_CPROP_T.DATA_TYPE, @SCHEMA@.TASK_TEMPL_CPROP_T.STRING_VALUE
 FROM @SCHEMA@.TASK_TEMPL_CPROP_T;

-- View: EscTemplCProp
CREATE VIEW @SCHEMA@.ESC_TEMPL_CPROP(ESTID, NAME, TKTID, DATA_TYPE, VALUE ) AS
 SELECT @SCHEMA@.ESC_TEMPL_CPROP_T.ESTID, @SCHEMA@.ESC_TEMPL_CPROP_T.NAME, @SCHEMA@.ESC_TEMPL_CPROP_T.TKTID, @SCHEMA@.ESC_TEMPL_CPROP_T.DATA_TYPE, @SCHEMA@.ESC_TEMPL_CPROP_T.STRING_VALUE
 FROM @SCHEMA@.ESC_TEMPL_CPROP_T;

-- View: TaskTemplDesc
CREATE VIEW @SCHEMA@.TASK_TEMPL_DESC(TKTID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT @SCHEMA@.TASK_TEMPL_LDESC_T.TKTID, @SCHEMA@.TASK_TEMPL_LDESC_T.LOCALE, @SCHEMA@.TASK_TEMPL_LDESC_T.DESCRIPTION, @SCHEMA@.TASK_TEMPL_LDESC_T.DISPLAY_NAME
 FROM @SCHEMA@.TASK_TEMPL_LDESC_T;

-- View: TaskCProp
CREATE VIEW @SCHEMA@.TASK_CPROP(TKIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT @SCHEMA@.TASK_INST_CPROP_T.TKIID, @SCHEMA@.TASK_INST_CPROP_T.NAME, @SCHEMA@.TASK_INST_CPROP_T.DATA_TYPE, @SCHEMA@.TASK_INST_CPROP_T.STRING_VALUE
 FROM @SCHEMA@.TASK_INST_CPROP_T;

-- View: TaskDesc
CREATE VIEW @SCHEMA@.TASK_DESC(TKIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT @SCHEMA@.TASK_INST_LDESC_T.TKIID, @SCHEMA@.TASK_INST_LDESC_T.LOCALE, @SCHEMA@.TASK_INST_LDESC_T.DESCRIPTION, @SCHEMA@.TASK_INST_LDESC_T.DISPLAY_NAME
 FROM @SCHEMA@.TASK_INST_LDESC_T;

-- View: EscalationCProp
CREATE VIEW @SCHEMA@.ESCALATION_CPROP(ESIID, NAME, DATA_TYPE, STRING_VALUE ) AS
 SELECT @SCHEMA@.ESC_INST_CPROP_T.ESIID, @SCHEMA@.ESC_INST_CPROP_T.NAME, @SCHEMA@.ESC_INST_CPROP_T.DATA_TYPE, @SCHEMA@.ESC_INST_CPROP_T.STRING_VALUE
 FROM @SCHEMA@.ESC_INST_CPROP_T;

-- View: TaskHistory
CREATE VIEW @SCHEMA@.TASK_HISTORY(TKIID, ESIID, PARENT_TKIID, EVENT, REASON, EVENT_TIME, NEXT_TIME, PRINCIPAL, WORK_ITEM_KIND, FROM_ID, TO_ID ) AS
 SELECT @SCHEMA@.TASK_HISTORY_T.TKIID, @SCHEMA@.TASK_HISTORY_T.ESIID, @SCHEMA@.TASK_HISTORY_T.PARENT_TKIID, @SCHEMA@.TASK_HISTORY_T.EVENT, @SCHEMA@.TASK_HISTORY_T.REASON, @SCHEMA@.TASK_HISTORY_T.EVENT_TIME, @SCHEMA@.TASK_HISTORY_T.NEXT_TIME, @SCHEMA@.TASK_HISTORY_T.PRINCIPAL, @SCHEMA@.TASK_HISTORY_T.WORK_ITEM_KIND, @SCHEMA@.TASK_HISTORY_T.FROM_ID, @SCHEMA@.TASK_HISTORY_T.TO_ID
 FROM @SCHEMA@.TASK_HISTORY_T;

-- View: EscalationDesc
CREATE VIEW @SCHEMA@.ESCALATION_DESC(ESIID, LOCALE, DESCRIPTION, DISPLAY_NAME ) AS
 SELECT @SCHEMA@.ESC_INST_LDESC_T.ESIID, @SCHEMA@.ESC_INST_LDESC_T.LOCALE, @SCHEMA@.ESC_INST_LDESC_T.DESCRIPTION, @SCHEMA@.ESC_INST_LDESC_T.DISPLAY_NAME
 FROM @SCHEMA@.ESC_INST_LDESC_T;

-- View: TaskAuditLog
CREATE VIEW @SCHEMA@.TASK_AUDIT_LOG(ALID, AUDIT_EVENT, CONTAINMENT_CTX_ID, ESIID, ESTID, EVENT_TIME, FAULT_NAME, FAULT_TYPE_NAME, FAULT_NAME_SPACE, FOLLOW_ON_TKIID, NAME, NAMESPACE, NEW_USER, OLD_USER, PARENT_CONTEXT_ID, PARENT_TASK_NAME, PARENT_TASK_NAMESP, PARENT_TKIID, PRINCIPAL, TASK_KIND, TASK_STATE, TKIID, TKTID, TOP_TKIID, VAILD_FROM, WORK_ITEM_REASON, USERS, DESCRIPTION, MESSAGE_DATA ) AS
 SELECT @SCHEMA@.TASK_AUDIT_LOG_T.ALID, @SCHEMA@.TASK_AUDIT_LOG_T.AUDIT_EVENT, @SCHEMA@.TASK_AUDIT_LOG_T.CONTAINMENT_CONTEXT_ID, @SCHEMA@.TASK_AUDIT_LOG_T.ESIID, @SCHEMA@.TASK_AUDIT_LOG_T.ESTID, @SCHEMA@.TASK_AUDIT_LOG_T.EVENT_TIME_UTC, @SCHEMA@.TASK_AUDIT_LOG_T.FAULT_NAME, @SCHEMA@.TASK_AUDIT_LOG_T.FAULT_TYPE_NAME, @SCHEMA@.TASK_AUDIT_LOG_T.FAULT_NAMESPACE, @SCHEMA@.TASK_AUDIT_LOG_T.FOLLOW_ON_TKIID, @SCHEMA@.TASK_AUDIT_LOG_T.NAME, @SCHEMA@.TASK_AUDIT_LOG_T.NAMESPACE, @SCHEMA@.TASK_AUDIT_LOG_T.NEW_USER, @SCHEMA@.TASK_AUDIT_LOG_T.OLD_USER, @SCHEMA@.TASK_AUDIT_LOG_T.PARENT_CONTEXT_ID, @SCHEMA@.TASK_AUDIT_LOG_T.PARENT_TASK_NAME, @SCHEMA@.TASK_AUDIT_LOG_T.PARENT_TASK_NAMESPACE, @SCHEMA@.TASK_AUDIT_LOG_T.PARENT_TKIID, @SCHEMA@.TASK_AUDIT_LOG_T.PRINCIPAL, @SCHEMA@.TASK_AUDIT_LOG_T.TASK_KIND, @SCHEMA@.TASK_AUDIT_LOG_T.TASK_STATE, @SCHEMA@.TASK_AUDIT_LOG_T.TKIID, @SCHEMA@.TASK_AUDIT_LOG_T.TKTID, @SCHEMA@.TASK_AUDIT_LOG_T.TOP_TKIID, @SCHEMA@.TASK_AUDIT_LOG_T.VALID_FROM_UTC, @SCHEMA@.TASK_AUDIT_LOG_T.WI_REASON, @SCHEMA@.TASK_AUDIT_LOG_T.USERS, @SCHEMA@.TASK_AUDIT_LOG_T.DESCRIPTION, @SCHEMA@.TASK_AUDIT_LOG_T.MESSAGE_DATA
 FROM @SCHEMA@.TASK_AUDIT_LOG_T;


-- start import scheduler DDL: createSchemaDB2.ddl


CREATE TABLE @SCHEMA@."SCHED_TASK" ("TASKID" BIGINT NOT NULL ,
              "VERSION" VARCHAR(5) NOT NULL ,
              "ROW_VERSION" INTEGER NOT NULL ,
              "TASKTYPE" INTEGER NOT NULL ,
              "TASKSUSPENDED" SMALLINT NOT NULL ,
              "CANCELLED" SMALLINT NOT NULL ,
              "NEXTFIRETIME" BIGINT NOT NULL ,
              "STARTBYINTERVAL" VARCHAR(254) ,
              "STARTBYTIME" BIGINT ,
              "VALIDFROMTIME" BIGINT ,
              "VALIDTOTIME" BIGINT ,
              "REPEATINTERVAL" VARCHAR(254) ,
              "MAXREPEATS" INTEGER NOT NULL ,
              "REPEATSLEFT" INTEGER NOT NULL ,
              "TASKINFO" BLOB(102400) LOGGED NOT COMPACT ,
              "NAME" VARCHAR(254) NOT NULL ,
              "AUTOPURGE" INTEGER NOT NULL ,
              "FAILUREACTION" INTEGER ,
              "MAXATTEMPTS" INTEGER ,
              "QOS" INTEGER ,
              "PARTITIONID" INTEGER ,
              "OWNERTOKEN" VARCHAR(200) NOT NULL ,
              "CREATETIME" BIGINT NOT NULL )  IN "SCHEDTS";

ALTER TABLE @SCHEMA@."SCHED_TASK" ADD PRIMARY KEY ("TASKID");

CREATE INDEX @SCHEMA@."SCHED_TASK_IDX1" ON @SCHEMA@."SCHED_TASK" ("TASKID",
              "OWNERTOKEN") ;

CREATE INDEX @SCHEMA@."SCHED_TASK_IDX2" ON @SCHEMA@."SCHED_TASK" ("NEXTFIRETIME" ASC,
               "REPEATSLEFT",
               "PARTITIONID") CLUSTER;

CREATE TABLE @SCHEMA@."SCHED_TREG" ("REGKEY" VARCHAR(254) NOT NULL ,
              "REGVALUE" VARCHAR(254) ) IN "SCHEDTS";

ALTER TABLE @SCHEMA@."SCHED_TREG" ADD PRIMARY KEY ("REGKEY");

CREATE TABLE @SCHEMA@."SCHED_LMGR" (LEASENAME VARCHAR(254) NOT NULL,
               LEASEOWNER VARCHAR(254) NOT NULL,
               LEASE_EXPIRE_TIME  BIGINT,
              DISABLED VARCHAR(5))IN "SCHEDTS";

ALTER TABLE @SCHEMA@."SCHED_LMGR" ADD PRIMARY KEY ("LEASENAME");

CREATE TABLE @SCHEMA@."SCHED_LMPR" (LEASENAME VARCHAR(254) NOT NULL,
              NAME VARCHAR(254) NOT NULL,
              VALUE VARCHAR(254) NOT NULL)IN "SCHEDTS";

CREATE INDEX @SCHEMA@."SCHED_LMPR_IDX1" ON @SCHEMA@."SCHED_LMPR" (LEASENAME,
               NAME);

-- end import scheduler DDL: createSchemaDB2.ddl

