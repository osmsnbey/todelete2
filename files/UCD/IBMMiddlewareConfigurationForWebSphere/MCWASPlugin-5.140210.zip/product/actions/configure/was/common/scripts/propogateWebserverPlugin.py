"""
		Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

		
		File name: propogateWebserverPlugin.py
		
		This script will propogate the webserver plugin file for each webserver defined in web_servers
		This script is invoked as:
		wsadmin -lang jython -profile jythonLib.py -f propogateWebserverPlugin.py
				-webservers ${SCOPE_HOME}/web_servers.xml --
						xml file describing the web servers to propoage the plugin into
				-nd_profile_home ${ND_WAS_HOME}/profiles/${ND_PROFILE_NAME}
"""


from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

import sys

propogateWebserverPluginLogger = _Logger("propogateWebserverPlugin", MessageManager.RB_WEBSPHERE_WAS)


# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'webservers:;nd_profile_home:' )

# parse the properties into props
xmlWebServers = ConfigFileReader.openXmlConfig( optDict['webservers'] )

cellName = AdminControl.getCell()
##print "Propogating web server plugins for cell:" + cellName
propogateWebserverPluginLogger.log("CRWWA2098I",[cellName])

## propogate plugin config to web servers
objectName = AdminControl.completeObjectName("WebSphere:*,type=PluginCfgGenerator")
profileRoot = optDict['nd_profile_home']


serverContainder = xmlWebServers.findRAFWContainerNode('WebServer')
webServerNodes = serverContainder.getFilteredNodeArray("Server")
for xmlNode in webServerNodes:
		nodeName = xmlNode.getAttrValue("node")
		serverName = xmlNode.getAttrValue("name")
		if nodeName == None:
				##print "The server " + str(serverName) + " element does not contain the node attribute."
				propogateWebserverPluginLogger.log("CRWWA2019I",[str(serverName)])
				##print "Will try DEPRECATED <WSConfig> approach"
				propogateWebserverPluginLogger.log("CRWWA4005I")
				continue
		#endIf 
		commandArgs="[" + profileRoot + "/config "
		commandArgs += cellName + " " + nodeName + " " + serverName + "]"
		##print "propagating plugin with args: " + commandArgs
		propogateWebserverPluginLogger.log("CRWWA2021I",[commandArgs])
		AdminControl.invoke(objectName, 'propagate', commandArgs)
#endFor


nodeArray = xmlWebServers.getFilteredNodeArray('WSConfig')
if len(nodeArray) > 0:
		##print "DEPRECATED: The <WSConfig> elements for propogating the plugin is deprecated."
		propogateWebserverPluginLogger.log("CRWWA2021I")
		##print "Use the node attribute of the <webserver> element instead"
		propogateWebserverPluginLogger.log("CRWWA2022I")
		for xmlNode in nodeArray:
				nodeName = xmlNode.getAttrValue("node")
				serverName = xmlNode.getAttrValue("name")
				commandArgs="[" + profileRoot + "/config "
				commandArgs += cellName + " " + nodeName + " " + serverName + "]"
				##print "propagating plugin with args: " + commandArgs
				propogateWebserverPlugin.log("CRWWA2022I",[commandArgs])
				AdminControl.invoke(objectName, 'propagate', commandArgs)
		#endFor
#endIf