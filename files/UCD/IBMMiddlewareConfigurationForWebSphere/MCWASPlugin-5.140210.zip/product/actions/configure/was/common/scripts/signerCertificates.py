"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: signerCertificates.py
"""

import java.util as util
import java.io as javaio


class signerCertificates:
    
    """ adds a signer certificate to the specified key store """
    def addSignerCertificate(self, keyStoreName, certificateAlias, certificateFilePath, keyStoreScope):
        signerCertificateLogger.debug("adding certificateAlias:" +  certificateAlias)
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        #certificateFilePath
        commandOptions.append('-certificateFilePath')
        commandOptions.append(certificateFilePath)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)

        
        for option in commandOptions:
            signerCertificateLogger.debug(option)

        signerCertificateLogger.debug("looking up certificateAlias")
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate == None):
            AdminTask.addSignerCertificate(commandOptions)
        else:
            signerCertificateLogger.error("CRWWA2017I" ,[certificateAlias])
    
    """ deletes a certificate from the specified key store"""
    def deleteCertificate(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
            
        for option in commandOptions:
            signerCertificateLogger.debug(option)
            
        # Delete certificate if it exists
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.deleteSignerCertificate(commandOptions)
        else:
            signerCertificateLogger.log('CRWWA2018I')
        
    """ Extracts the signer portion of a personal certificate to a file """
    def extractCertificate(self, keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        commandOptions.append('-certificateFilePath')
        commandOptions.append(certificateFilePath)
        commandOptions.append('-base64Encoded')
        commandOptions.append(base64Encoded)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            signerCertificateLogger.debug(option)
            
        # Extract certificate if it exists
        certificate = self.getCertificate(keyStoreName, certificateAlias, keyStoreScope)
        if(certificate != None):
            AdminTask.extractSignerCertificate(commandOptions)
        else:
            signerCertificateLogger.log('CRWWA2018I')
        
    """ Get information about a certificate from the keyStore """
    def getCertificate(self, keyStoreName, certificateAlias, keyStoreScope):
        # required parameters 
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        #certificateAlias
        commandOptions.append('-certificateAlias')
        commandOptions.append(certificateAlias)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            signerCertificateLogger.debug(option)
            
        certificate = None
        try:
            certificate = AdminTask.getSignerCertificate(commandOptions)
        except:
            signerCertificateLogger.log("CRWWA2016I" ,[certificateAlias])
        return certificate
    
    """ list certificates in the specified key store """
    def listCertificates(self, keyStoreName, keyStoreScope):
        # required parameters
        #keyStoreName
        commandOptions = ['-keyStoreName ']
        commandOptions.append(keyStoreName)
        
        # optional parameters
        if(keyStoreScope != None):
            commandOptions.append('-keyStoreScope')
            commandOptions.append(keyStoreScope)
        
        for option in commandOptions:
            signerCertificateLogger.debug(option)
            
        return AdminTask.listSignerCertificates(commandOptions)
           
    def appendCommandOptions(self, commandString, command, key):
        certificateRequestLogger.debug("commandString: " + commandString + " command: " + command + " key: " + key)
        value = self.getProperty(key)
        
        if(value == None):
            return commandString          
        else:
            commandString = commandString + ' ' + command + ' ' + thisCertificateRequest.getProperty(key)
            return commandString
    
    def getProperty(self, key):
        value = properties.get(key)
        if(value == None):
            return
        else:
            return value
        
    def readProperties(self, xmlFile):
        signerCertificateLogger.log("CRWWA2054I",[xmlFile])
        properties = util.Properties()
        propertiesFileInputStream =javaio.FileInputStream(xmlFile)
        properties.load(propertiesFileInputStream)
        return properties
        
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;scopename:;mode:;action:;cellName:;nodeName:' )

# get scope
scope = AdminHelper.buildScope( optDict )
xmlFile = optDict['properties'] 
scopeType = optDict['scope']
action = optDict['action']
mode = optDict['mode']
cellName = optDict['cellName']
nodeName = optDict['nodeName']

signerCertificateLogger = _Logger("signerCertificates", MessageManager.RB_WEBSPHERE_WAS)
thisSignerCertificates = signerCertificates()

properties = thisSignerCertificates.readProperties(xmlFile)

keyStoreName = properties.get('Security.CertCA.KeyStoreName')
certificateAlias = properties.get('Security.CertCA.CertificateAlias')
keyStoreScope = properties.get('Security.CertCA.KeyStoreScope')

if(mode == MODE_EXECUTE):
    if(action == "ADD_CERTIFICATE"):
        certificateFilePath = properties.get('Security.CertCA.CertificateFilePath')
        thisSignerCertificates.addSignerCertificate(keyStoreName, certificateAlias, certificateFilePath, keyStoreScope)
        
    elif(action == "DELETE_CERTIFICATE"):
        thisSignerCertificates.deleteCertificate(keyStoreName, certificateAlias, keyStoreScope)
                
    elif(action == "EXTRACT_CERTIFICATE"):
        certificateFilePath = properties.get('Security.CertCA.CertificateFilePath')
        base64Encoded = properties.get('Security.CertCA.Base64Encoded')
        thisSignerCertificates.extractCertificate(keyStoreName, certificateAlias, certificateFilePath, base64Encoded, keyStoreScope)
                
    else:
        #print "Unsupported ACTION supplied: %s " % optDict['action']
        signerCertificateLogger.log("CRWWA5000I",[optDict['action']])
    AdminHelper.saveAndSyncCell()
else:
    ##print "Unsupported MODE supplied: %s " % optDict['mode']
   signerCertificateLogger.log("CRWWA5001I",[optDict['mode']])