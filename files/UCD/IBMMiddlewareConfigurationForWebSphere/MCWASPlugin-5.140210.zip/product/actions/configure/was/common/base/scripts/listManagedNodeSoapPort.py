"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listManagedNodeSoapPort.py
	
	This script is to list the SOAP port used by the managed node
	This script is invoked as:
	wsadmin -lang jython -f listManagedNodeSoapPort.py -managedNodeName ${opt.managedNodeName} 
"""


import sys

from com.ibm.rational.rafw.wsadmin.util import Globals
from com.ibm.rational.rafw.wsadmin.util import PropertyFileWriter
from JavaConversionHelper import JavaConversionHelper

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'managedNodeName:' )

nodeName = optDict['managedNodeName']
portDict = {}

nodeConnProps = AdminTask.getManagedNodeConnectorProperties('[ -connType SOAP -managedNodeName ' + nodeName + ' ]')
nodePortPattern = java.util.regex.Pattern.compile('port\\s*(\\d+)')
nodePortMatcher = nodePortPattern.matcher(java.lang.String(nodeConnProps))
if (nodePortMatcher.find() > 0):
	portDict['SOAP_PORT_VALUE'] = nodePortMatcher.group(1)
else:
	portDict['SOAP_PORT_VALUE'] = ""
#endIf
rafwHome = Globals.getInstallRoot()
nodeSOAPfile = rafwHome + "/work/" + nodeName + "_soap" + ".properties"
PropertyFileWriter().writeFile(nodeSOAPfile, JavaConversionHelper.mapDictToJava(portDict))
#end main		

