"""
	Licensed Materials - Property of IBM Corp. 
IBM Middleware Configuration for WebSphere 
(c) Copyright IBM Corporation 2003, 2013. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: coreGroupBridges.py
	
	This script creates core group bridge configuration
"""

import sys
from Logger import _Logger
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import ConfigMediator

class CGBMediator:
	def createConfig(self, scope, scopeType, xmlFile, typeNames, excludedTypes, marker):
		scopeid = AdminConfig.getid(scope)
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
	
		if (len(scopeid) == 0):
			print "ERROR: unable to find parent scope: " + scopeid
			print "Cannot write WAS config. Returning without doing anything"
			return
		#endIf
		
		myConfigWriter = ConfigWriter()
		for typeName in typeNames:
			myConfigWriter.removeExistingConfig(scopeType, typeName, scopeid)
			nodeArray = xmlProp.getFilteredNodeArray(typeName)	
			for xmlNode in nodeArray:
				myConfigWriter.createWASObject(xmlNode, scopeid, excludedTypes)
				myConfigWriter.updateWASReferenceAttributes([xmlNode], xmlNode.getConfigId(), [])
			#endFor
		#endFor	
	#endDef
#endClass

# parse the options into optDict
optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )

# get scope
scope = AdminHelper.buildScope( optDict )

propFile = optDict['properties'] 
scopeType=optDict['scope']

mode = optDict['mode']
excludeTypes = []
typeNames = ["CoreGroupBridgeSettings"]
marker = 'coreGroupBridges'

thisMediator = CGBMediator()
SCRIPT_LOGGER = _Logger("coreGroupBridgeSettings", MessageManager.RB_WEBSPHERE_WAS)
if (mode == MODE_EXECUTE):
	print "Creating CoreGroupBridgeSettings in scope: " + scope
	thisMediator.createConfig(scope, scopeType, propFile, typeNames, excludeTypes, marker)
	AdminHelper.saveAndSyncCell()
elif (mode == MODE_IMPORT):
	print "Importing CoreGroupBridgeSettings in scope: " + scope
	ConfigMediator.importConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
elif (mode == MODE_COMPARE):
	print "Comparing CoreGroupBridgeSettings in scope: " + scope
	ConfigMediator.compareConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
else:
	print "Unsupported MODE supplied: " + mode
#endIf
