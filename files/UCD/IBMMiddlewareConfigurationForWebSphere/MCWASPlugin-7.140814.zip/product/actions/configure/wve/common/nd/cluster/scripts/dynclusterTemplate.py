"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: dynclusterTemplate.py
	
	This script is to manage an existing server sub config based on type
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py -f dynclusterTemplate.py 
		-scope <scope: node/cluster/server/cell> 
		-scopename <server/cluster name> 
		-nodeName <node name> 
		-properties <server xml file> 
		-config_type <sub config element name>
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java
from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from ConfigMediator import *

from AdminHelper import AdminHelper

newline = java.lang.System.getProperty("line.separator")

class DynClusterTemplate:
	
	## The following types apply to APPLICATION_SERVER server types
	WVE_61_CONFIG_TYPES = [ "ActivitySessionService", "AdminService", "ApplicationProfileService", "ApplicationServer.Classloader",
						"CoreGroupBridgeService", "CustomService", "DiagnosticProviderService", "HAManagerService", "HTTPAccessLoggingService",
						"I18NService", "JavaPersistenceAPIService", "JavaProcessDef", "MessageListenerService", "NameServer", "ObjectPoolService", 
						"ObjectRequestBroker", "PMIService", "RASLoggingService", "SIBService", "StartupBeansService", "StatisticsProvider", 
						"ThreadPoolManager", "TraceService", "TPVService", "TransportChannelService", "SERVER.outputStreamRedirect", 
						"SERVER.errorStreamRedirect", "WorkAreaService" ]
	WVE_70_ADTL_CONFIG_TYPES = []
	
	## Define config types to be excluded for specific WAS versions
	WAS_EXCLUDED_CONFIG_TYPES = { "WAS61" : ["JavaPersistenceAPIService"], "WAS70" : [], "WAS80" : [], "WAS85" : [] }
	WVE_FINAL_CONFIG_TYPES = ["ApplicationServer"]		
	
	def __init__ (self, mode):
		self.LOGGER = _Logger("DynClusterTemplate", MessageManager.RB_WEBSPHERE_WVE)		
		self.configWriter = ConfigWriter()
		self.configReader = ConfigReader()
		self.ignoreEmptyXml = 0
		self.ignoreConfigDifferences = 0
		self.mode = mode		
	#endDef
	
	"""
		Returns the WVE cell version as a 2 character string.  [major,minor]
		Example: 61 / 70
	"""
	def getWveVersion(self):
		self.LOGGER.traceEnter()
		dmgrNode = AdminControl.getNode()
		productVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.wxdopProductVersion]')
		major,minor,trash = productVersion.split('.', 2)
		version = major + minor
		self.LOGGER.traceExit(version)
		return version
	#endDef
	
	"""
		Returns the WAS cell version as a 2 character string.  [major,minor]
		Example: 61 / 70 / 80
	"""
	def getWASVersion(self):
		self.LOGGER.traceEnter()
		dmgrNode = AdminControl.getNode()
		productVersion = AdminTask.getMetadataProperty ('[-nodeName ' + dmgrNode + ' -propertyName com.ibm.websphere.baseProductVersion]')
		major,minor,trash = productVersion.split('.', 2)
		version = major + minor
		self.LOGGER.traceExit(version)
		return version
	#endDef
	
	"""
		True if xml nodes which contain no data should be ignored.
		If false, execute mode will fail with an error
	"""	
	def setIgnoreEmptyXml(self, ignoreIt):
		self.ignoreEmptyXml = ignoreIt
	#endDef
	
	"""
		True if differences between servers should be ignored.
		If false, import mode will fail with an error when importing 2 servers that have 
		different configuration.
	"""
	def setIgnoreConfigDifferences(self, ignoreIt):
		self.ignoreConfigDifferences = ignoreIt
	#endDef
	
	def processServer(self, serverIds, xmlFile, configType, marker, scopeType):
		if (self.mode == MODE_EXECUTE):
			self.executeServers(serverIds, xmlFile, configType, scopeType)
		elif (self.mode == MODE_AUGMENT):
			self.augmentServers(serverIds, xmlFile, configType, scopeType)
		elif (self.mode == MODE_IMPORT):
			self.importServers(serverIds, xmlFile, configType, marker, scopeType)
		elif (self.mode == MODE_COMPARE):
			self.compareServers(serverIds, xmlFile, configType, marker, scopeType)
		else:
			print "Unsupported MODE supplied: " + mode
		#endIf
	#endDef

	def executeServers(self, serverIds, xmlFile, configType, scopeType, save="1"):
	
		print "Updating server config: "
	
		xmlProp = XmlProperty(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(configType)
		nodeArray = xmlProp.getFilteredNodeArray(configType)
	
		excludedTypes = self.getExcludedTypes(configType, scopeType)
		for serverId in serverIds:
			# SERVER is used to denote that the configuration type is accessible 
			# as an attribute of the server
			if (configType.find('SERVER.') >= 0):
				attrName = configType.split('.')[1]
				objId = AdminConfig.showAttribute(serverId, attrName)
				if (len(nodeArray) != 1):
					if (self.ignoreEmptyXml):
						msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
								"CRWWA0010I", [configType, scopeType])
						self.LOGGER.warn(msg)
						return						
					else:
						self.LOGGER.warn("configuration elements whose parent type is a Server attribute must have 1 XML configuration stanza")
					#endIf	
				else:
					self.configWriter.modify(objId, nodeArray[0], excludedTypes)
				#endIf
			else:
				objId, actualConfigType = self.processConfigType(serverId, configType)
				self.configWriter.updateWASObject(nodeArray, objId, actualConfigType, excludedTypes)
			#endIf
		#endFor
		if save is not None:
			AdminHelper.saveAndSyncCell()
		#endIf
	#endDef

	def augmentServers(self, serverIds, xmlFile, configType, scopeType):
			
		configElements = ConfigElements()
		print "Augmenting server config: "
	
		if (configType == "CustomService" or configType == "ApplicationServer.Classloader"):
			try:
				xmlProp  = XmlProperty(xmlFile)
				xmlProp = xmlProp.findRAFWContainerNode(configType)
				nodeArray = xmlProp.getFilteredNodeArray(configType)
			except:
				print "Warn -- not able to find " + xmlFile
				print "Cannot write WAS config. Returning without doing anything"
				return
			#endTry
		
			excludedTypes = self.getExcludedTypes(configType, scopeType)
			for serverId in serverIds:			
				objId, actualConfigType = self.processConfigType(serverId, configType)
				for xmlNode in nodeArray:
					self.LOGGER.info("Processing xmlNode: " + str(xmlNode))
					if (configType == "ApplicationServer.Classloader"):
						if (len(objId) > 0):
							self.augmentServersProcessClassLoader(objId, xmlNode, actualConfigType)
							configElements.addReferenceId(objId, xmlNode)
						else:
							## The parent configuration id doesn't exist, so we cannot update the child or its references
							self.LOGGER.log("CRWWA0128E", [serverId, str(xmlNode)])
							
						#endIf
					elif (configType == "CustomService"):
						self.augmentServersProcessCustomService(objId, xmlNode, actualConfigType)
						configElements.addReferenceId(objId, xmlNode)
					#endIf
				#endFor
			#endFor
			processedNodeDict = configElements.getReferenceIds()
			for objId in processedNodeDict.keys():
				self.configWriter.updateWASReferenceAttributes(processedNodeDict[objId], objId)
			#endFor
			AdminHelper.saveAndSyncCell()
		else:
			print "Error: ConfigType: " + configType + " is not supported in augment mode"
		#endIf
	#endDef

	def augmentServersProcessCustomService(self, objId, xmlNode, actualConfigType):
		
		displayName = xmlNode.getAttrValue("displayName")
		customServices = AdminConfig.list(actualConfigType, objId).split(newline)
		for customService in customServices:
			if (customService != ""):
				self.LOGGER.trace("Found a customService:" + str(customService))
				# if the class loader modes match, this could be our classloader
				wasDisplayName = AdminConfig.showAttribute(customService, 'displayName')
				self.LOGGER.trace("comparing customService displayName: wasDisplayName:" + str(wasDisplayName))
				self.LOGGER.trace("displayName:" + str(displayName))
				if (wasDisplayName == displayName):
					print "Warning: A CustomService with the same displayName already exists."
					print "         The CustomService with displayName '" + displayName + "' will not be created."
					return
				#endIf
			#endIf -- len(customService) > 0
		#endFor
	
		## create missing custom service
		print "Info: Creating CustomService with name " + displayName
		self.configWriter.createWASObject(xmlNode, objId)
	#endDef

	"""
		Used to augment ApplicationServer.Classloader types.
		Attempts to find a matching classloader, if it can be found it will 
		be augmented by augmentServersProcessClassLoaderLibs

		If a matching classloader cannot be found, the entire classloader 
		and Library refs  are created by this method.
	"""
	def augmentServersProcessClassLoader(self, objId, xmlNode, actualConfigType):

		foundClassloader = 0
		## find all the classloaders under the application server
		clMode = xmlNode.getAttrValue("mode")
		classLoaders = AdminConfig.list(actualConfigType, objId).split(newline)
		for classLoader in classLoaders:
			if (classLoader != ""):
				self.LOGGER.trace("Found a classloader:" + str(classLoader))
				# if the class loader modes match, this could be our classloader
				wasCLMode = AdminConfig.showAttribute(classLoader, 'mode')
				self.LOGGER.trace("comparing classloader modes: wasCLMode:" + str(wasCLMode))
				self.LOGGER.trace("                             clMode:" + str(clMode))
				if (wasCLMode == clMode):
					self.LOGGER.trace("classloader mode in WAS matches:" + str(wasCLMode) + " for classloader:" + str(classLoader))
					foundClassloader = self.augmentServersProcessClassLoaderLibs(classLoader, xmlNode)
					if (foundClassloader):
						break
				#endIf
			#endIf -- len(classLoader) > 0
		#endFor 
	
		## create missing class loaders 
		if (not foundClassloader):
			print "Info: Creating ClassLoader and associated LibraryRef objects"
			self.LOGGER.info("Creating missing ClassLoader and child Libraries")
			self.LOGGER.info("ApplicationServer: " + str(objId))
			self.LOGGER.info("xmlClassloader: " + str(xmlNode))
			self.configWriter.createWASObject(xmlNode, objId)
		#endIf
	#endDef
	

	"""
		Used to augment ApplicationServer.Classloader types.
	
		If a classloader contains at least one of the same LibraryRef objects
		as the supplied xmlNode, it is augmented with any additional LibraryRef 
		objects which exist in the xmlNode
	
		If no matching LibraryRef objects can be found, this method returns false
		to indicate to the caller that the entire Classloader should be created.
	"""
	def augmentServersProcessClassLoaderLibs(self, classLoader, xmlNode):
		
		## we might have found a classloader match, lets see
		foundClassloader = 0;
		## find all the LibraryRef types and see if they match
		wasLibraries = AdminHelper.extractWASIdsFromList(AdminConfig.showAttribute(classLoader, 'libraries'))
		missingLibraries = []	
		xmlLibraries = xmlNode.getFilteredChildrenArray('LibraryRef')
		foundAnyLibrary = 0
		## determine if xml nodes represent a similar class loader
		for xmlLibrary in xmlLibraries:
			self.LOGGER.info("Processing xmlLibraryNode: " + str(xmlLibrary))
			foundLibrary = 0
			libraryName = xmlLibrary.getAttrValue('libraryName')
			for wasLibrary in wasLibraries:
				wasLibraryName = AdminConfig.showAttribute(wasLibrary, 'libraryName')
				if (wasLibraryName == libraryName):
					# found a matching library
					foundAnyLibrary = 1
					foundLibrary = 1
					break
				#endIf
			#endFor
			if (not foundLibrary):
				missingLibraries.extend([xmlLibrary])
		#endFor	
		## if we find at least 1 library ref, then we create any that 
		## we cannot find and continue
		if (foundAnyLibrary and len(missingLibraries) is 0):
			foundClassloader = 1
			print "Warning: A ClassLoader with the same mode and LibraryRef objects already exists."
			print "         The ClassLoader will not be created."
		elif (foundAnyLibrary and len(xmlLibraries) != len(missingLibraries)):
			foundClassloader = 1
			for xmlLibrary in missingLibraries:
				print "Info: Creating missing LibraryRef in existing ClassLoader"
				self.LOGGER.info("ClassLoader: " + str(classLoader))
				self.LOGGER.info("xmlLibrary: " + str(xmlLibrary))
				self.configWriter.createWASObject(xmlLibrary, classLoader)
			#endFor
		#endIf
		return foundClassloader
	#endDef

	def importServers(self, serverIds, xmlFile, configType, marker, scopeType):
	
		#print "Importing server config: " 
		lastData = None
		data = []
		# this is going to get the info for each server in scope, comparing to find the correct value
		for serverId in serverIds:
			print "processing server: " + serverId
			data = self.readServerConfigData(serverId, configType, scopeType)
			# compare data to last and stop if different
			if (lastData != None):
				# compare data to lastData
				if (not ConfigComparor.compareJyObject(configType, data, lastData)):
					## helpful message for ALL
					if (self.ignoreConfigDifferences):
						msg = MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, 
								"CRWWA0011I", [configType, scopeType])
						self.LOGGER.warn(msg)
						return
					else:
						self.LOGGER.log("CRWWA0004E", [scopeType])
						raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0004E", scopeType)
				#endIf
			#endIf
			lastData = data
		#endFor
		# inject it into the file
		GenericConfigFileWriter.processBasicFile(xmlFile, data, marker)
	#endDef

	def compareServers(self, serverIds, xmlFile, configType, marker, scopeType):
		self.LOGGER.traceEnter([serverIds, xmlFile, configType, marker, scopeType])
		excludedTypes = self.getExcludedTypes(configType, scopeType)
		for serverId in serverIds:
			# get wasConfig
			wasConfig = self.readServerConfigData(serverId, configType, scopeType)
		
			## XMLConfigReader will "fix" the node ids and remove anything before the .
			## therefore, we will also do that for the wasConfig to match
			for wasElement in wasConfig:
				wasId = wasElement['id']
				lastIndexOfDot = wasId.rfind('.') + 1
				if (lastIndexOfDot > 0):
					end = len(wasId)
					wasIdFixed = wasId[lastIndexOfDot:end]
					wasElement['id'] = wasIdFixed
				#endIf
			#endFor	
		
			# get rafwConfig
			xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
			xmlProp = xmlProp.findRAFWContainerNode(marker)
			filteredNodes = xmlProp.getFilteredNodeArray(configType)
			xmlConfigReader = XMLConfigReader()
			rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)

			ConfigComparor.compare(configType, wasConfig, rafwConfig)
		#endFor
		self.LOGGER.traceExit()		
	#endDef
		
	def processConfigType(self, scopeId, configType):
		self.LOGGER.traceEnter([scopeId, configType])
		## if configType contains [.] process until the last type 
		## and use that id as the scopeid
		start = configType.rfind('.') + 1
		if (start > 0):
			preTypes = configType[0:configType.rfind('.')]
			end = len(configType)
			configType = configType[start:end]
			types = preTypes.split('.')
			for type in types:
				print "configType=" + configType
				print "this type=" + type
				print "scopeId=" + scopeId
				scopeId = AdminConfig.list( type, scopeId ).split( newline )[0]
			#endFor
		#endIf
		self.LOGGER.traceExit([scopeId, configType])
		return [scopeId, configType]
	#endDef

	def getExcludedTypes(self, configType, scopeType):
		excludedTypes = []
		## For ApplicationServer, exclude Classloader, 
		## since we have a seperate target to handle that and don't need any confusion
		if (configType == "ApplicationServer"):
			excludedTypes.append("Classloader")
			## also exclude the key name when there are no classloaders defined
			excludedTypes.append("classloaders")
			## Exclude 'WebContainer' from the excludedTypes
            ##excludedTypes.append("WebContainer")
		#endIf
		## only manage EndPoint if scopeType is server
		if (scopeType != "server"):
			excludedTypes.append('EndPoint')
		#endIf
		return excludedTypes
	#endDef

	def readServerConfigData(self, scopeId, configType, scopeType):
		self.LOGGER.traceEnter([scopeId, configType, scopeType])
		## save original config type for later usage in writing the xml
		rafwConfigType = configType

		# SERVER is used to denote that the configuration type is accessible 
		# as an attribute of the server
		if (configType.find('SERVER.') >= 0):
			configType = configType.split('.')[1]
			objIds = [AdminConfig.showAttribute(scopeId, configType)]
		else:
			scopeId, configType = self.processConfigType(scopeId, configType)
			objIds = AdminConfig.list( configType, scopeId ).split( newline )
		data = []
		for objId in objIds:
			if ( len(objId) > 0 ):
				print "found: " + objId
				importedIds = []
				## exclude the serverId from the import, so that we don't get the parent, 
				## but only the children config elements
				importedIds.append(scopeId)
			
				excludedTypes = self.getExcludedTypes(configType, scopeType)
			
				self.configReader = ConfigReader(importedIds, excludedTypes)
				excludedAttributes = ["WebContainer.enableServletCaching"]
				self.configReader.setExcludedAttributes(excludedAttributes)
				## If we are processing the TransportChannelService, we need to process Chains first
				## NOTE: as of the current implementation, channel order cannot be modified in a chain
				## NOTE: channels cannot be added or removed - 
				##       this will happen if they are deleted from the xmlFile -- you have been warned
				##
				if (configType == "TransportChannelService"):
					self.configReader.processTypeFirst("Chain")
				#endIf
				configData = self.configReader.showAll(objId)
				configData['id'] = rafwConfigType
				data.append(configData)
			#endIf
		#endFor
		self.LOGGER.traceExit(data)
		return data
	#endDef

	def findServersInScope(self, scopeName, scopeType, nodeName):
		cellName = AdminControl.getCell()
		dynclusterTemplateServerId = []
		if (scopeType == 'cluster'):
			dynclusterTemplateServerId.append(AdminConfig.getid('/Cell:' + cellName + '/DynamicCluster:' + scopeName + '/Server:' + scopeName + '/'))
		elif (scopeType == 'cell'):
			dynclusters = AdminConfig.list('DynamicCluster').split(newline)
			for dyncluster in dynclusters:
				# Check if the 'dynclusters' array is empty
				if (dyncluster == ""):
					continue
				#endIf
				dynclusterName = AdminConfig.showAttribute (dyncluster, 'name')
				serverId=AdminConfig.getid('/Cell:' + cellName + '/DynamicCluster:' + dynclusterName + '/Server:' + dynclusterName + '/')
				dynclusterTemplateServerId.append(serverId)
				#endIf
			#endFor
		else:
			self.LOGGER.log("CRWVE1000E")
			raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WVE, "CRWVE1000E", None)
		#endIf
		return dynclusterTemplateServerId
	#endDef

#endClass

def export(optDict=None):
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	scope = optDict['wasscopetype']
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['type']
	marker = optDict['marker']
	
	dynClusterMediator = DynClusterTemplate(mode)
	serverIds = dynClusterMediator.findServersInScope(scopeName, scopeType, None)
	version = dynClusterMediator.getWveVersion()
	wasVersion = "WAS" + dynClusterMediator.getWASVersion()
	dynClusterMediator.executeServers(serverIds, xmlFile, configType, scopeType, None)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;scopename:;nodename:;properties:;mode:;config_type:' )
	
	# get scope
	scopeName = optDict['scopename']
	scopeType = optDict['scope']
	scope = AdminHelper.buildScope( optDict )
	nodeName = optDict['nodename']
	
	mode = optDict['mode']
	xmlFile  = optDict['properties']
	configType = optDict['config_type']
	marker = configType
	
	dynClusterMediator = DynClusterTemplate(mode)
	serverIds = dynClusterMediator.findServersInScope(scopeName, scopeType, nodeName)
	version = dynClusterMediator.getWveVersion()
	wasVersion = "WAS" + dynClusterMediator.getWASVersion()
	
	if (configType == "ALL"):
		dynClusterMediator.setIgnoreEmptyXml(1)
		dynClusterMediator.setIgnoreConfigDifferences(1)
		for type in DynClusterTemplate.WVE_61_CONFIG_TYPES:
			if (type in DynClusterTemplate.WAS_EXCLUDED_CONFIG_TYPES[wasVersion]):
				continue
			#endIf
			# set marker = type for individual config types
			dynClusterMediator.processServer(serverIds, xmlFile, type, type, scopeType)
		#endFor
		if (version > 61):
			for type in DynClusterTemplate.WVE_70_ADTL_CONFIG_TYPES:
				if (type in DynClusterTemplate.WAS_EXCLUDED_CONFIG_TYPES[wasVersion]):
					continue
				#endIf
				dynClusterMediator.processServer(serverIds, xmlFile, type, type, scopeType)
			#endFor
		#endIf
		for type in DynClusterTemplate.WVE_FINAL_CONFIG_TYPES:
			if (type in DynClusterTemplate.WAS_EXCLUDED_CONFIG_TYPES[wasVersion]):
				continue
			#endIf
			dynClusterMediator.processServer(serverIds, xmlFile, type, type, scopeType)
		#endFor
	else:
		dynClusterMediator.processServer(serverIds, xmlFile, configType, marker, scopeType)
	#endIf
	
	if (mode == MODE_EXECUTE or mode == MODE_AUGMENT):
		AdminHelper.saveAndSyncCell()
	#endIf
#endIf