--
-- Licensed Materials - Property of IBM
-- 5655-FLW (C) Copyright IBM Corporation 2006,2008.
-- All Rights Reserved.
-- US Government Users Restricted Rights- 
-- Use, duplication or disclosure restricted 
-- by GSA ADP Schedule Contract with IBM Corp.
--
-- Scriptfile to create tablespaces for DB2 UDB
-- Replace occurence or @location@ in this file with the location
-- where you want the tablespace containers to be stored, then run:
--      db2 connect to BPEDB
--      db2 -tf createTablespace.sql


---------------------------------
-- Create 4 K page tablespaces --
---------------------------------

CREATE TABLESPACE AUDITLOG
  MANAGED BY SYSTEM
  USING( '@location@/AUDITLOG' );

CREATE TABLESPACE INSTANCE
  MANAGED BY SYSTEM
  USING( '@location@/INSTANCE' );

CREATE TABLESPACE STAFFQRY
  MANAGED BY SYSTEM
  USING( '@location@/STAFFQRY' );

CREATE TABLESPACE TEMPLATE
  MANAGED BY SYSTEM
  USING( '@location@/TEMPLATE' );

CREATE TABLESPACE WORKITEM
  MANAGED BY SYSTEM
  USING( '@location@/WORKITEM' );


------------------------------------------------
-- Create 8 K page bufferpool and tablespaces --
------------------------------------------------


CREATE BUFFERPOOL BPEBP8K
  IMMEDIATE SIZE 1000 PAGESIZE 8 K;

CREATE SYSTEM TEMPORARY TABLESPACE BPETEMP8K
  PAGESIZE 8 K MANAGED BY SYSTEM
  USING( '@location@/BPETEMP8K' )
  BUFFERPOOL BPEBP8K;

CREATE TABLESPACE BPETS8K
  PAGESIZE 8 K MANAGED BY SYSTEM
  USING( '@location@/BPETS8K' )
  BUFFERPOOL BPEBP8K;



-- start import scheduler DDL: createTablespaceDB2.ddl

CREATE TABLESPACE SCHEDTS MANAGED BY SYSTEM USING( '@location@/SCHEDTS' );
-- end import scheduler DDL: createTablespaceDB2.ddl

