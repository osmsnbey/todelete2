--------------------------------------------------------------------------------
--  Licensed Materials - Property of IBM
--  5655-FLW (C) Copyright IBM Corporation 2005,2007.
--  All Rights Reserved.
--  US Government Users Restricted Rights-
--  Use, duplication or disclosure restricted
--  by GSA ADP Schedule Contract with IBM Corp.
--------------------------------------------------------------------------------
--   Version 1.4
--   Last update: 07/07/17 03:28:50
--------------------------------------------------------------------------------
--
-- SQL snippet for Observer UDF
-- for Oracle 9i and Oracle 10g
--
--------------------------------------------------------------------------------

---------------------
-- Create function --
---------------------
-- OBSVR_FUNCTION_BEGIN INTERVALIN

CREATE OR REPLACE FUNCTION
   @SCHEMA@.INTERVALIN(INTERVALUNIT NUMBER, TS1 TIMESTAMP, TS2 TIMESTAMP) RETURN NUMBER IS
   intervalValue NUMBER;

duration INTERVAL DAY(6) TO SECOND;

BEGIN --;
   -- return the number of intervalunits within two given timestamps
   -- MILLISECOND = 1;     not used
   -- SECOND = 2;
   -- MINUTE = 4;
   -- HOUR = 8;
   -- DAY = 16;
   -- WEEK = 32;
   -- MONTH = 64;
   -- QUARTER = 128;
   -- YEAR = 256;

   -- first get the interval
   duration := ts2 - ts1;

   CASE  --;
      WHEN intervalunit=1 THEN --;
         -- calculate the milliseconds of the interval and add them
         intervalValue:=extract(day FROM duration) * 86400000
                 +extract(hour FROM duration) * 3600000
                 +extract(minute FROM duration) * 60000
                 +extract(second FROM duration) * 1000;
      WHEN intervalunit=2 THEN --;
         -- calculate the seconds of the interval and add them
         intervalValue:=extract(day FROM duration) * 86400
                 +extract(hour FROM duration) * 3600
                 +extract(minute FROM duration) * 60
                 +extract(second FROM duration) ;
      WHEN intervalunit=4 THEN --;
         -- calculate the minutes of the interval and add them
         intervalValue:=extract(day FROM duration) * 1440
                 +extract(hour FROM duration) * 60
                 +extract(minute FROM duration);
      WHEN intervalunit=8 THEN --;
         -- calculate the hour of the interval and add them
         intervalValue:=extract(day FROM duration) * 24
                 +extract(hour FROM duration);
      WHEN intervalunit=16 THEN --;
         -- calculate the day of the interval and add them
         intervalValue:=extract(day FROM duration);
      WHEN intervalunit=32 THEN --;
         -- calculate the week of the interval and add them
         intervalValue:=extract(day FROM duration)/7;
      WHEN intervalunit=64 THEN --;
         -- calculate the month(30 days) of the interval and add them
         intervalValue:=extract(day FROM duration)/30;
      WHEN intervalunit=128 THEN --;
         -- calculate the quarter (90 days)  of the interval and add them
         intervalValue:=extract(day FROM duration)/90;
      WHEN intervalunit=256 THEN --;
         -- calculate the year (365 days) of the interval and add them
         intervalValue:=extract(day FROM duration)/365;
      ELSE --;
         intervalValue:=0;
   END CASE;

-- return only full values
RETURN TRUNC(intervalValue);
END INTERVALIN;
/
-- OBSVR_FUNCTION_END INTERVALIN

-- OBSVR_FUNCTION_BEGIN OBSVR_JAR_ACTIVE
CREATE OR REPLACE FUNCTION @SCHEMA@.OBSVR_JAR_ACTIVE RETURN NUMBER IS
BEGIN
  RETURN 0;
END OBSVR_JAR_ACTIVE;
/
-- OBSVR_FUNCTION_END OBSVR_JAR_ACTIVE
