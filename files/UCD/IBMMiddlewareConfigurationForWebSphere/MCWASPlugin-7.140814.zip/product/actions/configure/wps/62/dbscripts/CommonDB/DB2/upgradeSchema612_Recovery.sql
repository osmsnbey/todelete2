-- BEGIN COPYRIGHT
-- *************************************************************************
-- Licensed Materials - Property of IBM
-- 5724-L01, 5655-N53, 5724-I82, 5655-R15
-- Copyright IBM Corporation  2008. All rights reserved.
-- US Government Users Restricted Rights - Use, duplication, or disclosure
-- restricted by GSA ADP Schedule Contract with IBM Corp.
-- *************************************************************************
-- END COPYRIGHT

-- *******************************************
-- Schema change from 612 to 620
-- *******************************************

-- *******************************************
-- update table FailedEventDetail and create indexes
-- *******************************************


ALTER TABLE FailedEvents
   ADD EsQualified	SMALLINT;

ALTER TABLE FailedEvents
   ADD EventType		VARCHAR (10);

UPDATE FailedEvents set EventType='SCA';

CREATE INDEX INX_FEESQualified ON FailedEvents (EsQualified);

CREATE INDEX INX_FEEventType ON FailedEvents (EventType);