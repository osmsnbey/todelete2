"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listJVMSettings.py
	
	TODO: description
"""


import sys
import java.lang.System as Sys
from org.python.modules import re

print "{"
servers = AdminHelper.listServers()
for i in range( len(servers) ):
	svrName = AdminConfig.showAttribute(servers[i],'name')
	print "\t'%s' : {" % svrName
	for jvm in AdminConfig.list( 'JavaVirtualMachine', servers[i] ).split( newline ):
		for attr in AdminConfig.attributes( 'JavaVirtualMachine' ).split( newline ):
			jvmValue = AdminConfig.show( jvm, attr.split()[0] )
			if ( len(jvmValue) < 1 ):
				jvmValue="[" + attr.split()[0] + " NULL]"
			#endIf
			regex = re.compile( '\[(.*)\]$' )
			match = regex.match( jvmValue )
			jvmValue = match.group(1)
			key,value = jvmValue.split( ' ',1 )
			if ( key == 'systemProperties' ):
				newmatch = regex.search( value )
				if ( newmatch == None ):
					continue
				else:
					for valSet in newmatch.group(1).split():
						for rsKey in ['description','required','value']:
							print "\t\t 'sysProp_%s-%s' : '%s', " % ( AdminConfig.showAttribute(valSet, 'name'), rsKey,
								AdminConfig.showAttribute(valSet, rsKey) )
						#endFor
					#endFor
				#endIf
			else:
				print "\t\t '%s' : '%s', " % ( key,value )
			#endIf
			#print "\t%s" % (jvmValue)
		#endFor
		if ( (i+1) < len(servers) ): print "\t},"
		else: print "\t}"
	#endFor
#endFor
print "}"
