"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listJDBCProviders.py
	
	TODO: description
"""


import sys
from org.python.modules import re

print "{"
for provider in AdminConfig.list( "JDBCProvider" ).split( newline ):
	print "\t'%s' : {" % provider.split( '(' )[0].replace('"','')
	for attr in AdminConfig.show( provider ).split( newline ):
		attr = attr[1:len(attr)-1]
		key,value = attr.split(" ", 1 )
		print "\t\t'%s' : '%s'," % (key, value) 
	print "\t},"
print "}"
	#endFor
#endFor
