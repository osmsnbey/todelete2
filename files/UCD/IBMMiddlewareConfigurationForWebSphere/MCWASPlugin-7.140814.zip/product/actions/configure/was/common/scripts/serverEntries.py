"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: serverEntry.py
	
	This script is to create server entries
	This script is invoked as:
	wsadmin -lang jython -profile jythonLib.py 
		-f variables.py 
		-scope ${SCOPE} -scopename <scope name> 
		-properties <name space bindings properties file> 
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

from ConfigFileReader import ConfigFileReader

newline = java.lang.System.getProperty("line.separator")

## Finds the name of the configuration object using the configId 
def getName(configId):
	name = None
	if (configId.find('"') >=0):
		# Eg: '"My Bus(cells/cell/buses/My Bus|sib-bus.xml)"'
		name = configId.split('"')[1].split('(')[0]
	else:
		# Eg: 'Bus1(cells/cell/buses/Bus1|sib-bus.xml)'
		name = configId.split('(')[0]
	#endIf
	
	return name
#endDef

def getNamedEndPointNames(serverName):
	retMap = {}
	serverEntries = AdminConfig.list('ServerEntry', AdminConfig.getid(scope)).split(newline)
	for serverEntry in serverEntries:
		if (serverName == AdminConfig.showAttribute(serverEntry, 'serverName')):
			wasNamedEndPoints = AdminConfig.list('NamedEndPoint', serverEntry).split(newline)
			for wasNamedEndPoint in wasNamedEndPoints:
				endPointName = AdminConfig.showAttribute(wasNamedEndPoint, 'endPointName')
				retMap[endPointName] = wasNamedEndPoint
			#endFor
		#endIf
	#endFor
	return retMap
#endDef

def getServerEntryID(serverName):
	serverEntries = AdminConfig.list('ServerEntry', AdminConfig.getid(scope)).split(newline)
	for serverEntry in serverEntries:
		if (serverName == getName(serverEntry)):
			return serverEntry
		#endIf
	#endFor
	return ""
#endDef

def updateServerEntries(xmlFile, marker, typeNames, nodeName):	
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	serverEntries = xmlProp.getFilteredNodeArray(typeNames[0])
	for serverEntryNode in serverEntries:
		rafNamedEndPointNames = []
		wasNamedEndPointNamesMap = {}
		if (serverEntryNode.hasAttr("serverName")):
			serverName = serverEntryNode.getAttrValue("serverName")
			wasNamedEndPointNamesMap = getNamedEndPointNames(serverName)
			wasNamedEndPointNames = wasNamedEndPointNamesMap.keys()
			namedEndPointNodes = serverEntryNode.getFilteredChildrenArray("NamedEndPoint")
			if (len(namedEndPointNodes) == 0):
				##print "Warning: no NamedEndPoint nodes under server " + serverName
				SCRIPT_LOGGER.log("CRWWA2033I",[serverName])
				##print "         serverEntries for this server will not be updated."
			#endIf
			for namedEndPointNode in namedEndPointNodes:
				if (namedEndPointNode.hasAttr("endPointName")):
					endPointName = namedEndPointNode.getAttrValue("endPointName")
					rafNamedEndPointNames.append(endPointName)
					endPointNodes = namedEndPointNode.getFilteredChildrenArray("EndPoint")
					if (len(endPointNodes) == 0):
						##print "Warning: no EndPoint nodes under NamedEndPoint " + endPointName
						SCRIPT_LOGGER.log("CRWWA2035I",[endPointName])
						##print "         The end point for this NamedEndPoint will not be updated"
						if (not endPointName in wasNamedEndPointNames): #create only the NamedEndPoint with no EndPoint
							createNamedEndPointAttrs = "[[endPointName " + " \"" + endPointName + "\"]]"
							AdminConfig.create('NamedEndPoint', getServerEntryID(serverName), createNamedEndPointAttrs)
						#endIf
					#endIf
					for endPointNode in endPointNodes:
						attrs = '[-nodeName ' + nodeName + ' -endPointName ' + endPointName
						hasHost = 0
						hasPort = 0
						if (endPointNode.hasAttr("host")):
							host = endPointNode.getAttrValue("host")
							attrs = attrs + ' -host ' + str(host) 
							hasHost = 1
						#endIf
						if (endPointNode.hasAttr("port")):
							port = endPointNode.getAttrValue("port")
							attrs = attrs + ' -port ' + str(port) 
							hasPort = 1
						#endIf
						if (not hasHost and not hasPort):
							##print "Warning: no host or port is specified for EndPoint " + endPointName
							SCRIPT_LOGGER.log("CRWWA2037I",[endPointName])
							##print "         The end point for this EndPoint will not be updated"
							
						else:
							if (endPointName in wasNamedEndPointNames):
								attrs = attrs + ' -modifyShared]'
								SCRIPT_LOGGER.log("Modifying server port using attributes: " + attrs)
								AdminTask.modifyServerPort(serverName, attrs)
							else:
								createNamedEndPointAttrs = "[[endPointName " + " \"" + endPointName + "\"]]"
								namedEndPointID = AdminConfig.create('NamedEndPoint', getServerEntryID(serverName), createNamedEndPointAttrs)
								createEndPointAttrs = '['
								if (hasHost):
									createEndPointAttrs = createEndPointAttrs + "[host \"" + host + "\"]"
								if (hasPort):
									createEndPointAttrs = createEndPointAttrs + "[port \"" + port + "\"]"
								AdminConfig.create('EndPoint' , namedEndPointID, createEndPointAttrs + ']')
							#endIf
					#endFor
				else:
					##print "Error: NamedEndPoint node does not contain endPointName attribute, end point can not be updated."
					SCRIPT_LOGGER.log("CRWWA2039E")
				#endIf
		else:
		##	print "Error: ServerEntry node does not contain serverName attribute, entry can not be updated."
			SCRIPT_LOGGER.log("CRWWA2040E")
		#endIf
		
		#Now, delete all NamedEndPoints in WAS that are not in RAF
		for wasNamedEndPointName in wasNamedEndPointNames:
			if (not wasNamedEndPointName in rafNamedEndPointNames):
				AdminConfig.remove(wasNamedEndPointNamesMap[wasNamedEndPointName])
			#endIf
		#endFor
	#endFor
#endDef
	
SCRIPT_LOGGER = _Logger("serverEntries", MessageManager.RB_WEBSPHERE_WAS)

def export(optDict=None):
	global scope
	scopeType=optDict['scope']
	scope = optDict['wasscopetype']
	nodeName = optDict['scopename']
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=[optDict['type']]
	
	marker = optDict['marker']
	updateServerEntries(xmlFile, marker, typeNames, nodeName)	
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'type:;scope:;properties:;scopename:;nodename:;mode:' )
	
	# get scope
	scopeType=optDict['scope']
	scope = AdminHelper.buildScope( optDict )
	nodeName = optDict['nodename']
	xmlFile = optDict['properties'] 
	mode = optDict['mode']
	typeNames=["ServerEntry"]
	
	marker = "serverEntries"
	if (mode == MODE_EXECUTE):
		##print "Modifying server entries in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA2041I")
		updateServerEntries(xmlFile, marker, typeNames, nodeName)	
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing server entries in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA2042I")
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	elif (mode == MODE_COMPARE):
		##print "Comparing server entries in RAFW and WAS in scope: " + scope
		SCRIPT_LOGGER.log("CRWWA2043I")
		ConfigMediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames)
	
	else:
		##print "Unsupported MODE supplied: " + mode
		SCRIPT_LOGGER.log("CRWWA0008W")
	#endIf
#endIf