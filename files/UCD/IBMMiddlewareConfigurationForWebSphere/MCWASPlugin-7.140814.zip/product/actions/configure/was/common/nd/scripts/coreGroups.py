"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2005, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: coreGroups.py
	
	This script creates core group configuration
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException 
from ConfigWriter import ConfigWriter
from XmlProperty import XmlProperty
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

class dsMediator:
	def createConfig(self, scope, scopeType, xmlFile, typeNames):
	
		typeNames.append("builtin")
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		myConfigWriter = ConfigWriter();
		myConfigWriter.setUpdateReferences(1)
	
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			if ( typeName != "builtin" ):
				myConfigWriter.removeExistingConfig(scopeType, typeName, scopeId)
			#endIf
	
		 	nodeArray = xmlProp.getFilteredNodeArray(typeName)
			for xmlNode in nodeArray:
				if (typeName == "builtin"):
					coreGroupName= "DefaultCoreGroup"
					parentId = AdminConfig.getid( scope + 'CoreGroup:' + coreGroupName +  '/' )
					myConfigWriter.modify(parentId, xmlNode, [])
				else:
					#typeName is CoreGroup
					self.createConfigType(scopeId, xmlNode, myConfigWriter)
				#endIf
			#endFor
		#endFor
		
	#endDef
	
	def createConfigType(self, scopeId, xmlNode, myConfigWriter):
		SCRIPT_LOGGER.traceEnter([scopeId, xmlNode])
		## when we create CoreGroups, we get elements for free from WAS
		## create the top level core group and get the defaults created
		## then update it based on the xml node
		newId = myConfigWriter.createEntity(xmlNode, scopeId, [])
		myConfigWriter.updateWASChildren(xmlNode, newId, [])
		SCRIPT_LOGGER.traceExit()
	#endDef

	## exactly like ConfigMediator, except that builtin is not excluded
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
			
		data = []
		scopeId = AdminConfig.getid(scope)
		myConfigReader = ConfigReader()
		
		if (len(scopeId) == 0):
			print "ERROR: unable to find parent scope: " + scope
			print "Cannot read config data."
			return data
		#endIf
		for objId in AdminConfig.list(configType, scopeId).split(newline):
			myConfigReader.importedIds = []
			## if anything found, is in scope
			if (len(objId) > 0 and AdminHelper.isInScope(scopeType, objId)):
				## never show the top level configuration element in references
				if (excludedTypes != []):
					match = "no"
					for excludedType in excludedTypes:
						if (SystemUtils.regexp(excludedType, objId) == 1):
							match = "yes"
			   		#endFor
					if (match == "no"):
						print "Importing " + objId
						myConfigReader.importedIds.append(objId)
						data.append(myConfigReader.showAll(objId))
			   		#endIf
				else:
					print "Importing " + objId
					myConfigReader.importedIds.append(objId)
					data.append(myConfigReader.showAll(objId))
				#endIf
			#endIf
		#endFor
		return data
	#endDef
	
	def augmentConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes):
		
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		scopeId = AdminConfig.getid( scope )
		for typeName in typeNames:
			self._augmentConfigType(scopeId, scopeType, xmlProp, typeName)
		#endFor
	#endDef
	
	def _augmentConfigType(self, scopeId, scopeType, xmlProp, typeName):
		SCRIPT_LOGGER.traceEnter([scopeId, scopeType, xmlProp, typeName])
	
		myConfigWriter = ConfigWriter();
		myConfigWriter.setUpdateReferences(1)
		myConfigValidator = ConfigValidator()

	 	nodeArray = xmlProp.getFilteredNodeArray(typeName)
		for xmlNode in nodeArray:
			childId = myConfigValidator.validate2(xmlNode, scopeId)
			if (childId is None):
				print "Info: Processing " + typeName + " with name " + xmlNode.getAttrValue("name")
				self.createConfigType(scopeId, xmlNode, myConfigWriter)
			else:
				if (SystemUtils.updateOnAugment()):
					myConfigWriter.modify(childId, xmlNode)
				else:
					print "Warning: " + typeName + " will not be created."
				#endIf		
			#endIf		
		#endFor
		SCRIPT_LOGGER.traceExit()
	#endDef
#endClass

def importCoreConfig(scope, scopeType, dataFile, marker, typeNames, excludedTypes = [], myConfigReader = None):
	data = []
	data.extend(thisMediator.readConfigData(scope, scopeType, typeNames, excludedTypes))
	GenericConfigFileWriter.processBasicFile (dataFile, data, marker)
	#endDef

def compareCoreConfig(scope, scopeType, xmlFile, typeNames, excludedTypes, myConfigReader, marker):
	xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
	xmlProp = xmlProp.findRAFWContainerNode(marker)
	xmlConfigReader = XMLConfigReader()
	# get wasConfig
	for typeName in typeNames:
		wasConfig = myConfigReader.readConfigData(scope, scopeType, typeName, excludedTypes)

		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(typeName)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		if (typeName == "CoreGroup"):
			# we also need to include <builtin> in the comparison
			builtInFilteredNodes = xmlProp.getFilteredNodeArray("builtin")
			rafwConfig = rafwConfig + xmlConfigReader.readXmlConfig(builtInFilteredNodes)
		#endIf	
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
	#endFor
#endDef

def modifyPrefCoordinatorSvrs():
	xmlProp = XmlProperty(propFile)
	xmlProp = xmlProp.findRAFWContainerNode('coreGroups')
	builtin = xmlProp.getFilteredNodeArray('builtin')
	
	coreGroupName = "DefaultCoreGroup"
	print "Core Group: " + coreGroupName
	coreid = AdminConfig.getid(scope + "CoreGroup:" + coreGroupName + "/")
		
	for coreGrp in builtin:
		newPrefSvrList = []
		childNodes = coreGrp.getFilteredChildrenArray('CoreGroupServer')
		print "Searching for Preferred Coordinator Servers in RAF Configuration:"
		for cnode in childNodes:
			if(cnode.getAttrValue("WASKey") == "preferredCoordinatorServers"):
				#prefSvrCoreGrpId = AdminConfig.getid(scope + "Node:" + cnode.getAttrValue("nodeName") + "/Server:" + cnode.getAttrValue("serverName") + "/")
				print "Located a Preferred Coordinator Server in RAF Configuration: " + cnode.getAttrValue("serverName") + " Node Name: " + cnode.getAttrValue("nodeName")
				print "Searching Core Group Servers in WAS Configuration for matching Core Server Name!!"
				coreGrpServers = AdminConfig.showAttribute(coreid, "coreGroupServers")
				coreGrpServers = coreGrpServers[1:len(coreGrpServers)-1]
				coreGrpServers = coreGrpServers.split(" ")
				
				for svr in coreGrpServers:
					coSvrName = svr.split("(")
					serverName = coSvrName[0]
					if (cnode.getAttrValue("serverName") == serverName):
						print "Resolved Core Group Server ID for Server Name: " + serverName + " in WAS Configuration, adding to Preferred Coordinator Server List!"
						newPrefSvrList.append(svr)
				#endfor
			#endIf
		#endFor
		
		print "Modifying Core Group: " + coreGroupName + " Updating Preferred Coordinator Group Members:"
		for prefSvr in newPrefSvrList:
			print "Server ID: " + prefSvr
		#endFor
		AdminConfig.modify(coreid,[["preferredCoordinatorServers",[]]])
		AdminConfig.save()
		AdminConfig.modify(coreid,[["preferredCoordinatorServers",newPrefSvrList]])
		AdminConfig.save()

#endDef

def export(optDict=None):
	global marker, propFile, scope
	scope = optDict['wasscopetype']
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	
	mode = optDict['mode']
	#excludeTypes = ["CoreGroupServer"]
	excludeTypes = optDict['excludedtypes']
	typeNames = [optDict['type']]
	marker = optDict['marker']
	
	thisMediator = dsMediator()
	SCRIPT_LOGGER = _Logger("coreGroup", MessageManager.RB_WEBSPHERE_WAS)

	thisMediator.createConfig(scope, scopeType, propFile, typeNames)
	#AdminConfig.save()
	modifyPrefCoordinatorSvrs()
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'scope:;properties:;nodename:;scopename:;mode:' )
	
	# get scope
	scope = AdminHelper.buildScope( optDict )
	
	propFile = optDict['properties'] 
	scopeType=optDict['scope']
	
	mode = optDict['mode']
	#excludeTypes = ["CoreGroupServer"]
	excludeTypes = []
	typeNames = ["CoreGroup"]
	marker = 'coreGroups'
	
	thisMediator = dsMediator()
	SCRIPT_LOGGER = _Logger("coreGroup", MessageManager.RB_WEBSPHERE_WAS)
	if (mode == MODE_EXECUTE):
		print "Creating Core Providers in scope: " + scope
		thisMediator.createConfig(scope, scopeType, propFile, typeNames)
		AdminConfig.save()
		modifyPrefCoordinatorSvrs()
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		print "Importing Core Groups in scope: " + scope
		configType = typeNames[0]
		importCoreConfig(scope, scopeType, propFile, marker, configType, excludeTypes, thisMediator )
	
	elif (mode == MODE_COMPARE):
		print "Comparing Core Providers in RAFW and WAS in scope: " + scope
		compareCoreConfig(scope, scopeType, propFile, typeNames, excludeTypes, thisMediator,  marker)
		
	elif (mode == MODE_AUGMENT):
		print "Augmenting core groups in scope: " + scope
		thisMediator.augmentConfig(scope, scopeType, propFile, marker, typeNames, excludeTypes)
		AdminHelper.saveAndSyncCell()
	
	else:
		print "Unsupported MODE supplied: " + mode
	#endIf
#endif