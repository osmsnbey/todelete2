"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: updateVHCell.py
	
	TODO: description
"""


import sys
from org.python.modules import re
from org.python.modules import sre
from java.util import Properties
from java.io import FileInputStream, File
from com.ibm.rational.rafw.wsadmin.util import WsadminStringUtils

def wsadminToList(inStr):
	outList=[]
	if (len(inStr)>0 and inStr[0]=='[' and inStr[-1]==']'):
		tmpList = inStr[1:-1].split(" ")
	else:
		tmpList = inStr.split("\n")  #splits for Windows or Linux
	for item in tmpList:
		item = item.rstrip();        #removes any Windows "\r"
		if (len(item)>0):
			outList.append(item)
		#endIf
	#endFor
	return outList
#endDef

def updateVH(nodearr, clusterName, nodes, webServerPorts, isWPCluster):

    cell = AdminConfig.list("Cell")
    cellName = AdminConfig.showAttribute(cell, "name")

    print "Updating Virtual Hosts..."
    if (isWPCluster == "true"):
         vhName = "default_host"
         vh = AdminConfig.getid("/VirtualHost:default_host")
    else:
         vhName = clusterName
         vh = AdminConfig.getid("/VirtualHost:"+clusterName+"/")
    vh = AdminConfig.getid("/VirtualHost:"+vhName+"/")

    # remove existing vh
    if (vh != ''):
          AdminConfig.remove(vh)
    vtempl = AdminConfig.listTemplates('VirtualHost', 'default_host')

    name_attr = WsadminStringUtils.createJythonListFromString('name', vhName)
    vh=AdminConfig.createUsingTemplate('VirtualHost', cell, [name_attr], vtempl)

    # add entries for external web servers
    for webServerPort in webServerPorts.split(","):
        if (webServerPort.find(':') > 0):
           host, port = webServerPort.split(':')
        else:
           host = '*'
           port = webServerPort
        #endIf
        print "Updating the Virtual Host " + vhName + " to include web server port " + webServerPort
        AdminConfig.modify(vh, [['aliases', [[['port', port], ['hostname', host]]]]])
    #endFor
    clusters = AdminConfig.list("ServerCluster", cell)
    for aCluster in clusters.split():
        cName = AdminConfig.showAttribute(aCluster, "name")
        if (clusterName == cName):
            memberlist = AdminConfig.showAttribute(aCluster, "members")
            members = memberlist[1:len(memberlist)-1].split()
            previousHttpPort = ""
            previousHttpsPort = ""
            for member in members:
                nodeName = AdminConfig.showAttribute(member, "nodeName")
                serverName = AdminConfig.showAttribute(member, "memberName")
                node = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/")
                print "node=" + node
                # BEGIN Geir edit ## Now we auto associate the servers with the vhost we're creating
                print "--## Associating " + serverName + " with VHost " + vhName + " by default ###--"
                server = AdminConfig.getid("/Cell:" + cellName + "/Node:" + nodeName + "/Server:" + serverName + "/")
                appsvr = AdminConfig.list('ApplicationServer', server)
                if (len(appsvr) == 0):
                	raise "The ApplicationServer configuration id cannot be found under config id: " + str(server)
                wc     = AdminConfig.list('WebContainer', appsvr)
                if (len(wc) == 0):
                	raise "The WebContainer configuration id cannot be found under config id: " + str(appsvr)
                AdminConfig.modify(wc, [[ 'defaultVirtualHostName', vhName ]])
                print AdminConfig.show(wc)
                # END Geir edit #
                serverEntries = AdminConfig.list("ServerEntry", node).split(newline)
                for serverEntry in serverEntries:
                     sName = AdminConfig.showAttribute(serverEntry, "serverName")
                     if sName == serverName:
                          specialEndPoints = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
                          specialEndPoints = specialEndPoints[1:len(specialEndPoints)-1].split(" ")
                          for specialEndPoint in specialEndPoints:
                               endPointNm = AdminConfig.showAttribute(specialEndPoint, "endPointName")
                               if endPointNm == "WC_defaulthost":
                                    ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
                                    httpport = AdminConfig.showAttribute(ePoint, "port")
                                    hostname = AdminConfig.showAttribute(ePoint, "host")
                                    if (httpport != previousHttpPort):
                                         print "Updating the Virtual Host "+vhName+" to include web container transport port "+ httpport + " with hostname " + hostname
                                         AdminConfig.modify(vh, [['aliases', [[['port', httpport], ['hostname', hostname]]]]])
                                    previousHttpPort = httpport
                               #endIf
                               if endPointNm == "WC_defaulthost_secure":
                                    ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
                                    httpsport = AdminConfig.showAttribute(ePoint, "port")
                                    hostname = AdminConfig.showAttribute(ePoint, "host")
                                    if (httpsport != previousHttpsPort):
                                         print "Updating the Virtual Host "+vhName+" to include web container transport port "+ httpsport + " with hostname " + hostname
                                         AdminConfig.modify(vh, [['aliases', [[['port', httpsport], ['hostname', hostname]]]]])
                                    previousHttpsPort = httpsport
                               #endIf
                          #endFor
                     #endIf
                #endFor

                ## Read the file
                ## Iterate over the records in the mimes.xml file
                print nodearr
                if (nodearr != "empty"):
                     for nodeHash in nodearr:
                          type=nodeHash['MIMEEntry']['type']
                          extension=nodeHash['MIMEEntry']['extension']
                          print "Adding mime type: "+type
                          print "using extension: "+extension
                          mimeTypes=AdminConfig.showAttribute(vh, 'mimeTypes')
                          mimeTypes = mimeTypes[1:len(mimeTypes)-1]
                          for mimeType in mimeTypes.split():
                               currentType=AdminConfig.showAttribute(mimeType, 'type')
                               if (type == currentType):
                                     AdminConfig.remove(mimeType)
                                     AdminConfig.modify(vh, [['mimeTypes', [[['type', type], ['extensions', extension]]]]])
                               #endIf
                          #endFor
                     #endFor
                #endIf
        #EndIf
    #endFor
    AdminConfig.save()
#end def

optDict, args = SystemUtils.getopt(sys.argv, 'nodes:;clustername:;mimeFile:;ports:;portal:')
file = File(optDict['mimeFile'])
if (file.exists()):
      xmlProp  = XmlProperty(optDict['mimeFile'])
      nodelist = xmlProp.getFilteredNodeList('MIMEEntry')
      nodearr = xmlProp.xmlReadNodeLevel(nodelist)
else:
      nodearr = "empty"

updateVH(nodearr, optDict['clustername'], optDict['nodes'], 
	optDict['ports'], optDict['portal'])

AdminHelper.saveAndSyncCell()

