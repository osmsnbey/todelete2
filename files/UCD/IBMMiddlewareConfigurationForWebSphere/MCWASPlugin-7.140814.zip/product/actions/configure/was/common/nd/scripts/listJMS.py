"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listJMS.py
	
	TODO: description
"""


import java.lang.System as Sys


#for jmsSetting in [ 'JMSConnectionFactory','JMSConnector','JMSDestination','JMSProvider',
#							'JMSServer','JMSTransport','MQQueue','MQQueueConnectionFactory','MQTopic',
#							'MQTopicConnectionFactory','WASQueue','WASQueueConnectionFactory',
#							'WASTopic','WASTopicConnectionFactory' ]:
#	print "--## %s ##--" % jmsSetting
#	print "\t%s" % AdminConfig.attributes( jmsSetting )
#	for attr in AdminConfig.list( jmsSetting ).split( Sys.getProperty("line.separator") ):
#		if ( attr != "" ):
#			print AdminConfig.show( attr )
#		#endIf
#	#endFor
##endFor
#for jmsSetting in [ 'JMSConnectionFactory','JMSConnector','JMSDestination','JMSProvider',
#							'JMSServer','JMSTransport','MQQueue','MQQueueConnectionFactory','MQTopic',
#							'MQTopicConnectionFactory','WASQueue','WASQueueConnectionFactory',
#							'WASTopic','WASTopicConnectionFactory' ]:
#	print "--## %s ##--" % jmsSetting
#	print "\t\t%s" % AdminConfig.attributes( jmsSetting )
##endFor
#print "\t\t%s" % AdminConfig.types( )

for jms in AdminConfig.list('WASQueue').split(newline):
	print jms
