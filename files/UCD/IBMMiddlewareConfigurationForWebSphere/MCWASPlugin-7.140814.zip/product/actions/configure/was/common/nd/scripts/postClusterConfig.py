"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: poortClusterConfig.py
	
	TODO: description
"""


import org.python.modules
from sys import argv
from java.util import Properties
from java.io import FileInputStream


### functions ###

def updateJVM(serverId, jvmHeapMax, jvmHeapMin, jvmGenericArguments, classpath, bootClasspath, webThreadPoolMax, webThreadPoolMin, webThreadPoolGrowable, webTimeout ):

	processDef = AdminConfig.showAttribute(serverId, 'processDefinition')
	jvm = AdminConfig.showAttribute(processDef,'jvmEntries')
	jvm = jvm[1:len(jvm)-1]

	#update jvm args
	print "Getting jvm proccess definition attributes"
	print "Setting jvm arguments="+jvmGenericArguments
	AdminConfig.modify(jvm,[['genericJvmArguments',jvmGenericArguments]])  

	print "Setting jvm initialHeapSize="+jvmHeapMin
	AdminConfig.modify(jvm,[['initialHeapSize',jvmHeapMin]])
	print "Setting jvm maximumHeapSize="+jvmHeapMax
	AdminConfig.modify(jvm,[['maximumHeapSize',jvmHeapMax]])

	print "Setting jvm classpath="+classpath
	AdminConfig.modify(jvm,[['classpath',classpath]])

	print "Setting jvm boot classpath="+bootClasspath
	AdminConfig.modify(jvm,[['bootClasspath',bootClasspath]])

	#get the Web Container
	print "Getting WebContainer"
	wc=AdminConfig.list("WebContainer",serverId)

	#get the thread pool
	print "Getting Thread pool"
	tp=AdminConfig.showAttribute(wc,"threadPool")

	#modify the min threads
	print "Setting maximumSize="+str(webThreadPoolMax) 
	AdminConfig.modify(tp,[["maximumSize",webThreadPoolMax]])

	#modify the max threads
	print "Setting minimumSize="+str(webThreadPoolMin) 
	AdminConfig.modify(tp,[["minimumSize",webThreadPoolMin]])

	#modify the max threads
	print "Setting isGrowable="+str(webThreadPoolGrowable) 
	AdminConfig.modify(tp,[["isGrowable",webThreadPoolGrowable]])

#end def
 
### MAIN #####

arglen=len(sys.argv)
num_exp_args=1
if (arglen < num_exp_args):
    raise "One argument is required. This argument should be a properties file."

propFile=sys.argv[0]
properties=Properties();

try:
    properties.load(FileInputStream(propFile))
    print "Succesfully read property file "+propFile
except:
    raise "Cannot read property file "+propFile

# cluster info
clusterName=str(properties.getProperty("CLUSTER_NAME"))
nodes=str(properties.getProperty("NODES"))

# JVM settings
jvmHeapMax=str(properties.getProperty("JVM_HEAP_MAX"))
jvmHeapMin=str(properties.getProperty("JVM_HEAP_MIN"))
jvmGenericArguments=str(properties.getProperty("JVM_GENERIC_ARGUMENTS"))
classpath=str(properties.getProperty("CLASS_PATH"))
bootClasspath=str(properties.getProperty("BOOT_CLASS_PATH"))

# Web Container
webThreadPoolMax=str(properties.getProperty("WEB_THREAD_POOL_MAX"))
webThreadPoolMin=str(properties.getProperty("WEB_THREAD_POOL_MIN"))
webThreadPoolGrowable=str(properties.getProperty("WEB_THREAD_POOL_GROWABLE"))
webTimeout=str(properties.getProperty("SESSION_TIMEOUT"))


cell = AdminConfig.list("Cell" )
cellName = AdminConfig.showAttribute(cell, "name" )
clusters = AdminConfig.list("ServerCluster", cell )
for aCluster in clusters.split():
	cName = AdminConfig.showAttribute(aCluster, "name" )
	if (clusterName == cName):
		memberlist = AdminConfig.showAttribute(aCluster, "members" )
		members = memberlist[1:len(memberlist)-1]
		for member in members.split():
			nodeName = AdminConfig.showAttribute(member, "nodeName" )
			serverName = AdminConfig.showAttribute(member, "memberName" )
			serverId = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
			print "Updating "+serverName+" on node "+nodeName
			updateJVM(serverId, jvmHeapMax, jvmHeapMin, jvmGenericArguments, classpath, bootClasspath, webThreadPoolMax, webThreadPoolMin, webThreadPoolGrowable, webTimeout)
		#endFor
	#EndIf
#endFor

AdminHelper.saveAndSyncCell()
