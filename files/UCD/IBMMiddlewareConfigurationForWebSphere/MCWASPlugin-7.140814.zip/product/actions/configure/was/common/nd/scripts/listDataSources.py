"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: listDataSources.py
	
	TODO: description
"""


import sys
from org.python.modules import re

print "{"
ds = AdminConfig.list( "DataSource" ).split( newline )
for i in range( len(ds) ):
	dsName = AdminConfig.showAttribute(ds[i],'name')
	print "\t'%s' : {" % dsName
	for attr in AdminConfig.show( ds[i] ).split( newline ):
		regex = re.compile( '\[(.*)\]$' )
		match = regex.match( attr )
		dsValue = match.group(1)
		key,value = dsValue.split( ' ',1 )
		if ( key == "authDataAlias" ):
			print "\t\t'%s' : '%s'," % (key,value)
			attrAuthName = attr.split()[1].replace( ']','' )
			for alias in AdminConfig.list( 'JAASAuthData' ).split( newline ):
				aliasName = AdminConfig.showAttribute( alias, 'alias' )
				if ( attrAuthName == aliasName ):
					print "\t\t'userId' : '%s'," % AdminConfig.showAttribute( alias, 'userId' )
				#endIf
			#endFor
		elif ( key == "connectionPool" ):
			for prop in AdminConfig.list( "ConnectionPool", ds[i] ).split( newline ):
				for cpProp in AdminConfig.show( prop ).split( newline ): 
					cpProp = cpProp.replace( '[','' )
					cpProp = cpProp.replace( ']','' )
					key,value = cpProp.split( ' ', 1 )
					print "\t\t'connectionPool_%s' : '%s'," % (key.lstrip(),value)
				#endFor
			#endFor
		#endFor
		elif ( key == "propertySet" ):
			for prop in AdminConfig.list( "J2EEResourceProperty", ds[i] ).split( newline ):
				print "\t\t'propertySet_%s' : '%s'," % ( AdminConfig.showAttribute(prop,"name").lstrip(),AdminConfig.showAttribute(prop,"value") )
		#endFor
		#elif ( re.search( "\w \(.*\)",attr) ):
			#map = attr.split()[1].replace(']','') 
			#for mapValue in AdminConfig.show( map ).split( newline ):
				#print "\t\t%s->%s" % (attr,mapValue)
			##endFor
		else:
			print "\t\t'%s' : '%s'," % (key,value)
		#endIf
	#endFor
	if ( (i+1) < len(ds) ): print "\t},"
	else: print "\t}"
#endFor
print "}"
