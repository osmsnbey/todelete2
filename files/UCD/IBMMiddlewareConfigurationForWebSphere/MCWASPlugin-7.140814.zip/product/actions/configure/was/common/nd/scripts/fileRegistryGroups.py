"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: fileRegistryGroups.py
	
	TODO: description
"""


import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from org.python.modules import re
from org.python.modules import sre
from java.util import Properties
from java.io import FileInputStream

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileWriter import ConfigFileWriter
from ConfigFileReader import ConfigFileReader
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from java.util import HashSet
from WasConfig import WasConfig

class FileRegistryGroups:
	def __init__(self):
		self.LOGGER = _Logger("fileRegistryGroups", MessageManager.RB_WEBSPHERE_WAS)	
	#endDef
	
	def writeFileRegistryGroups (self, xmlFile, marker, deleteGroups ):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		nodeArray = xmlProp.getFilteredNodeArray('Group' ) 

		groupsInConfiguration = []
		## Create each group, without adding members
		## members will be added later so that groups can contain groups
		for xmlGroup in nodeArray:
			# do work
			groupDn = self.createFileRegistryGroup(xmlGroup)
			groupsInConfiguration.append(groupDn)
		#endFor

		## list all groups in WAS and remove any that were not in the configuration
		if (deleteGroups):
			groups = self.findAllDefinedGroups()
			for group in groups:#.split(newline):
				if (len(group) > 0):
					if (group not in groupsInConfiguration):
						# remove user
						print "Removing group: " + group
						attrsList = []
						attrsList.append('-uniqueName')
						attrsList.append(group)
						AdminTask.deleteGroup (attrsList)
					#endIf
				#endIf
			#endFor
		#endIf

		# Add members to the groups, this is done now so that:
		#
		#    groups that do not exist but are marked as members of other groups
		#    will be marked with an error 
		#
		#    all valid groups that are members of other groups are 
		#    created before being added as members of another group
		for xmlGroup in nodeArray:
			# do work
			self.addMembersToGroup ( xmlGroup )
		#endFor
			
	#endDef

	##
	##
	## @return: groupDn of the newly created or updated group
	def createFileRegistryGroup (self, xmlGroup ):

		#--------------------------------------------------------------
		# set up a new File Registry Group
		#--------------------------------------------------------------
		groupName = xmlGroup.getAttrValue("cn")
		group = AdminTask.searchGroups(['-cn', groupName])
		if (len(group)==0):
			# create group
			print "create " + groupName
			AdminTask.createGroup (xmlGroup.buildNodeAttrsList())
		else:
			# update group
			print "update " + group
			attrsList = xmlGroup.buildNodeAttrsList()
			attrsList.insert(0, '-uniqueName')
			attrsList.insert(1, group)
			AdminTask.updateGroup (attrsList)
			
			## remove all members so that the group is clean
			currentMembers = AdminTask.getMembersOfGroup (['-uniqueName', group]).split( newline )
			# each element in the returned list follows this pattern:
			# Person, uid=dmeyer,cn=users,dc=yourco,dc=com
			for currentMember in currentMembers:
				if (len(currentMember) > 0):
					print "member to be removed=" + currentMember
					memberUniqueName = currentMember.split(',', 1)[1]
					memberUniqueName = memberUniqueName.strip()
					AdminTask.removeMemberFromGroup (['-memberUniqueName', memberUniqueName, '-groupUniqueName', group])
				#endIf
			#endFor
		#endIf
		## Add all members to this group
		groupDn = AdminTask.searchGroups(['-cn', groupName])
		return groupDn
	#endDef

	"""
		Adds user and group members to the group represented by the 
		supplied xmlGroup.
		
		This should be done after all groups have been created so that 
		groups can be members of other groups.
	"""
	def addMembersToGroup (self, xmlGroup ):
		groupName = xmlGroup.getAttrValue("cn")
		groupDn = AdminTask.searchGroups(['-cn', groupName])
		users = xmlGroup.getFilteredChildrenArray('UserMember')
		for xmlUser in users:
			memberDn = AdminTask.searchUsers(xmlUser.buildNodeAttrsList())
			if (len(memberDn) == 0):
				user = xmlUser.getAttrValue("uid") 
				print "Error: User not found: User=" + user + " cannot be added to group " + groupName
			else:
				print "adding user " + memberDn + " to group " + groupDn
				AdminTask.addMemberToGroup(['-memberUniqueName', memberDn, '-groupUniqueName', groupDn])
			#endIf
		#endFor

		groups = xmlGroup.getFilteredChildrenArray('GroupMember')
		for xmlGroup in groups:
			memberDn = AdminTask.searchGroups(xmlGroup.buildNodeAttrsList())
			if (len(memberDn) == 0):
				group = xmlGroup.getAttrValue("cn") 
				print "Error: Group not found: Group=" + group + " cannot be added to group " + groupName
			else:
				print "adding group " + memberDn + " to group " + groupDn
				AdminTask.addMemberToGroup(['-memberUniqueName', memberDn, '-groupUniqueName', groupDn])
			#endIf
		#endFor
		return groupDn
	#endDef 

	def findAllDefinedGroups (self):
		#using set to guarantee uniqueness
		tmpGroups = HashSet()
		tmpGroups.addAll(self.getGroupArrayFromString(AdminTask.listGroupIDsOfAuthorizationGroup()))
		#Need this try catch block so v6.1 doesnt blow up as the next AdminTask function doesnt exist in 6.1
		try:
			tmpGroups.addAll(self.getGroupArrayFromString(AdminTask.listAuditGroupIDsOfAuthorizationGroup()))
		except:
			pass
		#convert back to a jython array
		groups = []
		for group in tmpGroups:
			groups.append(AdminTask.searchGroups(['-cn', group.split('@')[0]]))
		#endFor
		return groups
	#endDef	

	def getGroupArrayFromString(self, groupstr):
		#strip leading and trailing brackets and split on comma and loop
		allGroups=HashSet()
		for group in self.getAllArrays(groupstr):
			if (len(group) > 0):
				definedGroups = group.split(',')
				for g in definedGroups:
					if (len(g) > 0):
						allGroups.add(g)		
			#endFor
		#endFor
		return allGroups
	#endDef
	
	def getAllArrays(self, parseString):
		groupArrays=[]
		openidx = parseString.find('[', 0)
		closeidx = parseString.find(']',openidx)
		while (openidx != -1 and closeidx != -1): 
			groupArrays.append(parseString[openidx+1:closeidx]);
			openidx=parseString.find('[',closeidx)
			closeidx=parseString.find(']',openidx)
		#endWhile
		return groupArrays
	#endDef

	def readConfigData(self):
		groups = self.findAllDefinedGroups()
		confReader = ConfigReader()
		data = []
		newline = java.lang.System.getProperty("line.separator")
		for group in groups:#.split(newline):
			if (len(group) > 0):
				groupData = {}
				memberDict = confReader.convertToDict(AdminTask.getGroup(['-uniqueName', group]))
				groupData['attrs'] = memberDict
				members = AdminTask.getMembersOfGroup (['-uniqueName', group]).split( newline )
				memberChildren = []
				groupChildren = []
				for member in members:
					if (len(member) > 0):
						memberType, memberDn = member.split(", ")
						if (memberType.startswith("Person")):
							userDict = confReader.convertToDict(AdminTask.getUser(['-uniqueName', memberDn]))
							memberChildren.append(userDict)
						else:
							userDict = confReader.convertToDict(AdminTask.getGroup(['-uniqueName', memberDn]))
							groupChildren.append(userDict)
						#endIf
					#endIf
				#endFor
				groupData['memberChildren'] = memberChildren
				groupData['groupChildren'] = groupChildren
				data.append(groupData)
			#endIf - group is not an empty string
		#endFor
		return data
	#endDef
		
	def readFileRegistryGroups(self, xmlFile, marker):
		data = self.readConfigData()
		confWriter = ConfigFileWriter("fileRegistryGroups.vm")
		confWriter.processBasicFile(xmlFile, data, marker)
	#endDef

	def compareFileRegistryGroups(self, xmlFile, marker):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		xmlConfigReader = XMLConfigReader()
		configData = self.readConfigData()

		typeName = "Group"
		
		# initialize data struct
		data = {}
		data[typeName] = []
		## iterate over the children from WAS config
		for group in configData:
			attrs = {}
			attrs['id'] = typeName
			attrs['attrs'] = {}
			attrs['attrs']['cn'] = group['attrs']['cn']
			if ('description' in group['attrs'].keys()):
				attrs['attrs']['description'] = group['attrs']['description']
			#endIf	
			attrs['children'] = []
			for member in group['memberChildren']:
				memberAttrs = {}
				memberAttrs['id'] = 'UserMember'
				memberAttrs['attrs'] = {}
				memberAttrs['attrs']['uid'] = member['uid']
				memberAttrs['children'] = []
				attrs['children'].extend([memberAttrs])
			#endFor	
			for member in group['groupChildren']:
				memberAttrs = {}
				memberAttrs['id'] = 'GroupMember'
				memberAttrs['attrs'] = {}
				memberAttrs['attrs']['cn'] = member['cn']
				memberAttrs['children'] = []
				attrs['children'].extend([memberAttrs])
			#endFor	
			data[typeName].extend([attrs])
		#endFor
		
		# get wasConfig
		#print "comparing data for: " + typeName
		wasConfig = data[typeName]

		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(typeName)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
		
	#endDef
#endClass

'''
This is the function that is used by quick export to push the configuration data back to WAS
'''
def export(optDict=None):
	if (WasConfig.isWimEnabled(optDict)):
		global newline
		newline = java.lang.System.getProperty("line.separator")
		xmlFile = optDict['properties']
		mode = optDict['mode']
		marker = optDict['marker']
		thismediator = FileRegistryGroups()
		deleteGroups =  ""
		thismediator.writeFileRegistryGroups(xmlFile, marker, deleteGroups)
	else:
		self.LOGGER.log("CRWWA0002W")
		self.LOGGER.log("CRWWA0003W", "was_common_configure_file_registry_groups")
	#endIf
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:;delete_groups;scopename:;scope:;nodename:;washome:' )

	if (WasConfig.isWimEnabled(optDict)):
		xmlFile = optDict['properties']
		mode = optDict['mode']
		marker = "fileRegistryGroups"
		thismediator = FileRegistryGroups()
		if (mode == MODE_EXECUTE):
			print "Creating File Registry Groups"
			deleteGroups =  optDict["delete_groups"]
			thismediator.writeFileRegistryGroups(xmlFile, marker, deleteGroups)
			AdminHelper.saveAndSyncCell()
			
		elif (mode == MODE_AUGMENT):
			print "Augmenting File Registry Groups"
			deleteGroups = 0
			thismediator.writeFileRegistryGroups(xmlFile, marker, deleteGroups)
			AdminHelper.saveAndSyncCell()
		
		elif (mode == MODE_IMPORT):
			print "Importing File Registry Groups"
			thismediator.readFileRegistryGroups(xmlFile, marker)
			
		elif (mode == MODE_COMPARE):
			print "Comparing File Registry Groups"
			thismediator.compareFileRegistryGroups(xmlFile, marker)
		
		else:
			print "Unsupported MODE supplied: " + mode
		#endIf
	else:
		self.LOGGER.log("CRWWA0002W")
		self.LOGGER.log("CRWWA0003W", "was_common_configure_file_registry_groups")
	#endIf
#endIf