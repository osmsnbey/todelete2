"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 


	File name: J2CConnFactories.py

  This script is to create J2C Connection Factories under Resource Adapters in WAS 
	conneciton factories in a given scope.

  This script is invoked as:
  
     wsadmin -lang jython -profile jythonLib.py -f J2CConnFactories.py 
			-version <WAS version> -scope ${SCOPE} -scopename <scope name> 
			-properties <J2C properties file> 

  The script expects the following parameters:
    -version <WAS version>: specify the WAS version of the server
    -scope <scope>: specify the scope of the j2c connection factories to be created
    -scopename <scope name>: specify the scope name of the jms connection to be created 
    -properties <J2C properties file>: specify the name of the J2C properties 
			file to be used for the creation
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigFileReader import ConfigFileReader
from ConfigFileWriter import ConfigFileWriter
from ConfigWriter import ConfigWriterException
from ConfigWriter import ConfigWriter
from ConfigValidator import ConfigValidator
from XmlProperty import InvalidXmlConfigException
from J2CMediator import J2CConnFactoryMediator
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

LOGGER = _Logger("J2CConnFactories", MessageManager.RB_WEBSPHERE_WAS)

class DsMediator:
	
	def __init__(self):
		self.myConfigWriter = ConfigWriter();
		self.configValidator = ConfigValidator()
		self.configReader = ConfigReader()
		self.myJ2CMediator = J2CConnFactoryMediator()
	#endDef
	
	def createConfig(self, scope, scopeType, xmlFile, marker, typeNames, augment):
	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		
		scopeId = AdminConfig.getid( scope )
		#If my id is empty string, im probably processing ihs, which i dont add stuff to
		if scopeId == '':
			return
		## also handle CMPConnectorFactory
		typeNames.append("CMPConnectorFactory")
	
		processedXmlNodes = []
		for typeName in typeNames:
			if (augment):
				processedXmlNodes.extend(self.augmentConfigType(scopeId, scopeType, scope, xmlProp, typeName))
			else:
				processedXmlNodes.extend(self.myJ2CMediator.createConfigType(scopeId, scopeType, scope, xmlProp, typeName))
			#endIf
		#endFor
		try:
			self.myConfigWriter.updateWASReferenceAttributes(processedXmlNodes, scopeId, ["J2CResourceAdapter", "builtin", "ConnectionDefinition"])
		except ConfigWriterException, val :
			if (str(val).find("DataSource{") == -1):
				raise ConfigWriterException(str(val))
			else:
				msg = "\nIt looks like the jdbc entry is missing in WAS, try running was_common_configure_jdbc_datasources first. Exception details:\n " + str(val)
				raise ConfigWriterException(msg)
			#endif
		#endtry
	#endDef
	
	def augmentConfigType(self, scopeId, scopeType, scope, xmlProp, typeName):
	
	 	nodeArray = xmlProp.getFilteredNodeArray(typeName)
	
		processedXmlNodes = []
		for xmlNode in nodeArray:
			display = ""
			if (typeName=="CMPConnectorFactory"):
				childId = self.configValidator.validateUniqueAttr2(xmlNode, scopeId, 'name')
				display = "name " + xmlNode.getAttrValue("name")
			else:
				childId = self.configValidator.validateUniqueJndiName2(xmlNode, scopeId)
				display = "jndiName " + xmlNode.getAttrValue("jndiName")
			#endIf
			##print "Info: Processing " + typeName + " with " + display
			LOGGER.log("CRWWA1108I",[typeName,display])
			parentId = AdminHelper.findProviderId(xmlNode, scope, "J2CResourceAdapter", "name", "builtin")
			## connectionDefinition is required for types J2CConnectionFactory
			## but not for CMPConnectorFactory
			connDefNodes = xmlNode.getFilteredChildrenArray("ConnectionDefinition")
			if (typeName == "J2CConnectionFactory" and len(connDefNodes) > 0 and connDefNodes[0] != None):
				connectionDefId = self.myJ2CMediator._getConnectionDefId(xmlNode, scopeId, parentId)
				xmlNode.setAttrValue("connectionDefinition", connectionDefId)
			#endIf
			if (childId is None):
				self.myConfigWriter.createWASObject(xmlNode, parentId)
				processedXmlNodes.append(xmlNode)
			else:
				if (SystemUtils.updateOnAugment()):
					self.myConfigWriter.modify(childId, xmlNode)
					processedXmlNodes.append(xmlNode)
				else:
					##print "Warning: " + typeName + " will not be created."
					LOGGER.log("CRWWA1109W",[typeName])
				#endIf
			#endIf
		#endFor
		return processedXmlNodes
	#endDef
	
	def readConfigData(self, scope, scopeType, configType, excludedTypes):
		## read the config data as usual, then strip out the extra attributes of reference objects
		data = self.configReader.readConfigData(scope, scopeType, configType, excludedTypes)
		
		## the provider is located by name
		self.configReader.stripElement(data, "provider", None, ['name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		## leaving jndiName and name as attributes to locate references to cmpDataSources
		self.configReader.stripElement(data, "cmpDatasource", None,
								['jndiName', 'name', Globals.RAFW_TYPE, Globals.WAS_KEY_ATTR_NAME])	
		return data
	#endDef
	
	def compareConfig(self, scope, scopeType, xmlFile, marker, typeNames, excludedTypes = []):
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		xmlConfigReader = XMLConfigReader()
		# get wasConfig
		for typeName in typeNames:
			wasConfig = self.readConfigData(scope, scopeType, typeName, excludedTypes)

			# get rafwConfig
			filteredNodes = xmlProp.getFilteredNodeArray(typeName)
			## since J2CConnectionFactory objects can be CMPConnectorFactory types
			## read those into the comparison as well
			filteredNodes.extend(xmlProp.getFilteredNodeArray("CMPConnectorFactory"))
			
			rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
			ConfigComparor.compare(typeName, wasConfig, rafwConfig)
		#endFor
	#endDef
	
#endClass

def export(optDict=None):
	version= optDict['version']
		
	# get scope
	scope = optDict['wasscopetype']
	scopeType=optDict['scope']
	
	xmlFile = optDict['properties'] 
	
	typeNames = [optDict['type']]
	mode = optDict['mode']
	marker = optDict['marker']
	
	mediator = DsMediator()
	
	mediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 0)
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt(sys.argv, 'version:;scope:;properties:;nodename:;scopename:;mode:;script_name:')
	version= optDict['version']
		
	# get scope
	scope = AdminHelper.buildScope(optDict)
	scopeType=optDict['scope']
	
	xmlFile = optDict['properties'] 
	
	typeNames = ["J2CConnectionFactory"]
	mode = optDict['mode']
	marker = "J2CConnFactories"
	
	mediator = DsMediator()
	
	if (mode == MODE_EXECUTE):
	
		##print "Creating Resource Adapter J2C Connection Factories in scope: " + scope
		LOGGER.log("CRWWA1110I",[scope])
		LOGGER.debug("createConfig("+str(scope)+", "+str(scopeType)+", "
					+str(xmlFile)+", "+str(typeNames)+")")
		mediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 0)
	
		# save config
		AdminHelper.saveAndSyncCell()
	
	elif (mode == MODE_IMPORT):
		##print "Importing J2C Connection Factories in scope: " + scope
		LOGGER.log("CRWWA1111I",[scope])
		ConfigMediator.importConfig(scope, scopeType, xmlFile, marker, typeNames, [], mediator)
	elif (mode == MODE_COMPARE):
		##print "Comparing J2C Connection Factories in scope: " + scope
		LOGGER.log("CRWWA1112I",[scope])
		mediator.compareConfig(scope, scopeType, xmlFile, marker, typeNames)
	elif (mode == MODE_AUGMENT):
		##print "Augmenting Resource Adapter J2C Connection Factories in scope: " + scope
		LOGGER.log("CRWWA1113I",[scope])
		LOGGER.debug("createConfig("+str(scope)+", "+str(scopeType)+", "
					+str(xmlFile)+", "+str(typeNames)+")")
		mediator.createConfig(scope, scopeType, xmlFile, marker, typeNames, 1)
	
		# save config
		AdminHelper.saveAndSyncCell()
	else:
		##print "Unsupported MODE supplied: " + mode
		LOOGER.log("CRWWA0008W",[mode])
	#endIf
#endIf