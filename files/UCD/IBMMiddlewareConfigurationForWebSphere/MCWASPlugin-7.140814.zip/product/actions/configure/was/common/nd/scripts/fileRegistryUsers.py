"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: fileRegistryUsers.py
	
	TODO: description
"""

import sys
try:
	sys.modules['AdminConfig'] = AdminConfig
	sys.modules['AdminTask'] = AdminTask
except:
	pass
import AdminConfig
import AdminTask
import java

from Logger import _Logger
from SystemUtils import SystemUtils
from ConfigReader import ConfigReader
from ConfigReader import XMLConfigReader
from ConfigFileWriter import ConfigFileWriter
from ConfigFileReader import ConfigFileReader
from com.ibm.rational.rafw.wsadmin.logging import MessageManager
from java.util import HashSet
from WasConfig import WasConfig
from ConfigComparor import ConfigComparor

class FileRegistryUsers:
	def __init__(self):
		self.LOGGER = _Logger("fileRegistryUsers", MessageManager.RB_WEBSPHERE_WAS)	
	#endDef
	def writeFileRegistryUsers(self, xmlFile, marker, deleteUsers ):
		# parse the XML data 
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		
		nodeArray = xmlProp.getFilteredNodeArray('User' ) 
		usersInConfig = []
		for xmlUser in nodeArray:
			# do work
			user = self.createFileRegistryUser(xmlUser)
			usersInConfig.append(user)
		#endFor
		
		## delete all the users not in config
		if (deleteUsers):
			users = self.findAllDefinedUsers()#AdminTask.searchUsers(['-uid', "*" ])
			for user in users:#.split(newline):
				if (len(user) > 0):
					if (user not in usersInConfig):
						# remove user
						print "Removing user: " + user
						attrsList = []
						attrsList.append('-uniqueName')
						attrsList.append(user)
						AdminTask.deleteUser (attrsList)
					#endIf
				#endIf
			#endFor
		#endIf
	#endDef
	
	def findAllDefinedUsers (self):
		#using set to guarantee uniqueness
		tmpusers = HashSet()
		tmpusers.addAll(self.getUserArrayFromString(AdminTask.listUserIDsOfAuthorizationGroup()))
		#Need this try catch block so v6.1 doesnt blow up as the next AdminTask function doesnt exist in 6.1
		try:
			tmpusers.addAll(self.getUserArrayFromString(AdminTask.listAuditUserIDsOfAuthorizationGroup()))
		except:
			pass
		#convert back to a jython array
		users = []
		for user in tmpusers:
			users.append(AdminTask.searchUsers(['-uid', user]))
		#endFor
		return users
	#endDef	

	def getUserArrayFromString(self, userstr):
		#strip leading and trailing brackets and split on comma and loop
		allusers=HashSet()
		for user in self.getAllArrays(userstr):
			if (len(user) > 0):
				definedUsersInGroup = user.split(',')
				for u in definedUsersInGroup:
					if (len(u) > 0):
						allusers.add(u)
				#endFor
			#endIf
		#endFor
		return allusers
	#endDef

	def getAllArrays(self, parseString):
		userArrays=[]
		openidx = parseString.find('[', 0)
		closeidx = parseString.find(']',openidx)
		while (openidx != -1 and closeidx != -1): 
			userArrays.append(parseString[openidx+1:closeidx-1]);
			openidx=parseString.find('[',closeidx)
			closeidx=parseString.find(']',openidx)
		#endWhile
		return userArrays
	#endDef

	def createFileRegistryUser (self, xmlNode ):

		#--------------------------------------------------------------
		# set up a new console User
		#--------------------------------------------------------------
		userName = xmlNode.getAttrValue("uid")
		user = AdminTask.searchUsers(['-uid', userName ])
		if (len(user)==0):
			# create user
			print "create " + userName
			AdminTask.createUser (xmlNode.buildNodeAttrsList())
			user = AdminTask.searchUsers(['-uid', userName ])
		else:
			# update user
			print "update " + user
			attrsList = xmlNode.buildNodeAttrsList()
			attrsList.insert(0, '-uniqueName')
			attrsList.insert(1, user)

			AdminTask.updateUser (attrsList)
		#end if
		return user

	#endDef 

	def readConfigData(self):
		users = self.findAllDefinedUsers()#AdminTask.searchUsers(['-uid', "*",'-countLimit',"500"])
		
		confReader = ConfigReader()
		data = []
		newline = java.lang.System.getProperty("line.separator")
		for user in users:#.split(newline):
			if (len(user) > 0):
				userDict = confReader.convertToDict(AdminTask.getUser(['-uniqueName', user]))
				data.append(userDict)
			#endIf
		#endFor
		return data
	#endDef

	def readFileRegistryUsers(self, xmlFile, marker):
		data = self.readConfigData()
		confWriter = ConfigFileWriter("fileRegistryUsers.vm")
		confWriter.processBasicFile(xmlFile, data, marker)
	#endDef

	
		xmlProp = ConfigFileReader.openXmlConfig(xmlFile)
		xmlProp = xmlProp.findRAFWContainerNode(marker)
		xmlConfigReader = XMLConfigReader()
		configData = self.readConfigData()

		typeName = "User"
		
		# initialize data struct
		data = {}
		data[typeName] = []
		## iterate over the children from WAS config
		for user in configData:
			attrs = {}
			attrs['id'] = typeName
			attrs['attrs'] = {}
			attrs['attrs']['uid'] = user['uid']
			for attrName in ['cn', 'password', 'sn', 'mail']:
				if (attrName in user.keys()):
					attrs['attrs'][attrName] = user[attrName]
				#endIf	
			#endFor
			attrs['children'] = []
			data[typeName].extend([attrs])
		#endFor
		
		# get wasConfig
		#print "comparing data for: " + typeName
		print "Ignoring user passwords in the WebSphere Cell because they are one-way hashed and not accessible."
		wasConfig = data[typeName]

		# get rafwConfig
		filteredNodes = xmlProp.getFilteredNodeArray(typeName)
		rafwConfig = xmlConfigReader.readXmlConfig(filteredNodes)
		# we cannot read WAS passwords, so remove them if present from the rafwConfig
		for user in rafwConfig:
			attrs = user['attrs']
			if (attrs.has_key('password')):
				del attrs['password']
		#endFor
		ConfigComparor.compare(typeName, wasConfig, rafwConfig)
		
	#endDef
#endClass

def export(optDict=None):
	thismediator = FileRegistryUsers()
	if (WasConfig.isWimEnabled(optDict)):
		xmlFile = optDict['properties'] 
		marker = optDict['marker']
		mode = optDict['mode']
		deleteUsers =  ''
		thismediator.writeFileRegistryUsers(xmlFile, marker, deleteUsers)
	else:
		# WIM is not enabled, this action will not work correctly
		scriptLogger.log("CRWWA0002W")
		scriptLogger.log("CRWWA0003W", "was_common_configure_file_registry_users")
	#endIf
#enddef

#Don't want classes to run code when loaded as modules
if ( str(sys.argv).find("scopename") != -1):
	#Main
	# parse the options into optDict
	optDict, args = SystemUtils.getopt( sys.argv, 'properties:;mode:;delete_users;scopename:;scope:;nodename:;washome:' )
	thismediator = FileRegistryUsers()
	if (WasConfig.isWimEnabled(optDict)):
		xmlFile = optDict['properties'] 
		marker = "fileRegistryUsers"
		mode = optDict['mode']
		if (mode == MODE_EXECUTE):
			deleteUsers =  optDict["delete_users"]
			print "Creating File Registry Users"
			thismediator.writeFileRegistryUsers(xmlFile, marker, deleteUsers)
			AdminHelper.saveAndSyncCell()
		elif (mode == MODE_AUGMENT):
			deleteUsers = 0
			print "Augmenting File Registry Users"
			thismediator.writeFileRegistryUsers(xmlFile, marker, deleteUsers)
			AdminHelper.saveAndSyncCell()
		
		elif (mode == MODE_IMPORT):
			print "Importing File Registry Users"
			thismediator.readFileRegistryUsers(xmlFile, marker)
		
		elif (mode == MODE_COMPARE):
			print "Comparing File Registry Users"
			thismediator.compareFileRegistryUsers(xmlFile, marker)
			
		else:
			print "Unsupported MODE supplied: " + mode
		#endIf
	else:
		# WIM is not enabled, this action will not work correctly
		scriptLogger.log("CRWWA0002W")
		scriptLogger.log("CRWWA0003W", "was_common_configure_file_registry_users")
	#endIf
#endIf