import sys
from org.python.modules import time

#
# running = "websphere.cluster.running"
# partialstart = "websphere.cluster.partial.start"
# starting = "websphere.cluster.starting"
# stopped = "websphere.cluster.stopped"
#
def waitForStatus(clusterName, sleepSecs, retries, waitUntil):

    saveRetries = retries
    obj = AdminControl.completeObjectName("type=Cluster,name=" + clusterName + ",*")
    status = AdminControl.getAttribute(obj, "state")
    
    while(status != waitUntil and retries > 0):
        time.sleep(int(sleepSecs)) # seconds
        status = AdminControl.getAttribute(obj, "state")
        retries = int(retries)-1
        
    if(status != waitUntil and retries == 0):
        raise "Failed to reach " + waitUntil + " after " + str(int(saveRetries) * int(sleepSecs)) + " seconds"
    #endif
#endef


################
# Main program #
################
optDict, args = SystemUtils.getopt( sys.argv, 'waitUntil:;sleep:;retries:;scope:;properties:;nodename:;scopename:;mode:;cellProperties:' )

clusterName = optDict['scopename']
waitUntil = optDict['waitUntil'] # running or stopped
waitUntil = "websphere.cluster." + waitUntil
sleepSecs = optDict['sleep']
retries = optDict['retries']

waitForStatus(clusterName, sleepSecs, retries, waitUntil)

# end
