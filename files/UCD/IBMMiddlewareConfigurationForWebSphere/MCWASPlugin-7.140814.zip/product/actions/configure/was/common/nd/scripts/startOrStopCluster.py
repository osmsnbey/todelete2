"""
	Licensed Materials - Property of IBM Corp. 
IBM Rational Automation Framework 
(c) Copyright IBM Corporation 2003, 2012. All Rights Reserved.   

U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by 
GSA ADP Schedule Contract with IBM Corp. 

	
	File name: startOrStopCluster.py
	
	TODO: description
"""


import org.python.modules
from sys import argv
from java.util import Properties
from java.io import FileInputStream
from java.lang import Thread
from java.lang import Runnable
from encodings import __init__
from com.ibm.rational.rafw.wsadmin.logging import MessageManager

def checkServers ( startOrStop, clusterName ):

	global AdminControl
	global AdminConfig
	global AdminApp

	# check all the apps and servers in the cell to see if they are running
	cell = AdminConfig.list("Cell" )
	cellName = AdminControl.getCell( )
	clusters = AdminConfig.list("ServerCluster", cell )

	threads = []
	for aCluster in clusters.split():
		cName = AdminConfig.showAttribute(aCluster, "name" )
		if (clusterName == cName):
			memberlist = AdminConfig.showAttribute(aCluster, "members" )
			members = memberlist[1:len(memberlist)-1]
			for member in members.split():
				nodeName = AdminConfig.showAttribute(member, "nodeName" )
				serverName = AdminConfig.showAttribute(member, "memberName" )
				serverId = AdminConfig.getid("/Cell:"+cellName+"/Node:"+nodeName+"/Server:"+serverName+"/" )
				if ( startOrStop == "start" ):
					t = AdminHelper.startServerThread(serverName, nodeName)
					t.start();
					threads.append(t)
				elif ( startOrStop == "stop" ):
					AdminHelper.stopServer(serverName, nodeName )
				elif ( startOrStop == "ripplestart" ):
					AdminHelper.stopServer(serverName, nodeName )
					AdminHelper.startServer(serverName, nodeName )
				#endIf
			#endFor
		#EndIf
	#endFor
	failedServers = []
	if (len(threads) > 0):
		for t in threads:
			t.join()
			if (not t.getStatus()):
				failedServers.append(t.getServerName());
			#endIf
		#endFor
	#endIf
	if (len(failedServers) > 0):
		raise MessageManager.getExceptionMessage(MessageManager.RB_WEBSPHERE_WAS, "CRWWA0400E", ",".join(failedServers))
	#endIf
#endDef

startOrStop = sys.argv[0]
clusterName = sys.argv[1]

# check the servers
checkServers(startOrStop, clusterName )
