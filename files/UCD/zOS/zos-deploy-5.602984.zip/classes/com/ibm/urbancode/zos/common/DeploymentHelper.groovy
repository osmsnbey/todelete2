package com.ibm.urbancode.zos.common
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

import com.ibm.jzos.ZFile
import com.ibm.jzos.ZFileException

class DeploymentHelper {
	def static final filesCanBeDeletedFromWorkDir = new HashSet();
	static{
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.PACKAGE_MANIFEST_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.ROLLBACK_MANIFEST_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.DEPLOY_DELTA_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.DEPLOY_BACKUP_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.CONTAINER_MAPPER_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME_BACKUP);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.CHECK_ACCESS_DS_FILE_NAME);
		filesCanBeDeletedFromWorkDir.add(DeploymentConstants.PACKAGE_FILE_NAME);
	}

	static getStringInput(input) {
		return input?.trim();
	}

	static getBooleanInput(input) {
		return Boolean.valueOf(input?.trim());
	}

	//Repository path not located in the component name folder, we need to add this folder on the path
	static getVersionDirPathInRepository(basePath, componentName, versionName){
		def repobasePathToVersion = basePath + File.separator + componentName + File.separator + versionName;
		return(repobasePathToVersion);
	}

	static getFilePathInRepository(basePath, componentName, versionName, fileName) {
		def patToFileInRepo = getVersionDirPathInRepository(basePath,componentName,versionName) + File.separator + fileName;
		return(patToFileInRepo);
	}

	static getVersionPathInDeployBasePath(basePath, componentName, versionName){
		def basePathToVersion = basePath + File.separator +
				DeploymentConstants.ADDITIONAL_FOLDER_FOR_BASE_PATH + File.separator +
				componentName + File.separator +
				versionName;
		return(basePathToVersion);
	}

	static getFilePathinDeployBasePath(basePath, componentName, versionName, fileName) {
		def patToFileInBasePath = getVersionPathInDeployBasePath(basePath,componentName,versionName) + File.separator + fileName;
		return(patToFileInBasePath);
	}

	//Working copy default path is located in the component folder
	static getVersionDirPathInWorkingDir(basePath, versionname){
		return(basePath + File.separator + versionname);
	}

	static getFilePathInWorkingDir(basePath, versionname, fileName){
		def pathToFileInWorkDir = getVersionDirPathInWorkingDir(basePath, versionname) + File.separator + fileName
		return(pathToFileInWorkDir);
	}

	static getPath4ExecScriptInToolkit(toolkitHome, execName){
		return(toolkitHome + File.separator + DeploymentConstants.ZOS_TOOLKIT_EXEC_FOLDER_NAME + File.separator + execName);
	}

	//Get ant script,will depends on our pacakge structure
	static getAntScriptFolderPath(){
		final def pluginHome = System.getenv("PLUGIN_HOME");
		return(pluginHome + File.separator + "scripts" + File.separator + "deployment");
	}

	//Validation methods
	static validateFileExist(filePath, errorInfo){
		def file = new File(filePath);
		if( !(file.exists() && file.isFile()) ){
			throw new IllegalArgumentException(errorInfo);
		}
	}

	static validateDirectoryExist(filePath, errorInfo){
		def file = new File(filePath);
		if( !(file.exists() && file.isDirectory()) ){
			throw new IllegalArgumentException(errorInfo);
		}
	}

	static fileExists(filePath){
		def fileExist = false;
		def file = new File(filePath);
		if( file.exists() && file.isFile() ){
			fileExist = true;
		}

		return(fileExist);
	}

	//Handle user's input ruler mapping pair
	static handleMappingRule(pdsMapping, Map src2TargetMap) {
		if(pdsMapping && pdsMapping.size() > 0){
			def pdsMappingStr = "";
			pdsMappingStr = pdsMapping.trim();
			pdsMappingStr.replaceAll(DeploymentConstants.SYSTEM_LINE_SEPARATOR, DeploymentConstants.SRC_TO_TARGET_DELIMETER);
			def pdsMappingPairs = pdsMappingStr.split(DeploymentConstants.SRC_TO_TARGET_DELIMETER);
			pdsMappingPairs.each {pair->
				pair = pair.trim();
				if(pair.length() > 0){//Allow empty line which will be ignore
					def onePair = pair.split(DeploymentConstants.MAPPING_RULER_DELIMETER);
					onePair = onePair*.trim();
					if(onePair.size() == 2){
						if(!src2TargetMap.containsKey(onePair[0])){
							src2TargetMap.put(onePair[0], onePair[1]);
						}else{
							println "Warning - The mapping rule ${onePair[0]}, ${onePair[1]} is ignored,which was already set by ${onePair[0]}, ${src2TargetMap[onePair[0]]}";
						}
					}else{//abc,cc,dd or abc, or ,cc will be treat as illegal input
						throw new IllegalArgumentException("The format of ${pair} PDS mapping field is not correctly!");
					}
				}
			}
		}
	};

	//Check access

	static checkAccess4Input(Set targetDsSet, dsListFile4BackUpPath, checkAccessExePath) {
		def InputTargetVolumeMap = [:];
		targetDsSet.each { datasetName->
			def dsn = "'" + datasetName + "'";
			def exists = dsExist(dsn);
			if(!exists){
				println "Warning - Input dataset ${dsn} is not found!";
			}
			try {
				def vols = ZFile.locateDSN(dsn);
				if(null == vols || vols.size()<1){
					println "Warning - Input dataset ${dsn} is not found!";
				}else if( vols.size() > 1){
				}else{
					InputTargetVolumeMap.put(datasetName, vols[0]);
				}
			}
			catch(Exception locateException){
				//Can't find the the dsn
			}
		}
		//Generate the datasetlist file to call native checkaccess for deploy
		new File(dsListFile4BackUpPath).withWriter('IBM-1047'){ out ->
			InputTargetVolumeMap.each {datasetName,volume->
				out.println("${DeploymentConstants.CHECK_ACCESS_DS_INPUT_LEADER} ${datasetName} ${volume}");
			}
		}
		//Call native script to get the access code
		callCheckAccess(checkAccessExePath, dsListFile4BackUpPath, "input")
	}

	static checkAccess4Output(Set targetDsSet, dsListFilePath, checkAccessExePath) {
		def OutPutTargetVolumeMap = [:];
		targetDsSet.each { datasetName->
			def dsn = "'" + datasetName + "'";
			def exists = dsExist(dsn);
			if(!exists){
				OutPutTargetVolumeMap.put(datasetName, "******");
			}else{
				def vols = null;
				try{
					vols = ZFile.locateDSN(dsn);
				}catch(Exception locateException){
					println "The volumn of ${dsn} was not found for OUTPUT!";
				}

				if(null == vols || vols.size()){
					OutPutTargetVolumeMap.put(datasetName, "******");
				}else if( vols.size() > 1){
				}else{
					OutPutTargetVolumeMap.put(datasetName, vols[0]);
				}
			}
		}
		//Generate the datasetlist file to call native checkaccess for deploy
		new File(dsListFilePath).withWriter('IBM-1047'){ out ->
			OutPutTargetVolumeMap.each {datasetName,volume->
				out.println("${DeploymentConstants.CHECK_ACCESS_DS_OUTPUT_LEADER} ${datasetName} ${volume}");
			}
		}
		callCheckAccess(checkAccessExePath, dsListFilePath, "output")
	}

	static callCheckAccess(checkAccessExePath, dsListFilePath, ioType) {
		def accessResultProcess = [
			"${checkAccessExePath}",
			"-d",
			"${dsListFilePath}"
		].execute();
		accessResultProcess.waitFor();
		println accessResultProcess.text;
		def accessResult = accessResultProcess.exitValue();
		if(accessResult != 0){
			println "checkaccess:rc=${accessResult}";
			if(137 == accessResult){
				println "checkaccess utility failed. Please verify that checkaccess utility is set as APF authorized by running command \"extattr +a checkaccess\"";
				System.exit(137);
			}
			throw new IOException("These Datasets you listed in PDS mapping can't be used as the ${ioType} of the program!");
		}
	}

	static dsExist(singleQuotedDsName){
		def isExist = false;
		def f = null;
		try {
			f = new ZFile("//" + singleQuotedDsName, "r");
			isExist = true;
		} catch(ZFileException e) {
			// Assume that the file does not exist in this case.
		} finally {
			if (null != f) {
				f.close();
			}
		}

		return(isExist);
	}

	//Clean up after deploy or rollback
	static cleanWorkDir(workdir){
		def versionWorkingDirectory = new File(workdir);
		if (versionWorkingDirectory.exists() && versionWorkingDirectory.isDirectory()) {
			versionWorkingDirectory.eachFile{it->
				if( filesCanBeDeletedFromWorkDir.contains(it.name) ){
					it.delete();
				}
			}
		}
	}

	//Clean up back up data
	static cleanBackUpData(deployBasePath) {
		cleanWorkDir(deployBasePath);
	}

	//Verify copy/ftp result
	static verifyGetArtifectResult(filePath, errorInfo){
		def file = new File(filePath);
		if(!file.exists() || !file.isFile()){
			throw new IOException(errorInfo);
		}
	}

	//Not null or empty input checking
	static inputNotEmptyCheck(input, errorInformation) {
		if (null == input || input.length()<=0) {
			throw new IllegalArgumentException(errorInformation);
		}
	}
}
