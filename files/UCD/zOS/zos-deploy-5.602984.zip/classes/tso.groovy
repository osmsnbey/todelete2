import com.ibm.urbancode.zos.common.TSOHelper;
import com.ibm.urbancode.zos.deploy.common.DataSet;
import com.ibm.urbancode.zos.deploy.common.DeploymentResultHelper;
import com.ibm.urbancode.zos.deploy.common.Member;
import com.ibm.urbancode.zos.common.DeploymentHelper;

/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

try{
	final def workDir = new File('.').canonicalFile
	final def props = new Properties();
	final def inputPropsFile = new File(args[0]);
	try {
		inputPropsStream = new FileInputStream(inputPropsFile);
		props.load(inputPropsStream);
	}
	catch (IOException e) {
		throw new RuntimeException(e);
	}

	final def tsoCommand 		= DeploymentHelper.getStringInput(props['tsoCommand']);
	final def ispfGatewayPath 	= DeploymentHelper.getStringInput(props['ispfGatewayPath']);
	final def reuseSession 		= DeploymentHelper.getBooleanInput(props['reuseSession']);
	final def showLog 			= DeploymentHelper.getBooleanInput(props['showLog']);
	final def serviceType 		= DeploymentHelper.getStringInput(props['serviceType']);
	final def ispProf 			= DeploymentHelper.getStringInput(props['ispProf']);
	final def loopType 			= DeploymentHelper.getStringInput(props['loopType']);  //NONE, PDS, Member
	final def deployType 		= DeploymentHelper.getStringInput(props['deployType']); //* for all
	final def deployBasePath 	= DeploymentHelper.getStringInput(props['deployBasePath']);
	final def componentName 	= DeploymentHelper.getStringInput(props['componentName']);
	final def versionName 		= DeploymentHelper.getStringInput(props['versionName']);

	def tsoHelper = new TSOHelper()
	tsoHelper.ispfGatewayPath = ispfGatewayPath
	tsoHelper.reuseSession = reuseSession
	tsoHelper.serviceType = serviceType
	tsoHelper.ispProf = ispProf
//	tsoHelper.debug=true
	
	if(loopType == "NONE"){
		//run single command
		runTSOCommand(tsoCommand, tsoHelper, showLog)
	}else if(loopType == "PDS" || loopType == "Member"){
		//iterate for each deployed PDS or member with deployType equals ...
		
		if(deployBasePath == null || deployBasePath.trim().length()==0){
			throw new Exception("Deploy Base Path must be set to run commands for deployed data sets");
		}
		
		Set<DataSet> deployedDatasets = DeploymentResultHelper.getDeployedDataSets(deployBasePath, componentName, versionName);
		for(currentDataset in deployedDatasets){
			if("PDS"==loopType){
				if(currentDataset.getDeployType() == deployType || "*" == deployType){
					Map vars = [dataset: currentDataset.getName(), member: "", deployType: currentDataset.getDeployType()];
					//To compatible with 610, which has the default dataset,memeber,deployType keyword. So we support property and this.property grammar
					vars.put("this.dataset", currentDataset.getName());
					vars.put("this.member", "");
					vars.put("this.deployType", currentDataset.getDeployType());
					
					//Add customer properties here to support old way ${propertyName}
					def dsCustomerProperties = currentDataset.getCustomerProperties();
					if(null!=dsCustomerProperties){
						vars.putAll(dsCustomerProperties);
						supportThisExpression(vars, dsCustomerProperties);
					}
					try {
						runTSOCommand(envCommand(tsoCommand, vars), tsoHelper, showLog);
					} catch(MissingPropertyException noSuchProperty) {
						throw new IllegalArgumentException("Missing property propname for ${currentDataset.getName()}. Please make sure the property is set on the data set.");
					}
				}
			}else if("Member" == loopType){
				Set<Member> deployedMembersInCurrentDataSet = currentDataset.getMembers();
				for(member in deployedMembersInCurrentDataSet){
					if(member.getDeployType() == deployType || deployType == "*"){
						Map vars = [dataset: currentDataset.getName(), member: member.getName(), deployType: member.getDeployType()];
						vars.put("this.dataset", currentDataset.getName());
						vars.put("this.member", member.getName());
						vars.put("this.deployType", member.getDeployType());
						
						//Add customer properties here to support old way ${propertyName}
						def dsCustomerProperties = currentDataset.getCustomerProperties();
						if(null!=dsCustomerProperties && dsCustomerProperties.size()>0){
							vars.putAll(dsCustomerProperties);
							supportThisExpression(vars, dsCustomerProperties);
						}
						
						def mbCustomerProperties =member.getCustomerProperties(); 
						if(null != mbCustomerProperties && mbCustomerProperties.size()>0){
							vars.putAll(mbCustomerProperties);
							supportThisExpression(vars, mbCustomerProperties);
						}
						try {
							runTSOCommand(envCommand(tsoCommand, vars), tsoHelper, showLog);
						} catch (MissingPropertyException noSuchProperty) {
							throw new IllegalArgumentException("Missing property propname for ${currentDataset.getName()}(${member.getName()}). Please make sure the property is set on the data set or member.");
						}
					}
				}
			}
		}
	}
} catch (Exception e) {
    println "Error executing TSO/ISPF command: ${e.message}";
	e.printStackTrace();
    System.exit(1);
}

def envCommand(String s, Map vars) { 
	Binding bind = new Binding(vars)
	GroovyShell gs = new GroovyShell(bind) 
	return gs.evaluate("\"\"\"${s}\"\"\"") 
}

//---------------------------------------------------------------------
//Support ${this.propertyName} expression 
//Customer write the expression will replaced by customer properties of current iterate dataset/member.
def supportThisExpression(Map propertyMap, Map customerProperties) {
	def prefix = "this.";
	for (Map.Entry<String,String> entry : customerProperties.entrySet()) {
		def keywithPrefix = entry.getKey();
		propertyMap.put(keywithPrefix, entry.getValue());
	}
}

def runTSOCommand(tsoCommand, TSOHelper tsoHelper, boolean showLog){


	println('===============================')
	println (tsoHelper.serviceType + " command: ")
	println (tsoCommand);
	
	exitValue = tsoHelper.runCommand(tsoCommand)
	if( exitValue == 0){
		println('===============================')
		println("Command output: ")

		if(tsoHelper.serviceType == "ISPF"){
			print("Return Code: ")			
			println(tsoHelper.returnCode)
		}

		println(tsoHelper.outputText)
	
		if(showLog){
			println('===============================')
			println("ISPF Gateway operations log")
			println(tsoHelper.operationsLog)
		}
	}
	println('===============================')
	println("Command exit code: ${exitValue}")
	println("")
}

System.exit(0);

