/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
import java.io.IOException;
import java.util.Iterator;
import com.ibm.jzos.*;

try{
	final def workDir = new File('.').canonicalFile
	final def props = new Properties();
	final def inputPropsFile = new File(args[0]);
	try {
		inputPropsStream = new FileInputStream(inputPropsFile);
		props.load(inputPropsStream);
	}
	catch (IOException e) {
		throw new RuntimeException(e);
	}

	def propFileName = 'replace_tokens.properties'
	def dirOffset = props['dir']?:'.'
	workDir = new File(workDir, dirOffset).canonicalPath
	def includes = props['includes']
	def excludes = props['excludes']
	def startDelimiter = props['startDelimiter']?:''
	def endDelimiter = props['endDelimiter']?:''
	def propertyPrefix = props['propertyPrefix']
	def envPropValues = props['envPropValues']
	def explicitTokens = props['explicitTokens']
	def propFile = new File(workDir, propFileName)
	def fileList = [:];


	try {
		def Properties properties = new Properties()
		if (propFile.exists()) {
			propFileExistst = true
			println "Found existing input property file: ${propFile.canonicalPath}"
			def tempProps = new Properties()
			propFile.withInputStream { stream ->
				tempProps.load(stream)
			}
			tempProps.each { k,v ->
				properties.setProperty(startDelimiter + k + endDelimiter, v)
			}
		}
	
		//add properties
		if(envPropValues) {
			if (propertyPrefix) {
				println "Looking for properties starting with $propertyPrefix"
			}
			//this is jeffs magic regex to split on ,'s preceded by even # of \ including 0
			envPropValues.split("(?<=(^|[^\\\\])(\\\\{2}){0,8}),").each { prop ->
				//split out the name
				def parts = prop.split("(?<=(^|[^\\\\])(\\\\{2}){0,8})=",2);
				def propName = parts[0];
				def propValue = parts.size() == 2 ? parts[1] : "";
				//replace \, with just , and then \\ with \
				propName = propName.replace("\\=", "=").replace("\\,", ",").replace("\\\\", "\\")
				propValue = propValue.replace("\\=", "=").replace("\\,", ",").replace("\\\\", "\\")

				if ((!propertyPrefix || propName.startsWith(propertyPrefix))) {
					properties.setProperty(startDelimiter + propName + endDelimiter, propValue)
					//                println 'added: ' + startDelimiter + propName + endDelimiter + ':' + propValue
				}
			}
		}

		if (explicitTokens) {
			explicitTokens.eachLine {
				if (it && it.indexOf('->') > 0) {
					def index = it.indexOf('->')
					def propName = it.substring(0, index).trim()
					def propValue = index < (it.length() - 2) ? it.substring(index + 2) : ""
					properties.setProperty(propName, propValue)
//                println 'added: ' + propName + ':' + propValue
				}
				else if (it) {
					println "Found invalid explicit token $it - missing -> separator"
				}
			}
		}
		propFile.withOutputStream { outStream ->
			properties.store(outStream, 'Auto generated property file')
		}

		//parse file list
		if(includes) {
			includes.split('(\\s|;)').each{ line ->
				if(line.trim()){
					def items=line.split('\\(|\\)')
					if(items.length>0){
						def dsnPattern = items[0];
						def memberPattern=/.*/
						if (items.length>1){
							if(items[1].contains("*")){
								memberPattern=/^${items[1].replaceAll("\\*+",".*")}$/
							}else{
								memberPattern=/^${items[1]}$/
							}
						}
						println "Searching dataset with name pattern: ${dsnPattern}(${memberPattern})"

						//invoke catalog search interface to get a list of available datasets
						CatalogSearch catSearch = new CatalogSearch(dsnPattern, 64000);
						catSearch.addFieldName("ENTNAME");
						catSearch.search();
						while(catSearch.hasNext()){
							CatalogSearch.Entry entry = catSearch.next();
							if(entry.isDatasetEntry()){
								CatalogSearchField dataset =entry.getField("ENTNAME");
								def pdsName = dataset.getFString().trim();
								println "Found dataset ${pdsName}"
								//iterate through pds to get qualified member
								PdsDirectory pds = new PdsDirectory(ZFile.getSlashSlashQuotedDSN(pdsName,true))
								def List memberItems = fileList.get(pdsName)
								for(Iterator<PdsDirectory.MemberInfo> memberItr=pds.iterator();memberItr.hasNext();){
									PdsDirectory.MemberInfo member = memberItr.next()
									def memberName = member.getName();
									if (memberName.matches(memberPattern)){
										println "add member ${pdsName}(${memberName}) to file list"
										if (memberItems){
											if (!memberItems.contains(memberName)){
												memberItems.add(memberName)
											}
										}else{
											memberItems= []
											memberItems.add(memberName)
										}
									}
								}
								fileList.put(pdsName,memberItems)
								pds.close();
							}
						}
					}
				}
			}
		}
		if(excludes){
			excludes.split('\\s|;').each {line ->
				def items=line.split('\\(|\\)');
				if (items.length>0){
					def datasetFiter = items[0];
					if (datasetFiter && datasetFiter.trim().contains("*")){
						datasetFiter = datasetFiter.replaceAll("\\*+",".*");
					}
					def datasetRule= /^${datasetFiter}$/
					def memberFilter =null;
					def memberRule= /.*/;
					if (items.length>1){
						memberFilter = items[1];
						if (memberFilter && memberFilter.trim().contains("*")){
							memberFilter= memberFilter.replaceAll("\\*+",".*");
						}
						memberRule=/^${memberFilter}$/
					}

					println "Remove the files from file list whose name matches ${datasetRule.toString()}(${memberRule.toString()})"

					def keyset=fileList.keySet();
					def deleteDsList = [:]
					for(def Iterator keyIterator = keyset.iterator();keyIterator.hasNext();) {
						def String dsn = keyIterator.next();
						if (dsn.matches(datasetRule)) {
							def List memberList = fileList.get(dsn);
							def deleteMemberList=[];
							for(Iterator memberItr=memberList.iterator();memberItr.hasNext();){
								def memberName = memberItr.next();
								if (memberName.matches(memberRule)) {
									deleteMemberList.add(memberName);
									println "${dsn}(${memberName}) is removed from list"
								}
							}
							deleteDsList.put(dsn,deleteMemberList)
						}
					}
					deleteDsList.each {
						def List tmpMembers=fileList.get(it.key)
						tmpMembers.removeAll(it.value);
						if (tmpMembers.empty){
							fileList.remove(it.key)
						}else{
							fileList.put(it.key,tmpMembers);
						}
					}
				}
			}
		}

		def ant = new AntBuilder()
		if (properties.size() > 0) {
			fileList.each {key,value->
				println "Replace token in PDS ${key}"
				//copy files
				value.each {memberName->
					RecordReader reader = null;
					def writer = null;
					try{
						reader= RecordReader.newReader(ZFile.getSlashSlashQuotedDSN("${key}(${memberName}",true),ZFileConstants.FLAG_DISP_SHR);
						writer= new File(workDir,memberName).newWriter(ZUtil.getDefaultPlatformEncoding());
						byte[] recordBuf = new byte[reader.getLrecl()];
						int bytesRead;
						while ((bytesRead = reader.read(recordBuf)) > 0) {
							writer.writeLine(new String(recordBuf,ZUtil.getDefaultPlatformEncoding()));
						}
					} finally {
						if (reader != null) {
							try {
								reader.close();
							} catch (ZFileException zfe) {
								zfe.printStackTrace();  // but continue
							}
						}
						if (writer != null) {
							try {
								writer.flush();
								writer.close();
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}

				//replace token
				String encode = ZUtil.getDefaultPlatformEncoding();
				ant.replace(
						dir:workDir,
						summary: 'true',
						defaultexcludes: 'no',
						replacefilterfile: propFile.canonicalPath,
						encoding: encode)

				//apply changes
				value.each {memberName->
					RecordWriter member = RecordWriter.newWriter(ZFile.getSlashSlashQuotedDSN("${key}(${memberName}",true),ZFileConstants.FLAG_DISP_SHR);
					def tempFile = new File(workDir,memberName);
					def reader = tempFile.newReader(ZUtil.getDefaultPlatformEncoding());
					byte[] recBuf = null;
					int lineCounts=1;
					try{
						while((line = reader.readLine())!= null){
							def record =line.replaceAll(/\s+$/, '').padRight(member.getLrecl()).toString();
							recBuf =record.getBytes(ZUtil.getDefaultPlatformEncoding());
							if(recBuf.length >member.getLrecl()){
								println "Warning: line $lineCounts excceeds ${member.getLrecl()} bytes and will be truncated."
								println " $lineCounts: $line"
								member.write(recBuf,0,member.getLrecl());
							}
							else{
								member.write(recBuf, 0, recBuf.length);
							}
							lineCounts++;
						}
						tempFile.delete();
					}catch(e){
						e.printStackTrace();
					}finally{
						if(member) member.close();
						if(reader) reader.close();
					}
				}
			}
		}
		else {
			println 'Did not find any properties or explicit tokens for replacement.'
		}
	}
	catch (Exception e) {
		e.printStackTrace()
		println "Error replacing tokens!"
		System.exit(1)
	}
	finally {
		if (propFile) {
			propFile.delete();
		}
	}
} catch (Exception e) {
	println "${e.message}";
	e.printStackTrace();
	System.exit(1);
}

System.exit(0)