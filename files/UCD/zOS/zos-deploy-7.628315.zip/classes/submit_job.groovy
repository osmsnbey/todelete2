/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
import java.util.Map;

import com.urbancode.air.AirPluginTool

import static java.lang.Integer.valueOf

import com.ibm.urbancode.zos.jes.JESJob;
import com.ibm.urbancode.zos.jes.JobUtil;
import com.ibm.jzos.PdsDirectory;
import com.ibm.jzos.ZFile;
import com.ibm.jzos.ZUtil;
import com.ibm.jzos.CatalogSearch;
import com.ibm.jzos.ZFileException;
import com.ibm.jzos.RecordReader;
import com.ibm.jzos.ZFileConstants;

try{
	def apTool = new AirPluginTool(this.args[0], this.args[1])
	final def workDir = new File('.').canonicalFile
	def props = apTool.getStepProperties();
	final def inputPropsFile = new File(args[0]);

	final def mvsFilename = props['mvsFilename']?.trim();
	final def ussFilename = props['ussFilename']?.trim();
	final def jclString = props['jclString']?.trim();
	final def explicitTokens = props['explicitTokens']?.trim();
	final def waitForJob = Boolean.valueOf(props['waitForJob']);
	final def timeout = props['timeout']?.trim();
	final def showOutput = props['showOutput']?.trim();
	final def cutOff = props['cutOff']?.trim();
	final def maxRC = props['maxRC']?.trim();

	final def hostname = props['hostname']?.trim();
	final def userid = props['userid']?.trim();
	final def password = props['password']?.trim();
	final def port = props['port']?.trim();

	if(!hostname || hostname.length() < 1){
		throw new IllegalArgumentException("Host Name can not be empty.");
	}
	if(!userid || userid.length() < 1){
		throw new IllegalArgumentException("User ID can not be empty.");
	}
	if(!password || password.length() < 1){
		throw new IllegalArgumentException("Password can not be empty.");
	}
	if(!port || port.length() < 1){
		throw new IllegalArgumentException("Port can not be empty.");
	}
	
	def jobUtil = new JobUtil(hostname,port,userid,password)
	def toSubmitJclContent = "";
	if(mvsFilename && mvsFilename.length() > 0){
		if(explicitTokens && explicitTokens.length() >0){
			// If replacing rule is specified, read the content into string
			jobUtil.setJclString(readMvsFile(mvsFilename));
		}else{
			jobUtil.setMvsFilename(mvsFilename);
			toSubmitJclContent = readMvsFile(mvsFilename);
		}
	}else if(ussFilename && ussFilename.length() > 0){
		if(explicitTokens && explicitTokens.length() >0){
			// If replacing rule is specified, read the content into string			
			jobUtil.setJclString(readUssFile(ussFilename));
		}else{
			jobUtil.setUssFilename(ussFilename);
			toSubmitJclContent = readUssFile(ussFilename);
		}
	}else if(jclString && jclString.length() > 0){
		jobUtil.setJclString(jclString);
		toSubmitJclContent = jclString;
	}else{
		throw new IllegalArgumentException("At least one JCL input (JCL Dataset, JCL File or JCL) must be specified. ");
	}

	if(waitForJob){
		try{
			int timeoutValue = valueOf(timeout as String);
			jobUtil.setTimeout(timeoutValue);
		}catch(NumberFormatException e){
			throw new IllegalArgumentException("Time Out isn't a number.");
		}
		try{
			int cutOffValue = valueOf(cutOff as String);
			jobUtil.setCutoff(cutOffValue);
		}catch(NumberFormatException e){
			throw new IllegalArgumentException("Cut Off isn't a number.");
		}		
		try{
			int maxRCValue = valueOf(maxRC as String);
			jobUtil.setMaxReturnCode(maxRCValue);
		}catch(NumberFormatException e){
			throw new IllegalArgumentException("Max Return Code isn't a number.");
		}		
		jobUtil.setShowOutput(showOutput);
		
	}
	
	if(explicitTokens && explicitTokens.length() >0){
		// replace tokens
		jobUtil.setJclString(replaceJCL(jobUtil.getJclString(),explicitTokens));
		toSubmitJclContent = jobUtil.getJclString();
	}

	checkJobCard(toSubmitJclContent);//check job card before sumit
	def jobid = jobUtil.submitJob();
	apTool.setOutputProperty("JobId", jobid);
	//wait before check JCL Error
	Thread.sleep(500);
	if(jobUtil.isJclError(jobid)){
		def job = jobUtil.getJob(jobid, true);
		apTool.setOutputProperty("JobReturnCode", job.getReturnCode()==null?"":job.getReturnCode());
		apTool.setOutputProperty("JobReturnInfo", job.getReturnInfo()==null?"":job.getReturnInfo());
		apTool.setOutputProperty("JobReturnStatus", job.getReturnStatus()==null?"":job.getReturnStatus());
		
		jobUtil.disconnect();

		apTool.storeOutputProperties();
		System.exit(1);
	}
	
	if(waitForJob){
		def success = jobUtil.waitForJob(jobid);
		jobUtil.printLog(jobid);

		def job = jobUtil.getJob(jobid, true);
		apTool.setOutputProperty("JobReturnCode", job.getReturnCode()==null?"":job.getReturnCode());
		apTool.setOutputProperty("JobReturnInfo", job.getReturnInfo()==null?"":job.getReturnInfo());
		apTool.setOutputProperty("JobReturnStatus", job.getReturnStatus()==null?"":job.getReturnStatus());
		apTool.storeOutputProperties();

		jobUtil.disconnect();
		if(success){
			System.exit(0);
		}else{
			System.exit(1);
		}
	}else{
		apTool.storeOutputProperties();
	}
}catch (Exception e) {
    println "Error Running Job: ${e.message}";
	e.printStackTrace();
    System.exit(1);
}

def readMvsFile(String name) {
	RecordReader reader = null;
	StringBuffer buffer = new StringBuffer();
	try{
		reader= RecordReader.newReader(ZFile.getSlashSlashQuotedDSN(name,true),ZFileConstants.FLAG_DISP_SHR);	
		byte[] recordBuf = new byte[reader.getLrecl()];
		int bytesRead;
		while ((bytesRead = reader.read(recordBuf)) > 0) {
			buffer.append(new String(recordBuf)).append("\n");
		}
	} finally {
		if (reader != null) {
			try {
				reader.close();
			} catch (ZFileException zfe) {
				zfe.printStackTrace();  
			}
		}
	} 
	return buffer.toString();
}

def readUssFile(String name) {
	return new File(name).text;
}

def createStringAfterFillBlank(oriByteArr, replacedByteArr, TmpByteArrLength, remainLength, blank){
	byte [] currentBytesAfterTrancate = new byte[TmpByteArrLength];
	Arrays.fill(currentBytesAfterTrancate, blank);
	int withoutLineMetaInfoLength = replacedByteArr.length - remainLength;
	System.arraycopy(replacedByteArr, 0, currentBytesAfterTrancate, 0, withoutLineMetaInfoLength);//Copy 'real' content into temp array
	if(remainLength>0){
		System.arraycopy(oriByteArr, oriByteArr.length-remainLength, currentBytesAfterTrancate, TmpByteArrLength-remainLength, remainLength);//Copy row information content back to temp array, and also the switch line indicate
	}
	
	return new String(currentBytesAfterTrancate, ZUtil.getDefaultPlatformEncoding());
}

def createStringAfterTruncateBlank(oriByteArr, replacedByteArr, TmpByteArrLength, remainLength, blank, lineNumber, line){
	byte [] currentBytesAfterTrancate = new byte[TmpByteArrLength];
	Arrays.fill(currentBytesAfterTrancate, blank);
	
	int withoutLineMetaInfoLength = replacedByteArr.length - remainLength;
	int tmpStartOfmetaInfoLength = withoutLineMetaInfoLength;
	while(withoutLineMetaInfoLength-- >0 && replacedByteArr[withoutLineMetaInfoLength] == blank){};//Truncate whitespace
	if(withoutLineMetaInfoLength+1>71){//content bigger than 71 will cause issue.
		println "Error: line $lineNumber excceeds 71 bytes.";
		println " $lineNumber: $line";
		return(true);
	}else{
		System.arraycopy(replacedByteArr, 0, currentBytesAfterTrancate, 0, withoutLineMetaInfoLength+1);//Copy 'real' content into temp array
		if(remainLength>0){
			System.arraycopy(oriByteArr, oriByteArr.length-remainLength, currentBytesAfterTrancate, TmpByteArrLength-remainLength, remainLength);//Copy row information content back to temp array
		}
		
		return(new String(currentBytesAfterTrancate, ZUtil.getDefaultPlatformEncoding()));
	}
}

def checkJobCard(submitJclContent) {
	if(null != submitJclContent && submitJclContent.length()>0){
		//Check job card before submit job to jes server
		def checkJobCardlines= submitJclContent.split("\n")
		if(null != checkJobCardlines && checkJobCardlines.size() > 0){
			def firstLine = checkJobCardlines[0];
			if(!(firstLine =~ /\bJOB\b/)){
				println "Error: JOB statement must be provided in the first line.";
				System.exit(1);
			}
		}else{
			println "Error: JCL job must contain a JOB statement in the first line.";
			System.exit(1);
		}
	}else{
		println "Error:JCL content is empty";
		System.exit(1);
	}
}
def replaceJCL(String jcl, String rules){
	//Write rules into properties file
	def Properties properties = new Properties();
    rules.eachLine {
        if (it && it.indexOf('->') > 0) {
            def index = it.indexOf('->')
            def propName = it.substring(0, index).trim()
            def propValue = index < (it.length() - 2) ? it.substring(index + 2) : ""
            properties.setProperty(propName, propValue)
//            println 'added: ' + propName + ':' + propValue
        }
        else if (it) {
            println "Found invalid explicit token $it - missing -> separator"
			System.exit(1);
        }
    }
	def propFile = new File(".").createTempFile("property", "properties");
	propFile.withOutputStream { outStream ->
	    properties.store(outStream, 'Auto generated property file')
	}

	// Write data set content into a temp file
	File f= new File(".").createTempFile("mvs", "tmpmvsfile");
	f.deleteOnExit();
	PrintWriter pw = new PrintWriter(f);
	pw.println(jcl);
	pw.close();

	def originalLines = jcl.split("\n");
	byte[] oriRecBuf = null;
	//Run ant replace
	def ant = new AntBuilder()
	String encode = ZUtil.getDefaultPlatformEncoding();
	ant.replace(
		file:f.canonicalPath,
		summary: 'true',
		defaultexcludes: 'no',
		replacefilterfile: propFile.canonicalPath,
		encoding: encode)
	String targetJcl =f.text;
	f.delete();
	propFile.delete();
	
	println "========================================================================================================================"
	println "JCL after replacing token."
	//check for exceeding 80
	def lines=targetJcl.split("\n")
	def i = 1
	byte[] recBuf = null;
	
	boolean contentExceedMaxNum = false;
	def linesAfterTrancateArr = [];
	def currentLineNumberMetaInfo = [];
	def whiteSpaceStr = new String(" ", ZUtil.getDefaultPlatformEncoding());
	byte[] whitespaceBytes= whiteSpaceStr.getBytes(ZUtil.getDefaultPlatformEncoding());
	byte byte4WhiteSpace = whitespaceBytes[0];
	
	for(line in lines){
		if(line.startsWith('//*')){//ignore comment statement
			linesAfterTrancateArr.add(line);
			i++;
			continue;
		}
		
		recBuf = line.getBytes(ZUtil.getDefaultPlatformEncoding());
		def columNum = recBuf.length;
		oriRecBuf = originalLines[i-1].getBytes(ZUtil.getDefaultPlatformEncoding());
		def oriColumNum = oriRecBuf.length;
		
		if(oriColumNum == 80) {//Means contains line number meta information
			if(columNum<80){
				linesAfterTrancateArr.add(createStringAfterFillBlank(oriRecBuf, recBuf, 80, 9, byte4WhiteSpace));
			}else if(columNum==80){
				linesAfterTrancateArr.add(line);
			}else if(columNum > 80){
				def afterTruncate = createStringAfterTruncateBlank(oriRecBuf, recBuf, 80, 9, byte4WhiteSpace, i, line);
				if(true == afterTruncate){
					contentExceedMaxNum = true;
				}else{
					linesAfterTrancateArr.add(afterTruncate);
				}
			}
		} else {//Not contains line number meta information
			if(oriColumNum == 72 && oriRecBuf[71] != byte4WhiteSpace){//contains continue line information
				if(columNum<72){
					linesAfterTrancateArr.add(createStringAfterFillBlank(oriRecBuf, recBuf, 72, 1, byte4WhiteSpace));
				}else if(columNum==72){
					linesAfterTrancateArr.add(line);
				}else if(columNum>72){
					def afterTruncate = createStringAfterTruncateBlank(oriRecBuf, recBuf, 72, 1, byte4WhiteSpace, i, line);
					if(true == afterTruncate){
						contentExceedMaxNum = true;
					}else{
						linesAfterTrancateArr.add(afterTruncate);
					}
				}
			}else{
				if(columNum<=71){
					linesAfterTrancateArr.add(line);
				}else if(columNum>71){
					def afterTruncate = createStringAfterTruncateBlank(oriRecBuf, recBuf, 72, 0, byte4WhiteSpace, i, line);
					if(true == afterTruncate){
						contentExceedMaxNum = true;
					}else{
						linesAfterTrancateArr.add(afterTruncate);
					}
				}
			}
		}
		
		i++
	}
	
	if(contentExceedMaxNum){
		println "Job not submitted because the content exceed 71 bytes after replacing tokens.";
		System.exit(1);
	}else{
		targetJcl = linesAfterTrancateArr.join("\n");
	}
	
	println "========================================================================================================================"
	println (targetJcl);
	
	
	return targetJcl;
}

System.exit(0);
