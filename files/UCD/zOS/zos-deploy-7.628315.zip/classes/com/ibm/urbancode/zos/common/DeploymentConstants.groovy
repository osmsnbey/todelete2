package com.ibm.urbancode.zos.common
/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */

class DeploymentConstants {
	//Constants for mapping ruler handle
	def static final MAPPING_RULER_DELIMETER = ",";
	def static final SYSTEM_LINE_SEPARATOR = System.getProperty("line.separator");
	def static final SRC_TO_TARGET_DELIMETER = "\n";
	
	//Constants for copy/ftp/deploy/rollback files or path name 
	def static final CONTAINER_MAPPER_FILE_NAME = "containerMapper.xml";
	def static final PACKAGE_FILE_NAME = "package.zip";
	def static final PACKAGE_MANIFEST_FILE_NAME = "packageManifest.xml";
	def static final ROLLBACK_MANIFEST_FILE_NAME = "rollbackManifest.xml";
	def static final DEPLOY_DELTA_FILE_NAME = "deltaDeployed.xml";
	def static final DEPLOY_BACKUP_FILE_NAME = "backup.zip";
	def static final ADDITIONAL_FOLDER_FOR_BASE_PATH = "deploy";
	
	//Constants for check access
	def static final CHECK_ACCESS_DS_FILE_NAME_BACKUP = "dataSetListFile4BackUp";
	def static final CHECK_ACCESS_DS_FILE_NAME = "dataSetListFile";
	def static final CHECK_ACCESS_DS_INPUT_LEADER = "INPUT";
	def static final CHECK_ACCESS_DS_OUTPUT_LEADER = "OUTPUT";
	
	//Constants for exec related
	def static final ZOS_TOOLKIT_EXEC_FOLDER_NAME = "bin";
	def static final ZOS_TOOLKIT_ISPF_SCRIPT_NAME = "startispf.sh";
	def static final ENTRY_ANT_SCRIPT = "deploy.xml";
	def static final ENTRY_ANT_SCRIPT_TASK_DEPLOY = "main";
	def static final ENTRY_ANT_SCRIPT_TASK_ROLLBACK = "rollbackMain";
	def static final CHECK_ACCESS_EXE = "checkaccess";

}
