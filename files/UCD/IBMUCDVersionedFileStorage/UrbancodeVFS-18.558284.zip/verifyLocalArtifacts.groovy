#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.commons.fileutils.filelister.FileType
import com.urbancode.vfs.client.Client
import com.urbancode.vfs.client.PatternPathFilter
import com.urbancode.vfs.common.ClientChangeSet
import com.urbancode.vfs.common.ClientPathEntry
import com.urbancode.vfs.common.Hash

import org.apache.log4j.Logger
import org.apache.log4j.PatternLayout
import org.apache.log4j.ConsoleAppender
import org.apache.log4j.Level;

def props = new Properties();
def inputPropsFile = new File(args[0]);
inputPropsFile.withInputStream {
    props.load(it);
}

def repositoryUrl = props['repositoryUrl']
def repositoryId = props['repositoryId']
def label = props['label']
def directoryOffset = props['directoryOffset']
def fileIncludePatterns = props['fileIncludePatterns']
def fileExcludePatterns = props['fileExcludePatterns']

def baseDirectory = new File(directoryOffset).canonicalFile

def includesArray = fileIncludePatterns?.readLines().toArray(new String[0])
def excludesArray = fileExcludePatterns?.readLines().toArray(new String[0])

def proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
def proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf(System.env['PROXY_PORT']) : null

//
// Validation
//

if (baseDirectory.isFile()) {
    throw new IllegalArgumentException("Base directory ${baseDirectory} is a file!")
}

//
// Configure logging to get rid of logging warning messages
//
Logger logger = Logger.getRootLogger();

PatternLayout layout = new PatternLayout("%m%n");
ConsoleAppender appender = new ConsoleAppender(layout);

logger.removeAllAppenders();
logger.addAppender(appender);
logger.setLevel(Level.ERROR);

//
// Download the files
//

def client = new Client(repositoryUrl, proxyHost, proxyPort)

println "Verifying files in ${baseDirectory}"
println "Including ${fileIncludePatterns}"
println "Excluding ${fileExcludePatterns}"

ClientChangeSet curChangeSet = client.getChangeSetByLabel(repositoryId, label);
ClientPathEntry[] curEntries = curChangeSet.getEntries();
def filter = new PatternPathFilter(includesArray, excludesArray)
def failureList = []
curEntries.each {
    if (filter.includes(it.path)) {
        def file = new File(baseDirectory, it.path)
        if (it.contentHash && it.contentHash.algorithm && it.type.equals(FileType.REGULAR)) {
            if (file.exists()) {
                def hash = null
                try {
                    hash = Hash.hashForFile(file, it.contentHash.algorithm)
                    if (hash && hash.equals(it.contentHash)) {
                        println "Verified file ${it.path}"
                    }
                    else {
                        failureList << "Hash check for ${it.path} failed - expected ${it.contentHash} but found $hash"
                    }
                }
                catch (Exception e) {
                    failureList << "Error calculating hash for ${it.path}: ${e.message}"
                }
            }
            else {
                failureList << "File ${it.path} not found!"
            }
        }
        else if (it.type.equals(FileType.DIRECTORY)) {
            if (file.exists() && file.isDirectory()) {
                println "Verified directory ${it.path}"
            }
            else {
                failureList << "Directory ${it.path} not found or not a directory!"
            }
        }
        else {
            failureList << "Could not determine hash algorithm for file ${it.path}: ${it.contentHash}"
        }
    }
}

if (failureList.size() > 0) {
    failureList.each {
        println it
    }
    System.exit 1
}
else {
    println "All files match!"
    System.exit 0
}
