#!/usr/bin/env groovy
/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/

import com.urbancode.vfs.client.Client
import com.urbancode.vfs.common.ClientChangeSet
import com.urbancode.vfs.common.ClientPathEntry
import com.urbancode.vfs.common.ClientPathEntryBuilder
import com.urbancode.commons.fileutils.filelister.FileListerBuilder.Directories;
import com.urbancode.commons.fileutils.filelister.FileListerBuilder.Permissions;
import com.urbancode.commons.fileutils.filelister.FileListerBuilder.Symlinks;
import com.urbancode.commons.fileutils.filelister.FileType;
import java.net.URLDecoder;
import java.nio.charset.Charset;

def workDir = new File('.').canonicalFile
def props = new Properties();
def inputPropsFile = new File(args[0]);
inputPropsFile.withInputStream {
    props.load(it);
}

def MAX_TRIES=3;
def repositoryUrl = props['repositoryUrl']
def repositoryId = props['repositoryId']
def changeUser = props['changeUser']
def changeComment = props['changeComment']
def directoryOffset = props['directoryOffset']
def fileIncludePatterns = props['fileIncludePatterns']
def fileExcludePatterns = props['fileExcludePatterns']

final File AGENT_HOME = new File(System.getenv().get("AGENT_HOME"))
final def agentInstalledProps = new File(AGENT_HOME, "conf/agent/installed.properties")
final def agentProps = new Properties();
final def agentInputStream = null;
try {
    agentInputStream = new FileInputStream(agentInstalledProps);
    agentProps.load(agentInputStream);
}
catch (IOException e) {
    throw new RuntimeException(e);
}
def systemCharset;
if (agentProps['system.default.encoding']){
    systemCharset = Charset.forName(agentProps['system.default.encoding'])
}

def extensions = props['extensions']?.split(",")
for (int i=0; i<extensions.length; i++) {
    extensions[i] = extensions[i].trim()
}

def label = props['label'];
def update = props['update'];
def saveFileExecuteBits = props['saveFileExecuteBits'] != null && Boolean.valueOf(props['saveFileExecuteBits']);

def baseDirectory = new File(directoryOffset)

def includesArray = fileIncludePatterns?.readLines().toArray(new String[0])
def excludesArray = fileExcludePatterns?.readLines().toArray(new String[0])

def proxyHost = System.env['PROXY_HOST'] ? System.env['PROXY_HOST'] : null
def proxyPort = System.env['PROXY_PORT'] ? Integer.valueOf(System.env['PROXY_PORT']) : null

def outputFilePath = props['outputFile']

def verbose = false

//
// Validation
//

if (baseDirectory.isFile()) {
    throw new IllegalArgumentException("Base directory ${baseDirectory} is a file!")
}

try {
    UUID uuid = UUID.fromString(repositoryId)
}
catch(IllegalArgumentException e) {
    println "The repository ID was not valid. Check hidden properties for this step."
    println "If you are using a property to reference the ID, it was likely not resolved."
    System.exit(1)
}

//
// Collect the files to upload
//

def directories = Directories.INCLUDE_ALL;
def symlinks = Symlinks.AS_LINK;
def hashAlgorithm = "SHA-256";

def permissions = Permissions.NONE;
if (saveFileExecuteBits) {
    permissions = Permissions.FILE_EXECUTE_ONLY;
}

def entries = new ClientPathEntryBuilder().
                baseFile(baseDirectory).
                includes(includesArray).
                excludes(excludesArray).
                directories(directories).
                permissions(permissions).
                symlinks(symlinks).
                extensions(extensions).
                charset(systemCharset).
                hashAlgorithms(hashAlgorithm).
                buildEntries() as List;

//
// Upload the files
//

def client = new Client(repositoryUrl, proxyHost, proxyPort)

String stageId = client.createStagingDirectory()
println("Created staging directory: ${stageId}")

try {
    entries.each() { entry ->
        def entryFile = new File(baseDirectory, entry.path)
        println("Adding ${entry.path} to staging directory...")
        client.addFileToStagingDirectory(stageId, entry.path, entryFile)
    }

    try {
        ClientChangeSet oldChangeSet = client.getChangeSetByLabel(repositoryId, label);
        if (update && oldChangeSet != null) {
            def oldEntries = oldChangeSet.getEntries();
            oldEntries.each { entry->
                def newEntry = entries.find {it.path == entry.path };
                if (newEntry == null) {
                    println("Adding ${entry.path} from old changeset to entries...")
                    entries.add(entry);
                }
            }
        }
    }
    catch (Exception e) {
        //swallow becuase getChangeSet throws Exception if change set does not exist
    }


    ClientChangeSet changeSet = ClientChangeSet.newChangeSet(repositoryId, changeUser, changeComment, entries as ClientPathEntry[])

    println("Committing change set...") 
    Exception finalException = null;
    String changeSetId = null;
    def done = false;
    int tries = 0;
    while (!done && tries < MAX_TRIES) {
        try {
            changeSetId = client.commitStagingDirectory(stageId, changeSet)
            done = true;
        } 
        catch (Exception e) {
            println "Error committing changeset " + e.getMessage();
            done = false;
            finalException=e;
        }
        tries++;
    }

    if (!done) {
        if (finalException != null) {
            throw finalException;
        }
        else {
            throw new Exception("Unkown error trying to commit staging Directory");
        }
    }

    println("Created change set: ${changeSetId}")

    if (label != null && label.trim() != "") {
        println("Labeling change set with label : ${label}");
        finalException = null;
        tries = 0;
        done = false;
        while (!done && tries < MAX_TRIES) {
            try { 
                client.labelChangeSet(repositoryId, URLDecoder.decode(changeSetId), label, changeUser, changeComment);
                done = true;
            }
            catch (Exception e) {
               done = false;
               println "Error Labeling ChangeSet : " +e.getMessage();
               finalException = e;
            }
            tries++;
        }

        if (!done) {
            if (finalException != null) {
                throw finalException;
            }
            else {
                throw new Exception("Unkown error trying to label ChangeSet");
            }
        }
        println ("Done labeling change set!");
    }
}
catch (Exception e) {
    println(e)
    client.deleteStagingDirectory(stageId)
    println("Deleted staging directory: ${stageId}")
    System.exit(1)
}
