package com.urbancode.air.plugin.servicenow

public class ApiSelector {

    public static boolean selectApi (def airPluginToolIn) {
        def airPluginTool = airPluginToolIn
        def props = airPluginTool.getStepProperties()

        def serviceNowReleaseName = props ['serviceNowReleaseName']

        serviceNowReleaseName = serviceNowReleaseName.toLowerCase()
        if (serviceNowReleaseName.equals('fuji') || serviceNowReleaseName.equals('eureka')) {
            println "Using REST API version one for Eureka and above."
            return true
        }
        else if (serviceNowReleaseName.equals('dublin')) {
            println "Using old Dublin REST API."
            return false
        }
        else {
            println ("This plugin does not currently support: " + serviceNowReleaseName )
            System.exit(1)
        }
    }
}

// This fails on networks which do not pass 400 errors back to the agent

//    // Checks for REST API V1 compatibility by issuing a GET resquest to serverUrl + '/api/now/v1/table/'
//    // Should only return 400 for compatilibilty or 200 otherwise. Anything else is unexpected.
//    def Boolean checkAPI() {
//        HttpGet get = new HttpGet(serverUrl + '/api/now/v1/table/')
//        def resp = client.execute(get)
//        client = clientBuilder.buildClient()
//
//        def statusCode = resp.getStatusLine().getStatusCode()
//        if (statusCode >= 400)
//        {
//            println "Using REST API version one for Eureka and above."
//            return true
//       }
//        else if (statusCode >= 200 && statusCode < 300)
//        {
//            println "Using old pre-Eureka REST API."
//            return false
//        }
//        else
//        {
//            println "Request failed with status ${statusCode}. Failed to determine proper API."
//            System.exit(1)
//        }
//    }
