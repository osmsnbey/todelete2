/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Deploy
* (c) Copyright IBM Corporation 2011, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
final def PLUGIN_HOME = System.getenv()['PLUGIN_HOME']
final def script = this.args[0]

File pluginHome = new File(PLUGIN_HOME)
File libDir = new File(pluginHome, "lib")
File scriptFile = new File(script)

libDir.eachFileMatch(~/.*\.jar/) { jar ->
    this.class.classLoader.rootLoader.addURL(jar.toURL())
}

def scriptArgs = []
scriptArgs << this.args[1]
scriptArgs << this.args[2]
println scriptFile
run(scriptFile, scriptArgs as String[])